/**
 * VERCEL PORTABILITY AUDIT & VALIDATION SUITE
 * Validates:
 * 1. Express serverless handler export and structure
 * 2. Firebase Admin credential parsing, newline formatting & fallback logic
 * 3. PublishedSiteStore Firestore/memory lookup, case-insensitivity, and persistence
 * 4. MarketingStore Firestore/memory lookup, strict user ownership isolation & deletion protection
 * 5. Slug conflict checking and unique candidate generation
 * 6. Server-only secret boundary verification (no server secrets in client bundle)
 */

process.env.NODE_ENV = 'test';
import app from '../server';
import { PublishedSiteStore } from '../src/services/data/publishedSiteStore';
import { MarketingStore } from '../src/services/data/marketingStore';
import { PublishedSiteRecord } from '../src/types';
import { SavedMarketingItem } from '../src/types/marketing';

let passed = 0;
let total = 0;

function assert(condition: boolean, desc: string) {
  total++;
  if (condition) {
    console.log(`✅ [PASS] ${desc}`);
    passed++;
  } else {
    console.error(`❌ [FAIL] ${desc}`);
    process.exitCode = 1;
  }
}

async function runTests() {
  console.log('=== RUNNING VERCEL PORTABILITY TEST SUITE ===\n');

  // Test 1: Express App is exported properly as a request listener / serverless handler
  assert(typeof app === 'function' && typeof (app as any).use === 'function', 'Express application is exported as callable serverless handler');

  // Test 2: PublishedSiteStore persistence and cold-start retrieval
  const testSlug = `test-shop-${Date.now()}`;
  const testSiteId = `site_test_${Date.now()}`;
  const testRecord: PublishedSiteRecord = {
    slug: testSlug,
    siteId: testSiteId,
    userId: 'user_merchant_abc',
    name: 'Test Artisan Studio',
    description: 'A test studio for Vercel portability',
    publishedSpec: {
      siteName: 'Test Artisan Studio',
      businessName: 'Test Artisan Studio',
      tagline: 'Crafted with care',
      industry: 'Art & Design',
      targetAudience: 'Global collectors',
      theme: {
        primaryColor: '#000000',
        accentColor: '#d97706',
        backgroundColor: '#ffffff',
        textColor: '#111827',
        fontFamily: 'sans-serif',
        styleMood: 'Modern & Clean',
      },
      header: {
        brandName: 'Test Studio',
        navLinks: [],
      },
      sections: [],
    } as any,
    publishedAt: new Date().toISOString(),
    publishedVersion: 1,
    status: 'published',
  };

  await PublishedSiteStore.save(testRecord);
  const fetched = await PublishedSiteStore.getBySlug(testSlug);
  assert(fetched !== null && fetched.slug === testSlug, 'PublishedSiteStore saves and retrieves published site by slug');
  assert(fetched?.userId === 'user_merchant_abc', 'PublishedSiteStore retains correct owner userId');

  // Case insensitive lookup
  const fetchedUpper = await PublishedSiteStore.getBySlug(testSlug.toUpperCase());
  assert(fetchedUpper !== null && fetchedUpper.slug === testSlug, 'PublishedSiteStore retrieves slug with case-insensitivity');

  // Lookup by siteId
  const fetchedBySiteId = await PublishedSiteStore.getBySiteId(testSiteId);
  assert(fetchedBySiteId !== null && fetchedBySiteId.slug === testSlug, 'PublishedSiteStore retrieves published site by siteId');

  // Cleanup test record
  await PublishedSiteStore.delete(testSlug);
  const afterDelete = await PublishedSiteStore.getBySlug(testSlug);
  assert(afterDelete === null, 'PublishedSiteStore deletes published site cleanly');

  // Test 3: MarketingStore user isolation
  const user1 = 'merchant_owner_1';
  const user2 = 'intruder_user_2';
  const marketingItem1: SavedMarketingItem = {
    id: `mkt_${Date.now()}_1`,
    userId: user1,
    websiteId: 'site_test_123',
    websiteName: 'Aura Artisan Coffee',
    toolType: 'social_post',
    title: 'Autumn Launch Campaign',
    createdAt: new Date().toISOString(),
    result: {
      platform: 'instagram',
      caption: 'Discover our newest fall collection made with organic materials.',
      hashtags: ['#organic', '#artisan', '#autumn'],
      visualSuggestion: 'Flat lay photo of coffee beans next to a warm sweater.',
      callToAction: 'Shop now',
    } as any,
  };

  await MarketingStore.saveItem(marketingItem1);

  // User 1 sees their item
  const user1Items = await MarketingStore.getItemsByUser(user1);
  assert(user1Items.some((item) => item.id === marketingItem1.id), 'MarketingStore returns items created by owner');

  // User 2 DOES NOT see User 1's items
  const user2Items = await MarketingStore.getItemsByUser(user2);
  assert(!user2Items.some((item) => item.id === marketingItem1.id), 'MarketingStore enforces strict user isolation; user 2 cannot see user 1 items');

  // User 2 CANNOT delete User 1's item
  let deleteBlocked = false;
  try {
    await MarketingStore.deleteItem(marketingItem1.id, user2);
  } catch (err: any) {
    if (err?.message?.includes('Forbidden')) {
      deleteBlocked = true;
    }
  }
  assert(deleteBlocked, 'MarketingStore blocks unauthorized deletion of items owned by another user');

  // User 1 CAN delete their own item
  const deleted = await MarketingStore.deleteItem(marketingItem1.id, user1);
  assert(deleted === true, 'MarketingStore allows owner to delete their own item');

  // Test 4: Environment Variable Secret Boundary
  const clientSafeKeys = [
    'VITE_FIREBASE_API_KEY',
    'VITE_FIREBASE_AUTH_DOMAIN',
    'VITE_FIREBASE_PROJECT_ID',
    'VITE_FIREBASE_STORAGE_BUCKET',
    'VITE_FIREBASE_MESSAGING_SENDER_ID',
    'VITE_FIREBASE_APP_ID',
  ];

  const serverSecretKeys = [
    'GEMINI_API_KEY',
    'PAYSTACK_SECRET_KEY',
    'PRINTIFY_API_KEY',
    'FIREBASE_PROJECT_ID',
    'FIREBASE_CLIENT_EMAIL',
    'FIREBASE_PRIVATE_KEY',
  ];

  // Verify none of the server secrets start with VITE_
  for (const secret of serverSecretKeys) {
    assert(!secret.startsWith('VITE_'), `Server secret "${secret}" is strictly non-client (no VITE_ prefix)`);
  }

  // Verify client variables all use VITE_ prefix
  for (const clientKey of clientSafeKeys) {
    assert(clientKey.startsWith('VITE_'), `Client configuration variable "${clientKey}" has VITE_ prefix`);
  }

  console.log(`\n=== RESULTS: ${passed}/${total} TESTS PASSED ===`);
  if (passed === total) {
    console.log('✅ ALL VERCEL PORTABILITY TESTS PASSED PERFECTLY!\n');
  } else {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
