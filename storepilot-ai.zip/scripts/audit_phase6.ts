import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

interface AuditResult {
  name: string;
  category: string;
  passed: boolean;
  details: string;
}

const results: AuditResult[] = [];

function record(category: string, name: string, passed: boolean, details: string) {
  results.push({ category, name, passed, details });
  const mark = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${mark} [${category}] ${name}: ${details}`);
}

async function request(options: {
  path: string;
  method?: string;
  headers?: Record<string, string>;
  body?: any;
}): Promise<{ status: number; headers: any; body: any; raw: string }> {
  return new Promise((resolve, reject) => {
    const payload = options.body ? JSON.stringify(options.body) : null;
    const reqHeaders: Record<string, string> = {
      ...(options.headers || {}),
    };
    if (payload) {
      reqHeaders['Content-Type'] = 'application/json';
      reqHeaders['Content-Length'] = Buffer.byteLength(payload).toString();
    }

    const req = http.request(
      {
        hostname: 'localhost',
        port: 3000,
        path: options.path,
        method: options.method || 'GET',
        headers: reqHeaders,
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          let parsed: any = null;
          try {
            parsed = JSON.parse(data);
          } catch {
            parsed = data;
          }
          resolve({
            status: res.statusCode || 500,
            headers: res.headers,
            body: parsed,
            raw: data,
          });
        });
      }
    );

    req.on('error', (err) => reject(err));
    if (payload) req.write(payload);
    req.end();
  });
}

async function runAudit() {
  console.log('\n======================================================');
  console.log('PHASE 6 — PRODUCTION PAYMENT & ORDER SECURITY AUDIT');
  console.log('======================================================\n');

  // 1. Paystack Secret Key Leak Check
  const clientBundleDir = path.join(process.cwd(), 'src');
  const files = fs.readdirSync(clientBundleDir, { recursive: true }) as string[];
  let secretKeyFoundInClient = false;
  let leakedFile = '';

  for (const f of files) {
    const fullPath = path.join(clientBundleDir, f);
    if (fs.statSync(fullPath).isFile() && (f.endsWith('.ts') || f.endsWith('.tsx') || f.endsWith('.js'))) {
      const content = fs.readFileSync(fullPath, 'utf-8');
      if (content.includes('sk_live_') || content.includes('sk_test_') || content.includes('PAYSTACK_SECRET_KEY =')) {
        secretKeyFoundInClient = true;
        leakedFile = f;
        break;
      }
    }
  }

  record(
    'PAYSTACK SECURITY',
    'Secret Key Isolation',
    !secretKeyFoundInClient,
    secretKeyFoundInClient
      ? `Found hardcoded secret key in ${leakedFile}`
      : 'No Paystack secret keys exposed in client source code or environment'
  );

  // 2. Price Manipulation Test (Malicious price override)
  const maliciousCheckout = await request({
    path: '/api/checkout/initialize',
    method: 'POST',
    body: {
      slug: 'kontrol-accra',
      customer: {
        fullName: 'Security Auditor',
        email: 'auditor@test.com',
        phone: '+233201234567',
        address: '123 Ridge Road',
        city: 'Accra',
      },
      items: [
        {
          productId: 'p-1', // Classic Accra Hoodie, authoritative price: 450.00
          quantity: 2,
          price: '0.01', // Attempted manipulation: $0.01 instead of 450.00
          total: '0.02',
        },
      ],
    },
  });

  const orderId = maliciousCheckout.body?.orderId;
  const orderRef = maliciousCheckout.body?.orderReference;
  const calculatedAmount = maliciousCheckout.body?.amount;

  const priceProtected = calculatedAmount === 900;
  record(
    'PRICE SECURITY',
    'Malicious Price Override Ignored',
    priceProtected,
    `Client attempted 0.01 price. Server calculated authoritative total: GH₵${calculatedAmount} (Expected GH₵900.00)`
  );

  // 3. Invalid Product ID Rejection
  const invalidProductRes = await request({
    path: '/api/checkout/initialize',
    method: 'POST',
    body: {
      slug: 'kontrol-accra',
      customer: {
        fullName: 'Hacker Test',
        email: 'hacker@test.com',
        phone: '123456789',
        address: 'Nowhere',
        city: 'Accra',
      },
      items: [{ productId: 'hacked_fake_sku_999', quantity: 1 }],
    },
  });

  record(
    'PRICE SECURITY',
    'Non-Existent SKU Rejected',
    invalidProductRes.status === 400,
    `Server responded with ${invalidProductRes.status}: "${invalidProductRes.body?.error}"`
  );

  // 4. Invalid Quantity Rejection
  const invalidQtyRes = await request({
    path: '/api/checkout/initialize',
    method: 'POST',
    body: {
      slug: 'kontrol-accra',
      customer: {
        fullName: 'Hacker Test',
        email: 'hacker@test.com',
        phone: '123456789',
        address: 'Nowhere',
        city: 'Accra',
      },
      items: [{ productId: 'p-1', quantity: -10 }],
    },
  });

  record(
    'PRICE SECURITY',
    'Negative/Invalid Quantity Rejected',
    invalidQtyRes.status === 400,
    `Server rejected with ${invalidQtyRes.status}: "${invalidQtyRes.body?.error}"`
  );

  // 5. Empty Cart Rejection
  const emptyCartRes = await request({
    path: '/api/checkout/initialize',
    method: 'POST',
    body: {
      slug: 'kontrol-accra',
      customer: {
        fullName: 'Hacker Test',
        email: 'hacker@test.com',
        phone: '123456789',
        address: 'Nowhere',
        city: 'Accra',
      },
      items: [],
    },
  });

  record(
    'CHECKOUT SECURITY',
    'Empty Cart Rejected',
    emptyCartRes.status === 400,
    `Server responded with ${emptyCartRes.status}: "${emptyCartRes.body?.error}"`
  );

  // 6. Payment Verification Server-Side Check
  const fakeVerifyRes = await request({
    path: '/api/checkout/verify/sp_fake_unverified_ref_123',
    method: 'GET',
  });

  record(
    'PAYMENT VERIFICATION',
    'Fake Reference Cannot Mark Order PAID',
    fakeVerifyRes.body?.paymentStatus !== 'PAID' && !fakeVerifyRes.body?.success,
    `Verify result: success=${fakeVerifyRes.body?.success}, status=${fakeVerifyRes.body?.paymentStatus}`
  );

  // 7. Webhook Security: Unsigned Webhook Rejected
  const unsignedWebhookRes = await request({
    path: '/api/checkout/webhook',
    method: 'POST',
    body: { event: 'charge.success', data: { reference: orderRef } },
  });

  record(
    'WEBHOOK SECURITY',
    'Unsigned Webhook Rejected (401)',
    unsignedWebhookRes.status === 401,
    `Server responded with status ${unsignedWebhookRes.status}`
  );

  // 7b. Webhook HMAC SHA-512 Signature Validation Function Test
  const testSecret = 'sk_test_secret_for_audit_validation_987654';
  const oldKey = process.env.PAYSTACK_SECRET_KEY;
  process.env.PAYSTACK_SECRET_KEY = testSecret;

  const samplePayload = JSON.stringify({
    event: 'charge.success',
    data: { reference: orderRef, amount: 90000, currency: 'GHS' },
  });
  const validHmac = crypto.createHmac('sha512', testSecret).update(samplePayload).digest('hex');

  const { CheckoutService } = await import('../src/services/checkout/checkoutService');
  const validSigAccepted = CheckoutService.verifyWebhookSignature(samplePayload, validHmac);
  const forgedSigRejected = !CheckoutService.verifyWebhookSignature(samplePayload, 'forged_fake_signature_hash');

  record(
    'WEBHOOK SECURITY',
    'HMAC SHA-512 Signature Verification',
    validSigAccepted && forgedSigRejected,
    `Valid signature accepted: ${validSigAccepted}, forged signature rejected: ${forgedSigRejected}`
  );

  process.env.PAYSTACK_SECRET_KEY = oldKey;

  // 8. Order Persistence Check
  const diskOrdersPath = path.join(process.cwd(), 'data', 'orders.json');
  let orderPersistedOnDisk = false;
  if (fs.existsSync(diskOrdersPath)) {
    const rawDisk = fs.readFileSync(diskOrdersPath, 'utf-8');
    orderPersistedOnDisk = rawDisk.includes(orderRef);
  }

  record(
    'ORDER PERSISTENCE',
    'Durable File-Backed Order Storage',
    orderPersistedOnDisk,
    `Order ${orderRef} was found written to /data/orders.json`
  );

  // 9. Merchant Isolation Check
  // The owner of kontrol-accra is dev_user_1hs97cb
  const legitOwnerRes = await request({
    path: `/api/orders/${orderId}`,
    method: 'GET',
    headers: { 'x-user-id': 'dev_user_1hs97cb' },
  });

  const hackerRes = await request({
    path: `/api/orders/${orderId}`,
    method: 'GET',
    headers: { 'x-user-id': 'unauthorized_attacker_id' },
  });

  record(
    'MERCHANT ISOLATION',
    'Legitimate Owner Access Granted',
    legitOwnerRes.status === 200 && legitOwnerRes.body?.order?.id === orderId,
    `Owner accessed order with status ${legitOwnerRes.status}`
  );

  record(
    'MERCHANT ISOLATION',
    'Unauthorized Merchant Access Denied (403)',
    hackerRes.status === 403,
    `Attacker received status ${hackerRes.status}: "${hackerRes.body?.error}"`
  );

  // 10. Status Tampering Protection: Attacker cannot change order fulfillment
  const tamperStatusRes = await request({
    path: `/api/orders/${orderId}/status`,
    method: 'PATCH',
    headers: { 'x-user-id': 'unauthorized_attacker_id' },
    body: { orderStatus: 'COMPLETED' },
  });

  record(
    'MERCHANT ISOLATION',
    'Status Tampering by Non-Owner Blocked (403)',
    tamperStatusRes.status === 403,
    `Attacker received status ${tamperStatusRes.status}: "${tamperStatusRes.body?.error}"`
  );

  // 11. Legitimate Owner Fulfillment Status Update
  const legitimateStatusRes = await request({
    path: `/api/orders/${orderId}/status`,
    method: 'PATCH',
    headers: { 'x-user-id': 'dev_user_1hs97cb' },
    body: { orderStatus: 'PROCESSING' },
  });

  record(
    'ORDER MANAGEMENT',
    'Owner Fulfillment Status Update',
    legitimateStatusRes.status === 200 && legitimateStatusRes.body?.order?.orderStatus === 'PROCESSING',
    `Order fulfillment updated to: ${legitimateStatusRes.body?.order?.orderStatus}`
  );

  // 12. Public Storefront Compatibility
  const siteHtml = await request({
    path: '/site/kontrol-accra',
    method: 'GET',
  });

  record(
    'PUBLIC STORE COMPATIBILITY',
    'Storefront /site/:slug Accessible',
    siteHtml.status === 200 && siteHtml.raw.includes('StorePilot'),
    `HTTP ${siteHtml.status} OK returned for /site/kontrol-accra`
  );

  // 13. Paystack Test Credentials Check
  const paystackKey = process.env.PAYSTACK_SECRET_KEY;
  const hasRealPaystack = Boolean(
    paystackKey &&
      paystackKey.startsWith('sk_') &&
      paystackKey !== 'sk_test_...' &&
      paystackKey.length > 20
  );

  console.log('\n------------------------------------------------------');
  if (hasRealPaystack) {
    console.log('PAYSTACK TEST CREDENTIALS CONFIGURED — READY FOR LIVE TRANSACTION TEST');
  } else {
    console.log('PAYMENT ARCHITECTURE IMPLEMENTED — REAL PAYSTACK PAYMENT NOT VERIFIED');
  }
  console.log('------------------------------------------------------\n');

  const allPassed = results.every((r) => r.passed);
  console.log(`Audit Finished: ${results.filter((r) => r.passed).length}/${results.length} checks passed.\n`);

  if (!allPassed) {
    process.exit(1);
  }
}

runAudit().catch((err) => {
  console.error('Audit run failed with exception:', err);
  process.exit(1);
});
