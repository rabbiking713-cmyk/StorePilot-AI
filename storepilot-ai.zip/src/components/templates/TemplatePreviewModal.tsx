import React, { useState, useEffect } from 'react';
import {
  X,
  Monitor,
  Tablet,
  Smartphone,
  Maximize2,
  Minimize2,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { Template } from '../../types';
import { WebsiteRenderer } from '../preview/WebsiteRenderer';
import { DevicePreviewFrame, ViewportMode } from '../preview/DevicePreviewFrame';
import { Button } from '../ui/Button';

interface TemplatePreviewModalProps {
  template: Template;
  isOpen: boolean;
  onClose: () => void;
  onUseTemplate: (template: Template) => void;
}

export const TemplatePreviewModal: React.FC<TemplatePreviewModalProps> = ({
  template,
  isOpen,
  onClose,
  onUseTemplate,
}) => {
  const [viewport, setViewport] = useState<ViewportMode>('desktop');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Keyboard shortcut listener (Escape to exit fullscreen / close)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isFullscreen) {
          setIsFullscreen(false);
        } else {
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isFullscreen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col bg-slate-950/85 backdrop-blur-md transition-all duration-200 ${
        isFullscreen ? 'p-0' : 'p-2 sm:p-4 md:p-6'
      }`}
    >
      <div
        className={`flex-1 flex flex-col bg-slate-900 overflow-hidden border border-slate-800 shadow-2xl transition-all ${
          isFullscreen ? 'rounded-none border-none' : 'rounded-2xl'
        }`}
      >
        {/* Top bar controls */}
        <header className="h-16 px-4 sm:px-6 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0 text-white select-none">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-400/30 text-indigo-400 flex items-center justify-center font-bold text-xs shrink-0">
              SP
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white truncate">
                  {template.name}
                </h3>
                <span className="text-xs text-slate-400 hidden sm:inline">
                  · {template.category}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate hidden md:block">
                {template.styleMood} · {template.spec.sections.length} tailored sections
              </p>
            </div>
          </div>

          {/* Viewport switcher */}
          <div className="flex items-center bg-slate-800/90 p-1 rounded-lg border border-slate-700/60 text-xs">
            <button
              onClick={() => setViewport('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewport === 'desktop'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Desktop View (1440px viewport)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Desktop</span>
            </button>
            <button
              onClick={() => setViewport('tablet')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewport === 'tablet'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Tablet View (768px viewport)"
            >
              <Tablet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Tablet</span>
              <span className="text-[10px] text-slate-400 hidden md:inline">(768px)</span>
            </button>
            <button
              onClick={() => setViewport('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewport === 'mobile'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Mobile View (390px viewport)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mobile</span>
              <span className="text-[10px] text-slate-400 hidden md:inline">(390px)</span>
            </button>
          </div>

          {/* Right action group */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer hidden sm:flex items-center gap-1.5 text-xs"
              title={isFullscreen ? 'Exit Fullscreen (Esc)' : 'Fullscreen'}
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="w-4 h-4" />
                  <span className="hidden lg:inline">Exit Fullscreen</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-4 h-4" />
                  <span className="hidden lg:inline">Fullscreen</span>
                </>
              )}
            </button>

            <Button
              variant="primary"
              size="sm"
              onClick={() => onUseTemplate(template)}
              icon={<Sparkles className="w-3.5 h-3.5" />}
              className="text-xs"
            >
              Use This Template
            </Button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Close Preview (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Live Preview Canvas with Realistic Device Frame */}
        <div className="flex-1 overflow-y-auto bg-slate-950 p-3 sm:p-6 md:p-8 flex justify-center items-start">
          <DevicePreviewFrame
            viewport={viewport}
            siteName={template.spec.siteName || template.name}
          >
            <WebsiteRenderer
              spec={template.spec}
              viewport={viewport}
              isInteractive={true}
              isEditorMode={false}
            />
          </DevicePreviewFrame>
        </div>

        {/* Bottom bar summary */}
        <footer className="h-12 px-6 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-4">
            <span>Palette: {template.spec.theme.styleMood}</span>
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">Typography: {template.spec.theme.fontFamily}</span>
            <span className="hidden md:inline">·</span>
            <span className="hidden md:inline">Active Viewport: {viewport.toUpperCase()}</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-400 hidden sm:inline">Ready for instant customization</span>
            <button
              onClick={() => onUseTemplate(template)}
              className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              Customize in Visual Editor <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};
