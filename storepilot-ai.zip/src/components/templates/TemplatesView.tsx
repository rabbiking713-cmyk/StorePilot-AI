import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  Eye,
  ArrowRight,
  Palette,
  CheckCircle2,
  Layers,
  ArrowUpRight,
  Filter,
} from 'lucide-react';
import { Template, TemplateCategory, Website } from '../../types';
import { TEMPLATES, TEMPLATE_CATEGORIES } from '../../data/templates';
import { useWebsites } from '../../context/WebsitesContext';
import { Button } from '../ui/Button';
import { TemplatePreviewModal } from './TemplatePreviewModal';
import { VisualWebsiteEditor } from '../editor/VisualWebsiteEditor';

interface TemplatesViewProps {
  onOpenEditor?: (website: Website) => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({ onOpenEditor }) => {
  const { createFromTemplate } = useWebsites();
  const [selectedCategory, setSelectedCategory] = useState<TemplateCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyFeatured, setOnlyFeatured] = useState(false);
  const [previewingTemplate, setPreviewingTemplate] = useState<Template | null>(null);
  const [editingWebsite, setEditingWebsite] = useState<Website | null>(null);
  const [creatingTemplateId, setCreatingTemplateId] = useState<string | null>(null);

  // Compute category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: TEMPLATES.length };
    TEMPLATES.forEach((tmpl) => {
      counts[tmpl.category] = (counts[tmpl.category] || 0) + 1;
    });
    return counts;
  }, []);

  // Filter templates
  const filteredTemplates = useMemo(() => {
    return TEMPLATES.filter((tmpl) => {
      // Category match
      if (selectedCategory !== 'All' && tmpl.category !== selectedCategory) {
        return false;
      }
      // Featured match
      if (onlyFeatured && !tmpl.featured) {
        return false;
      }
      // Search query match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const inName = tmpl.name.toLowerCase().includes(query);
        const inDesc = tmpl.description.toLowerCase().includes(query);
        const inCategory = tmpl.category.toLowerCase().includes(query);
        const inTags = tmpl.tags.some((t) => t.toLowerCase().includes(query));
        const inMood = tmpl.styleMood.toLowerCase().includes(query);
        if (!inName && !inDesc && !inCategory && !inTags && !inMood) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCategory, onlyFeatured, searchQuery]);

  const handleUseTemplate = (template: Template) => {
    setCreatingTemplateId(template.id);
    try {
      const newWebsite = createFromTemplate(template);
      setPreviewingTemplate(null);
      if (onOpenEditor) {
        onOpenEditor(newWebsite);
      } else {
        setEditingWebsite(newWebsite);
      }
    } catch (err) {
      console.error('Failed to create website from template:', err);
    } finally {
      setCreatingTemplateId(null);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 md:p-10 shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold tracking-wider uppercase">
            <Palette className="w-4 h-4" />
            <span>StorePilot Curated Library · Phase 3</span>
          </div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
            Professional Website Templates
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Start from an intentionally crafted foundation designed with semantic typography, responsive layouts, and matching color theory. Preview any template on mobile, tablet, or desktop, then customize every detail inside the Visual Editor.
          </p>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search templates by industry, keyword, or mood..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 font-bold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Featured Toggle & Results Summary */}
          <div className="flex items-center gap-3 self-end md:self-auto text-xs text-slate-600">
            <button
              onClick={() => setOnlyFeatured(!onlyFeatured)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                onlyFeatured
                  ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-2xs'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Sparkles className={`w-3.5 h-3.5 ${onlyFeatured ? 'text-amber-600' : 'text-slate-400'}`} />
              <span>Featured Only</span>
            </button>
            <span className="text-slate-400 hidden sm:inline">·</span>
            <span className="font-mono text-[11px] text-slate-500">
              {filteredTemplates.length} {filteredTemplates.length === 1 ? 'template' : 'templates'}
            </span>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs">
          {TEMPLATE_CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat.id;
            const count = categoryCounts[cat.id] || 0;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                    isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Templates Grid */}
      {filteredTemplates.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-lg mx-auto space-y-4 shadow-2xs">
          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Filter className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">No matching templates found</h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              We couldn’t find any templates matching your search criteria. Try clearing the filter or searching for another keyword.
            </p>
          </div>
          <div className="pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setOnlyFeatured(false);
              }}
            >
              Reset Filters
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <div
              key={template.id}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Thumbnail Preview Area */}
                <div className="relative aspect-16/10 bg-slate-100 overflow-hidden cursor-pointer" onClick={() => setPreviewingTemplate(template)}>
                  <img
                    src={template.thumbnailUrl}
                    alt={template.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 backdrop-blur-2xs">
                    <span className="px-3 py-1.5 bg-white text-slate-900 font-semibold text-xs rounded-lg shadow-md flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                      <Eye className="w-3.5 h-3.5" /> Quick Preview
                    </span>
                  </div>

                  {template.featured && (
                    <div className="absolute top-3 left-3 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Featured
                    </div>
                  )}

                  <div className="absolute bottom-2 right-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-mono px-2 py-0.5 rounded">
                    {template.spec.sections.length} Sections
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 space-y-3">
                  {/* Clean unboxed metadata kicker */}
                  <div className="text-xs text-slate-500 flex items-center gap-2">
                    <span className="font-semibold text-slate-700">{template.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{template.styleMood}</span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {template.name}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                    {template.description}
                  </p>

                  {/* Clean tags with dot separator */}
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400 pt-1">
                    {template.tags.map((tag, idx) => (
                      <React.Fragment key={tag}>
                        <span>#{tag}</span>
                        {idx < template.tags.length - 1 && <span aria-hidden="true">·</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Actions */}
              <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPreviewingTemplate(template)}
                  icon={<Eye className="w-3.5 h-3.5" />}
                  className="text-xs"
                >
                  Preview
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => handleUseTemplate(template)}
                  disabled={creatingTemplateId === template.id}
                  icon={<ArrowRight className="w-3.5 h-3.5" />}
                  className="text-xs"
                >
                  {creatingTemplateId === template.id ? 'Creating...' : 'Use Template'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Template Fullscreen Preview Modal */}
      {previewingTemplate && (
        <TemplatePreviewModal
          template={previewingTemplate}
          isOpen={!!previewingTemplate}
          onClose={() => setPreviewingTemplate(null)}
          onUseTemplate={handleUseTemplate}
        />
      )}

      {/* Visual Website Editor when template is selected directly */}
      {editingWebsite && (
        <VisualWebsiteEditor
          website={editingWebsite}
          onClose={() => setEditingWebsite(null)}
          onSaved={() => setEditingWebsite(null)}
        />
      )}
    </div>
  );
};
