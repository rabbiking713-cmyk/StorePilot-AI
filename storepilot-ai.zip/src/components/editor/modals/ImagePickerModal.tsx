import React, { useState } from 'react';
import { X, Check, Image as ImageIcon, Link as LinkIcon, Sparkles } from 'lucide-react';
import { CURATED_IMAGE_LIBRARY } from '../../../config/editorPresets';
import { Button } from '../../ui/Button';

interface ImagePickerModalProps {
  isOpen: boolean;
  currentImageUrl?: string;
  title?: string;
  onClose: () => void;
  onSelectImage: (newUrl: string) => void;
}

export const ImagePickerModal: React.FC<ImagePickerModalProps> = ({
  isOpen,
  currentImageUrl = '',
  title = 'Replace Image',
  onClose,
  onSelectImage,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('fashion');
  const [customUrl, setCustomUrl] = useState<string>(currentImageUrl);
  const [previewUrl, setPreviewUrl] = useState<string>(currentImageUrl);
  const [activeTab, setActiveTab] = useState<'library' | 'url'>('library');
  const [urlError, setUrlError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleApply = () => {
    const finalUrl = activeTab === 'url' ? customUrl.trim() : previewUrl.trim();
    if (!finalUrl) {
      setUrlError('Please provide or select an image.');
      return;
    }

    // Safety check for URL protocol
    if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://') && !finalUrl.startsWith('data:image/')) {
      setUrlError('Image URL must start with https:// or http://');
      return;
    }

    onSelectImage(finalUrl);
    onClose();
  };

  const handleSelectPreset = (url: string) => {
    setPreviewUrl(url);
    setCustomUrl(url);
    setUrlError(null);
  };

  const activeCategoryData = CURATED_IMAGE_LIBRARY.find((c) => c.id === selectedCategory) || CURATED_IMAGE_LIBRARY[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{title}</h3>
              <p className="text-[11px] text-slate-500">
                Choose from royalty-free photography or provide a direct web image URL.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher: Curated Library vs Custom URL */}
        <div className="px-6 pt-3 pb-2 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'library'
                ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curated Photo Library</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('url')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'url'
                ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5" />
            <span>Direct Image URL</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'library' ? (
            <div className="space-y-4">
              {/* Category buttons */}
              <div className="flex flex-wrap gap-1.5">
                {CURATED_IMAGE_LIBRARY.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Photo grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {activeCategoryData.images.map((img, idx) => {
                  const isSelected = previewUrl === img.url;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectPreset(img.url)}
                      className={`group relative rounded-xl overflow-hidden aspect-4/3 border-2 transition-all text-left cursor-pointer ${
                        isSelected
                          ? 'border-indigo-600 ring-2 ring-indigo-200'
                          : 'border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <img
                        src={img.thumbnail}
                        alt={img.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent p-2 flex flex-col justify-end">
                        <span className="text-[11px] font-medium text-white line-clamp-1">
                          {img.title}
                        </span>
                      </div>
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-md">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Web Image URL
                </label>
                <div className="relative">
                  <input
                    type="url"
                    value={customUrl}
                    onChange={(e) => {
                      setCustomUrl(e.target.value);
                      setPreviewUrl(e.target.value);
                      setUrlError(null);
                    }}
                    placeholder="https://images.unsplash.com/... or https://..."
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 font-mono"
                  />
                </div>
                {urlError && <p className="text-xs text-rose-600 mt-1">{urlError}</p>}
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Supports HTTPS image links from Unsplash, Shopify CDN, Cloudinary, AWS S3, or any public web hosting.
                </p>
              </div>

              {/* Preview */}
              {previewUrl && (
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 uppercase">Image Preview:</span>
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 aspect-16/9 bg-slate-100 max-h-48 flex items-center justify-center">
                    <img
                      src={previewUrl}
                      alt="URL preview"
                      className="w-full h-full object-cover"
                      onError={() => {
                        setUrlError('Unable to load image from this URL. Please verify the link is accessible.');
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500 truncate max-w-xs">
            {previewUrl ? 'Selected image ready to apply' : 'No image selected'}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={onClose} className="text-xs">
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleApply}
              disabled={!previewUrl}
              className="text-xs"
            >
              Apply Image
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
