import React, { useState, useEffect } from 'react';
import { X, Monitor, Tablet, Smartphone } from 'lucide-react';
import { WebsiteSpec } from '../../../types/websiteSpec';
import { WebsiteRenderer } from '../../preview/WebsiteRenderer';
import { DevicePreviewFrame, ViewportMode } from '../../preview/DevicePreviewFrame';

interface ExpandedPreviewModalProps {
  isOpen: boolean;
  spec: WebsiteSpec;
  onClose: () => void;
}

export const ExpandedPreviewModal: React.FC<ExpandedPreviewModalProps> = ({
  isOpen,
  spec,
  onClose,
}) => {
  const [viewport, setViewport] = useState<ViewportMode>('desktop');

  // Keyboard shortcut listener (Escape to exit fullscreen)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col animate-in fade-in duration-200">
      {/* Top control bar */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 px-4 sm:px-6 flex items-center justify-between shrink-0 text-white select-none">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold tracking-tight text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Full-Screen Live Preview: {spec.siteName}
          </span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            Interactive device preview
          </span>
        </div>

        {/* Viewport controls */}
        <div className="flex items-center bg-slate-800 p-1 rounded-lg border border-slate-700 text-xs">
          <button
            onClick={() => setViewport('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-colors cursor-pointer ${
              viewport === 'desktop'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Desktop</span>
          </button>
          <button
            onClick={() => setViewport('tablet')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-colors cursor-pointer ${
              viewport === 'tablet'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Tablet (768px)</span>
          </button>
          <button
            onClick={() => setViewport('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-colors cursor-pointer ${
              viewport === 'mobile'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Mobile (390px)</span>
          </button>
        </div>

        {/* Exit Preview */}
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Exit Fullscreen (Esc)"
          >
            <X className="w-4 h-4" />
            <span>Exit Fullscreen</span>
          </button>
        </div>
      </header>

      {/* Main Preview Frame */}
      <div className="flex-1 overflow-y-auto bg-slate-950 p-3 sm:p-6 md:p-8 flex justify-center items-start">
        <DevicePreviewFrame
          viewport={viewport}
          siteName={spec.siteName}
        >
          <WebsiteRenderer
            spec={spec}
            viewport={viewport}
            isInteractive={true}
            isEditorMode={false}
          />
        </DevicePreviewFrame>
      </div>
    </div>
  );
};
