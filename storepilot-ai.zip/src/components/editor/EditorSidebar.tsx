import React, { useState } from 'react';
import {
  Layers,
  Palette,
  FileText,
  Sparkles,
  Settings,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import {
  WebsiteSpec,
  WebsiteSection,
  WebsiteTheme,
  HeaderConfig,
  FooterConfig,
} from '../../types/websiteSpec';
import { SectionsListPanel } from './panels/SectionsListPanel';
import { SectionDetailEditor } from './panels/SectionDetailEditor';
import { ThemeEditorPanel } from './panels/ThemeEditorPanel';
import { ContentEditorPanel } from './panels/ContentEditorPanel';
import { AiRefinePanel } from './panels/AiRefinePanel';

export type EditorTab = 'sections' | 'theme' | 'content' | 'ai_refine';

interface EditorSidebarProps {
  spec: WebsiteSpec;
  activeTab: EditorTab;
  selectedSectionId: string | null;
  onSelectTab: (tab: EditorTab) => void;
  onSelectSection: (sectionId: string | null) => void;
  onUpdateSections: (newSections: WebsiteSection[]) => void;
  onUpdateSection: (sectionId: string, updatedSection: WebsiteSection) => void;
  onUpdateTheme: (newTheme: WebsiteTheme) => void;
  onUpdateSpec: (updated: Partial<WebsiteSpec>) => void;
  onUpdateHeader: (updatedHeader: HeaderConfig) => void;
  onUpdateFooter: (updatedFooter: FooterConfig) => void;
  onApplyRefinedSpec: (newSpec: WebsiteSpec) => void;
}

export const EditorSidebar: React.FC<EditorSidebarProps> = ({
  spec,
  activeTab,
  selectedSectionId,
  onSelectTab,
  onSelectSection,
  onUpdateSections,
  onUpdateSection,
  onUpdateTheme,
  onUpdateSpec,
  onUpdateHeader,
  onUpdateFooter,
  onApplyRefinedSpec,
}) => {
  return (
    <aside className="w-80 sm:w-96 bg-white border-r border-slate-200 flex flex-col shrink-0 h-[calc(100vh-3.5rem)] z-20">
      {/* Tab Navigation Rail */}
      <div className="grid grid-cols-4 border-b border-slate-200 bg-slate-50/70 p-1.5 gap-1 shrink-0">
        <button
          type="button"
          onClick={() => {
            onSelectTab('sections');
          }}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
            activeTab === 'sections'
              ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4 mb-1" />
          <span>Sections</span>
        </button>

        <button
          type="button"
          onClick={() => {
            onSelectTab('theme');
          }}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
            activeTab === 'theme'
              ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Palette className="w-4 h-4 mb-1" />
          <span>Design</span>
        </button>

        <button
          type="button"
          onClick={() => {
            onSelectTab('content');
          }}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
            activeTab === 'content'
              ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4 mb-1" />
          <span>Branding</span>
        </button>

        <button
          type="button"
          onClick={() => {
            onSelectTab('ai_refine');
          }}
          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl text-[11px] font-semibold transition-all cursor-pointer ${
            activeTab === 'ai_refine'
              ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4 mb-1" />
          <span>AI Refine</span>
        </button>
      </div>

      {/* Main Panel Content Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5">
        {activeTab === 'sections' && (
          <>
            {selectedSectionId ? (
              <SectionDetailEditor
                spec={spec}
                selectedSectionId={selectedSectionId}
                onBack={() => onSelectSection(null)}
                onUpdateSection={onUpdateSection}
                onUpdateHeader={onUpdateHeader}
                onUpdateFooter={onUpdateFooter}
              />
            ) : (
              <SectionsListPanel
                spec={spec}
                selectedSectionId={selectedSectionId}
                onSelectSection={onSelectSection}
                onUpdateSections={onUpdateSections}
              />
            )}
          </>
        )}

        {activeTab === 'theme' && (
          <ThemeEditorPanel spec={spec} onUpdateTheme={onUpdateTheme} />
        )}

        {activeTab === 'content' && (
          <ContentEditorPanel spec={spec} onUpdateSpec={onUpdateSpec} />
        )}

        {activeTab === 'ai_refine' && (
          <AiRefinePanel
            spec={spec}
            onApplyRefinedSpec={onApplyRefinedSpec}
          />
        )}
      </div>
    </aside>
  );
};
