import React, { useState, useEffect, useCallback } from 'react';
import { Website } from '../../types';
import {
  WebsiteSpec,
  WebsiteSection,
  WebsiteTheme,
  HeaderConfig,
  FooterConfig,
} from '../../types/websiteSpec';
import { useEditorHistory } from '../../hooks/useEditorHistory';
import { useWebsites } from '../../context/WebsitesContext';
import { EditorTopBar } from './EditorTopBar';
import { EditorSidebar, EditorTab } from './EditorSidebar';
import { WebsiteRenderer } from '../preview/WebsiteRenderer';
import { DevicePreviewFrame } from '../preview/DevicePreviewFrame';
import { ExpandedPreviewModal } from './modals/ExpandedPreviewModal';
import { PublishModal } from '../publish/PublishModal';
import { WebsiteService } from '../../services/data/websiteService';

interface VisualWebsiteEditorProps {
  website: Website;
  onClose: () => void;
  onSaved?: (updatedWebsite: Website) => void;
}

export const VisualWebsiteEditor: React.FC<VisualWebsiteEditorProps> = ({
  website,
  onClose,
  onSaved,
}) => {
  const { updateWebsite } = useWebsites();

  // Initial spec fallback if missing
  const fallbackSpec: WebsiteSpec = {
    siteName: website.name || 'My StorePilot Site',
    businessName: website.name || 'StorePilot Business',
    tagline: 'Crafted with StorePilot AI',
    businessDescription: website.description || 'Welcome to our modern business website.',
    industry: website.businessType || 'General Business',
    targetAudience: 'Customers and community',
    theme: {
      primaryColor: '#0f172a',
      accentColor: '#3b82f6',
      backgroundColor: '#ffffff',
      textColor: '#0f172a',
      fontFamily: 'sans',
      styleMood: 'Modern Minimalist',
    },
    header: {
      brandName: website.name || 'StorePilot',
      navLinks: [
        { id: 'n1', label: 'Offerings', targetSectionId: 'products' },
        { id: 'n2', label: 'Story', targetSectionId: 'about' },
        { id: 'n3', label: 'Contact', targetSectionId: 'contact' },
      ],
      ctaButton: { label: 'Get Started', targetSectionId: 'contact' },
    },
    sections: [],
    footer: {
      brandName: website.name || 'StorePilot',
      copyright: `© ${new Date().getFullYear()} ${website.name || 'StorePilot'}. All rights reserved.`,
      description: 'Built with StorePilot AI website platform.',
      quickLinks: [
        { label: 'Privacy', href: '#' },
        { label: 'Terms', href: '#' },
      ],
    },
  };

  // Draft check in sessionStorage
  const getInitialSpec = (): WebsiteSpec => {
    try {
      const draft = sessionStorage.getItem(`storepilot_draft_${website.id}`);
      if (draft) {
        const parsed = JSON.parse(draft);
        if (parsed && parsed.siteName && Array.isArray(parsed.sections)) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not restore draft:', e);
    }
    return website.spec || fallbackSpec;
  };

  const {
    spec,
    canUndo,
    canRedo,
    undo,
    redo,
    updateSpec,
    resetHistory,
  } = useEditorHistory(getInitialSpec());

  const [activeTab, setActiveTab] = useState<EditorTab>('sections');
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isExpandedPreview, setIsExpandedPreview] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [publishModalTab, setPublishModalTab] = useState<'storepilot' | 'custom_domain'>('storepilot');

  // Compute live publish status
  const publishStatus = WebsiteService.getPublishStatus({ ...website, spec });

  // Compare spec with saved website spec
  const initialSerialized = JSON.stringify(website.spec || fallbackSpec);
  const currentSerialized = JSON.stringify(spec);
  const isDirty = initialSerialized !== currentSerialized;

  // Temporary local draft persistence on changes
  useEffect(() => {
    if (isDirty) {
      try {
        sessionStorage.setItem(`storepilot_draft_${website.id}`, JSON.stringify(spec));
      } catch (e) {
        // quota exceeded or private mode
      }
    }
  }, [spec, isDirty, website.id]);

  // Keyboard shortcuts: Undo / Redo / Save
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check if user is typing inside an input or textarea
      const target = e.target as HTMLElement;
      const isInput =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          if (canRedo) redo();
        } else {
          // If in text field, only undo if not typing or prevent default to trigger app undo
          if (!isInput) {
            e.preventDefault();
            if (canUndo) undo();
          }
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        if (canRedo) redo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSave();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [canUndo, canRedo, undo, redo]);

  // Section updates
  const handleUpdateSections = (newSections: WebsiteSection[]) => {
    updateSpec({
      ...spec,
      sections: newSections,
    });
  };

  const handleUpdateSection = (sectionId: string, updatedSection: WebsiteSection) => {
    const updated = spec.sections.map((sec, idx) =>
      sec.id === sectionId || `section-${idx}` === sectionId ? updatedSection : sec
    );
    updateSpec({
      ...spec,
      sections: updated,
    });
  };

  const handleUpdateTheme = (newTheme: WebsiteTheme) => {
    updateSpec({
      ...spec,
      theme: newTheme,
    });
  };

  const handleUpdateSpec = (updated: Partial<WebsiteSpec>) => {
    updateSpec({
      ...spec,
      ...updated,
    });
  };

  const handleUpdateHeader = (updatedHeader: HeaderConfig) => {
    updateSpec({
      ...spec,
      header: updatedHeader,
    });
  };

  const handleUpdateFooter = (updatedFooter: FooterConfig) => {
    updateSpec({
      ...spec,
      footer: updatedFooter,
    });
  };

  const handleApplyRefinedSpec = (newSpec: WebsiteSpec) => {
    updateSpec(newSpec);
    // Switch to sections tab to see updated layout
    setActiveTab('sections');
  };

  // Section selection from live preview
  const handleSelectSectionFromPreview = (sectionId: string) => {
    setSelectedSectionId(sectionId);
    setActiveTab('sections');
  };

  // Save changes handler
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const updatedFields = {
        spec,
        name: spec.siteName || website.name,
        businessType: spec.industry || website.businessType,
        description: spec.businessDescription || website.description,
      };

      updateWebsite(website.id, updatedFields);

      // Direct authoritative Cloud Firestore write
      await WebsiteService.saveWebsiteDirectly({
        ...website,
        ...updatedFields,
        updatedAt: new Date().toISOString(),
      });

      // Clear draft on successful save
      try {
        sessionStorage.removeItem(`storepilot_draft_${website.id}`);
      } catch (e) {
        // ignore
      }

      if (onSaved) {
        onSaved({
          ...website,
          ...updatedFields,
        });
      }
    } catch (err) {
      console.error('Save failed:', err);
    } finally {
      setTimeout(() => setIsSaving(false), 500);
    }
  };

  const handleExit = () => {
    if (isDirty) {
      const confirmed = window.confirm(
        'You have unsaved changes. Are you sure you want to exit the editor?'
      );
      if (!confirmed) return;
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 flex flex-col font-sans select-none animate-in fade-in duration-150">
      {/* 1. Top Navigation Bar */}
      <EditorTopBar
        siteName={spec.siteName || website.name}
        isDemo={website.isDemo}
        isDirty={isDirty}
        isSaving={isSaving}
        canUndo={canUndo}
        canRedo={canRedo}
        viewport={viewport}
        publishStatus={publishStatus}
        publishedSlug={website.publishedSlug}
        customDomain={website.customDomain}
        onUndo={undo}
        onRedo={redo}
        onChangeViewport={setViewport}
        onExpandPreview={() => setIsExpandedPreview(true)}
        onSave={handleSave}
        onExit={handleExit}
        onOpenPublish={() => {
          setPublishModalTab('storepilot');
          setIsPublishModalOpen(true);
        }}
        onOpenDomainSettings={() => {
          setPublishModalTab('custom_domain');
          setIsPublishModalOpen(true);
        }}
      />

      {/* 2. Main Workspace Body: Left Controls + Center Live Preview */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Editing Sidebar */}
        <EditorSidebar
          spec={spec}
          activeTab={activeTab}
          selectedSectionId={selectedSectionId}
          onSelectTab={setActiveTab}
          onSelectSection={setSelectedSectionId}
          onUpdateSections={handleUpdateSections}
          onUpdateSection={handleUpdateSection}
          onUpdateTheme={handleUpdateTheme}
          onUpdateSpec={handleUpdateSpec}
          onUpdateHeader={handleUpdateHeader}
          onUpdateFooter={handleUpdateFooter}
          onApplyRefinedSpec={handleApplyRefinedSpec}
        />

        {/* Center Live Website Canvas */}
        <main className="flex-1 overflow-y-auto bg-slate-900/95 p-3 sm:p-6 lg:p-8 flex justify-center items-start">
          <DevicePreviewFrame
            viewport={viewport}
            siteName={spec.siteName || website.name}
          >
            <WebsiteRenderer
              spec={spec}
              viewport={viewport}
              isInteractive={true}
              isEditorMode={true}
              selectedSectionId={selectedSectionId}
              onSelectSection={handleSelectSectionFromPreview}
            />
          </DevicePreviewFrame>
        </main>
      </div>

      {/* Full-Screen Preview Modal */}
      <ExpandedPreviewModal
        isOpen={isExpandedPreview}
        spec={spec}
        onClose={() => setIsExpandedPreview(false)}
      />

      {/* Publish to StorePilot URL & Custom Domain Modal */}
      <PublishModal
        website={{ ...website, spec }}
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        initialTab={publishModalTab}
        onPublished={() => {
          handleSave();
        }}
      />
    </div>
  );
};
