import React from 'react';
import { Palette, Type, Check, Sparkles } from 'lucide-react';
import { WebsiteSpec, WebsiteTheme, ThemePreset } from '../../../types/websiteSpec';
import { THEME_PRESETS } from '../../../config/editorPresets';

interface ThemeEditorPanelProps {
  spec: WebsiteSpec;
  onUpdateTheme: (newTheme: WebsiteTheme) => void;
}

export const ThemeEditorPanel: React.FC<ThemeEditorPanelProps> = ({
  spec,
  onUpdateTheme,
}) => {
  const currentTheme = spec.theme || {
    primaryColor: '#0f172a',
    accentColor: '#3b82f6',
    backgroundColor: '#ffffff',
    textColor: '#0f172a',
    fontFamily: 'sans',
    styleMood: 'Modern Minimalist',
  };

  const handleApplyPreset = (preset: ThemePreset) => {
    onUpdateTheme({
      ...preset.theme,
    });
  };

  const handleColorChange = (key: keyof WebsiteTheme, value: string) => {
    onUpdateTheme({
      ...currentTheme,
      [key]: value,
    });
  };

  const handleFontChange = (font: 'sans' | 'serif' | 'mono') => {
    onUpdateTheme({
      ...currentTheme,
      fontFamily: font,
    });
  };

  // Curated color swatches for quick clicking
  const QUICK_SWATCHES = {
    primary: ['#0f172a', '#1e293b', '#2563eb', '#4f46e5', '#7c3aed', '#ea580c', '#15803d', '#1c1917'],
    accent: ['#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#db2777', '#f43f5e', '#84cc16', '#b45309'],
    background: ['#ffffff', '#f8fafc', '#f1f5f9', '#fbfaf8', '#fefcf8', '#f7fee7', '#faf5ff', '#0f172a'],
    text: ['#0f172a', '#1e293b', '#334155', '#1c1917', '#292524', '#09090b', '#ffffff'],
  };

  return (
    <div className="space-y-6">
      {/* 1. Theme Presets */}
      <div>
        <div className="flex items-center gap-1.5 mb-1">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Curated Style Presets
          </h3>
        </div>
        <p className="text-[11px] text-slate-500 mb-3">
          Click a preset to instantly restyle your website while keeping all section content intact.
        </p>

        <div className="grid grid-cols-2 gap-2">
          {THEME_PRESETS.map((preset) => {
            const isMatch =
              currentTheme.primaryColor === preset.theme.primaryColor &&
              currentTheme.backgroundColor === preset.theme.backgroundColor;

            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleApplyPreset(preset)}
                className={`p-2.5 rounded-xl border text-left transition-all relative cursor-pointer ${
                  isMatch
                    ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-200'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">
                    {preset.name}
                  </span>
                  {isMatch && (
                    <div className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>

                {/* Color swatches preview bar */}
                <div className="flex items-center gap-1">
                  <span
                    className="w-4 h-4 rounded-full border border-black/10 shadow-2xs"
                    style={{ backgroundColor: preset.theme.primaryColor }}
                    title={`Primary: ${preset.theme.primaryColor}`}
                  />
                  <span
                    className="w-4 h-4 rounded-full border border-black/10 shadow-2xs"
                    style={{ backgroundColor: preset.theme.accentColor }}
                    title={`Accent: ${preset.theme.accentColor}`}
                  />
                  <span
                    className="w-4 h-4 rounded-full border border-black/10 shadow-2xs"
                    style={{ backgroundColor: preset.theme.backgroundColor }}
                    title={`Background: ${preset.theme.backgroundColor}`}
                  />
                  <span className="text-[10px] text-slate-400 font-mono ml-auto">
                    {preset.theme.fontFamily}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Typography Selection */}
      <div className="pt-4 border-t border-slate-100">
        <div className="flex items-center gap-1.5 mb-1">
          <Type className="w-3.5 h-3.5 text-indigo-600" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Font Family
          </h3>
        </div>
        <p className="text-[11px] text-slate-500 mb-3">
          Choose the typographic voice that best represents your brand.
        </p>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleFontChange('sans')}
            className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
              currentTheme.fontFamily === 'sans'
                ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold ring-2 ring-indigo-200'
                : 'border-slate-200 hover:border-slate-300 text-slate-700 font-medium'
            }`}
          >
            <span className="block text-base font-sans">Aa</span>
            <span className="text-[11px] block mt-0.5">Sans-Serif</span>
          </button>

          <button
            type="button"
            onClick={() => handleFontChange('serif')}
            className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
              currentTheme.fontFamily === 'serif'
                ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold ring-2 ring-indigo-200'
                : 'border-slate-200 hover:border-slate-300 text-slate-700 font-medium'
            }`}
          >
            <span className="block text-base font-serif">Aa</span>
            <span className="text-[11px] block mt-0.5">Editorial Serif</span>
          </button>

          <button
            type="button"
            onClick={() => handleFontChange('mono')}
            className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
              currentTheme.fontFamily === 'mono'
                ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold ring-2 ring-indigo-200'
                : 'border-slate-200 hover:border-slate-300 text-slate-700 font-medium'
            }`}
          >
            <span className="block text-base font-mono">Aa</span>
            <span className="text-[11px] block mt-0.5">Monospace</span>
          </button>
        </div>
      </div>

      {/* 3. Color Customization */}
      <div className="pt-4 border-t border-slate-100 space-y-4">
        <div className="flex items-center gap-1.5 mb-1">
          <Palette className="w-3.5 h-3.5 text-indigo-600" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Custom Palette Controls
          </h3>
        </div>

        {/* Primary Color */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800">
              Primary Brand Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={currentTheme.primaryColor}
                onChange={(e) => handleColorChange('primaryColor', e.target.value)}
                className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
              />
              <input
                type="text"
                value={currentTheme.primaryColor}
                onChange={(e) => handleColorChange('primaryColor', e.target.value)}
                className="w-20 text-[11px] font-mono px-2 py-1 rounded border border-slate-300 text-slate-800 bg-white"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1 pt-1">
            {QUICK_SWATCHES.primary.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => handleColorChange('primaryColor', hex)}
                className={`w-5 h-5 rounded-md border transition-transform cursor-pointer ${
                  currentTheme.primaryColor === hex
                    ? 'scale-110 ring-2 ring-indigo-500 border-white'
                    : 'border-black/10 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={hex}
              />
            ))}
          </div>
        </div>

        {/* Accent Color */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800">
              Accent / Highlight Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={currentTheme.accentColor}
                onChange={(e) => handleColorChange('accentColor', e.target.value)}
                className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
              />
              <input
                type="text"
                value={currentTheme.accentColor}
                onChange={(e) => handleColorChange('accentColor', e.target.value)}
                className="w-20 text-[11px] font-mono px-2 py-1 rounded border border-slate-300 text-slate-800 bg-white"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1 pt-1">
            {QUICK_SWATCHES.accent.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => handleColorChange('accentColor', hex)}
                className={`w-5 h-5 rounded-md border transition-transform cursor-pointer ${
                  currentTheme.accentColor === hex
                    ? 'scale-110 ring-2 ring-indigo-500 border-white'
                    : 'border-black/10 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={hex}
              />
            ))}
          </div>
        </div>

        {/* Background Color */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800">
              Page Background Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={currentTheme.backgroundColor}
                onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
                className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
              />
              <input
                type="text"
                value={currentTheme.backgroundColor}
                onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
                className="w-20 text-[11px] font-mono px-2 py-1 rounded border border-slate-300 text-slate-800 bg-white"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1 pt-1">
            {QUICK_SWATCHES.background.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => handleColorChange('backgroundColor', hex)}
                className={`w-5 h-5 rounded-md border transition-transform cursor-pointer ${
                  currentTheme.backgroundColor === hex
                    ? 'scale-110 ring-2 ring-indigo-500 border-white'
                    : 'border-black/10 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={hex}
              />
            ))}
          </div>
        </div>

        {/* Text Color */}
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800">
              Base Text Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={currentTheme.textColor}
                onChange={(e) => handleColorChange('textColor', e.target.value)}
                className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
              />
              <input
                type="text"
                value={currentTheme.textColor}
                onChange={(e) => handleColorChange('textColor', e.target.value)}
                className="w-20 text-[11px] font-mono px-2 py-1 rounded border border-slate-300 text-slate-800 bg-white"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1 pt-1">
            {QUICK_SWATCHES.text.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => handleColorChange('textColor', hex)}
                className={`w-5 h-5 rounded-md border transition-transform cursor-pointer ${
                  currentTheme.textColor === hex
                    ? 'scale-110 ring-2 ring-indigo-500 border-white'
                    : 'border-black/10 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={hex}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
