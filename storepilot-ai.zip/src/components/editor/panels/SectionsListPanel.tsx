import React, { useState } from 'react';
import {
  Layers,
  Eye,
  EyeOff,
  ChevronUp,
  ChevronDown,
  Trash2,
  Plus,
  Edit2,
  Sparkles,
  ShoppingBag,
  Info,
  MessageSquare,
  Megaphone,
  Mail,
  Sliders,
  Compass,
} from 'lucide-react';
import { WebsiteSpec, WebsiteSection } from '../../../types/websiteSpec';
import { createDefaultSection } from '../../../config/editorPresets';

interface SectionsListPanelProps {
  spec: WebsiteSpec;
  selectedSectionId: string | null;
  onSelectSection: (sectionId: string) => void;
  onUpdateSections: (newSections: WebsiteSection[]) => void;
}

export const SectionsListPanel: React.FC<SectionsListPanelProps> = ({
  spec,
  selectedSectionId,
  onSelectSection,
  onUpdateSections,
}) => {
  const [showAddMenu, setShowAddMenu] = useState(false);

  const getSectionIcon = (type: string) => {
    switch (type) {
      case 'hero':
        return <Sparkles className="w-4 h-4 text-amber-500" />;
      case 'features':
        return <Sliders className="w-4 h-4 text-blue-500" />;
      case 'products':
        return <ShoppingBag className="w-4 h-4 text-emerald-500" />;
      case 'about':
        return <Info className="w-4 h-4 text-indigo-500" />;
      case 'testimonials':
        return <MessageSquare className="w-4 h-4 text-purple-500" />;
      case 'cta':
        return <Megaphone className="w-4 h-4 text-rose-500" />;
      case 'contact':
        return <Mail className="w-4 h-4 text-teal-500" />;
      default:
        return <Layers className="w-4 h-4 text-slate-500" />;
    }
  };

  const getSectionTitle = (section: WebsiteSection) => {
    switch (section.type) {
      case 'hero':
        return section.headline || 'Hero Banner';
      case 'features':
        return section.title || 'Features / Value Props';
      case 'products':
        return `${section.title || 'Products'} (${section.items?.length || 0} items)`;
      case 'about':
        return section.title || 'About Section';
      case 'testimonials':
        return `${section.title || 'Testimonials'} (${section.items?.length || 0} reviews)`;
      case 'cta':
        return section.headline || 'Call to Action';
      case 'contact':
        return section.title || 'Contact & Inquiry';
      default:
        return 'Custom Section';
    }
  };

  const handleToggleVisibility = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = [...spec.sections];
    updated[idx] = {
      ...updated[idx],
      hidden: !updated[idx].hidden,
    };
    onUpdateSections(updated);
  };

  const handleMoveUp = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (idx === 0) return;
    const updated = [...spec.sections];
    const temp = updated[idx];
    updated[idx] = updated[idx - 1];
    updated[idx - 1] = temp;
    onUpdateSections(updated);
  };

  const handleMoveDown = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (idx === spec.sections.length - 1) return;
    const updated = [...spec.sections];
    const temp = updated[idx];
    updated[idx] = updated[idx + 1];
    updated[idx + 1] = temp;
    onUpdateSections(updated);
  };

  const handleDeleteSection = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const confirmed = window.confirm(
      `Are you sure you want to remove the "${spec.sections[idx].type}" section? (You can use Undo if needed)`
    );
    if (!confirmed) return;
    const updated = spec.sections.filter((_, i) => i !== idx);
    onUpdateSections(updated);
  };

  const handleAddSection = (type: 'hero' | 'features' | 'products' | 'about' | 'testimonials' | 'cta' | 'contact') => {
    const newSec = createDefaultSection(type, spec.businessName || 'StorePilot');
    const updated = [...spec.sections, newSec];
    onUpdateSections(updated);
    setShowAddMenu(false);
    onSelectSection(newSec.id);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Page Sections
          </h3>
          <p className="text-[11px] text-slate-500">
            Reorder, toggle visibility, or select a section to edit its content.
          </p>
        </div>
      </div>

      {/* Header Bar Item */}
      <div
        onClick={() => onSelectSection('header')}
        className={`p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
          selectedSectionId === 'header'
            ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-200'
            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
        }`}
      >
        <div className="flex items-center gap-2.5">
          <Compass className="w-4 h-4 text-slate-700" />
          <div>
            <span className="text-xs font-bold text-slate-800">Site Header & Navigation</span>
            <p className="text-[10px] text-slate-400">Brand logo, nav links, cart & CTA button</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-indigo-600 font-semibold px-2 py-0.5 rounded bg-indigo-50 border border-indigo-100">
            Edit
          </span>
        </div>
      </div>

      {/* Sections List */}
      <div className="space-y-1.5">
        {spec.sections.map((section, idx) => {
          const sectionId = section.id || `section-${idx}`;
          const isSelected = selectedSectionId === sectionId;
          const isHidden = !!section.hidden;

          return (
            <div
              key={sectionId}
              onClick={() => onSelectSection(sectionId)}
              className={`p-2.5 rounded-xl border transition-all flex items-center justify-between group cursor-pointer ${
                isSelected
                  ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-200 shadow-xs'
                  : isHidden
                  ? 'bg-slate-50/80 border-dashed border-slate-300 opacity-60'
                  : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {/* Left Title & Icon */}
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                  {getSectionIcon(section.type)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">
                      {section.type}
                    </span>
                    {isHidden && (
                      <span className="text-[9px] font-semibold text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                        Hidden
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-semibold text-slate-800 truncate">
                    {getSectionTitle(section)}
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1 shrink-0">
                {/* Move Up */}
                <button
                  type="button"
                  title="Move Up"
                  disabled={idx === 0}
                  onClick={(e) => handleMoveUp(idx, e)}
                  className="p-1 text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 rounded disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>

                {/* Move Down */}
                <button
                  type="button"
                  title="Move Down"
                  disabled={idx === spec.sections.length - 1}
                  onClick={(e) => handleMoveDown(idx, e)}
                  className="p-1 text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 rounded disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {/* Toggle Visibility */}
                <button
                  type="button"
                  title={isHidden ? 'Show Section' : 'Hide Section'}
                  onClick={(e) => handleToggleVisibility(idx, e)}
                  className={`p-1 rounded cursor-pointer ${
                    isHidden
                      ? 'text-amber-600 hover:bg-amber-100'
                      : 'text-slate-400 hover:text-slate-800 hover:bg-slate-200/60'
                  }`}
                >
                  {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>

                {/* Delete */}
                <button
                  type="button"
                  title="Delete Section"
                  onClick={(e) => handleDeleteSection(idx, e)}
                  className="p-1 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Bar Item */}
      <div
        onClick={() => onSelectSection('footer')}
        className={`p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
          selectedSectionId === 'footer'
            ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-200'
            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
        }`}
      >
        <div className="flex items-center gap-2.5">
          <Layers className="w-4 h-4 text-slate-700" />
          <div>
            <span className="text-xs font-bold text-slate-800">Site Footer</span>
            <p className="text-[10px] text-slate-400">Copyright, quick links & brand statement</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-indigo-600 font-semibold px-2 py-0.5 rounded bg-indigo-50 border border-indigo-100">
            Edit
          </span>
        </div>
      </div>

      {/* Add Section Button */}
      <div className="relative pt-2">
        <button
          type="button"
          onClick={() => setShowAddMenu(!showAddMenu)}
          className="w-full py-2.5 px-3 rounded-xl border-2 border-dashed border-slate-300 hover:border-slate-400 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Section</span>
        </button>

        {showAddMenu && (
          <div className="absolute left-0 right-0 bottom-full mb-2 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-30 space-y-1 text-xs">
            <span className="block px-2 py-1 text-[10px] font-bold uppercase text-slate-400">
              Select Section to Add
            </span>
            <button
              onClick={() => handleAddSection('hero')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Hero Banner</span>
            </button>
            <button
              onClick={() => handleAddSection('features')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-blue-500" />
              <span>Features & Value Props</span>
            </button>
            <button
              onClick={() => handleAddSection('products')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-emerald-500" />
              <span>Products & Catalog</span>
            </button>
            <button
              onClick={() => handleAddSection('about')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <Info className="w-3.5 h-3.5 text-indigo-500" />
              <span>About & Founder Story</span>
            </button>
            <button
              onClick={() => handleAddSection('testimonials')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-purple-500" />
              <span>Client Reviews & Testimonials</span>
            </button>
            <button
              onClick={() => handleAddSection('cta')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <Megaphone className="w-3.5 h-3.5 text-rose-500" />
              <span>Call to Action Banner</span>
            </button>
            <button
              onClick={() => handleAddSection('contact')}
              className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-2 font-medium cursor-pointer"
            >
              <Mail className="w-3.5 h-3.5 text-teal-500" />
              <span>Contact & Inquiry Form</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
