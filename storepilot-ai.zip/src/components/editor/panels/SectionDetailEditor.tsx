import React, { useState } from 'react';
import {
  ArrowLeft,
  Image as ImageIcon,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  Star,
  Sparkles,
  Sliders,
  ShoppingBag,
  Info,
  MessageSquare,
  Megaphone,
  Mail,
  Compass,
  Layers,
} from 'lucide-react';
import {
  WebsiteSpec,
  WebsiteSection,
  HeroSection,
  FeaturesSection,
  ProductsSection,
  AboutSection,
  TestimonialsSection,
  CtaSection,
  ContactSection,
  HeaderConfig,
  FooterConfig,
  ProductItem,
  FeatureItem,
  TestimonialItem,
} from '../../../types/websiteSpec';
import { ImagePickerModal } from '../modals/ImagePickerModal';
import { Button } from '../../ui/Button';

interface SectionDetailEditorProps {
  spec: WebsiteSpec;
  selectedSectionId: string;
  onBack: () => void;
  onUpdateSection: (sectionId: string, updatedSection: WebsiteSection) => void;
  onUpdateHeader: (updatedHeader: HeaderConfig) => void;
  onUpdateFooter: (updatedFooter: FooterConfig) => void;
}

export const SectionDetailEditor: React.FC<SectionDetailEditorProps> = ({
  spec,
  selectedSectionId,
  onBack,
  onUpdateSection,
  onUpdateHeader,
  onUpdateFooter,
}) => {
  // Image picker modal state
  const [imagePickerOpen, setImagePickerOpen] = useState(false);
  const [imageTarget, setImageTarget] = useState<{
    type: 'hero' | 'about' | 'product' | 'testimonial';
    itemId?: string;
    currentUrl?: string;
  } | null>(null);

  const openImagePicker = (
    type: 'hero' | 'about' | 'product' | 'testimonial',
    itemId?: string,
    currentUrl?: string
  ) => {
    setImageTarget({ type, itemId, currentUrl });
    setImagePickerOpen(true);
  };

  const handleApplyImage = (newUrl: string) => {
    if (!imageTarget) return;

    if (imageTarget.type === 'hero') {
      const hero = currentSection as HeroSection;
      onUpdateSection(selectedSectionId, {
        ...hero,
        imageUrl: newUrl,
      });
    } else if (imageTarget.type === 'about') {
      const about = currentSection as AboutSection;
      onUpdateSection(selectedSectionId, {
        ...about,
        imageUrl: newUrl,
      });
    } else if (imageTarget.type === 'product' && imageTarget.itemId) {
      const productsSec = currentSection as ProductsSection;
      const updatedItems = productsSec.items.map((item) =>
        item.id === imageTarget.itemId ? { ...item, imageUrl: newUrl } : item
      );
      onUpdateSection(selectedSectionId, {
        ...productsSec,
        items: updatedItems,
      });
    } else if (imageTarget.type === 'testimonial' && imageTarget.itemId) {
      const testSec = currentSection as TestimonialsSection;
      const updatedItems = testSec.items.map((item) =>
        item.id === imageTarget.itemId ? { ...item, avatarUrl: newUrl } : item
      );
      onUpdateSection(selectedSectionId, {
        ...testSec,
        items: updatedItems,
      });
    }

    setImagePickerOpen(false);
    setImageTarget(null);
  };

  // Find the target section
  const currentSection = spec.sections.find(
    (s, idx) => s.id === selectedSectionId || `section-${idx}` === selectedSectionId
  );

  // Check if Header or Footer
  const isHeader = selectedSectionId === 'header';
  const isFooter = selectedSectionId === 'footer';

  if (!isHeader && !isFooter && !currentSection) {
    return (
      <div className="p-4 text-center space-y-3">
        <p className="text-xs text-slate-500">Selected section not found.</p>
        <Button variant="outline" size="sm" onClick={onBack} className="text-xs">
          Return to Sections
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Top back navigation & title */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <button
          type="button"
          onClick={onBack}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>All Sections</span>
        </button>

        <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
          {isHeader
            ? 'Header'
            : isFooter
            ? 'Footer'
            : currentSection?.type || 'Section'}
        </span>
      </div>

      {/* ---------------- 1. HEADER EDITOR ---------------- */}
      {isHeader && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Brand Display Name
            </label>
            <input
              type="text"
              value={spec.header.brandName}
              onChange={(e) =>
                onUpdateHeader({ ...spec.header, brandName: e.target.value })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Header Tagline (Optional)
            </label>
            <input
              type="text"
              value={spec.header.tagline || ''}
              onChange={(e) =>
                onUpdateHeader({ ...spec.header, tagline: e.target.value })
              }
              placeholder="e.g. Accra, Ghana"
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Header CTA Button Label
            </label>
            <input
              type="text"
              value={spec.header.ctaButton?.label || ''}
              onChange={(e) =>
                onUpdateHeader({
                  ...spec.header,
                  ctaButton: {
                    label: e.target.value,
                    targetSectionId: spec.header.ctaButton?.targetSectionId || 'products',
                  },
                })
              }
              placeholder="e.g. Shop Now or Contact"
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Navigation Links */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Navigation Menu Links
              </label>
              <button
                type="button"
                onClick={() => {
                  const newLinks = [
                    ...(spec.header.navLinks || []),
                    {
                      id: `nav-${Date.now()}`,
                      label: 'New Link',
                      targetSectionId: 'products',
                    },
                  ];
                  onUpdateHeader({ ...spec.header, navLinks: newLinks });
                }}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Link
              </button>
            </div>

            {spec.header.navLinks?.map((link, idx) => (
              <div
                key={link.id || idx}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-center gap-2"
              >
                <input
                  type="text"
                  value={link.label}
                  onChange={(e) => {
                    const updated = [...(spec.header.navLinks || [])];
                    updated[idx] = { ...updated[idx], label: e.target.value };
                    onUpdateHeader({ ...spec.header, navLinks: updated });
                  }}
                  placeholder="Link label"
                  className="flex-1 text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
                <input
                  type="text"
                  value={link.targetSectionId}
                  onChange={(e) => {
                    const updated = [...(spec.header.navLinks || [])];
                    updated[idx] = { ...updated[idx], targetSectionId: e.target.value };
                    onUpdateHeader({ ...spec.header, navLinks: updated });
                  }}
                  placeholder="Target section id"
                  className="w-28 text-xs px-2 py-1.5 rounded-lg border border-slate-300 bg-white font-mono"
                />
                <button
                  type="button"
                  onClick={() => {
                    const updated = spec.header.navLinks.filter((_, i) => i !== idx);
                    onUpdateHeader({ ...spec.header, navLinks: updated });
                  }}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- 2. FOOTER EDITOR ---------------- */}
      {isFooter && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Footer Brand Name
            </label>
            <input
              type="text"
              value={spec.footer.brandName}
              onChange={(e) =>
                onUpdateFooter({ ...spec.footer, brandName: e.target.value })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Short Description / Mission
            </label>
            <textarea
              rows={2}
              value={spec.footer.description || ''}
              onChange={(e) =>
                onUpdateFooter({ ...spec.footer, description: e.target.value })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Copyright Notice
            </label>
            <input
              type="text"
              value={spec.footer.copyright}
              onChange={(e) =>
                onUpdateFooter({ ...spec.footer, copyright: e.target.value })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>
        </div>
      )}

      {/* ---------------- 3. HERO SECTION ---------------- */}
      {currentSection?.type === 'hero' && (
        <div className="space-y-4">
          {/* Badge */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Top Badge Text
            </label>
            <input
              type="text"
              value={(currentSection as HeroSection).badge || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  badge: e.target.value,
                })
              }
              placeholder="e.g. New Drop 2026 or Handcrafted in Ghana"
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Headline */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Main Headline
            </label>
            <input
              type="text"
              value={(currentSection as HeroSection).headline}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  headline: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Subheadline */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subheadline / Description
            </label>
            <textarea
              rows={3}
              value={(currentSection as HeroSection).subheadline}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subheadline: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 leading-relaxed resize-none"
            />
          </div>

          {/* Primary CTA */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800">
              Primary Action Button
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-slate-500 block mb-0.5">Label</span>
                <input
                  type="text"
                  value={(currentSection as HeroSection).primaryCta?.label || ''}
                  onChange={(e) =>
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      primaryCta: {
                        ...(currentSection as HeroSection).primaryCta,
                        label: e.target.value,
                      },
                    })
                  }
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block mb-0.5">Scroll Target</span>
                <input
                  type="text"
                  value={(currentSection as HeroSection).primaryCta?.targetSectionId || 'products'}
                  onChange={(e) =>
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      primaryCta: {
                        ...(currentSection as HeroSection).primaryCta,
                        targetSectionId: e.target.value,
                      },
                    })
                  }
                  placeholder="e.g. products"
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Secondary CTA */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800">
              Secondary Button (Optional)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-slate-500 block mb-0.5">Label</span>
                <input
                  type="text"
                  value={(currentSection as HeroSection).secondaryCta?.label || ''}
                  onChange={(e) =>
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      secondaryCta: {
                        label: e.target.value,
                        targetSectionId: (currentSection as HeroSection).secondaryCta?.targetSectionId || 'about',
                      },
                    })
                  }
                  placeholder="e.g. Learn More"
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block mb-0.5">Scroll Target</span>
                <input
                  type="text"
                  value={(currentSection as HeroSection).secondaryCta?.targetSectionId || 'about'}
                  onChange={(e) =>
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      secondaryCta: {
                        label: (currentSection as HeroSection).secondaryCta?.label || 'Learn More',
                        targetSectionId: e.target.value,
                      },
                    })
                  }
                  placeholder="e.g. about"
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Hero Featured Image
            </label>
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 shrink-0">
                {(currentSection as HeroSection).imageUrl ? (
                  <img
                    src={(currentSection as HeroSection).imageUrl}
                    alt="Hero preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                )}
              </div>
              <div className="flex-1 space-y-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    openImagePicker('hero', undefined, (currentSection as HeroSection).imageUrl)
                  }
                  className="text-xs w-full flex items-center justify-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Choose or Replace Image</span>
                </Button>
                <p className="text-[10px] text-slate-400 truncate">
                  {(currentSection as HeroSection).imageUrl || 'No image selected'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- 4. FEATURES SECTION ---------------- */}
      {currentSection?.type === 'features' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section Title
            </label>
            <input
              type="text"
              value={(currentSection as FeaturesSection).title}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  title: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subtitle
            </label>
            <input
              type="text"
              value={(currentSection as FeaturesSection).subtitle || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subtitle: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Feature items */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Value Props / Features ({(currentSection as FeaturesSection).items?.length || 0})
              </label>
              <button
                type="button"
                onClick={() => {
                  const newFeatures = [
                    ...((currentSection as FeaturesSection).items || []),
                    {
                      id: `feat-${Date.now()}`,
                      title: 'New Feature',
                      description: 'Highlight what makes your service or product distinct.',
                      iconName: 'Shield' as const,
                    },
                  ];
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    items: newFeatures,
                  });
                }}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Feature
              </button>
            </div>

            {(currentSection as FeaturesSection).items?.map((feat, idx) => (
              <div
                key={feat.id || idx}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-600">
                    Feature #{idx + 1}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = (currentSection as FeaturesSection).items.filter(
                        (_, i) => i !== idx
                      );
                      onUpdateSection(selectedSectionId, {
                        ...currentSection,
                        items: updated,
                      });
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <input
                      type="text"
                      value={feat.title}
                      onChange={(e) => {
                        const updated = [...(currentSection as FeaturesSection).items];
                        updated[idx] = { ...updated[idx], title: e.target.value };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      placeholder="Title"
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <select
                      value={feat.iconName || 'Sparkles'}
                      onChange={(e) => {
                        const updated = [...(currentSection as FeaturesSection).items];
                        updated[idx] = {
                          ...updated[idx],
                          iconName: e.target.value as any,
                        };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="w-full text-xs px-2 py-1.5 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="Sparkles">Sparkles</option>
                      <option value="Shield">Shield</option>
                      <option value="Zap">Zap</option>
                      <option value="Truck">Truck</option>
                      <option value="Star">Star</option>
                      <option value="Clock">Clock</option>
                      <option value="Check">Check</option>
                      <option value="Heart">Heart</option>
                    </select>
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={feat.description}
                  onChange={(e) => {
                    const updated = [...(currentSection as FeaturesSection).items];
                    updated[idx] = { ...updated[idx], description: e.target.value };
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      items: updated,
                    });
                  }}
                  placeholder="Description..."
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white resize-none"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- 5. PRODUCTS SECTION ---------------- */}
      {currentSection?.type === 'products' && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Section Title
              </label>
              <input
                type="text"
                value={(currentSection as ProductsSection).title}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    title: e.target.value,
                  })
                }
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Currency
              </label>
              <input
                type="text"
                value={(currentSection as ProductsSection).currencySymbol || '$'}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    currencySymbol: e.target.value,
                  })
                }
                placeholder="$, GH₵, €, £"
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subtitle
            </label>
            <input
              type="text"
              value={(currentSection as ProductsSection).subtitle || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subtitle: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Products List */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Products & Offerings ({(currentSection as ProductsSection).items?.length || 0})
              </label>
              <button
                type="button"
                onClick={() => {
                  const newProducts = [
                    ...((currentSection as ProductsSection).items || []),
                    {
                      id: `prod-${Date.now()}`,
                      name: 'New Product Item',
                      price: '49.00',
                      category: 'New In',
                      badge: 'New',
                      description: 'Detailed description of quality and design.',
                      imageUrl:
                        'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
                    },
                  ];
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    items: newProducts,
                  });
                }}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Product
              </button>
            </div>

            {(currentSection as ProductsSection).items?.map((item, idx) => (
              <div
                key={item.id || idx}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-800">
                      #{idx + 1} {item.name || 'Untitled Product'}
                    </span>
                    {item.printifyBlueprintId && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        Printify #{item.printifyBlueprintId}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Move Up */}
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => {
                        const updated = [...(currentSection as ProductsSection).items];
                        const temp = updated[idx];
                        updated[idx] = updated[idx - 1];
                        updated[idx - 1] = temp;
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="p-1 text-slate-400 hover:text-slate-800 disabled:opacity-30 cursor-pointer"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    {/* Move Down */}
                    <button
                      type="button"
                      disabled={idx === (currentSection as ProductsSection).items.length - 1}
                      onClick={() => {
                        const updated = [...(currentSection as ProductsSection).items];
                        const temp = updated[idx];
                        updated[idx] = updated[idx + 1];
                        updated[idx + 1] = temp;
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="p-1 text-slate-400 hover:text-slate-800 disabled:opacity-30 cursor-pointer"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => {
                        const updated = (currentSection as ProductsSection).items.filter(
                          (_, i) => i !== idx
                        );
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                      Product Name
                    </label>
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => {
                        const updated = [...(currentSection as ProductsSection).items];
                        updated[idx] = { ...updated[idx], name: e.target.value };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                      Price
                    </label>
                    <input
                      type="text"
                      value={item.price}
                      onChange={(e) => {
                        const updated = [...(currentSection as ProductsSection).items];
                        updated[idx] = { ...updated[idx], price: e.target.value };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                      Category
                    </label>
                    <input
                      type="text"
                      value={item.category || ''}
                      onChange={(e) => {
                        const updated = [...(currentSection as ProductsSection).items];
                        updated[idx] = { ...updated[idx], category: e.target.value };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      placeholder="e.g. Hoodies"
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                      Badge (Optional)
                    </label>
                    <input
                      type="text"
                      value={item.badge || ''}
                      onChange={(e) => {
                        const updated = [...(currentSection as ProductsSection).items];
                        updated[idx] = { ...updated[idx], badge: e.target.value };
                        onUpdateSection(selectedSectionId, {
                          ...currentSection,
                          items: updated,
                        });
                      }}
                      placeholder="e.g. Bestseller"
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                    Description
                  </label>
                  <textarea
                    rows={2}
                    value={item.description}
                    onChange={(e) => {
                      const updated = [...(currentSection as ProductsSection).items];
                      updated[idx] = { ...updated[idx], description: e.target.value };
                      onUpdateSection(selectedSectionId, {
                        ...currentSection,
                        items: updated,
                      });
                    }}
                    className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white resize-none"
                  />
                </div>

                {/* Product Image */}
                <div className="flex items-center gap-3 pt-1">
                  <div className="w-12 h-12 rounded-lg border border-slate-200 overflow-hidden bg-slate-100 shrink-0">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <ImageIcon className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openImagePicker('product', item.id, item.imageUrl)}
                    className="text-xs flex items-center gap-1.5"
                  >
                    <ImageIcon className="w-3 h-3" />
                    <span>Change Product Image</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- 6. ABOUT SECTION ---------------- */}
      {currentSection?.type === 'about' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section Title
            </label>
            <input
              type="text"
              value={(currentSection as AboutSection).title}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  title: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Story Headline
            </label>
            <input
              type="text"
              value={(currentSection as AboutSection).headline}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  headline: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Story Content Paragraph
            </label>
            <textarea
              rows={4}
              value={(currentSection as AboutSection).content}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  content: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 leading-relaxed resize-none"
            />
          </div>

          {/* Highlights checklist */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Bullet Highlights
              </label>
              <button
                type="button"
                onClick={() => {
                  const newHighlights = [
                    ...((currentSection as AboutSection).highlights || []),
                    'New core commitment or milestone',
                  ];
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    highlights: newHighlights,
                  });
                }}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Highlight
              </button>
            </div>

            {(currentSection as AboutSection).highlights?.map((hl, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  value={hl}
                  onChange={(e) => {
                    const updated = [...((currentSection as AboutSection).highlights || [])];
                    updated[idx] = e.target.value;
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      highlights: updated,
                    });
                  }}
                  className="flex-1 text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
                <button
                  type="button"
                  onClick={() => {
                    const updated = (currentSection as AboutSection).highlights?.filter(
                      (_, i) => i !== idx
                    );
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      highlights: updated,
                    });
                  }}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* About Image */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Founder / Story Image
            </label>
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 shrink-0">
                {(currentSection as AboutSection).imageUrl ? (
                  <img
                    src={(currentSection as AboutSection).imageUrl}
                    alt="About preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                )}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  openImagePicker('about', undefined, (currentSection as AboutSection).imageUrl)
                }
                className="text-xs flex items-center gap-1.5"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Replace Story Photo</span>
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- 7. TESTIMONIALS SECTION ---------------- */}
      {currentSection?.type === 'testimonials' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section Title
            </label>
            <input
              type="text"
              value={(currentSection as TestimonialsSection).title}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  title: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subtitle
            </label>
            <input
              type="text"
              value={(currentSection as TestimonialsSection).subtitle || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subtitle: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Testimonial items */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Reviews ({(currentSection as TestimonialsSection).items?.length || 0})
              </label>
              <button
                type="button"
                onClick={() => {
                  const newItems = [
                    ...((currentSection as TestimonialsSection).items || []),
                    {
                      id: `t-${Date.now()}`,
                      author: 'Customer Name',
                      role: 'Verified Buyer',
                      quote: 'Excellent service and exceptional quality. Highly recommended!',
                      rating: 5,
                      avatarUrl:
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
                    },
                  ];
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    items: newItems,
                  });
                }}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                Add Review
              </button>
            </div>

            {(currentSection as TestimonialsSection).items?.map((t, idx) => (
              <div
                key={t.id || idx}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    {t.author || 'Reviewer'}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = (currentSection as TestimonialsSection).items.filter(
                        (_, i) => i !== idx
                      );
                      onUpdateSection(selectedSectionId, {
                        ...currentSection,
                        items: updated,
                      });
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={t.author}
                    onChange={(e) => {
                      const updated = [...(currentSection as TestimonialsSection).items];
                      updated[idx] = { ...updated[idx], author: e.target.value };
                      onUpdateSection(selectedSectionId, {
                        ...currentSection,
                        items: updated,
                      });
                    }}
                    placeholder="Author name"
                    className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                  <input
                    type="text"
                    value={t.role}
                    onChange={(e) => {
                      const updated = [...(currentSection as TestimonialsSection).items];
                      updated[idx] = { ...updated[idx], role: e.target.value };
                      onUpdateSection(selectedSectionId, {
                        ...currentSection,
                        items: updated,
                      });
                    }}
                    placeholder="Role or City"
                    className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                </div>

                <textarea
                  rows={2}
                  value={t.quote}
                  onChange={(e) => {
                    const updated = [...(currentSection as TestimonialsSection).items];
                    updated[idx] = { ...updated[idx], quote: e.target.value };
                    onUpdateSection(selectedSectionId, {
                      ...currentSection,
                      items: updated,
                    });
                  }}
                  placeholder="Review quote..."
                  className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white resize-none"
                />

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-slate-500 font-bold mr-1">Rating:</span>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => {
                          const updated = [...(currentSection as TestimonialsSection).items];
                          updated[idx] = { ...updated[idx], rating: star };
                          onUpdateSection(selectedSectionId, {
                            ...currentSection,
                            items: updated,
                          });
                        }}
                        className="cursor-pointer"
                      >
                        <Star
                          className={`w-3.5 h-3.5 ${
                            star <= (t.rating || 5)
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openImagePicker('testimonial', t.id, t.avatarUrl)}
                    className="text-[11px] h-7 px-2"
                  >
                    Change Avatar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- 8. CTA SECTION ---------------- */}
      {currentSection?.type === 'cta' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Main Headline
            </label>
            <input
              type="text"
              value={(currentSection as CtaSection).headline}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  headline: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subheadline
            </label>
            <textarea
              rows={2}
              value={(currentSection as CtaSection).subheadline}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subheadline: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Button Label
              </label>
              <input
                type="text"
                value={(currentSection as CtaSection).buttonLabel}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    buttonLabel: e.target.value,
                  })
                }
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Target Section ID
              </label>
              <input
                type="text"
                value={(currentSection as CtaSection).targetSectionId || 'contact'}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    targetSectionId: e.target.value,
                  })
                }
                placeholder="e.g. contact"
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* ---------------- 9. CONTACT SECTION ---------------- */}
      {currentSection?.type === 'contact' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section Title
            </label>
            <input
              type="text"
              value={(currentSection as ContactSection).title}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  title: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Subtitle
            </label>
            <input
              type="text"
              value={(currentSection as ContactSection).subtitle || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  subtitle: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={(currentSection as ContactSection).email || ''}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    email: e.target.value,
                  })
                }
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={(currentSection as ContactSection).phone || ''}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    phone: e.target.value,
                  })
                }
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Physical Location / Address
            </label>
            <input
              type="text"
              value={(currentSection as ContactSection).address || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  address: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Opening Hours
            </label>
            <input
              type="text"
              value={(currentSection as ContactSection).hours || ''}
              onChange={(e) =>
                onUpdateSection(selectedSectionId, {
                  ...currentSection,
                  hours: e.target.value,
                })
              }
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
            />
          </div>

          {/* Form Enabled toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-xs font-bold text-slate-800 block">
                Interactive Contact Form
              </span>
              <span className="text-[10px] text-slate-500">
                Display direct inquiry message form in this section
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={(currentSection as ContactSection).formEnabled !== false}
                onChange={(e) =>
                  onUpdateSection(selectedSectionId, {
                    ...currentSection,
                    formEnabled: e.target.checked,
                  })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        </div>
      )}

      {/* Image Picker Modal */}
      <ImagePickerModal
        isOpen={imagePickerOpen}
        title={
          imageTarget?.type === 'product'
            ? 'Replace Product Photo'
            : imageTarget?.type === 'about'
            ? 'Replace Story Photo'
            : imageTarget?.type === 'testimonial'
            ? 'Replace Review Avatar'
            : 'Replace Hero Banner Image'
        }
        currentImageUrl={imageTarget?.currentUrl || ''}
        onClose={() => {
          setImagePickerOpen(false);
          setImageTarget(null);
        }}
        onSelectImage={handleApplyImage}
      />
    </div>
  );
};
