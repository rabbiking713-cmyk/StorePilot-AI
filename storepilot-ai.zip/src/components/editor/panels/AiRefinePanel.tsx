import React, { useState } from 'react';
import { Sparkles, Send, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { WebsiteSpec } from '../../../types/websiteSpec';
import { refineWebsite, REFINEMENT_CHIPS } from '../../../services/ai/aiWebsiteService';
import { Button } from '../../ui/Button';

interface AiRefinePanelProps {
  spec: WebsiteSpec;
  onApplyRefinedSpec: (newSpec: WebsiteSpec) => void;
}

export const AiRefinePanel: React.FC<AiRefinePanelProps> = ({
  spec,
  onApplyRefinedSpec,
}) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRefine = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setError(null);

    try {
      const refined = await refineWebsite(spec, prompt.trim());
      onApplyRefinedSpec(refined);
      setPrompt('');
    } catch (err: any) {
      console.error('Refinement failed:', err);
      setError(
        err.message ||
          'Failed to refine website with AI. Please check your internet connection and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleChipClick = (chip: string) => {
    setPrompt(chip);
  };

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center gap-1.5 mb-1">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Natural-Language AI Refinement
          </h3>
        </div>
        <p className="text-[11px] text-slate-500">
          Describe any changes in plain English. StorePilot AI will update your site while preserving your content. You can always Undo if you don't like the result.
        </p>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
          <div>
            <span className="font-semibold block">Refinement Alert</span>
            <p className="text-[11px] text-rose-700">{error}</p>
          </div>
        </div>
      )}

      {/* Prompt input */}
      <div className="space-y-2">
        <textarea
          rows={3}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g. 'Make the hero more premium and luxurious with darker tones', 'Add more punchy copy to features', 'Focus on streetwear vibes'..."
          disabled={loading}
          className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 leading-relaxed resize-none disabled:opacity-60 bg-white"
        />

        <Button
          variant="primary"
          size="sm"
          onClick={handleRefine}
          disabled={loading || !prompt.trim()}
          className="w-full text-xs flex items-center justify-center gap-2 py-2.5"
        >
          {loading ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Gemini AI is refining your website...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5" />
              <span>Apply AI Refinement</span>
            </>
          )}
        </Button>
      </div>

      {/* Suggested Quick Refinement Chips */}
      <div className="pt-2 border-t border-slate-100">
        <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
          Quick Refinement Ideas
        </span>
        <div className="flex flex-wrap gap-1.5">
          {REFINEMENT_CHIPS.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleChipClick(chip)}
              disabled={loading}
              className="text-[11px] font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer disabled:opacity-50 text-left"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
