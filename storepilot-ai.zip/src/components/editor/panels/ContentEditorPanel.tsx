import React from 'react';
import { Briefcase, FileText, Tag, Users } from 'lucide-react';
import { WebsiteSpec } from '../../../types/websiteSpec';

interface ContentEditorPanelProps {
  spec: WebsiteSpec;
  onUpdateSpec: (updated: Partial<WebsiteSpec>) => void;
}

export const ContentEditorPanel: React.FC<ContentEditorPanelProps> = ({
  spec,
  onUpdateSpec,
}) => {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
          Brand & Identity
        </h3>
        <p className="text-[11px] text-slate-500">
          Core information used across your website titles, search previews, and branding.
        </p>
      </div>

      <div className="space-y-4">
        {/* Site Name */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Website Project Name
          </label>
          <input
            type="text"
            value={spec.siteName}
            onChange={(e) => onUpdateSpec({ siteName: e.target.value })}
            placeholder="e.g. KONTROL ACCRA"
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
          />
        </div>

        {/* Business Legal/Brand Name */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Business Display Name
          </label>
          <input
            type="text"
            value={spec.businessName}
            onChange={(e) => onUpdateSpec({ businessName: e.target.value })}
            placeholder="e.g. KONTROL Streetwear"
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
          />
        </div>

        {/* Tagline */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Brand Tagline / Slogan
          </label>
          <input
            type="text"
            value={spec.tagline || ''}
            onChange={(e) => onUpdateSpec({ tagline: e.target.value })}
            placeholder="e.g. Defining youth urban culture in West Africa"
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
          />
        </div>

        {/* Business Description */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Business Description
          </label>
          <textarea
            rows={3}
            value={spec.businessDescription || ''}
            onChange={(e) => onUpdateSpec({ businessDescription: e.target.value })}
            placeholder="Describe what your business does, your values, and unique value proposition..."
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900 leading-relaxed resize-none"
          />
        </div>

        {/* Industry */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Industry / Category
          </label>
          <input
            type="text"
            value={spec.industry || ''}
            onChange={(e) => onUpdateSpec({ industry: e.target.value })}
            placeholder="e.g. Fashion & Streetwear"
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
          />
        </div>

        {/* Target Audience */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Target Audience
          </label>
          <input
            type="text"
            value={spec.targetAudience || ''}
            onChange={(e) => onUpdateSpec({ targetAudience: e.target.value })}
            placeholder="e.g. Fashion-conscious youth aged 16-28 in Ghana"
            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
          />
        </div>
      </div>
    </div>
  );
};
