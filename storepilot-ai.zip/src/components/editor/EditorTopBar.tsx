import React, { useState } from 'react';
import {
  Undo2,
  Redo2,
  Monitor,
  Tablet,
  Smartphone,
  Maximize2,
  Save,
  CheckCircle2,
  ArrowLeft,
  Loader2,
  Globe,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { useSubscription } from '../../context/SubscriptionContext';
import { UpgradePaywallModal } from '../subscription/UpgradePaywallModal';

interface EditorTopBarProps {
  siteName: string;
  isDemo?: boolean;
  isDirty: boolean;
  isSaving: boolean;
  canUndo: boolean;
  canRedo: boolean;
  viewport: 'desktop' | 'tablet' | 'mobile';
  publishStatus?: 'draft' | 'published' | 'changes_unpublished';
  publishedSlug?: string;
  customDomain?: string;
  onUndo: () => void;
  onRedo: () => void;
  onChangeViewport: (v: 'desktop' | 'tablet' | 'mobile') => void;
  onExpandPreview: () => void;
  onSave: () => void;
  onExit: () => void;
  onOpenPublish?: () => void;
  onOpenDomainSettings?: () => void;
}

export const EditorTopBar: React.FC<EditorTopBarProps> = ({
  siteName,
  isDemo = false,
  isDirty,
  isSaving,
  canUndo,
  canRedo,
  viewport,
  publishStatus = 'draft',
  publishedSlug,
  customDomain,
  onUndo,
  onRedo,
  onChangeViewport,
  onExpandPreview,
  onSave,
  onExit,
  onOpenPublish,
  onOpenDomainSettings,
}) => {
  const { canPublish } = useSubscription();
  const [showPaywallModal, setShowPaywallModal] = useState(false);

  return (
    <>
      <header className="h-14 border-b border-slate-200 bg-white px-3 sm:px-4 flex items-center justify-between shrink-0 z-30 shadow-2xs">
      {/* 1. Left: Exit & Site Identity */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onExit}
          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          title="Exit Visual Editor"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black text-xs shrink-0 shadow-xs">
            SP
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900 truncate max-w-[140px] sm:max-w-[200px]">
                {siteName || 'Untitled Website'}
              </span>
              {isDemo && (
                <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.2 rounded border border-amber-200">
                  Demo
                </span>
              )}
            </div>
            {/* Status indicator */}
            <div className="flex items-center gap-1.5 text-[10px]">
              {isSaving ? (
                <span className="text-indigo-600 flex items-center gap-1 font-medium">
                  <Loader2 className="w-2.5 h-2.5 animate-spin" />
                  Saving...
                </span>
              ) : isDirty ? (
                <span className="text-amber-600 flex items-center gap-1 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Unsaved changes
                </span>
              ) : (
                <span className="text-emerald-600 flex items-center gap-1 font-medium">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  All changes saved
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Center: Undo/Redo & Viewport switcher */}
      <div className="hidden md:flex items-center gap-4">
        {/* Undo / Redo */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          <button
            type="button"
            disabled={!canUndo}
            onClick={onUndo}
            title="Undo (Ctrl+Z)"
            className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:hover:text-slate-600 rounded cursor-pointer"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={!canRedo}
            onClick={onRedo}
            title="Redo (Ctrl+Shift+Z)"
            className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:hover:text-slate-600 rounded cursor-pointer"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Viewport switcher */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          <button
            type="button"
            onClick={() => onChangeViewport('desktop')}
            className={`p-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewport === 'desktop'
                ? 'bg-white text-indigo-600 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Desktop Viewport"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">Desktop</span>
          </button>
          <button
            type="button"
            onClick={() => onChangeViewport('tablet')}
            className={`p-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewport === 'tablet'
                ? 'bg-white text-indigo-600 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Tablet Viewport (768px)"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">Tablet</span>
          </button>
          <button
            type="button"
            onClick={() => onChangeViewport('mobile')}
            className={`p-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewport === 'mobile'
                ? 'bg-white text-indigo-600 shadow-2xs'
                : 'text-slate-500 hover:text-slate-900'
            }`}
            title="Mobile Viewport (390px)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">Mobile</span>
          </button>
        </div>
      </div>

      {/* 3. Right: Fullscreen Preview & Save Button */}
      <div className="flex items-center gap-2">
        {/* Undo/Redo for mobile/small screens */}
        <div className="flex md:hidden items-center bg-slate-100 p-0.5 rounded-lg">
          <button
            type="button"
            disabled={!canUndo}
            onClick={onUndo}
            className="p-1 text-slate-600 disabled:opacity-30"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={!canRedo}
            onClick={onRedo}
            className="p-1 text-slate-600 disabled:opacity-30"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Expand Preview */}
        <button
          type="button"
          onClick={onExpandPreview}
          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          title="Open Fullscreen Preview"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {/* Publish / Republish / Published Button */}
        {onOpenPublish && (
          <div className="flex items-center gap-1">
            {!canPublish ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPaywallModal(true)}
                className="text-xs flex items-center gap-1.5 px-3 py-1.5 transition-colors cursor-pointer border-indigo-200 text-indigo-700 bg-indigo-50/80 hover:bg-indigo-100 font-semibold"
                title="Publishing requires an upgrade to Professional or Agency"
              >
                <Lock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Upgrade to Publish</span>
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={onOpenPublish}
                className={`text-xs flex items-center gap-1.5 px-3 py-1.5 transition-colors cursor-pointer ${
                  publishStatus === 'published'
                    ? 'border-emerald-300 text-emerald-700 bg-emerald-50/80 hover:bg-emerald-100 font-semibold'
                    : publishStatus === 'changes_unpublished'
                    ? 'border-amber-300 text-amber-800 bg-amber-50/80 hover:bg-amber-100 font-semibold'
                    : 'border-indigo-200 text-indigo-700 bg-indigo-50/60 hover:bg-indigo-100 font-medium'
                }`}
                title={
                  publishStatus === 'published'
                    ? 'Website is live! Click to manage or view link'
                    : publishStatus === 'changes_unpublished'
                    ? 'You have unpublished changes in your draft'
                    : 'Publish website to a live public URL'
                }
              >
                <Globe
                  className={`w-3.5 h-3.5 ${
                    publishStatus === 'published'
                      ? 'text-emerald-600'
                      : publishStatus === 'changes_unpublished'
                      ? 'text-amber-600'
                      : 'text-indigo-600'
                  }`}
                />
                <span>
                  {publishStatus === 'published'
                    ? 'Published'
                    : publishStatus === 'changes_unpublished'
                    ? 'Republish'
                    : 'Publish'}
                </span>
              </Button>
            )}

            {canPublish && publishedSlug && (
              <a
                href={`/site/${publishedSlug}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer hidden sm:flex items-center"
                title="Open live website in new tab"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            {/* Custom Domain Quick Button */}
            <button
              type="button"
              onClick={() => {
                if (!canPublish) {
                  setShowPaywallModal(true);
                } else if (onOpenDomainSettings) {
                  onOpenDomainSettings();
                }
              }}
              className={`px-2.5 py-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 text-xs ${
                customDomain
                  ? 'border-indigo-200 bg-indigo-50/70 text-indigo-700 hover:bg-indigo-100 font-mono text-[11px]'
                  : 'border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100'
              }`}
              title={
                !canPublish
                  ? 'Custom domains require Professional or Agency'
                  : customDomain
                  ? `Custom Domain: ${customDomain} — Manage settings`
                  : 'Connect a Custom Domain'
              }
            >
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden md:inline truncate max-w-[120px]">
                {customDomain || 'Domain'}
              </span>
            </button>
          </div>
        )}

        {/* Save Changes */}
        <Button
          variant="primary"
          size="sm"
          onClick={onSave}
          disabled={isSaving}
          className="text-xs flex items-center gap-1.5 px-3 py-1.5"
        >
          {isSaving ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Save className="w-3.5 h-3.5" />
          )}
          <span>{isSaving ? 'Saving' : 'Save Changes'}</span>
        </Button>
      </div>
    </header>

    {/* Starter Plan Paywall Modal */}
    <UpgradePaywallModal
      isOpen={showPaywallModal}
      onClose={() => setShowPaywallModal(false)}
      triggerContext="publish"
    />
  </>
  );
};
