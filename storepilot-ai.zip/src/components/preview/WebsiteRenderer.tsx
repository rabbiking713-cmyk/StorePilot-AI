import React, { useState } from 'react';
import {
  WebsiteSpec,
  HeroSection,
  FeaturesSection,
  ProductsSection,
  AboutSection,
  TestimonialsSection,
  CtaSection,
  ContactSection,
} from '../../types/websiteSpec';
import {
  Sparkles,
  Shield,
  Zap,
  Truck,
  Star,
  Clock,
  Check,
  Heart,
  ArrowRight,
  Mail,
  Phone,
  MapPin,
  ShoppingBag,
  Menu,
  X,
  Send,
  CheckCircle2,
  Edit2,
} from 'lucide-react';
import { ViewportMode } from './DevicePreviewFrame';
import { useOptionalCart } from '../../context/CartContext';

export interface WebsiteRendererProps {
  spec: WebsiteSpec;
  viewport?: ViewportMode;
  className?: string;
  isInteractive?: boolean;
  isEditorMode?: boolean;
  selectedSectionId?: string | null;
  onSelectSection?: (sectionId: string) => void;
}

export const WebsiteRenderer: React.FC<WebsiteRendererProps> = ({
  spec,
  viewport: forcedViewport,
  className = '',
  isInteractive = true,
  isEditorMode = false,
  selectedSectionId = null,
  onSelectSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [localCartCount, setLocalCartCount] = useState(0);
  const [cartAlert, setCartAlert] = useState<string | null>(null);
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // Optional global Cart Context
  const optionalCart = useOptionalCart();
  const cartCount = optionalCart ? optionalCart.itemCount : localCartCount;

  // Sync currency symbol if products section has one
  React.useEffect(() => {
    if (optionalCart && spec.sections) {
      const prodSec = spec.sections.find((s) => s.type === 'products') as ProductsSection | undefined;
      if (prodSec?.currencySymbol) {
        optionalCart.setCurrencySymbol(prodSec.currencySymbol);
      }
    }
  }, [spec.sections, optionalCart]);

  // Dynamic viewport detection when viewport prop is omitted (e.g. live public website)
  const [detectedViewport, setDetectedViewport] = useState<ViewportMode>('desktop');
  React.useEffect(() => {
    if (forcedViewport) return;
    const handleResize = () => {
      if (typeof window === 'undefined') return;
      if (window.innerWidth < 768) {
        setDetectedViewport('mobile');
      } else if (window.innerWidth < 1024) {
        setDetectedViewport('tablet');
      } else {
        setDetectedViewport('desktop');
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [forcedViewport]);

  const viewport = forcedViewport || detectedViewport;
  const isMobile = viewport === 'mobile';
  const isTablet = viewport === 'tablet';
  const isDesktop = viewport === 'desktop';

  const { theme, header, sections, footer } = spec;

  const getFontFamilyClass = (font?: string) => {
    switch (font) {
      case 'serif':
        return 'font-serif';
      case 'mono':
        return 'font-mono';
      default:
        return 'font-sans';
    }
  };

  const scrollToSection = (sectionId: string) => {
    setMobileMenuOpen(false);
    if (!isInteractive) return;
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleAddToCart = (product: {
    id?: string;
    name: string;
    price: string;
    imageUrl?: string;
    badge?: string;
    category?: string;
  } | string) => {
    if (!isInteractive) return;

    if (typeof product === 'string') {
      if (optionalCart) {
        optionalCart.addItem({
          id: product,
          name: product,
          price: '0.00',
        });
      } else {
        setLocalCartCount((prev) => prev + 1);
        setCartAlert(`Added "${product}" to cart!`);
        setTimeout(() => setCartAlert(null), 3000);
      }
      return;
    }

    if (optionalCart) {
      optionalCart.addItem({
        id: product.id || product.name,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        badge: product.badge,
        category: product.category,
      });
    } else {
      setLocalCartCount((prev) => prev + 1);
      setCartAlert(`Added "${product.name}" to cart!`);
      setTimeout(() => setCartAlert(null), 3000);
    }
  };

  const renderIcon = (name?: string) => {
    switch (name) {
      case 'Shield':
        return <Shield className="w-5 h-5" />;
      case 'Zap':
        return <Zap className="w-5 h-5" />;
      case 'Truck':
        return <Truck className="w-5 h-5" />;
      case 'Star':
        return <Star className="w-5 h-5" />;
      case 'Clock':
        return <Clock className="w-5 h-5" />;
      case 'Check':
        return <Check className="w-5 h-5" />;
      case 'Heart':
        return <Heart className="w-5 h-5" />;
      case 'Sparkles':
      default:
        return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <div
      className={`w-full min-h-full bg-white text-slate-900 select-text overflow-x-hidden ${getFontFamilyClass(
        theme?.fontFamily
      )} ${className}`}
      style={{
        backgroundColor: theme?.backgroundColor || '#ffffff',
        color: theme?.textColor || '#0f172a',
      }}
    >
      {/* Toast Notification */}
      {cartAlert && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-medium animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{cartAlert}</span>
        </div>
      )}

      {/* 1. Header / Navigation */}
      <header
        onClick={() => isEditorMode && onSelectSection?.('header')}
        className={`sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100 transition-all ${
          isEditorMode && selectedSectionId === 'header'
            ? 'ring-2 ring-indigo-500 ring-offset-2'
            : isEditorMode
            ? 'hover:ring-1 hover:ring-indigo-300 cursor-pointer'
            : ''
        }`}
      >
        <div
          className={`mx-auto flex items-center justify-between transition-all ${
            isMobile
              ? 'px-4 h-14'
              : isTablet
              ? 'px-6 h-16 max-w-full'
              : 'max-w-7xl px-4 sm:px-6 lg:px-8 h-16'
          }`}
        >
          {/* Brand */}
          <div className="flex items-center gap-2.5 min-w-0">
            <span
              className={`font-extrabold tracking-tight truncate ${
                isMobile ? 'text-base max-w-[190px]' : 'text-lg'
              }`}
              style={{ color: theme?.primaryColor || '#0f172a' }}
            >
              {header?.brandName || spec.businessName}
            </span>
            {header?.tagline && !isMobile && (
              <span
                className={`text-xs text-slate-400 pl-3 border-l border-slate-200 truncate ${
                  isTablet ? 'hidden lg:inline-block max-w-[160px]' : 'hidden md:inline-block'
                }`}
              >
                {header.tagline}
              </span>
            )}
          </div>

          {/* Desktop/Tablet Nav Links */}
          {!isMobile && (
            <nav
              className={`flex items-center font-semibold text-slate-600 ${
                isTablet ? 'gap-4 text-xs' : 'gap-6 text-xs'
              }`}
            >
              {header?.navLinks?.map((link) => (
                <button
                  key={link.id || link.label}
                  onClick={() => scrollToSection(link.targetSectionId)}
                  className="hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap"
                >
                  {link.label}
                </button>
              ))}
            </nav>
          )}

          {/* Right Action / CTA & Cart */}
          {!isMobile && (
            <div className="flex items-center gap-3 shrink-0">
              {cartCount > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (optionalCart) {
                      optionalCart.openCart();
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-800 transition-colors cursor-pointer group shadow-2xs"
                  title="View Cart"
                  aria-label={`View Cart (${cartCount} items)`}
                >
                  <ShoppingBag className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                  <span>{cartCount}</span>
                </button>
              )}

              {header?.ctaButton && (
                <button
                  onClick={() => scrollToSection(header.ctaButton!.targetSectionId)}
                  className="px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-lg text-xs font-semibold text-white shadow-xs transition-opacity hover:opacity-90 cursor-pointer whitespace-nowrap"
                  style={{ backgroundColor: theme?.primaryColor || '#0f172a' }}
                >
                  {header.ctaButton.label}
                </button>
              )}
            </div>
          )}

          {/* Mobile Menu Toggle & Cart */}
          {isMobile && (
            <div className="flex items-center gap-2 shrink-0">
              {cartCount > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (optionalCart) {
                      optionalCart.openCart();
                    }
                  }}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-800 transition-colors cursor-pointer"
                  title="View Cart"
                  aria-label={`View Cart (${cartCount} items)`}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>{cartCount}</span>
                </button>
              )}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          )}
        </div>

        {/* Mobile Dropdown Nav */}
        {isMobile && mobileMenuOpen && (
          <div className="border-b border-slate-200 bg-white/95 backdrop-blur-md px-4 py-3 space-y-2 shadow-lg animate-in fade-in slide-in-from-top-1 duration-150">
            {header?.navLinks?.map((link) => (
              <button
                key={link.id || link.label}
                onClick={() => scrollToSection(link.targetSectionId)}
                className="block w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
            {cartCount > 0 && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  optionalCart?.openCart();
                }}
                className="w-full flex items-center justify-between py-2.5 px-3 rounded-lg text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" />
                  <span>View Shopping Cart</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-white text-[11px] font-bold text-slate-900 shadow-xs">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'}
                </span>
              </button>
            )}
            {header?.ctaButton && (
              <button
                onClick={() => scrollToSection(header.ctaButton!.targetSectionId)}
                className="w-full text-center py-2.5 mt-2 rounded-lg text-xs font-bold text-white shadow-xs cursor-pointer transition-opacity hover:opacity-95"
                style={{ backgroundColor: theme?.primaryColor || '#0f172a' }}
              >
                {header.ctaButton.label}
              </button>
            )}
          </div>
        )}
      </header>

      {/* 2. Main Content Sections */}
      <main>
        {sections.map((section, idx) => {
          if (section.hidden) return null;
          const sectionId = section.id || `section-${idx}`;
          const isSelected = isEditorMode && selectedSectionId === sectionId;

          const renderSectionInner = () => {
            switch (section.type) {
              case 'hero': {
                const hero = section as HeroSection;
                return (
                  <section
                    key={hero.id || idx}
                    id={hero.id || 'hero'}
                    className={`mx-auto overflow-hidden transition-all ${
                      isMobile
                        ? 'py-10 px-4 max-w-full'
                        : isTablet
                        ? 'py-14 px-6 max-w-full'
                        : 'py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl'
                    }`}
                  >
                    <div
                      className={
                        isMobile
                          ? 'flex flex-col gap-8'
                          : isTablet
                          ? 'grid grid-cols-12 gap-8 items-center'
                          : 'grid grid-cols-1 lg:grid-cols-12 gap-10 items-center'
                      }
                    >
                      <div
                        className={
                          isMobile
                            ? 'space-y-4'
                            : isTablet
                            ? 'col-span-7 space-y-4'
                            : 'lg:col-span-7 space-y-6'
                        }
                      >
                        {hero.badge && (
                          <div
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider"
                            style={{
                              backgroundColor: `${theme?.primaryColor || '#0f172a'}15`,
                              color: theme?.primaryColor || '#0f172a',
                            }}
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>{hero.badge}</span>
                          </div>
                        )}

                        <h1
                          className={`font-black tracking-tight leading-[1.15] break-words ${
                            isMobile
                              ? 'text-2xl sm:text-3xl'
                              : isTablet
                              ? 'text-3xl lg:text-4xl'
                              : 'text-3xl sm:text-5xl lg:text-6xl'
                          }`}
                        >
                          {hero.headline}
                        </h1>

                        <p
                          className={`text-slate-600 leading-relaxed break-words ${
                            isMobile
                              ? 'text-xs sm:text-sm'
                              : isTablet
                              ? 'text-sm'
                              : 'text-base sm:text-lg max-w-2xl'
                          }`}
                        >
                          {hero.subheadline}
                        </p>

                        <div
                          className={`flex items-center gap-3 pt-1 ${
                            isMobile
                              ? 'flex-col sm:flex-row w-full items-stretch sm:items-center'
                              : 'flex-wrap'
                          }`}
                        >
                          {hero.primaryCta && (
                            <button
                              onClick={() =>
                                scrollToSection(hero.primaryCta.targetSectionId || 'products')
                              }
                              className="px-6 py-3 rounded-xl text-xs sm:text-sm font-bold text-white shadow-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-2 cursor-pointer"
                              style={{
                                backgroundColor: theme?.primaryColor || '#0f172a',
                              }}
                            >
                              <span>{hero.primaryCta.label}</span>
                              <ArrowRight className="w-4 h-4" />
                            </button>
                          )}

                          {hero.secondaryCta && (
                            <button
                              onClick={() =>
                                scrollToSection(hero.secondaryCta!.targetSectionId || 'about')
                              }
                              className="px-5 py-3 rounded-xl text-xs sm:text-sm font-semibold border border-slate-300 hover:bg-slate-50 transition-colors cursor-pointer text-slate-800 text-center"
                            >
                              {hero.secondaryCta.label}
                            </button>
                          )}
                        </div>
                      </div>

                      <div
                        className={
                          isMobile
                            ? 'w-full'
                            : isTablet
                            ? 'col-span-5'
                            : 'lg:col-span-5'
                        }
                      >
                        <div
                          className={`relative rounded-2xl overflow-hidden shadow-xl border border-slate-200/80 bg-slate-100 ${
                            isMobile
                              ? 'aspect-16/10 w-full'
                              : isTablet
                              ? 'aspect-4/3 w-full'
                              : 'aspect-4/3 sm:aspect-16/10 lg:aspect-square'
                          }`}
                        >
                          {hero.imageUrl ? (
                            <img
                              src={hero.imageUrl}
                              alt={hero.headline}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.src =
                                  'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80';
                              }}
                            />
                          ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center bg-slate-50">
                              <Sparkles className="w-10 h-10 text-slate-400 mb-3" />
                              <p className="text-xs font-semibold text-slate-500">
                                {spec.businessName}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              case 'features': {
                const feat = section as FeaturesSection;
                return (
                  <section
                    key={feat.id || idx}
                    id={feat.id || 'features'}
                    className={`bg-slate-50 border-y border-slate-200/60 transition-all ${
                      isMobile
                        ? 'py-10 px-4'
                        : isTablet
                        ? 'py-14 px-6'
                        : 'py-16 sm:py-20 px-4 sm:px-6 lg:px-8'
                    }`}
                  >
                    <div className="max-w-7xl mx-auto">
                      <div
                        className={`text-center max-w-2xl mx-auto ${
                          isMobile ? 'mb-8' : 'mb-12'
                        }`}
                      >
                        <h2
                          className={`font-bold tracking-tight break-words ${
                            isMobile ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl'
                          }`}
                        >
                          {feat.title}
                        </h2>
                        {feat.subtitle && (
                          <p
                            className={`mt-2 text-slate-600 break-words ${
                              isMobile ? 'text-xs' : 'text-sm'
                            }`}
                          >
                            {feat.subtitle}
                          </p>
                        )}
                      </div>

                      <div
                        className={`grid gap-4 sm:gap-6 ${
                          isMobile
                            ? 'grid-cols-1'
                            : isTablet
                            ? 'grid-cols-2 md:grid-cols-3'
                            : 'grid-cols-1 md:grid-cols-3'
                        }`}
                      >
                        {feat.items?.map((item) => (
                          <div
                            key={item.id || item.title}
                            className="bg-white rounded-xl p-5 sm:p-6 border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
                          >
                            <div>
                              <div
                                className="w-10 h-10 rounded-lg flex items-center justify-center mb-4 shrink-0"
                                style={{
                                  backgroundColor: `${theme?.primaryColor || '#0f172a'}15`,
                                  color: theme?.primaryColor || '#0f172a',
                                }}
                              >
                                {renderIcon(item.iconName)}
                              </div>
                              <h3 className="text-base font-bold text-slate-900 mb-2 break-words">
                                {item.title}
                              </h3>
                              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed break-words">
                                {item.description}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </section>
                );
              }

              case 'products': {
                const prod = section as ProductsSection;
                return (
                  <section
                    key={prod.id || idx}
                    id={prod.id || 'products'}
                    className={`mx-auto transition-all ${
                      isMobile
                        ? 'py-10 px-4 max-w-full'
                        : isTablet
                        ? 'py-14 px-6 max-w-full'
                        : 'py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl'
                    }`}
                  >
                    <div
                      className={`flex justify-between gap-4 ${
                        isMobile
                          ? 'flex-col mb-6'
                          : 'flex-col sm:flex-row sm:items-end mb-10'
                      }`}
                    >
                      <div>
                        <h2
                          className={`font-bold tracking-tight break-words ${
                            isMobile ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl'
                          }`}
                        >
                          {prod.title}
                        </h2>
                        {prod.subtitle && (
                          <p
                            className={`mt-1.5 text-slate-600 break-words ${
                              isMobile ? 'text-xs' : 'text-sm'
                            }`}
                          >
                            {prod.subtitle}
                          </p>
                        )}
                      </div>
                      {prod.items?.length > 0 && (
                        <span className="text-xs font-semibold text-slate-500 shrink-0">
                          {prod.items.length} featured items
                        </span>
                      )}
                    </div>

                    <div
                      className={`grid gap-4 sm:gap-6 ${
                        isMobile
                          ? 'grid-cols-1'
                          : isTablet
                          ? 'grid-cols-2'
                          : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
                      }`}
                    >
                      {prod.items?.map((item) => (
                        <div
                          key={item.id || item.name}
                          className="group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                        >
                          <div>
                            <div className="relative aspect-4/3 bg-slate-100 overflow-hidden">
                              {item.imageUrl ? (
                                <img
                                  src={item.imageUrl}
                                  alt={item.name}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                  onError={(e) => {
                                    e.currentTarget.src =
                                      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80';
                                  }}
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-slate-400">
                                  <ShoppingBag className="w-8 h-8" />
                                </div>
                              )}

                              {item.badge && (
                                <span
                                  className="absolute top-3 left-3 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full text-white shadow-xs"
                                  style={{
                                    backgroundColor: theme?.accentColor || '#f59e0b',
                                  }}
                                >
                                  {item.badge}
                                </span>
                              )}
                            </div>

                            <div className="p-4 sm:p-5">
                              {item.category && (
                                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                                  {item.category}
                                </span>
                              )}
                              <h3 className="text-base font-bold text-slate-900 mt-1 break-words">
                                {item.name}
                              </h3>
                              <p className="text-xs text-slate-600 mt-1.5 line-clamp-2 leading-relaxed break-words">
                                {item.description}
                              </p>
                            </div>
                          </div>

                          <div className="p-4 sm:p-5 pt-0 flex items-center justify-between gap-3 border-t border-slate-100 mt-2">
                            <span className="text-base font-extrabold text-slate-900 truncate">
                              {item.price.startsWith('$') ||
                              item.price.startsWith('€') ||
                              item.price.startsWith('£') ||
                              item.price.startsWith('₵')
                                ? item.price
                                : `${prod.currencySymbol || '$'}${item.price}`}
                            </span>
                            <button
                              onClick={() => handleAddToCart(item)}
                              className="px-3.5 py-2 rounded-lg text-xs font-bold text-white shadow-xs hover:opacity-90 transition-opacity flex items-center gap-1.5 cursor-pointer shrink-0 min-h-[38px]"
                              style={{
                                backgroundColor: theme?.primaryColor || '#0f172a',
                              }}
                            >
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>{prod.ctaLabel || 'Add to Cart'}</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </section>
                );
              }

              case 'about': {
                const about = section as AboutSection;
                return (
                  <section
                    key={about.id || idx}
                    id={about.id || 'about'}
                    className={`bg-slate-50 border-t border-slate-200/80 transition-all ${
                      isMobile
                        ? 'py-10 px-4'
                        : isTablet
                        ? 'py-14 px-6'
                        : 'py-16 sm:py-24 px-4 sm:px-6 lg:px-8'
                    }`}
                  >
                    <div className="max-w-7xl mx-auto">
                      <div
                        className={
                          isMobile
                            ? 'flex flex-col gap-8'
                            : isTablet
                            ? 'grid grid-cols-12 gap-8 items-center'
                            : 'grid grid-cols-1 lg:grid-cols-12 gap-10 items-center'
                        }
                      >
                        <div
                          className={
                            isMobile
                              ? 'space-y-4'
                              : isTablet
                              ? 'col-span-7 space-y-4'
                              : 'lg:col-span-6 space-y-5'
                          }
                        >
                          <span
                            className="text-xs font-bold uppercase tracking-wider"
                            style={{ color: theme?.primaryColor || '#0f172a' }}
                          >
                            {about.title}
                          </span>
                          <h2
                            className={`font-black tracking-tight leading-tight break-words ${
                              isMobile
                                ? 'text-xl sm:text-2xl'
                                : 'text-2xl sm:text-4xl'
                            }`}
                          >
                            {about.headline}
                          </h2>
                          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line break-words">
                            {about.content}
                          </p>

                          {about.highlights && about.highlights.length > 0 && (
                            <div className="pt-2 space-y-2">
                              {about.highlights.map((h, hIdx) => (
                                <div
                                  key={hIdx}
                                  className="flex items-center gap-2 text-xs text-slate-700 font-medium"
                                >
                                  <CheckCircle2
                                    className="w-4 h-4 shrink-0"
                                    style={{ color: theme?.primaryColor || '#0f172a' }}
                                  />
                                  <span className="break-words">{h}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        <div
                          className={
                            isMobile
                              ? 'w-full'
                              : isTablet
                              ? 'col-span-5'
                              : 'lg:col-span-6'
                          }
                        >
                          <div
                            className={`rounded-2xl overflow-hidden shadow-lg border border-slate-200/80 bg-slate-100 ${
                              isMobile ? 'aspect-16/10' : 'aspect-4/3'
                            }`}
                          >
                            {about.imageUrl ? (
                              <img
                                src={about.imageUrl}
                                alt={about.headline}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.currentTarget.src =
                                    'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1000&q=80';
                                }}
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-slate-200/50 text-slate-400">
                                <Sparkles className="w-8 h-8" />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              case 'testimonials': {
                const test = section as TestimonialsSection;
                return (
                  <section
                    key={test.id || idx}
                    id={test.id || 'testimonials'}
                    className={`mx-auto transition-all ${
                      isMobile
                        ? 'py-10 px-4 max-w-full'
                        : isTablet
                        ? 'py-14 px-6 max-w-full'
                        : 'py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl'
                    }`}
                  >
                    <div
                      className={`text-center max-w-2xl mx-auto ${
                        isMobile ? 'mb-8' : 'mb-12'
                      }`}
                    >
                      <h2
                        className={`font-bold tracking-tight break-words ${
                          isMobile ? 'text-xl sm:text-2xl' : 'text-2xl sm:text-3xl'
                        }`}
                      >
                        {test.title}
                      </h2>
                      {test.subtitle && (
                        <p
                          className={`mt-2 text-slate-600 break-words ${
                            isMobile ? 'text-xs' : 'text-sm'
                          }`}
                        >
                          {test.subtitle}
                        </p>
                      )}
                    </div>

                    <div
                      className={`grid gap-4 sm:gap-6 ${
                        isMobile
                          ? 'grid-cols-1'
                          : isTablet
                          ? 'grid-cols-2'
                          : 'grid-cols-1 md:grid-cols-3'
                      }`}
                    >
                      {test.items?.map((item) => (
                        <div
                          key={item.id || item.author}
                          className="bg-white rounded-xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center gap-1 text-amber-400 mb-3">
                              {[...Array(item.rating || 5)].map((_, sIdx) => (
                                <Star key={sIdx} className="w-3.5 h-3.5 fill-amber-400" />
                              ))}
                            </div>
                            <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed break-words">
                              &ldquo;{item.quote}&rdquo;
                            </p>
                          </div>

                          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-3">
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white shrink-0"
                              style={{ backgroundColor: theme?.primaryColor || '#0f172a' }}
                            >
                              {item.author.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-slate-900 truncate">
                                {item.author}
                              </div>
                              <div className="text-[11px] text-slate-500 truncate">
                                {item.role}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </section>
                );
              }

              case 'cta': {
                const cta = section as CtaSection;
                return (
                  <section
                    key={cta.id || idx}
                    id={cta.id || 'cta'}
                    className={`mx-auto transition-all ${
                      isMobile
                        ? 'py-10 px-4 max-w-full'
                        : isTablet
                        ? 'py-14 px-6 max-w-full'
                        : 'py-16 sm:py-20 px-4 sm:px-6 lg:px-8 max-w-7xl'
                    }`}
                  >
                    <div
                      className={`text-center text-white shadow-xl relative overflow-hidden transition-all ${
                        isMobile
                          ? 'rounded-2xl p-6'
                          : isTablet
                          ? 'rounded-3xl p-8'
                          : 'rounded-3xl p-8 sm:p-12'
                      }`}
                      style={{ backgroundColor: theme?.primaryColor || '#0f172a' }}
                    >
                      <div className="relative z-10 max-w-2xl mx-auto space-y-4">
                        <h2
                          className={`font-extrabold tracking-tight break-words ${
                            isMobile
                              ? 'text-xl sm:text-2xl'
                              : 'text-2xl sm:text-4xl'
                          }`}
                        >
                          {cta.headline}
                        </h2>
                        <p className="text-xs sm:text-sm text-white/80 leading-relaxed break-words">
                          {cta.subheadline}
                        </p>
                        <div className="pt-3">
                          <button
                            onClick={() => scrollToSection(cta.targetSectionId || 'contact')}
                            className={`px-6 py-3 rounded-xl text-xs sm:text-sm font-bold bg-white text-slate-900 shadow-md hover:bg-slate-50 transition-colors cursor-pointer ${
                              isMobile ? 'w-full sm:w-auto' : ''
                            }`}
                          >
                            {cta.buttonLabel}
                          </button>
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              case 'contact': {
                const contact = section as ContactSection;
                return (
                  <section
                    key={contact.id || idx}
                    id={contact.id || 'contact'}
                    className={`bg-slate-50 border-t border-slate-200/80 transition-all ${
                      isMobile
                        ? 'py-10 px-4'
                        : isTablet
                        ? 'py-14 px-6'
                        : 'py-16 sm:py-24 px-4 sm:px-6 lg:px-8'
                    }`}
                  >
                    <div className="max-w-7xl mx-auto">
                      <div
                        className={
                          isMobile
                            ? 'flex flex-col gap-8'
                            : isTablet
                            ? 'grid grid-cols-12 gap-8'
                            : 'grid grid-cols-1 lg:grid-cols-12 gap-10'
                        }
                      >
                        <div
                          className={
                            isMobile
                              ? 'space-y-4'
                              : isTablet
                              ? 'col-span-5 space-y-5'
                              : 'lg:col-span-5 space-y-6'
                          }
                        >
                          <div>
                            <h2
                              className={`font-bold tracking-tight break-words ${
                                isMobile
                                  ? 'text-xl sm:text-2xl'
                                  : 'text-2xl sm:text-3xl'
                              }`}
                            >
                              {contact.title}
                            </h2>
                            {contact.subtitle && (
                              <p className="mt-2 text-xs sm:text-sm text-slate-600 break-words">
                                {contact.subtitle}
                              </p>
                            )}
                          </div>

                          <div className="space-y-3 text-xs text-slate-700">
                            {contact.email && (
                              <div className="flex items-center gap-3">
                                <Mail
                                  className="w-4 h-4 shrink-0"
                                  style={{ color: theme?.primaryColor || '#0f172a' }}
                                />
                                <span className="font-mono break-all">{contact.email}</span>
                              </div>
                            )}

                            {contact.phone && (
                              <div className="flex items-center gap-3">
                                <Phone
                                  className="w-4 h-4 shrink-0"
                                  style={{ color: theme?.primaryColor || '#0f172a' }}
                                />
                                <span className="break-words">{contact.phone}</span>
                              </div>
                            )}

                            {contact.address && (
                              <div className="flex items-center gap-3">
                                <MapPin
                                  className="w-4 h-4 shrink-0"
                                  style={{ color: theme?.primaryColor || '#0f172a' }}
                                />
                                <span className="break-words">{contact.address}</span>
                              </div>
                            )}

                            {contact.hours && (
                              <div className="flex items-center gap-3">
                                <Clock
                                  className="w-4 h-4 shrink-0"
                                  style={{ color: theme?.primaryColor || '#0f172a' }}
                                />
                                <span className="break-words">{contact.hours}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <div
                          className={
                            isMobile
                              ? 'w-full'
                              : isTablet
                              ? 'col-span-7'
                              : 'lg:col-span-7'
                          }
                        >
                          <div className="bg-white rounded-2xl p-5 sm:p-8 border border-slate-200/80 shadow-xs">
                            {contactSubmitted ? (
                              <div className="py-8 text-center space-y-2">
                                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                                <h3 className="text-base font-bold text-slate-900">
                                  Message Sent
                                </h3>
                                <p className="text-xs text-slate-600">
                                  Thank you for contacting {spec.businessName}. We will reply shortly.
                                </p>
                              </div>
                            ) : (
                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  setContactSubmitted(true);
                                }}
                                className="space-y-4"
                              >
                                <div
                                  className={`grid gap-4 ${
                                    isMobile ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'
                                  }`}
                                >
                                  <div>
                                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                                      Your Name
                                    </label>
                                    <input
                                      type="text"
                                      required
                                      placeholder="Jane Doe"
                                      className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                                      Email Address
                                    </label>
                                    <input
                                      type="email"
                                      required
                                      placeholder="jane@example.com"
                                      className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900"
                                    />
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                                    Message
                                  </label>
                                  <textarea
                                    rows={4}
                                    required
                                    placeholder="How can we help your business?"
                                    className="w-full text-xs p-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900"
                                  />
                                </div>

                                <button
                                  type="submit"
                                  className="w-full py-2.5 rounded-lg text-xs font-bold text-white shadow-xs transition-opacity hover:opacity-90 flex items-center justify-center gap-2 cursor-pointer"
                                  style={{
                                    backgroundColor: theme?.primaryColor || '#0f172a',
                                  }}
                                >
                                  <Send className="w-3.5 h-3.5" />
                                  <span>Send Message</span>
                                </button>
                              </form>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                );
              }

              default:
                return null;
            }
          };

          return (
            <div
              key={sectionId}
              onClick={(e) => {
                if (isEditorMode && onSelectSection) {
                  e.stopPropagation();
                  onSelectSection(sectionId);
                }
              }}
              className={`relative transition-all ${
                isSelected
                  ? 'ring-2 ring-indigo-500 ring-offset-2'
                  : isEditorMode
                  ? 'hover:ring-1 hover:ring-indigo-300 cursor-pointer'
                  : ''
              }`}
            >
              {isEditorMode && isSelected && (
                <div className="absolute top-3 right-4 z-30 bg-indigo-600 text-white text-[10px] font-bold px-2.5 py-1 rounded shadow-md pointer-events-none flex items-center gap-1.5 uppercase tracking-wider">
                  <Edit2 className="w-3 h-3" />
                  Editing {section.type}
                </div>
              )}
              {renderSectionInner()}
            </div>
          );
        })}
      </main>

      {/* 3. Footer */}
      <footer
        onClick={() => isEditorMode && onSelectSection?.('footer')}
        className={`border-t border-slate-200 bg-white transition-all relative ${
          isMobile
            ? 'py-8 px-4'
            : isTablet
            ? 'py-10 px-6'
            : 'py-12 px-4 sm:px-6 lg:px-8'
        } ${
          isEditorMode && selectedSectionId === 'footer'
            ? 'ring-2 ring-indigo-500 ring-offset-2'
            : isEditorMode
            ? 'hover:ring-1 hover:ring-indigo-300 cursor-pointer'
            : ''
        }`}
      >
        <div
          className={`max-w-7xl mx-auto flex gap-6 text-xs text-slate-500 ${
            isMobile
              ? 'flex-col items-center text-center'
              : isTablet
              ? 'flex-col sm:flex-row items-center justify-between'
              : 'flex-col md:flex-row items-center justify-between'
          }`}
        >
          <div className={isMobile ? 'text-center' : ''}>
            <span
              className="text-base font-extrabold"
              style={{ color: theme?.primaryColor || '#0f172a' }}
            >
              {footer?.brandName || spec.businessName}
            </span>
            {footer?.description && (
              <p className="mt-1 text-slate-500 max-w-sm leading-relaxed break-words">
                {footer.description}
              </p>
            )}
          </div>

          <div
            className={`flex flex-wrap items-center gap-4 sm:gap-6 font-medium ${
              isMobile ? 'justify-center' : ''
            }`}
          >
            {footer?.quickLinks?.map((q, qIdx) => (
              <a
                key={qIdx}
                href={q.href || '#'}
                className="hover:text-slate-900 transition-colors"
              >
                {q.label}
              </a>
            ))}
          </div>

          <div className="text-[11px] text-slate-400 text-center">
            {footer?.copyright ||
              `© ${new Date().getFullYear()} ${spec.businessName}. Powered by StorePilot AI.`}
          </div>
        </div>
      </footer>

      {/* Floating Cart Pill for easy access while browsing */}
      {cartCount > 0 && isInteractive && (
        <aside
          aria-label="Floating cart shortcut"
          className="fixed bottom-5 left-5 z-40 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <button
            type="button"
            onClick={() => {
              if (optionalCart) {
                optionalCart.openCart();
              }
            }}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-full text-white font-semibold text-xs shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/20 backdrop-blur-md"
            style={{ backgroundColor: theme?.primaryColor || '#0f172a' }}
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              <span className="absolute -top-1.5 -right-2 px-1.5 min-w-[16px] h-4 rounded-full bg-amber-400 text-slate-950 font-black text-[9px] flex items-center justify-center leading-none">
                {cartCount}
              </span>
            </div>
            <span>View Cart</span>
            {optionalCart && optionalCart.subtotal > 0 && (
              <span className="opacity-90 pl-1 border-l border-white/25 font-bold">
                {optionalCart.currencySymbol}
                {optionalCart.subtotal.toFixed(2)}
              </span>
            )}
          </button>
        </aside>
      )}
    </div>
  );
};
