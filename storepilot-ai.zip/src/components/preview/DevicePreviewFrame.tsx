import React, { useRef, useState, useEffect } from 'react';
import { Lock, Smartphone, Tablet, Monitor } from 'lucide-react';

export type ViewportMode = 'desktop' | 'tablet' | 'mobile';

interface DevicePreviewFrameProps {
  viewport: ViewportMode;
  children: React.ReactNode;
  siteName?: string;
  className?: string;
}

export const DevicePreviewFrame: React.FC<DevicePreviewFrameProps> = ({
  viewport,
  children,
  siteName = 'My StorePilot Site',
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number>(1);
  const contentRef = useRef<HTMLDivElement>(null);
  const [contentHeight, setContentHeight] = useState<number>(0);

  // Target frame widths
  const TARGET_WIDTHS = {
    mobile: 390,
    tablet: 768,
    desktop: 1280,
  };

  // Frame outer widths including bezel
  const FRAME_OUTER_WIDTHS = {
    mobile: 414, // 390 + 24 bezel
    tablet: 792, // 768 + 24 bezel
    desktop: 1280,
  };

  useEffect(() => {
    const updateScale = () => {
      if (!containerRef.current) return;
      const containerWidth = containerRef.current.clientWidth;

      if (viewport === 'mobile') {
        const neededWidth = FRAME_OUTER_WIDTHS.mobile + 24;
        if (containerWidth < neededWidth) {
          setScale(Math.max(0.4, (containerWidth - 24) / FRAME_OUTER_WIDTHS.mobile));
        } else {
          setScale(1);
        }
      } else if (viewport === 'tablet') {
        const neededWidth = FRAME_OUTER_WIDTHS.tablet + 32;
        if (containerWidth < neededWidth) {
          setScale(Math.max(0.4, (containerWidth - 32) / FRAME_OUTER_WIDTHS.tablet));
        } else {
          setScale(1);
        }
      } else {
        setScale(1);
      }
    };

    updateScale();
    const ro = new ResizeObserver(updateScale);
    if (containerRef.current) {
      ro.observe(containerRef.current);
    }
    window.addEventListener('resize', updateScale);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', updateScale);
    };
  }, [viewport]);

  // Keep track of content height for scaled wrapper
  useEffect(() => {
    if (!contentRef.current) return;
    const updateHeight = () => {
      if (contentRef.current) {
        setContentHeight(contentRef.current.offsetHeight);
      }
    };

    updateHeight();
    const ro = new ResizeObserver(updateHeight);
    ro.observe(contentRef.current);

    return () => ro.disconnect();
  }, [viewport, children]);

  const slug = siteName
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 20) || 'mysite';

  // Desktop Frame
  if (viewport === 'desktop') {
    return (
      <div ref={containerRef} className={`w-full flex justify-center ${className}`}>
        <div className="w-full max-w-[1340px] shadow-2xl rounded-xl border border-slate-700/60 overflow-hidden bg-white transition-all duration-300">
          {/* Browser Chrome Header */}
          <div className="h-9 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between gap-4 select-none shrink-0">
            {/* Window control dots */}
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-3 h-3 rounded-full bg-rose-500/80 border border-rose-600/50" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80 border border-amber-600/50" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80 border border-emerald-600/50" />
            </div>

            {/* Address bar */}
            <div className="flex-1 max-w-md mx-auto h-6 bg-slate-950/70 rounded-md border border-slate-800 px-3 flex items-center justify-center gap-1.5 text-[11px] text-slate-400 font-mono truncate">
              <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
              <span className="truncate">https://{slug}.storepilot.live</span>
            </div>

            {/* Viewport badge */}
            <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 shrink-0">
              <Monitor className="w-3 h-3" />
              <span>100% · Desktop</span>
            </div>
          </div>

          {/* Website Canvas */}
          <div className="w-full bg-white">{children}</div>
        </div>
      </div>
    );
  }

  // Tablet Frame (768px internal viewport)
  if (viewport === 'tablet') {
    const outerWidth = FRAME_OUTER_WIDTHS.tablet;
    const isScaled = scale < 0.99;

    return (
      <div
        ref={containerRef}
        className={`w-full flex flex-col items-center justify-start py-4 ${className}`}
      >
        <div
          style={{
            width: isScaled ? outerWidth * scale : outerWidth,
            height: isScaled && contentHeight ? contentHeight * scale : 'auto',
          }}
          className="flex justify-center transition-all duration-200"
        >
          <div
            ref={contentRef}
            style={{
              width: outerWidth,
              transform: isScaled ? `scale(${scale})` : undefined,
              transformOrigin: 'top center',
            }}
            className="bg-slate-900 p-3 rounded-[32px] shadow-2xl border-4 border-slate-800/90 ring-1 ring-white/10 shrink-0"
          >
            {/* Tablet Camera Bezel */}
            <div className="h-6 flex items-center justify-center select-none">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-800 ring-1 ring-slate-700/60 shadow-inner" />
            </div>

            {/* Tablet Screen Canvas (Exactly 768px) */}
            <div className="w-[768px] min-w-[768px] max-w-[768px] rounded-[20px] overflow-hidden bg-white shadow-inner">
              {children}
            </div>

            {/* Tablet Bottom Bezel */}
            <div className="h-4 flex items-center justify-center">
              <div className="w-20 h-1 bg-slate-800 rounded-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Mobile Frame (390px internal viewport)
  const outerWidth = FRAME_OUTER_WIDTHS.mobile;
  const isScaled = scale < 0.99;

  return (
    <div
      ref={containerRef}
      className={`w-full flex flex-col items-center justify-start py-4 ${className}`}
    >
      <div
        style={{
          width: isScaled ? outerWidth * scale : outerWidth,
          height: isScaled && contentHeight ? contentHeight * scale : 'auto',
        }}
        className="flex justify-center transition-all duration-200"
      >
        <div
          ref={contentRef}
          style={{
            width: outerWidth,
            transform: isScaled ? `scale(${scale})` : undefined,
            transformOrigin: 'top center',
          }}
          className="bg-slate-950 p-3 rounded-[48px] shadow-2xl border-4 border-slate-900 ring-1 ring-slate-800 shrink-0"
        >
          {/* Dynamic Island / Top Bezel */}
          <div className="h-7 flex items-center justify-center select-none pt-1">
            <div className="w-28 h-4.5 bg-slate-900 rounded-full flex items-center justify-end px-2.5 shadow-inner border border-slate-800/80">
              <div className="w-2 h-2 rounded-full bg-slate-950 ring-1 ring-slate-800" />
            </div>
          </div>

          {/* Mobile Screen Canvas (Exactly 390px) */}
          <div className="w-[390px] min-w-[390px] max-w-[390px] rounded-[34px] overflow-hidden bg-white shadow-inner">
            {children}
          </div>

          {/* Bottom Home Indicator */}
          <div className="h-6 flex items-center justify-center">
            <div className="w-32 h-1 bg-slate-500/40 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
