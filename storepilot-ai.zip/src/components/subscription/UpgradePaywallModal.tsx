import React, { useState } from 'react';
import {
  Sparkles,
  Check,
  X,
  Globe,
  ShieldCheck,
  Loader2,
  ArrowRight,
  Zap,
  Lock,
} from 'lucide-react';
import { useSubscription } from '../../context/SubscriptionContext';
import { Button } from '../ui/Button';

export interface UpgradePaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue?: () => void;
  title?: string;
  subtitle?: string;
  triggerContext?: 'create_website' | 'publish' | 'copy_link' | 'general';
}

export const UpgradePaywallModal: React.FC<UpgradePaywallModalProps> = ({
  isOpen,
  onClose,
  onContinue,
  title,
  subtitle,
  triggerContext = 'general',
}) => {
  const { upgradeToPlan, isUpgrading, plan: currentPlan } = useSubscription();
  const [selectedPlanForUpgrade, setSelectedPlanForUpgrade] = useState<'professional' | 'agency' | null>(null);
  const [upgradeError, setUpgradeError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleUpgrade = async (plan: 'professional' | 'agency') => {
    setUpgradeError(null);
    setSelectedPlanForUpgrade(plan);
    try {
      const res = await upgradeToPlan(plan);
      if (!res.success && res.error) {
        setUpgradeError(res.error);
      }
    } catch (err: any) {
      setUpgradeError(err?.message || 'Payment initiation failed. Please try again.');
    } finally {
      setSelectedPlanForUpgrade(null);
    }
  };

  const defaultTitle =
    triggerContext === 'publish'
      ? 'Publish & Share Your Website'
      : triggerContext === 'copy_link'
      ? 'Upgrade to Share Live Link'
      : 'Turn your idea into a real website';

  const defaultSubtitle =
    triggerContext === 'publish'
      ? 'Starter allows you to build and preview your draft privately. Upgrade to Professional or Agency to publish it to a live public URL and share it with the world.'
      : triggerContext === 'copy_link'
      ? 'Public sharing links require an active subscription. Upgrade to Professional or Agency to publish and distribute your live website.'
      : 'You can build and preview your website for free. Upgrade to Professional or Agency to publish it and share it with the world.';

  const displayTitle = title || defaultTitle;
  const displaySubtitle = subtitle || defaultSubtitle;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-start justify-between bg-gradient-to-b from-indigo-50/50 to-white">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-indigo-600/20">
              <Sparkles className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900">{displayTitle}</h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                  Plans & Publishing
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-500 leading-relaxed max-w-lg">
                {displaySubtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Free Starter Note Banner */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>
              Current Plan: <strong className="text-slate-900 capitalize">{currentPlan} ($0/month)</strong> — Build & preview privately
            </span>
          </div>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            Publishing requires an active paid tier
          </span>
        </div>

        {/* Plan Cards */}
        <div className="p-6 overflow-y-auto space-y-4">
          {upgradeError && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
              <Lock className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{upgradeError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Professional Tier */}
            <div className="rounded-xl border-2 border-slate-200 hover:border-indigo-400 p-5 bg-white flex flex-col justify-between transition-all duration-200 shadow-xs hover:shadow-md">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    Professional
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    Most Popular
                  </span>
                </div>

                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-slate-900">$29</span>
                  <span className="text-xs text-slate-500 font-medium">/ month</span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  Ideal for creators, businesses, and entrepreneurs launching their live public website.
                </p>

                <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>Publish up to 5 live websites</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Public StorePilot URLs & live sharing</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Custom domain connection</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Full AI Marketing Studio</span>
                  </div>
                </div>
              </div>

              <div className="pt-5">
                <Button
                  variant="primary"
                  size="md"
                  onClick={() => handleUpgrade('professional')}
                  disabled={isUpgrading}
                  isLoading={isUpgrading && selectedPlanForUpgrade === 'professional'}
                  className="w-full text-xs font-semibold py-2.5 flex items-center justify-center gap-1.5"
                >
                  <span>Upgrade to Professional</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>

            {/* Agency / Studio Tier */}
            <div className="rounded-xl border-2 border-indigo-500 bg-indigo-50/20 p-5 flex flex-col justify-between relative shadow-sm">
              <div className="absolute -top-3 right-4 bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow-xs">
                Agency & Studio
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                    Agency / Studio
                  </span>
                </div>

                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-slate-900">$79</span>
                  <span className="text-xs text-slate-500 font-medium">/ month</span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  Best value for agencies, studios, and high-volume operators managing client stores.
                </p>

                <div className="space-y-2 pt-2 border-t border-indigo-100 text-xs text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>Unlimited live published websites</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Unlimited public sharing links</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Unlimited custom domains</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>White-label & high priority AI</span>
                  </div>
                </div>
              </div>

              <div className="pt-5">
                <Button
                  variant="primary"
                  size="md"
                  onClick={() => handleUpgrade('agency')}
                  disabled={isUpgrading}
                  isLoading={isUpgrading && selectedPlanForUpgrade === 'agency'}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2.5 flex items-center justify-center gap-1.5"
                >
                  <span>Upgrade to Agency</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-slate-400 text-center sm:text-left">
            Secure billing handled via Paystack. Cancel anytime.
          </p>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              disabled={isUpgrading}
              className="text-xs w-full sm:w-auto"
            >
              Cancel
            </Button>

            {onContinue && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  onClose();
                  onContinue();
                }}
                disabled={isUpgrading}
                className="text-xs font-medium w-full sm:w-auto border-indigo-200 text-indigo-700 bg-white hover:bg-indigo-50"
              >
                Continue Exploring
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
