import React, { useState } from 'react';
import {
  Check,
  Shield,
  Sparkles,
  AlertCircle,
  CreditCard,
  Calendar,
  RefreshCw,
  ExternalLink,
  Code,
  CheckCircle2,
} from 'lucide-react';
import { useSubscription } from '../../context/SubscriptionContext';
import { useAuth } from '../../context/AuthContext';
import { STOREPILOT_PLANS, SubscriptionPlan } from '../../types/subscription';
import { Button } from '../ui/Button';

export const SubscriptionView: React.FC = () => {
  const { user } = useAuth();
  const {
    plan: currentPlan,
    subscriptionStatus,
    isDeveloper,
    developerTier,
    isLoading,
    isUpgrading,
    paystackConfigured,
    currentPeriodEnd,
    upgradeToPlan,
    cancelSubscription,
    refreshSubscription,
    verificationMessage,
    clearVerificationMessage,
  } = useSubscription();

  const [selectedPlanForAction, setSelectedPlanForAction] = useState<SubscriptionPlan | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const [cancelSuccess, setCancelSuccess] = useState(false);

  const handleUpgrade = async (plan: 'professional' | 'agency') => {
    setActionError(null);
    setSelectedPlanForAction(plan);
    try {
      const res = await upgradeToPlan(plan);
      if (!res.success && res.error) {
        setActionError(res.error);
      }
    } catch (err: any) {
      setActionError(err.message || 'Payment initiation failed.');
    } finally {
      setSelectedPlanForAction(null);
    }
  };

  const handleCancel = async () => {
    if (!window.confirm('Are you sure you want to cancel your paid subscription? Your current projects and websites will be preserved, but access to AI generation and custom domains will end after the current billing period.')) {
      return;
    }
    setIsCancelling(true);
    setActionError(null);
    try {
      const res = await cancelSubscription();
      if (res.success) {
        setCancelSuccess(true);
        setTimeout(() => setCancelSuccess(false), 5000);
      } else if (res.error) {
        setActionError(res.error);
      }
    } catch (err: any) {
      setActionError(err.message || 'Cancellation request failed.');
    } finally {
      setIsCancelling(false);
    }
  };

  const formattedPeriodEnd = currentPeriodEnd
    ? new Date(currentPeriodEnd).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      })
    : 'Ongoing Active Access';

  const planList = [
    STOREPILOT_PLANS.starter,
    STOREPILOT_PLANS.professional,
    STOREPILOT_PLANS.agency,
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Subscription & Plan Management
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-slate-500">
            Authoritative billing tiers, feature access gating, and Paystack integration.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => refreshSubscription()}
          icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          disabled={isLoading}
        >
          Refresh Status
        </Button>
      </div>

      {/* Verification Success Message */}
      {verificationMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start justify-between gap-3 text-emerald-900">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold">Subscription Updated</p>
              <p className="text-xs text-emerald-800 mt-0.5">{verificationMessage}</p>
            </div>
          </div>
          <button
            onClick={clearVerificationMessage}
            className="text-emerald-700 hover:text-emerald-900 text-xs font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-start justify-between gap-3 text-rose-900">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold">Subscription Action Failed</p>
              <p className="text-xs text-rose-800 mt-0.5">{actionError}</p>
            </div>
          </div>
          <button
            onClick={() => setActionError(null)}
            className="text-rose-700 hover:text-rose-900 text-xs font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Cancellation Notice Banner */}
      {cancelSuccess && (
        <div className="p-4 rounded-xl bg-slate-100 border border-slate-300 flex items-start gap-2.5 text-slate-900">
          <CheckCircle2 className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold">Subscription Cancelled</p>
            <p className="text-xs text-slate-600 mt-0.5">
              Your subscription will remain active until the end of your billing cycle. No data has been deleted.
            </p>
          </div>
        </div>
      )}

      {/* Current Plan Status Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Your Current Plan:
              </span>
              {isDeveloper ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-900 border border-purple-200">
                  <Code className="w-3 h-3 text-purple-700" />
                  Developer Access (Agency Tier)
                </span>
              ) : (
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                    currentPlan === 'agency'
                      ? 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                      : currentPlan === 'professional'
                      ? 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                      : 'bg-slate-100 text-slate-800 border border-slate-200'
                  }`}
                >
                  {STOREPILOT_PLANS[currentPlan].name}
                </span>
              )}

              <span
                className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                  subscriptionStatus === 'active'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : subscriptionStatus === 'cancelled'
                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}
              >
                Status: {subscriptionStatus.toUpperCase()}
              </span>
            </div>

            <p className="text-xs text-slate-600 max-w-xl">
              {isDeveloper
                ? 'Your authenticated Firebase account is granted internal developer access for StorePilot development and QA testing. All Professional and Agency/Studio capabilities are unlocked server-side without requiring Paystack billing.'
                : STOREPILOT_PLANS[currentPlan].description}
            </p>
          </div>

          {/* Plan Details & Cancellation */}
          <div className="flex flex-wrap items-center gap-4 border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6">
            {!isDeveloper && (
              <div>
                <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Renewal / Period:
                </div>
                <div className="text-xs font-bold text-slate-900 mt-0.5">
                  {currentPlan === 'starter' ? 'Free Forever' : formattedPeriodEnd}
                </div>
              </div>
            )}

            {!isDeveloper && (currentPlan === 'professional' || currentPlan === 'agency') && subscriptionStatus === 'active' && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleCancel}
                isLoading={isCancelling}
                className="text-xs text-rose-700 border-rose-200 hover:bg-rose-50 hover:text-rose-800"
              >
                Cancel Subscription
              </Button>
            )}
          </div>
        </div>

        {/* Server & Paystack Gateway Status Indicator */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              Paystack Gateway:{' '}
              {paystackConfigured ? (
                <span className="font-semibold text-emerald-700">Configured Server-Side</span>
              ) : (
                <span className="font-semibold text-amber-700">
                  Not configured (PAYSTACK_SECRET_KEY required for live checkout)
                </span>
              )}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-slate-400 shrink-0" />
            <span>Server-side verification strictly enforced on every protected route</span>
          </div>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Available Plans</h3>
          <p className="text-xs text-slate-500">
            Select the tier that aligns with your website creation and brand scaling needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          {planList.map((p) => {
            const isCurrent = !isDeveloper && currentPlan === p.id;
            const isDevCurrent = isDeveloper && p.id === 'agency';

            return (
              <div
                key={p.id}
                className={`rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all bg-white ${
                  p.primary
                    ? 'border-2 border-slate-900 shadow-md relative'
                    : isCurrent || isDevCurrent
                    ? 'border-2 border-indigo-500 shadow-xs'
                    : 'border border-slate-200 shadow-xs'
                }`}
              >
                {p.primary && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-extrabold px-3 py-0.5 rounded-full uppercase tracking-wider">
                    {p.badge}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-base font-extrabold text-slate-900">{p.name}</span>
                    <span className="text-[11px] font-semibold text-slate-500">{p.badge}</span>
                  </div>

                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="text-4xl font-extrabold text-slate-900 tabular-nums">
                      {p.priceFormatted}
                    </span>
                    <span className="text-xs font-semibold text-slate-500">{p.billingPeriod}</span>
                  </div>

                  <p className="mt-3 text-xs text-slate-600 leading-relaxed min-h-[36px]">
                    {p.description}
                  </p>

                  <div className="mt-6 pt-6 border-t border-slate-100 space-y-2.5">
                    <span className="text-xs font-bold text-slate-900 block">
                      Included capabilities:
                    </span>
                    {p.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 pt-4 border-t border-slate-100">
                  {isDeveloper ? (
                    <Button
                      variant={p.id === 'agency' ? 'primary' : 'outline'}
                      className="w-full justify-center text-xs"
                      disabled
                    >
                      {p.id === 'agency' ? 'Developer Access (Active)' : 'Included in Dev Access'}
                    </Button>
                  ) : isCurrent ? (
                    <Button
                      variant="outline"
                      className="w-full justify-center text-xs border-emerald-300 text-emerald-800 bg-emerald-50/50"
                      disabled
                    >
                      Current Plan
                    </Button>
                  ) : p.id === 'starter' ? (
                    <Button
                      variant="outline"
                      className="w-full justify-center text-xs"
                      disabled={currentPlan !== 'starter'}
                    >
                      Start Free
                    </Button>
                  ) : (
                    <Button
                      variant={p.primary ? 'primary' : 'outline'}
                      className="w-full justify-center text-xs"
                      isLoading={isUpgrading && selectedPlanForAction === p.id}
                      onClick={() => handleUpgrade(p.id as 'professional' | 'agency')}
                    >
                      {p.id === 'professional' ? 'Upgrade to Professional' : 'Upgrade to Agency'}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
