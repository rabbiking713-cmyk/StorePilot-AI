import React, { useState } from 'react';
import { ROADMAP_PHASES } from '../../config/roadmap';
import { RoadmapPhase } from '../../types';
import { CheckCircle2, Clock, ChevronRight } from 'lucide-react';

interface RoadmapSectionProps {
  selectedPhaseNumber?: number;
}

export const RoadmapSection: React.FC<RoadmapSectionProps> = ({ selectedPhaseNumber }) => {
  const [activePhaseIndex, setActivePhaseIndex] = useState<number>(
    selectedPhaseNumber !== undefined ? selectedPhaseNumber : 0
  );

  React.useEffect(() => {
    if (selectedPhaseNumber !== undefined) {
      setActivePhaseIndex(selectedPhaseNumber);
    }
  }, [selectedPhaseNumber]);

  const selectedPhase: RoadmapPhase = ROADMAP_PHASES[activePhaseIndex] || ROADMAP_PHASES[0];

  return (
    <section id="roadmap" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Execution Strategy
          </p>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            12-Phase Master Roadmap
          </h2>
          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            StorePilot AI is engineered methodically. We do not claim features are built before their respective phase is implemented and validated.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Phase Selector List (Left 5 col) */}
          <div className="lg:col-span-5 border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 max-h-[580px] overflow-y-auto">
            {ROADMAP_PHASES.map((p, idx) => {
              const isActive = idx === activePhaseIndex;
              const isCurrentBuild = p.phase === 0;

              return (
                <button
                  key={p.phase}
                  onClick={() => setActivePhaseIndex(idx)}
                  className={`w-full text-left p-4 transition-colors flex items-center justify-between cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'bg-white hover:bg-slate-50 text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : isCurrentBuild
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      P{p.phase}
                    </span>
                    <div>
                      <div
                        className={`text-sm font-semibold truncate ${
                          isActive ? 'text-white' : 'text-slate-900'
                        }`}
                      >
                        {p.title}
                      </div>
                      <div
                        className={`text-xs truncate max-w-[200px] sm:max-w-xs ${
                          isActive ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        {p.status === 'active' ? 'Active in Current Release' : 'Planned'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isCurrentBuild ? (
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-emerald-300' : 'text-emerald-600'
                        }`}
                      />
                    ) : (
                      <Clock
                        className={`w-3.5 h-3.5 shrink-0 ${
                          isActive ? 'text-slate-300' : 'text-slate-400'
                        }`}
                      />
                    )}
                    <ChevronRight
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-white' : 'text-slate-400'
                      }`}
                    />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Detailed Inspector Card (Right 7 col) */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-8">
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold bg-slate-900 text-white px-2.5 py-1 rounded">
                  Phase {selectedPhase.phase}
                </span>
                <span className="text-xs font-medium text-slate-500">
                  {selectedPhase.estimatedTiming || 'Future Implementation'}
                </span>
              </div>
              <span
                className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                  selectedPhase.status === 'active'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {selectedPhase.status === 'active' ? 'Currently Implemented' : 'Scheduled'}
              </span>
            </div>

            <div className="mt-6">
              <h3 className="text-2xl font-bold text-slate-900">
                {selectedPhase.title}
              </h3>
              <p className="mt-3 text-base text-slate-700 leading-relaxed font-medium">
                {selectedPhase.shortDesc}
              </p>

              <div className="mt-6 pt-6 border-t border-slate-200 space-y-4">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Engineering Scope & Deliverables
                  </h4>
                  <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                    {selectedPhase.details}
                  </p>
                </div>

                {selectedPhase.phase === 0 ? (
                  <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-1">
                    <p className="font-bold">Phase 0 Status: Ready & Operating</p>
                    <p>
                      This web application serves as the verified foundation: responsive UI layout, authenticated session state, project workspace, and modular architecture.
                    </p>
                  </div>
                ) : (
                  <div className="p-4 rounded-lg bg-white border border-slate-200 text-xs text-slate-600 space-y-1">
                    <p className="font-bold text-slate-900">
                      Why not implemented in Phase 0?
                    </p>
                    <p>
                      In adherence to Phase 0 constraints, we avoid mock stubs or fake AI outputs. Phase {selectedPhase.phase} will be implemented with real logic in its designated engineering cycle.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
