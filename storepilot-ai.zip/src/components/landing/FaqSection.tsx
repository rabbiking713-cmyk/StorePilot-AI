import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FaqItem {
  q: string;
  a: string;
}

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      q: 'What is StorePilot AI?',
      a: 'StorePilot AI is an AI-powered website-building and marketing web platform designed to help business owners, creators, and entrepreneurs turn ideas into professional, high-converting online presences through natural language prompts and intuitive visual customization.',
    },
    {
      q: 'Is StorePilot AI a mobile application (Android/iOS) or a website?',
      a: 'StorePilot AI is strictly a modern, responsive web application accessible in any standard web browser on desktop, laptop, tablet, and mobile devices (targeted for storepilot.ai). It is NOT a native Android/iOS app, does not require an APK download, and runs smoothly in Google Chrome, Safari, Firefox, and Edge.',
    },
    {
      q: 'What is currently available in Phase 0?',
      a: 'Phase 0 provides the production foundation: responsive web application layout, user authentication architecture (Firebase Cloud Auth ready + local development session handling), a personalized user dashboard, interactive website project management, and clean modular code structured for the subsequent 12 development phases.',
    },
    {
      q: 'Why can I not generate a live website or make payments yet?',
      a: 'In accordance with our engineering discipline, we do not add fake AI responses, simulated payment gateways, or mock builders that pretend to work. Real AI website generation will be introduced in Phase 1, visual editing in Phase 2, and real Paystack subscription processing in Phase 8.',
    },
    {
      q: 'How is authentication configured?',
      a: 'StorePilot AI includes a clean AuthService abstraction integrated with the official Firebase SDK. If your Firebase project credentials are provided in environment variables, it uses live Firebase Cloud Auth. Otherwise, it operates with local session management for testing without breaking.',
    },
    {
      q: 'Will my websites be able to use custom domains?',
      a: 'Yes. In Phase 4 (Publishing & Domains), users will be able to connect custom domains (like yourbrand.com) or publish instantly to a StorePilot subdomain with automated SSL security certificates.',
    },
  ];

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Clear Answers
          </p>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            Everything you need to know about StorePilot AI and our current Phase 0 foundation.
          </p>
        </div>

        <div className="mt-12 space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.q}
                className="border border-slate-200 rounded-xl overflow-hidden transition-all bg-white"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-slate-900">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-slate-900' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
