import React, { useState } from 'react';
import { Navbar } from './Navbar';
import { Hero } from './Hero';
import { Capabilities } from './Capabilities';
import { RoadmapSection } from './RoadmapSection';
import { PricingSection } from './PricingSection';
import { FaqSection } from './FaqSection';
import { Footer } from './Footer';
import { AuthModal } from '../auth/AuthModal';
import { FirebaseConfigStatusModal } from '../auth/FirebaseConfigStatusModal';
import { useAuth } from '../../context/AuthContext';

interface LandingPageProps {
  onGoToDashboard: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGoToDashboard }) => {
  const { user, openAuthModal } = useAuth();
  const [selectedRoadmapPhase, setSelectedRoadmapPhase] = useState<number>(0);

  const handleGetStarted = () => {
    if (user) {
      onGoToDashboard();
    } else {
      openAuthModal('signup');
    }
  };

  const handleLearnMorePhase = (phaseNum: number) => {
    setSelectedRoadmapPhase(phaseNum);
    const element = document.getElementById('roadmap');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectPlan = (plan: string) => {
    if (user) {
      onGoToDashboard();
    } else {
      openAuthModal('signup');
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
      <Navbar onNavigateToDashboard={onGoToDashboard} />

      <main className="flex-1">
        <Hero
          onGetStarted={handleGetStarted}
          onExploreRoadmap={() => {
            const el = document.getElementById('roadmap');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        <Capabilities onLearnMorePhase={handleLearnMorePhase} />

        <RoadmapSection selectedPhaseNumber={selectedRoadmapPhase} />

        <PricingSection onSelectPlan={handleSelectPlan} />

        <FaqSection />
      </main>

      <Footer />

      {/* Auth & Config Modals */}
      <AuthModal />
      <FirebaseConfigStatusModal />
    </div>
  );
};
