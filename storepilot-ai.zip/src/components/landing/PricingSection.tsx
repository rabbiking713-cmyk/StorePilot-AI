import React from 'react';
import { Check, Shield, CreditCard } from 'lucide-react';
import { Button } from '../ui/Button';

interface PricingSectionProps {
  onSelectPlan: (plan: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  const plans = [
    {
      name: 'Starter',
      badge: 'Free Tier',
      price: '$0',
      period: '/ month',
      desc: 'Everything you need to test the foundation and set up your initial business website project.',
      features: [
        'Responsive Web Application Dashboard',
        'Website project creation & management',
        'Persistent user session handling',
        'Firebase Cloud Auth architecture',
        'Phase 1 AI Builder priority waitlist',
      ],
      cta: 'Start Free',
      primary: false,
    },
    {
      name: 'Professional',
      badge: 'Most Popular',
      price: '$29',
      period: '/ month',
      desc: 'AI website generation, custom domains, and automated marketing campaigns.',
      features: [
        'Natural Language Prompt Website Builder',
        'Custom domain hosting (.com / storepilot.ai)',
        'Visual block editor & style customizer',
        'AI Marketing Studio',
        'Paystack automated billing & renewals',
      ],
      cta: 'Upgrade to Professional',
      primary: true,
    },
    {
      name: 'Agency / Studio',
      badge: 'For Scaling Teams',
      price: '$79',
      period: '/ month',
      desc: 'Unlimited client websites, advanced brand kit memory, and digital marketplace seller access.',
      features: [
        'Unlimited active business websites',
        'White-label preview links',
        'Marketplace template selling access',
        'Multi-currency Paystack checkout',
        'Dedicated customer success channels',
      ],
      cta: 'Upgrade to Agency',
      primary: false,
    },
  ];

  return (
    <section id="pricing" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Plans & Subscriptions
          </p>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Transparent pricing designed for scale
          </h2>
          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            Secure recurring subscriptions powered by Paystack. Start free to build your foundation, and unlock full AI generation and custom domains whenever you are ready.
          </p>
        </div>

        {/* Notice banner */}
        <div className="mt-8 max-w-2xl mx-auto p-3 rounded-lg bg-indigo-50/70 border border-indigo-200 flex items-center justify-center gap-2 text-xs text-indigo-900 font-medium">
          <CreditCard className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>Paystack automated billing with instant activation & server-side plan verification.</span>
        </div>

        {/* Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all ${
                p.primary
                  ? 'bg-white border-2 border-slate-900 shadow-md relative'
                  : 'bg-white border border-slate-200 shadow-xs'
              }`}
            >
              {p.primary && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[11px] font-bold px-3 py-0.5 rounded-full uppercase tracking-wider">
                  Recommended Tier
                </div>
              )}

              <div>
                <div className="flex items-center justify-between">
                  <span className="text-base font-bold text-slate-900">{p.name}</span>
                  <span className="text-xs text-slate-500 font-medium">{p.badge}</span>
                </div>

                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-slate-900 tabular-nums">
                    {p.price}
                  </span>
                  <span className="text-xs font-medium text-slate-500">{p.period}</span>
                </div>

                <p className="mt-3 text-xs text-slate-600 leading-relaxed">{p.desc}</p>

                <div className="mt-6 pt-6 border-t border-slate-100 space-y-3">
                  <span className="text-xs font-semibold text-slate-900 block">
                    Included capabilities:
                  </span>
                  {p.features.map((f) => (
                    <div key={f} className="flex items-start gap-2 text-xs text-slate-600">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4">
                <Button
                  variant={p.primary ? 'primary' : 'outline'}
                  className="w-full justify-center text-xs"
                  onClick={() => onSelectPlan(p.name)}
                >
                  {p.cta}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
