import React from 'react';
import { Sparkles, Sliders, Megaphone, ArrowUpRight } from 'lucide-react';

interface CapabilitiesProps {
  onLearnMorePhase: (phaseNum: number) => void;
}

export const Capabilities: React.FC<CapabilitiesProps> = ({ onLearnMorePhase }) => {
  return (
    <section id="capabilities" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Product Capabilities & Horizon
          </p>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            How StorePilot AI transforms ideas into living digital stores.
          </h2>
          <p className="mt-4 text-base text-slate-600 leading-relaxed">
            The platform is structured in distinct phases. Phase 0 delivers our core responsive web foundation. Here is what is being engineered for upcoming releases.
          </p>
        </div>

        {/* Feature Bento Grid */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Card 1: AI Prompt Builder (Large 7 col) */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-6 sm:p-8 flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-4">
                <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  01. Prompt-to-Website Engine
                </span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                  Phase 1 Release
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
                Describe your business. We generate structure, copy, and layout.
              </h3>
              <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                Rather than wrestling with complex design tools or generic blank templates, users input their business vision. The engine extracts domain semantics, generates navigation routes, responsive product catalogs, and tailored marketing copy.
              </p>
            </div>

            {/* Visual Preview */}
            <div className="mt-6 rounded-lg border border-slate-200 overflow-hidden bg-slate-100 aspect-16/9 relative">
              <img
                src="/src/assets/images/feature_builder_canvas_1790188719930.jpg"
                alt="StorePilot AI builder canvas interface concept"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end p-4">
                <p className="text-xs text-white/90 font-medium">
                  Structured prompt intake pipeline & JSON schema generation
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Data schema drafted in Phase 0 codebase
              </span>
              <button
                onClick={() => onLearnMorePhase(1)}
                className="text-xs font-semibold text-slate-900 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
              >
                Inspect Phase 1 Spec <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Card 2: Marketing Studio (5 col) */}
          <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 sm:p-8 flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-4">
                <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                  <Megaphone className="w-4 h-4 text-blue-600" />
                  02. AI Marketing Studio
                </span>
                <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                  Phase 5 Release
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
                Campaigns, ad copy, and social content synced to your store.
              </h3>
              <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                A great website needs qualified visitors. The Marketing Studio reads your website catalog to generate launch campaigns, promotional calendars, and targeted advertisements.
              </p>
            </div>

            <div className="mt-6 rounded-lg border border-slate-200 overflow-hidden bg-slate-100 aspect-4/3 relative">
              <img
                src="/src/assets/images/feature_marketing_studio_1790188731405.jpg"
                alt="StorePilot AI marketing studio preview"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end p-4">
                <p className="text-xs text-white/90 font-medium">
                  Multi-channel social & ad copy orchestrator
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Scheduled for Phase 5
              </span>
              <button
                onClick={() => onLearnMorePhase(5)}
                className="text-xs font-semibold text-slate-900 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
              >
                Inspect Phase 5 Spec <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Row 2: Visual Editor & Publishing highlights */}
          <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs">
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
              <Sliders className="w-4 h-4 text-slate-700" />
              <span className="font-semibold text-slate-900">03. Visual Canvas & Section Customizer</span>
              <span className="text-slate-300">·</span>
              <span className="font-mono text-slate-600">Phase 2</span>
            </div>
            <h4 className="text-lg font-bold text-slate-900">
              Live block-level editing without touching raw HTML
            </h4>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Fine-tune copy, swap imagery, reorder sections, and adjust color palettes with immediate visual feedback across desktop, tablet, and mobile viewports.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
              Designed for non-technical business founders and agency creators alike.
            </div>
          </div>

          <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs">
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
              <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-[10px]">
                ✓
              </span>
              <span className="font-semibold text-slate-900">04. Paystack & Custom Domains</span>
              <span className="text-slate-300">·</span>
              <span className="font-mono text-slate-600">Phase 4 & Phase 8</span>
            </div>
            <h4 className="text-lg font-bold text-slate-900">
              Global custom domains & secure Paystack subscriptions
            </h4>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Host on fast global edge networks, connect your domain (e.g. storepilot.ai or your own brand), and collect payments via trusted African & global Paystack gateways.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
              Billing architecture prepared; no live charges during Phase 0 preview.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
