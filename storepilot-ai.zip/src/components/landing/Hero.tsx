import React from 'react';
import { ArrowRight, Check, Compass, Layout } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../context/AuthContext';

interface HeroProps {
  onGetStarted: () => void;
  onExploreRoadmap: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted, onExploreRoadmap }) => {
  const { user } = useAuth();

  return (
    <section id="overview" className="relative pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden">
      {/* Subtle background grid pattern */}
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#f1f5f9_1px,transparent_1px),linear-gradient(to_bottom,#f1f5f9_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-70" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          {/* Phase 0 Foundation Notice */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700 mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Phase 0: Architecture & Foundation Active</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-500">storepilot.ai</span>
          </div>

          {/* Requested Exact Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight text-balance leading-[1.12]">
            Build your business website with AI.
          </h1>

          {/* Requested Exact Supporting Text */}
          <p className="mt-6 text-lg sm:text-xl text-slate-600 leading-relaxed max-w-2xl mx-auto text-balance">
            Describe what you want. StorePilot AI will help you turn your idea into a professional online presence.
          </p>

          {/* CTAs */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button
              size="lg"
              variant="primary"
              onClick={onGetStarted}
              icon={<ArrowRight className="w-4 h-4" />}
            >
              {user ? 'Open Your Dashboard' : 'Get Started Free'}
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={onExploreRoadmap}
              icon={<Compass className="w-4 h-4 text-slate-500" />}
            >
              Explore 12-Phase Roadmap
            </Button>
          </div>

          {/* Core Foundation Highlights */}
          <div className="mt-8 pt-6 border-t border-slate-200/80 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              Responsive Web Platform (Desktop & Mobile)
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              Firebase Auth Ready
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              Clean Modular Architecture
            </span>
          </div>
        </div>

        {/* Hero Marquee Preview */}
        <div className="mt-14 max-w-5xl mx-auto">
          <div className="rounded-xl border border-slate-200/80 bg-white shadow-xl shadow-slate-200/50 overflow-hidden">
            {/* Browser window chrome bar */}
            <div className="bg-slate-100/90 border-b border-slate-200 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-slate-300" />
                <div className="w-3 h-3 rounded-full bg-slate-300" />
                <div className="w-3 h-3 rounded-full bg-slate-300" />
              </div>
              <div className="bg-white border border-slate-200 text-slate-600 rounded-md px-4 py-1 text-xs font-mono max-w-xs truncate flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                https://storepilot.ai/preview/sample-store
              </div>
              <div className="text-xs text-slate-400 font-mono hidden sm:block">
                Responsive Viewport: 1440×900
              </div>
            </div>

            {/* Generated Image Showcase */}
            <div className="relative aspect-16/9 bg-slate-50 overflow-hidden">
              <img
                src="/src/assets/images/hero_website_preview_1790188702757.jpg"
                alt="StorePilot AI generated website preview showcasing a modern boutique business online presence"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  // Fallback container if local asset failed
                  e.currentTarget.style.display = 'none';
                }}
              />
              {/* Overlay banner describing the preview */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md border border-slate-200/80 p-3 sm:p-4 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Layout className="w-3.5 h-3.5 text-slate-700" />
                    Target Generation Model: Complete Multi-Page Business Site
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Phase 0 provides the interactive dashboard and project manager. Prompt-driven AI generation arrives in Phase 1.
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded">
                    Phase 1 Pipeline
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
