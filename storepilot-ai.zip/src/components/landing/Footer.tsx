import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
              SP
            </span>
            <span className="text-sm font-bold text-slate-900 tracking-tight">
              StorePilot AI
            </span>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs text-slate-500">
              Web Application Foundation (Phase 0)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-500">
            <a href="#overview" className="hover:text-slate-900 transition-colors">
              Overview
            </a>
            <a href="#capabilities" className="hover:text-slate-900 transition-colors">
              Capabilities
            </a>
            <a href="#roadmap" className="hover:text-slate-900 transition-colors">
              12-Phase Roadmap
            </a>
            <a href="#pricing" className="hover:text-slate-900 transition-colors">
              Pricing Plans
            </a>
            <a href="#faq" className="hover:text-slate-900 transition-colors">
              FAQ
            </a>
          </div>

          <div className="text-xs text-slate-500">
            Targeting{' '}
            <span className="font-mono text-slate-700 font-semibold">storepilot.ai</span>
            {' '}— Responsive Web Platform
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} StorePilot AI. All rights reserved.
          </div>
          <div>
            Zero native APKs or mobile apps. Engineered purely as a responsive web experience.
          </div>
        </div>
      </div>
    </footer>
  );
};
