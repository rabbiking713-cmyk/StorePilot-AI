import React from 'react';
import { ShieldCheck, AlertCircle, Key, Server, Terminal } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import { firebaseConfigState } from '../../services/firebase/firebaseConfig';

export const FirebaseConfigStatusModal: React.FC = () => {
  const { isConfigModalOpen, closeConfigModal, isFirebaseConfigured } = useAuth();

  const envRequirements = [
    { key: 'VITE_FIREBASE_API_KEY', desc: 'Firebase Web API Key', present: !firebaseConfigState.missingKeys.includes('VITE_FIREBASE_API_KEY') },
    { key: 'VITE_FIREBASE_PROJECT_ID', desc: 'GCP / Firebase Project ID', present: !firebaseConfigState.missingKeys.includes('VITE_FIREBASE_PROJECT_ID') },
    { key: 'VITE_FIREBASE_APP_ID', desc: 'Firebase Application ID', present: !firebaseConfigState.missingKeys.includes('VITE_FIREBASE_APP_ID') },
    { key: 'VITE_FIREBASE_AUTH_DOMAIN', desc: 'OAuth redirect domain', present: !!import.meta.env.VITE_FIREBASE_AUTH_DOMAIN },
  ];

  return (
    <Modal
      isOpen={isConfigModalOpen}
      onClose={closeConfigModal}
      maxWidth="lg"
      title="Authentication Architecture & Firebase Status"
      description="StorePilot AI Phase 0 identity & authentication infrastructure status."
    >
      <div className="space-y-4">
        {/* Status card */}
        <div
          className={`p-4 rounded-xl border flex items-start gap-3 ${
            isFirebaseConfigured
              ? 'bg-emerald-50/50 border-emerald-200'
              : 'bg-amber-50/50 border-amber-200'
          }`}
        >
          {isFirebaseConfigured ? (
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          )}
          <div>
            <h4 className="text-sm font-bold text-slate-900">
              {isFirebaseConfigured
                ? 'Firebase Live Cloud Authentication Active'
                : 'Development Session Handling Active (Firebase Ready)'}
            </h4>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {isFirebaseConfigured
                ? `Connected to Firebase project: ${firebaseConfigState.projectId}. All user sessions, Google OAuth, and email credentials authenticate against your live cloud tenant.`
                : 'The application architecture is fully prepared with the official Firebase SDK and a modular AuthService abstraction. Until your Firebase project keys are configured in environment variables or provisioning, StorePilot AI operates with persistent local sessions so you can test all dashboard, website creation, and profile workflows.'}
            </p>
          </div>
        </div>

        {/* Configuration Checklist */}
        <div>
          <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <Key className="w-3.5 h-3.5 text-slate-500" />
            Environment Variables Checklist
          </h5>
          <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 text-xs">
            {envRequirements.map((req) => (
              <div
                key={req.key}
                className="p-2.5 flex items-center justify-between gap-3 bg-white"
              >
                <div className="font-mono text-slate-800 text-[11px] font-semibold">
                  {req.key}
                  <span className="text-slate-400 font-sans ml-2 text-xs font-normal">
                    {req.desc}
                  </span>
                </div>
                <span
                  className={`text-[11px] font-medium px-2 py-0.5 rounded ${
                    req.present
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {req.present ? 'Detected' : 'Pending'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-600 space-y-1.5">
          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-slate-700" />
            How to Connect Your Live Firebase Project
          </div>
          <ol className="list-decimal pl-4 space-y-1 text-slate-600">
            <li>
              Add the keys above to your environment configuration or provide a{' '}
              <code className="bg-slate-200 px-1 py-0.5 rounded text-[11px]">
                firebase-applet-config.json
              </code>{' '}
              file.
            </li>
            <li>Enable Google Sign-in and Email/Password in your Firebase Console.</li>
            <li>
              StorePilot AI automatically switches from local development session mode to live
              Firebase Cloud Authentication.
            </li>
          </ol>
        </div>

        <div className="pt-2 flex justify-end">
          <Button variant="primary" size="sm" onClick={closeConfigModal}>
            Understood
          </Button>
        </div>
      </div>
    </Modal>
  );
};
