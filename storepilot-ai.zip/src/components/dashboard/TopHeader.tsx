import React, { useState } from 'react';
import { Plus, Menu, ShieldCheck, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useWebsites } from '../../context/WebsitesContext';
import { useSubscription } from '../../context/SubscriptionContext';
import { UpgradePaywallModal } from '../subscription/UpgradePaywallModal';

interface TopHeaderProps {
  onToggleMobileSidebar: () => void;
  title: string;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  onToggleMobileSidebar,
  title,
}) => {
  const { user, isFirebaseConfigured, openConfigModal } = useAuth();
  const { openCreateModal } = useWebsites();
  const { canPublish } = useSubscription();
  const [showPaywallModal, setShowPaywallModal] = useState(false);
  const isDemoSession = user?.isDemo || user?.email?.includes('.local') || user?.providerId === 'local_dev';

  const handleCreateClick = () => {
    if (!canPublish) {
      setShowPaywallModal(true);
    } else {
      openCreateModal();
    }
  };

  return (
    <>
      <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30">
        {/* Left zone: Mobile toggle & Breadcrumb */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileSidebar}
            className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            aria-label="Toggle Navigation Drawer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium hidden sm:inline">
              StorePilot
            </span>
            <span className="text-slate-300 hidden sm:inline">/</span>
            <h1 className="text-sm font-bold text-slate-900">{title}</h1>

            {isDemoSession && (
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-900 border border-amber-200">
                Demo Founder Mode
              </span>
            )}
          </div>
        </div>

        {/* Right zone: Firebase status & Primary CTA */}
        <div className="flex items-center gap-3">
          {/* Firebase indicator */}
          <button
            onClick={openConfigModal}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
              isFirebaseConfigured
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
            }`}
            title="Click to view Firebase setup & environment configuration"
          >
            {isFirebaseConfigured ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            )}
            <span className="hidden md:inline">
              {isFirebaseConfigured ? 'Firebase Auth Connected' : 'Local Dev Session'}
            </span>
            <span className="md:hidden">
              {isFirebaseConfigured ? 'Cloud Auth' : 'Dev Auth'}
            </span>
          </button>

          {/* Create Website CTA */}
          <Button
            variant="primary"
            size="sm"
            onClick={handleCreateClick}
            icon={<Plus className="w-4 h-4" />}
          >
            Create Website
          </Button>
        </div>
      </header>

      {/* Starter Plan Paywall Modal */}
      <UpgradePaywallModal
        isOpen={showPaywallModal}
        onClose={() => setShowPaywallModal(false)}
        onContinue={() => {
          setShowPaywallModal(false);
          openCreateModal();
        }}
        triggerContext="create_website"
      />
    </>
  );
};
