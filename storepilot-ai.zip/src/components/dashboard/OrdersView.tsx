import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  Truck,
  ExternalLink,
  ChevronRight,
  Mail,
  Phone,
  MapPin,
  Calendar,
  X,
  CreditCard,
  ArrowUpRight,
  Package,
} from 'lucide-react';
import { StoreOrder, OrderFulfillmentStatus, OrderPaymentStatus } from '../../types/order';
import { useWebsites } from '../../context/WebsitesContext';
import { useAuth } from '../../context/AuthContext';
import { AuthService } from '../../services/auth/authService';
import { Button } from '../ui/Button';

export const OrdersView: React.FC = () => {
  const { websites } = useWebsites();
  const { user } = useAuth();
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [siteFilter, setSiteFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [fulfillmentFilter, setFulfillmentFilter] = useState<string>('all');

  // Selected Order for detail modal
  const [selectedOrder, setSelectedOrder] = useState<StoreOrder | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState<boolean>(false);
  const [statusUpdateMessage, setStatusUpdateMessage] = useState<string | null>(null);
  const [isFulfillingPrintify, setIsFulfillingPrintify] = useState<boolean>(false);
  const [isSyncingPrintify, setIsSyncingPrintify] = useState<boolean>(false);
  const [isSendingToProd, setIsSendingToProd] = useState<boolean>(false);

  const getAuthHeaders = async (): Promise<Record<string, string>> => {
    const token = await AuthService.getIdToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    } else if (user?.id) {
      headers['Authorization'] = `Bearer ${user.id}`;
    }
    return headers;
  };

  const fetchOrders = async (manual = false) => {
    if (manual) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      const url =
        siteFilter !== 'all'
          ? `/api/orders?websiteId=${encodeURIComponent(siteFilter)}`
          : '/api/orders';

      const headers = await getAuthHeaders();
      const response = await fetch(url, { headers });
      const data = await response.json();

      if (response.ok && data.success) {
        setOrders(data.orders || []);
      } else {
        setError(data.error || 'Failed to fetch customer orders.');
      }
    } catch (err: any) {
      console.error('Failed to load orders:', err);
      setError(err?.message || 'Failed to connect to orders service.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchOrders();
    }
  }, [siteFilter, user?.id]);

  const handleUpdateFulfillment = async (
    orderId: string,
    newStatus: OrderFulfillmentStatus
  ) => {
    setIsUpdatingStatus(true);
    setStatusUpdateMessage(null);

    try {
      const headers = await getAuthHeaders();
      const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ orderStatus: newStatus }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? data.order : o))
        );
        if (selectedOrder && selectedOrder.id === orderId) {
          setSelectedOrder(data.order);
        }
        setStatusUpdateMessage(`Fulfillment updated to ${newStatus}`);
        setTimeout(() => setStatusUpdateMessage(null), 3000);
      } else {
        alert(data.error || 'Failed to update order status');
      }
    } catch (err: any) {
      console.error('Update status error:', err);
      alert(err?.message || 'Network error updating order status');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleFulfillPrintify = async (orderId: string) => {
    setIsFulfillingPrintify(true);
    setStatusUpdateMessage(null);
    try {
      const headers = await getAuthHeaders();
      const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}/fulfill-printify`, {
        method: 'POST',
        headers,
      });
      const data = await response.json();
      if (response.ok && data.success && data.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        if (selectedOrder && selectedOrder.id === orderId) {
          setSelectedOrder(data.order);
        }
        setStatusUpdateMessage(`Printify order created successfully: #${data.order.printifyOrder?.orderId || ''}`);
        setTimeout(() => setStatusUpdateMessage(null), 4000);
      } else {
        alert(data.error || 'Failed to submit order to Printify.');
      }
    } catch (err: any) {
      console.error('Printify fulfillment error:', err);
      alert(err?.message || 'Network error submitting to Printify.');
    } finally {
      setIsFulfillingPrintify(false);
    }
  };

  const handleSyncPrintify = async (orderId: string) => {
    setIsSyncingPrintify(true);
    setStatusUpdateMessage(null);
    try {
      const headers = await getAuthHeaders();
      const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}/sync-printify`, {
        method: 'POST',
        headers,
      });
      const data = await response.json();
      if (response.ok && data.success && data.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        if (selectedOrder && selectedOrder.id === orderId) {
          setSelectedOrder(data.order);
        }
        const tracking = data.order.printifyOrder?.trackingNumber ? ` (Tracking: ${data.order.printifyOrder.trackingNumber})` : '';
        setStatusUpdateMessage(`Printify status synchronized: ${data.order.printifyOrder?.status || 'OK'}${tracking}`);
        setTimeout(() => setStatusUpdateMessage(null), 4000);
      } else {
        alert(data.error || 'Failed to sync with Printify.');
      }
    } catch (err: any) {
      console.error('Printify sync error:', err);
      alert(err?.message || 'Network error syncing with Printify.');
    } finally {
      setIsSyncingPrintify(false);
    }
  };

  const handleSendToProduction = async (orderId: string) => {
    setIsSendingToProd(true);
    setStatusUpdateMessage(null);
    try {
      const headers = await getAuthHeaders();
      const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}/send-to-production`, {
        method: 'POST',
        headers,
      });
      const data = await response.json();
      if (response.ok && data.success && data.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? data.order : o)));
        if (selectedOrder && selectedOrder.id === orderId) {
          setSelectedOrder(data.order);
        }
        setStatusUpdateMessage('Order sent to live Printify production!');
        setTimeout(() => setStatusUpdateMessage(null), 4000);
      } else {
        alert(data.error || 'Failed to send order to production.');
      }
    } catch (err: any) {
      console.error('Send to production error:', err);
      alert(err?.message || 'Network error sending to production.');
    } finally {
      setIsSendingToProd(false);
    }
  };

  // Filtered orders list
  const filteredOrders = orders.filter((order) => {
    if (paymentFilter !== 'all' && order.paymentStatus !== paymentFilter) {
      return false;
    }
    if (fulfillmentFilter !== 'all' && order.orderStatus !== fulfillmentFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = order.customer.fullName.toLowerCase().includes(q);
      const matchEmail = order.customer.email.toLowerCase().includes(q);
      const matchPhone = order.customer.phone.toLowerCase().includes(q);
      const matchId = order.id.toLowerCase().includes(q);
      const matchRef = order.paystackReference?.toLowerCase().includes(q);
      const matchSite = (order.websiteSlug || '').toLowerCase().includes(q);
      return matchName || matchEmail || matchPhone || matchId || matchRef || matchSite;
    }
    return true;
  });

  // Calculate metrics
  const totalRevenue = orders
    .filter((o) => o.paymentStatus === 'PAID')
    .reduce((sum, o) => sum + o.total, 0);

  const paidOrdersCount = orders.filter((o) => o.paymentStatus === 'PAID').length;
  const pendingOrdersCount = orders.filter(
    (o) => o.orderStatus === 'NEW' || o.orderStatus === 'PROCESSING'
  ).length;

  const getPaymentBadge = (status: OrderPaymentStatus) => {
    switch (status) {
      case 'PAID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Paid
          </span>
        );
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            Pending Payment
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
            <AlertCircle className="w-3 h-3 text-rose-600" />
            Failed
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
            Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const getFulfillmentBadge = (status: OrderFulfillmentStatus) => {
    switch (status) {
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">
            Completed
          </span>
        );
      case 'SHIPPED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-800">
            <Truck className="w-3 h-3" />
            Shipped
          </span>
        );
      case 'PROCESSING':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-100 text-indigo-800">
            Processing
          </span>
        );
      case 'NEW':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800">
            New Order
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-600">
            Cancelled
          </span>
        );
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner / Metrics Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <span>Total Sales</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">
              GH₵{totalRevenue.toFixed(2)}
            </span>
            <p className="text-xs text-slate-400 mt-1">Verified Paystack Revenue</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <span>Paid Orders</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{paidOrdersCount}</span>
            <p className="text-xs text-slate-400 mt-1">Successful transactions</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <span>To Fulfill</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{pendingOrdersCount}</span>
            <p className="text-xs text-slate-400 mt-1">Pending dispatch</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <span>Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-900">{orders.length}</span>
            <p className="text-xs text-slate-400 mt-1">All store checkouts</p>
          </div>
        </div>
      </div>

      {/* Control Bar: Filters & Search */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by customer, email, phone, or order ID..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-colors"
            />
          </div>

          <div className="flex items-center flex-wrap gap-2.5">
            {/* Filter by Site */}
            <select
              value={siteFilter}
              onChange={(e) => setSiteFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer"
            >
              <option value="all">All Websites</option>
              {websites.map((w) => (
                <option key={w.id} value={w.slug}>
                  {w.name} ({w.slug})
                </option>
              ))}
            </select>

            {/* Filter by Payment */}
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer"
            >
              <option value="all">All Payment Statuses</option>
              <option value="PAID">Paid</option>
              <option value="PENDING">Pending Payment</option>
              <option value="FAILED">Failed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>

            {/* Filter by Fulfillment */}
            <select
              value={fulfillmentFilter}
              onChange={(e) => setFulfillmentFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer"
            >
              <option value="all">All Fulfillment</option>
              <option value="NEW">New Order</option>
              <option value="PROCESSING">Processing</option>
              <option value="SHIPPED">Shipped</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>

            {/* Refresh Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => fetchOrders(true)}
              disabled={isRefreshing}
              icon={
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`}
                />
              }
            >
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {/* Orders Table / List */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="p-16 text-center space-y-3">
            <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin mx-auto" />
            <p className="text-xs font-semibold text-slate-600">Loading customer orders...</p>
          </div>
        ) : error ? (
          <div className="p-12 text-center space-y-3">
            <AlertCircle className="w-8 h-8 text-rose-500 mx-auto" />
            <p className="text-sm font-semibold text-slate-900">Failed to load orders</p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">{error}</p>
            <Button variant="outline" size="sm" onClick={() => fetchOrders(true)}>
              Retry
            </Button>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="p-16 text-center space-y-4 max-w-md mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <ShoppingBag className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">No Orders Found</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {orders.length === 0
                  ? 'Your store is ready to accept orders! When customers complete checkout on your published website, orders will appear here automatically.'
                  : 'No orders matched your active search and filter criteria.'}
              </p>
            </div>
            {orders.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchQuery('');
                  setPaymentFilter('all');
                  setFulfillmentFilter('all');
                  setSiteFilter('all');
                }}
              >
                Clear Filters
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="px-5 py-3.5">Order</th>
                  <th className="px-5 py-3.5">Customer</th>
                  <th className="px-5 py-3.5">Site / Date</th>
                  <th className="px-5 py-3.5">Payment</th>
                  <th className="px-5 py-3.5">Fulfillment</th>
                  <th className="px-5 py-3.5 text-right">Total</th>
                  <th className="px-5 py-3.5 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.map((order) => {
                  const dateStr = new Date(order.createdAt).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <tr
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                    >
                      <td className="px-5 py-4 font-mono font-bold text-slate-900">
                        #{order.id.slice(-6).toUpperCase()}
                        <div className="text-[10px] font-normal text-slate-400">
                          {order.items.reduce((s, i) => s + i.quantity, 0)} items
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-semibold text-slate-900">
                          {order.customer.fullName}
                        </div>
                        <div className="text-slate-500 text-[11px] truncate max-w-[180px]">
                          {order.customer.email}
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-medium text-slate-700">/{order.websiteSlug}</div>
                        <div className="text-[11px] text-slate-400">{dateStr}</div>
                      </td>
                      <td className="px-5 py-4">{getPaymentBadge(order.paymentStatus)}</td>
                      <td className="px-5 py-4">{getFulfillmentBadge(order.orderStatus)}</td>
                      <td className="px-5 py-4 text-right font-extrabold text-slate-900">
                        {order.currencySymbol}
                        {order.total.toFixed(2)}
                      </td>
                      <td className="px-5 py-4 text-center">
                        <span className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-semibold text-xs">
                          Details
                          <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Details Slideout / Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-hidden flex select-text">
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
            onClick={() => setSelectedOrder(null)}
          />

          <div className="relative ml-auto w-full max-w-xl bg-white shadow-2xl flex flex-col justify-between h-full z-10 animate-in slide-in-from-right duration-200">
            {/* Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Order #{selectedOrder.id.slice(-8).toUpperCase()}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Placed on {new Date(selectedOrder.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {statusUpdateMessage && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{statusUpdateMessage}</span>
                </div>
              )}

              {/* Status and Action banner */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Payment Status
                  </span>
                  <div>{getPaymentBadge(selectedOrder.paymentStatus)}</div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Update Fulfillment
                  </span>
                  <div className="flex items-center gap-2">
                    <select
                      value={selectedOrder.orderStatus}
                      disabled={isUpdatingStatus}
                      onChange={(e) =>
                        handleUpdateFulfillment(
                          selectedOrder.id,
                          e.target.value as OrderFulfillmentStatus
                        )
                      }
                      className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer disabled:opacity-50"
                    >
                      <option value="NEW">New Order</option>
                      <option value="PROCESSING">Processing</option>
                      <option value="SHIPPED">Shipped</option>
                      <option value="COMPLETED">Completed</option>
                      <option value="CANCELLED">Cancelled</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Printify Live Fulfillment Panel */}
              <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Printify On-Demand Fulfillment
                    </h4>
                  </div>
                  {selectedOrder.printifyOrder?.status ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-100 text-indigo-800 border border-indigo-200">
                      {selectedOrder.printifyOrder.status}
                    </span>
                  ) : selectedOrder.paymentStatus === 'PAID' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">
                      Ready for Fulfillment
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-200 text-slate-600">
                      Payment Required
                    </span>
                  )}
                </div>

                {selectedOrder.printifyOrder?.submissionStatus === 'SUBMITTED' ? (
                  <div className="space-y-2.5 text-xs bg-white p-3.5 rounded-xl border border-indigo-100">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100">
                      <span className="text-slate-500 text-[11px]">Printify Order ID:</span>
                      <span className="font-mono font-bold text-indigo-900">#{selectedOrder.printifyOrder.orderId}</span>
                    </div>

                    {selectedOrder.printifyOrder.trackingNumber ? (
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500 text-[11px]">Carrier / Tracking:</span>
                          <span className="font-bold text-slate-800">{selectedOrder.printifyOrder.carrier || 'Standard Carrier'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-slate-900 bg-slate-100 px-2 py-1 rounded text-[11px] font-bold">
                            {selectedOrder.printifyOrder.trackingNumber}
                          </span>
                          {selectedOrder.printifyOrder.trackingUrl && (
                            <a
                              href={selectedOrder.printifyOrder.trackingUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-indigo-600 hover:text-indigo-800 text-[11px] font-bold inline-flex items-center gap-1"
                            >
                              Track Shipment
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-[11px] text-slate-500 py-1 flex items-center justify-between">
                        <span>Tracking Number:</span>
                        <span className="italic text-slate-400">Not assigned yet by print provider</span>
                      </div>
                    )}

                    {selectedOrder.printifyOrder.syncedAt && (
                      <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 flex items-center justify-between">
                        <span>Last Synced:</span>
                        <span>{new Date(selectedOrder.printifyOrder.syncedAt).toLocaleTimeString()}</span>
                      </div>
                    )}

                    <div className="pt-2 flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handleSyncPrintify(selectedOrder.id)}
                        disabled={isSyncingPrintify}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncingPrintify ? 'animate-spin' : ''}`} />
                        <span>{isSyncingPrintify ? 'Syncing...' : 'Sync Live Tracking'}</span>
                      </button>

                      {!selectedOrder.printifyOrder.sentToProduction && selectedOrder.printifyOrder.status === 'on-hold' && (
                        <button
                          onClick={() => handleSendToProduction(selectedOrder.id)}
                          disabled={isSendingToProd}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{isSendingToProd ? 'Submitting...' : 'Send to Production'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : selectedOrder.paymentStatus === 'PAID' ? (
                  <div className="space-y-3 bg-white p-3.5 rounded-xl border border-indigo-100 text-xs">
                    <p className="text-slate-600 text-[11px]">
                      Payment is verified. Click below to submit this order directly to Printify for production.
                    </p>

                    {selectedOrder.printifyOrder?.submissionStatus === 'SUBMISSION_FAILED' && (
                      <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-[11px]">
                        <strong>Last Submission Error:</strong> {selectedOrder.printifyOrder.submissionError}
                      </div>
                    )}

                    <button
                      onClick={() => handleFulfillPrintify(selectedOrder.id)}
                      disabled={isFulfillingPrintify}
                      className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <Package className={`w-3.5 h-3.5 ${isFulfillingPrintify ? 'animate-spin' : ''}`} />
                      <span>{isFulfillingPrintify ? 'Creating Printify Order...' : 'Submit to Printify Fulfillment'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-amber-900 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Printify fulfillment is strictly blocked until payment is independently verified by Paystack.</span>
                  </div>
                )}
              </div>

              {/* Customer Contact & Delivery Info */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Customer & Delivery Details
                </h4>
                <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-2.5 text-xs">
                  <div className="font-bold text-sm text-slate-900">
                    {selectedOrder.customer.fullName}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <a
                      href={`mailto:${selectedOrder.customer.email}`}
                      className="hover:text-indigo-600 underline"
                    >
                      {selectedOrder.customer.email}
                    </a>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <a
                      href={`tel:${selectedOrder.customer.phone}`}
                      className="hover:text-indigo-600"
                    >
                      {selectedOrder.customer.phone}
                    </a>
                  </div>
                  <div className="flex items-start gap-2 text-slate-600 pt-1 border-t border-slate-100">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <div>{selectedOrder.customer.address}</div>
                      <div>
                        {selectedOrder.customer.city}
                        {selectedOrder.customer.region
                          ? `, ${selectedOrder.customer.region}`
                          : ''}
                      </div>
                    </div>
                  </div>
                  {selectedOrder.customer.notes && (
                    <div className="p-2.5 bg-slate-50 rounded-lg text-slate-600 text-[11px] italic">
                      "{selectedOrder.customer.notes}"
                    </div>
                  )}
                </div>
              </div>

              {/* Order Items */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Order Items ({selectedOrder.items.length})
                </h4>
                <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden bg-white">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="p-3.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-400">
                              <ShoppingBag className="w-4 h-4" />
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">{item.name}</div>
                          <div className="text-slate-400 text-[11px]">
                            Qty: {item.quantity} × {selectedOrder.currencySymbol}
                            {item.price.toFixed(2)}
                          </div>
                        </div>
                      </div>
                      <div className="font-bold text-slate-900">
                        {selectedOrder.currencySymbol}
                        {(item.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Summary */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span>
                    {selectedOrder.currencySymbol}
                    {selectedOrder.subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Delivery / Shipping</span>
                  <span className="text-emerald-700 font-medium">Free</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between font-black text-sm text-slate-900">
                  <span>Total Paid</span>
                  <span>
                    {selectedOrder.currencySymbol}
                    {selectedOrder.total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Paystack / Reference Info */}
              {selectedOrder.paystackReference && (
                <div className="p-3.5 bg-slate-100/70 rounded-xl text-[11px] font-mono text-slate-600 flex items-center justify-between">
                  <span className="text-slate-400">Paystack Ref:</span>
                  <span className="font-bold">{selectedOrder.paystackReference}</span>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-200 bg-white flex items-center justify-between gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedOrder(null)}
              >
                Close
              </Button>
              <div className="flex items-center gap-2">
                <a
                  href={`tel:${selectedOrder.customer.phone}`}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors inline-flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  Call Customer
                </a>
                <a
                  href={`mailto:${selectedOrder.customer.email}?subject=Regarding your order #${selectedOrder.id.slice(-6).toUpperCase()}`}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" />
                  Email Receipt
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
