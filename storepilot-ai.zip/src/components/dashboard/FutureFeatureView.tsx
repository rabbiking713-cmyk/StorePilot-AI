import React from 'react';
import {
  Sparkles,
  Sliders,
  Palette,
  Megaphone,
  ArrowLeft,
  Calendar,
  Code2,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { ActiveDashboardTab } from '../../types';

interface FutureFeatureViewProps {
  tab: ActiveDashboardTab;
  onReturnToOverview: () => void;
}

export const FutureFeatureView: React.FC<FutureFeatureViewProps> = ({
  tab,
  onReturnToOverview,
}) => {
  const contentMap: Record<
    string,
    {
      phaseNumber: number;
      title: string;
      subtitle: string;
      icon: React.ReactNode;
      overview: string;
      prerequisites: string[];
      technicalPlan: string[];
      samplePrompt: string;
    }
  > = {
    builder_preview: {
      phaseNumber: 1,
      title: 'AI Website Builder',
      subtitle: 'Natural language prompt-to-website engine',
      icon: <Sparkles className="w-6 h-6 text-amber-500" />,
      overview:
        'In Phase 1, StorePilot AI will allow founders to simply type what their business does. The engine processes the prompt into multi-page layout structures, responsive components, tailored copy, and industry-grounded image slots.',
      prerequisites: [
        'Phase 0 Foundation established (Completed)',
        'JSON data schemas defined for website pages and navigation',
        'Structured prompt intake interface with domain tagging',
      ],
      technicalPlan: [
        'Domain schema generator translating business type into navigation tree',
        'Automated hero headline, copy, and product catalog synthesis',
        'Responsive layout serialization ready for the Phase 2 visual editor',
      ],
      samplePrompt:
        '"Build an artisanal ceramic studio website selling handmade stoneware mugs and vases, featuring our studio workshops in Portland, customer testimonials, and an online shop."',
    },
    editor_preview: {
      phaseNumber: 2,
      title: 'Visual Website Editor',
      subtitle: 'Interactive block canvas and style customizer',
      icon: <Sliders className="w-6 h-6 text-slate-700" />,
      overview:
        'In Phase 2, founders will be able to visually modify the AI-generated website. Click on any text to edit inline, reorder section blocks with drag-and-drop, swap color palettes, and preview changes across desktop, tablet, and mobile viewports.',
      prerequisites: [
        'Phase 1 website generation output tree',
        'Component block library with parameterized props',
        'Real-time iframe / DOM synchronization bridge',
      ],
      technicalPlan: [
        'WYSIWYG inline content editable handlers with history undo/redo',
        'Design token customizer for typography, border radiuses, and brand colors',
        'Responsive breakpoint emulator (1440px desktop, 768px tablet, 375px mobile)',
      ],
      samplePrompt:
        'Select any section block, drag to reposition, or adjust theme colors directly on the canvas.',
    },
    templates_preview: {
      phaseNumber: 3,
      title: 'Curated Template Library',
      subtitle: 'Professionally crafted industry starters',
      icon: <Palette className="w-6 h-6 text-indigo-600" />,
      overview:
        'In Phase 3, StorePilot AI will introduce a collection of high-converting, professionally designed industry templates for founders who prefer starting from an established blueprint.',
      prerequisites: [
        'Phase 1 & Phase 2 editing canvas',
        'Responsive component design system',
        'One-click template cloning engine',
      ],
      technicalPlan: [
        'Industry presets for Boutiques, Coffee Bars, Consultancies, and Tech',
        'Typography and color theme bundling',
        'Modular section kits compatible with both manual and AI-assisted customization',
      ],
      samplePrompt:
        'Choose from presets: "Boutique Minimalist", "Nordic Roast Cafe", "Apex Consulting", or "Lumina Studio".',
    },
    marketing_preview: {
      phaseNumber: 5,
      title: 'AI Marketing Studio',
      subtitle: 'Multi-channel promotional and advertising suite',
      icon: <Megaphone className="w-6 h-6 text-blue-600" />,
      overview:
        'In Phase 5, StorePilot AI will connect your website catalog directly to automated marketing generation. Create social media posts, launch announcements, Google / Meta ad copy, and seasonal sales promotions matching your brand voice.',
      prerequisites: [
        'Phase 1 website catalog structure',
        'Phase 4 published website URL',
        'Multi-channel format templates (Instagram, X, LinkedIn, Email)',
      ],
      technicalPlan: [
        'Catalog-aware marketing copy generator referencing products and prices',
        'Promotional calendar planner with launch scheduling',
        'Ad copy generator tuned for high conversion click-through rates',
      ],
      samplePrompt:
        '"Generate a 7-day Instagram launch sequence announcing our grand opening with a 15% discount code for the first 100 customers."',
    },
  };

  const feature = contentMap[tab] || contentMap.builder_preview;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      {/* Return button */}
      <div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onReturnToOverview}
          icon={<ArrowLeft className="w-4 h-4" />}
        >
          Return to My Websites
        </Button>
      </div>

      {/* Main card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
              {feature.icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold bg-slate-900 text-white px-2 py-0.5 rounded">
                  Phase {feature.phaseNumber}
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                  Scheduled for Phase {feature.phaseNumber}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
                {feature.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <Calendar className="w-4 h-4" />
            <span>Phase 0: Architecture Ready</span>
          </div>
        </div>

        {/* Feature Notice */}
        <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <p className="font-semibold text-slate-900 mb-1">
            Status: Architecture In Progress (Not Claimed as Complete)
          </p>
          <p>{feature.overview}</p>
        </div>

        {/* Planned Technical Architecture */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Engineering Prerequisites
            </h3>
            <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-2 text-xs">
              {feature.prerequisites.map((req, i) => (
                <div key={i} className="flex items-start gap-2 text-slate-600">
                  <span className="text-slate-400 font-mono">0{i + 1}.</span>
                  <span>{req}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <Code2 className="w-4 h-4 text-blue-600" />
              Planned Technical Pipeline
            </h3>
            <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-2 text-xs">
              {feature.technicalPlan.map((plan, i) => (
                <div key={i} className="flex items-start gap-2 text-slate-600">
                  <span className="text-slate-400 font-mono">0{i + 1}.</span>
                  <span>{plan}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Example Prompt Input Concept */}
        <div className="mt-8 pt-6 border-t border-slate-200">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
            Target User Experience Concept
          </h4>
          <div className="p-4 bg-slate-100/70 border border-slate-200 rounded-lg font-mono text-xs text-slate-700">
            {feature.samplePrompt}
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Current Build: Phase 0 Foundation
          </span>
          <Button variant="primary" size="sm" onClick={onReturnToOverview}>
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};
