import React, { useState, useMemo } from 'react';
import {
  Globe,
  Plus,
  Trash2,
  Sparkles,
  Megaphone,
  ArrowRight,
  Clock,
  Edit3,
  AlertCircle,
  Eye,
  Sliders,
  Copy,
  Search,
  Filter,
  Palette,
  ExternalLink,
  CheckCircle2,
  RefreshCw,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useWebsites } from '../../context/WebsitesContext';
import { useSubscription } from '../../context/SubscriptionContext';
import { WebsiteService } from '../../services/data/websiteService';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { Website, ActiveDashboardTab } from '../../types';
import { AiWebsiteBuilder } from '../builder/AiWebsiteBuilder';
import { VisualWebsiteEditor } from '../editor/VisualWebsiteEditor';
import { PublishModal } from '../publish/PublishModal';
import { UpgradePaywallModal } from '../subscription/UpgradePaywallModal';

interface OverviewViewProps {
  onNavigateTab: (tab: ActiveDashboardTab) => void;
}

const BUSINESS_CATEGORIES = [
  'All',
  'Recent',
  'Fashion & Luxury Apparel',
  'Specialty Dining & Cafe',
  'Beauty & Skincare',
  'Luxury Real Estate',
  'Software & Technology',
  'Commercial Photography & Art',
  'Higher Education & Tech Training',
  'Management Consulting & Finance',
  'Design Studio & Creative Direction',
  'Artisanal Home Goods & Retail',
];

export const OverviewView: React.FC<OverviewViewProps> = ({ onNavigateTab }) => {
  const { user } = useAuth();
  const {
    websites,
    openCreateModal,
    deleteWebsite,
    updateWebsite,
    duplicateWebsite,
    renameWebsite,
    setSelectedWebsite,
  } = useWebsites();

  const { canPublish } = useSubscription();

  const [inspectingWebsite, setInspectingWebsite] = useState<Website | null>(null);
  const [activeBuilderSite, setActiveBuilderSite] = useState<Website | null>(null);
  const [activeEditorSite, setActiveEditorSite] = useState<Website | null>(null);

  // Upgrade / Paywall modal state for Starter users
  const [paywallModal, setPaywallModal] = useState<{
    isOpen: boolean;
    triggerContext: 'create_website' | 'publish' | 'copy_link' | 'general';
    onContinue?: () => void;
  }>({
    isOpen: false,
    triggerContext: 'general',
  });

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Rename modal state
  const [renamingSite, setRenamingSite] = useState<Website | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState('');

  // Delete confirmation modal state
  const [deletingSite, setDeletingSite] = useState<Website | null>(null);

  // Publish & Domain modal state
  const [publishingWebsite, setPublishingWebsite] = useState<Website | null>(null);
  const [publishModalTab, setPublishModalTab] = useState<'storepilot' | 'custom_domain'>('storepilot');
  const [copiedSiteId, setCopiedSiteId] = useState<string | null>(null);

  const handleCopyLiveLink = async (site: Website) => {
    if (!canPublish) {
      setPaywallModal({
        isOpen: true,
        triggerContext: 'copy_link',
      });
      return;
    }

    const slug = site.publishedSlug || site.slug;
    const url = `${window.location.origin}/site/${slug}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopiedSiteId(site.id);
      setTimeout(() => setCopiedSiteId(null), 2000);
    } catch {
      // Fallback
    }
  };

  // Edit metadata modal state
  const [editingWebsite, setEditingWebsite] = useState<Website | null>(null);
  const [editForm, setEditForm] = useState<{
    name: string;
    businessType: string;
    slug: string;
    description: string;
    customDomain: string;
  }>({
    name: '',
    businessType: '',
    slug: '',
    description: '',
    customDomain: '',
  });

  const isDemoSession = user?.isDemo || user?.email?.includes('.local') || user?.providerId === 'local_dev';

  // Filtered websites
  const filteredWebsites = useMemo(() => {
    let result = [...websites];

    // Category filter
    if (categoryFilter === 'Recent') {
      // Sort by newest updatedAt
      result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    } else if (categoryFilter !== 'All') {
      result = result.filter(
        (site) =>
          site.businessType.toLowerCase().includes(categoryFilter.toLowerCase()) ||
          site.spec?.industry?.toLowerCase().includes(categoryFilter.toLowerCase())
      );
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter((site) => {
        const inName = site.name.toLowerCase().includes(q);
        const inDesc = site.description?.toLowerCase().includes(q);
        const inType = site.businessType.toLowerCase().includes(q);
        const inSlug = site.slug.toLowerCase().includes(q);
        const inPrompt = site.originalPrompt?.toLowerCase().includes(q);
        return inName || inDesc || inType || inSlug || inPrompt;
      });
    }

    return result;
  }, [websites, categoryFilter, searchQuery]);

  const formattedDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Recently';
    }
  };

  const getWebsiteThumbnail = (site: Website) => {
    if (site.spec?.sections) {
      for (const section of site.spec.sections) {
        if ('imageUrl' in section && section.imageUrl) {
          return section.imageUrl;
        }
        if ('items' in section && Array.isArray(section.items)) {
          for (const item of section.items) {
            if ('imageUrl' in item && item.imageUrl) {
              return item.imageUrl;
            }
          }
        }
      }
    }
    return 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80';
  };

  // Duplicate handler
  const handleDuplicate = (site: Website) => {
    try {
      const copy = duplicateWebsite(site.id);
      // Give gentle visual selection
    } catch (err) {
      console.error('Failed to duplicate website:', err);
    }
  };

  // Open Rename Modal
  const handleOpenRename = (site: Website) => {
    setRenamingSite(site);
    setRenameValue(site.name);
    setRenameError('');
  };

  const handleSaveRename = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = renameValue.trim();
    if (!trimmed) {
      setRenameError('Website name cannot be empty');
      return;
    }
    if (trimmed.length < 2) {
      setRenameError('Website name must be at least 2 characters');
      return;
    }
    if (!renamingSite) return;

    renameWebsite(renamingSite.id, trimmed);
    setRenamingSite(null);
  };

  // Delete confirmation
  const handleConfirmDelete = () => {
    if (!deletingSite) return;
    deleteWebsite(deletingSite.id);
    if (inspectingWebsite?.id === deletingSite.id) {
      setInspectingWebsite(null);
    }
    setDeletingSite(null);
  };

  const handleOpenEdit = (site: Website) => {
    setEditingWebsite(site);
    setEditForm({
      name: site.name,
      businessType: site.businessType,
      slug: site.slug,
      description: site.description,
      customDomain: site.customDomain || '',
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWebsite || !editForm.name.trim()) return;

    updateWebsite(editingWebsite.id, {
      name: editForm.name.trim(),
      businessType: editForm.businessType.trim(),
      slug:
        editForm.slug
          .trim()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '') || editingWebsite.slug,
      description: editForm.description.trim(),
      customDomain: editForm.customDomain.trim() || undefined,
    });

    if (inspectingWebsite?.id === editingWebsite.id) {
      setInspectingWebsite({
        ...inspectingWebsite,
        name: editForm.name.trim(),
        businessType: editForm.businessType.trim(),
        slug: editForm.slug.trim(),
        description: editForm.description.trim(),
        customDomain: editForm.customDomain.trim() || undefined,
      });
    }

    setEditingWebsite(null);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Demo Evaluation Mode Notice */}
      {isDemoSession && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3 shadow-xs">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Local Demo Session Active (Evaluation Mode)</p>
            <p className="text-amber-800 leading-relaxed">
              You are exploring the StorePilot AI Platform in an isolated sandbox session. Website creations, updates, templates, and edits are preserved locally in your browser workspace. Live multi-user cloud authentication can be activated by configuring Firebase credentials.
            </p>
          </div>
        </div>
      )}

      {/* 1. Header & Quick Actions */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="text-xs text-slate-500 flex items-center gap-2 mb-2">
            <span className="font-semibold text-slate-700">Workspace Dashboard</span>
            <span aria-hidden="true">·</span>
            <span>Phase 3 Active</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Welcome back, {user?.displayName || 'Founder'}
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
            Manage your websites, build with AI, customize via the Visual Editor, or start from curated professional templates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <Button
            variant="outline"
            size="md"
            onClick={() => onNavigateTab('templates_preview')}
            icon={<Palette className="w-4 h-4 text-indigo-600" />}
          >
            Browse Templates
          </Button>
          <Button
            variant="primary"
            size="md"
            onClick={() => onNavigateTab('builder_preview')}
            icon={<Sparkles className="w-4 h-4" />}
          >
            Build with AI
          </Button>
          <Button
            variant="ghost"
            size="md"
            onClick={() => {
              if (!canPublish) {
                setPaywallModal({
                  isOpen: true,
                  triggerContext: 'create_website',
                  onContinue: openCreateModal,
                });
              } else {
                openCreateModal();
              }
            }}
            icon={<Plus className="w-4 h-4" />}
          >
            Blank Project
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">My Websites</div>
          <div className="mt-2 text-2xl font-bold text-slate-900 tabular-nums">
            {websites.length}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Stored securely in your workspace
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Platform Features</div>
          <div className="mt-2 text-sm font-bold text-slate-900 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            AI Builder · Visual Editor · Templates
          </div>
          <div className="mt-1 text-[11px] text-emerald-700 font-medium">
            Phases 1, 2, and 3 Live
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Curated Templates</div>
          <div className="mt-2 text-2xl font-bold text-slate-900 tabular-nums">
            10 Ready
          </div>
          <div className="mt-1 text-[11px] text-indigo-600 font-medium cursor-pointer" onClick={() => onNavigateTab('templates_preview')}>
            Instant 1-click clone →
          </div>
        </div>
      </div>

      {/* 2. "My Websites" Section */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">My Websites</h3>
            <p className="text-xs text-slate-500">
              Web properties owned and isolated to your account
            </p>
          </div>

          {/* Search bar & Category filter */}
          {websites.length > 0 && (
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search my websites..."
                  className="w-full sm:w-64 pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 hover:text-slate-700 font-bold cursor-pointer"
                  >
                    ×
                  </button>
                )}
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 cursor-pointer"
              >
                <option value="All">All Categories</option>
                <option value="Recent">Recently Modified</option>
                {BUSINESS_CATEGORIES.filter((c) => c !== 'All' && c !== 'Recent').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {websites.length === 0 ? (
          /* Empty State - No fake cards! */
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-lg mx-auto space-y-4 shadow-2xs">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center mx-auto text-indigo-600">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">No websites yet</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto leading-relaxed">
                Create your first website with AI or start from a professionally designed template.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
              <Button
                variant="primary"
                size="sm"
                onClick={() => onNavigateTab('builder_preview')}
                icon={<Sparkles className="w-4 h-4" />}
              >
                Build with AI
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateTab('templates_preview')}
                icon={<Palette className="w-4 h-4" />}
              >
                Browse Templates
              </Button>
            </div>
          </div>
        ) : filteredWebsites.length === 0 ? (
          /* Search Empty State */
          <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center max-w-md mx-auto space-y-3">
            <p className="text-xs font-semibold text-slate-700">No matching websites found</p>
            <p className="text-xs text-slate-400">
              No websites match &quot;{searchQuery}&quot;. Try adjusting your search query or category filter.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchQuery('');
                setCategoryFilter('All');
              }}
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          /* Populated State Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredWebsites.map((site) => {
              const pubStatus = WebsiteService.getPublishStatus(site);

              return (
                <div
                  key={site.id}
                  className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between group"
                >
                  <div>
                    {/* Card Thumbnail Area */}
                    <div
                      className="relative aspect-16/9 bg-slate-100 overflow-hidden cursor-pointer"
                      onClick={() => setActiveEditorSite(site)}
                    >
                      <img
                        src={getWebsiteThumbnail(site)}
                        alt={site.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-slate-950/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 backdrop-blur-2xs">
                        <span className="px-3 py-1.5 bg-white text-slate-900 font-semibold text-xs rounded-lg shadow-md flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                          <Sliders className="w-3.5 h-3.5 text-indigo-600" /> Open in Visual Editor
                        </span>
                      </div>

                      <div className="absolute bottom-2 right-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-mono px-2 py-0.5 rounded">
                        {site.spec ? `${site.spec.sections.length} Sections` : 'Spec Ready'}
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-5 space-y-3">
                      <div className="text-xs text-slate-500 flex items-center justify-between">
                        <span className="font-semibold text-slate-700 truncate max-w-[180px]">
                          {site.businessType}
                        </span>
                        <span className="flex items-center gap-1 text-[11px] text-slate-400 shrink-0">
                          <Clock className="w-3 h-3" />
                          {formattedDate(site.updatedAt)}
                        </span>
                      </div>

                      <h4 className="text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors truncate">
                        {site.name}
                      </h4>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {site.description || 'No description provided.'}
                      </p>

                      {/* Live URL & Status Badge */}
                      <div className="pt-2 text-xs flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1 min-w-0">
                          {canPublish && (pubStatus === 'published' || pubStatus === 'changes_unpublished') ? (
                            <a
                              href={`/site/${site.publishedSlug || site.slug}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono text-[11px] text-indigo-600 hover:text-indigo-800 hover:underline truncate flex items-center gap-1 font-medium"
                              title="Open live public URL in new tab"
                            >
                              <span className="truncate">/site/{site.publishedSlug || site.slug}</span>
                              <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                            </a>
                          ) : (
                            <span className="font-mono text-[11px] text-slate-400 truncate">
                              Private Draft
                            </span>
                          )}
                        </div>

                        {/* Status indicator badge */}
                        {pubStatus === 'published' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                            <Globe className="w-2.5 h-2.5 text-emerald-600" />
                            Published
                          </span>
                        ) : pubStatus === 'changes_unpublished' ? (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 shrink-0"
                            title="Draft changes differ from published snapshot"
                          >
                            <RefreshCw className="w-2.5 h-2.5 text-amber-600" />
                            Changes not published
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 shrink-0">
                            Draft
                          </span>
                        )}
                      </div>

                      {/* Custom Domain indicator if present */}
                      {site.customDomain && (
                        <div className="flex items-center justify-between pt-2 text-xs border-t border-slate-100 mt-2">
                          <div className="flex items-center gap-1.5 text-slate-600 truncate">
                            <ShieldCheck className="w-3 h-3 text-indigo-600 shrink-0" />
                            <span className="font-mono text-[11px] truncate">
                              {site.customDomain}
                            </span>
                          </div>
                          <button
                            onClick={() => {
                              setPublishModalTab('custom_domain');
                              setPublishingWebsite(site);
                            }}
                            className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer ml-2 shrink-0"
                          >
                            Domain settings
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Card Action Footer */}
                  <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-1.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Button
                        variant="primary"
                        size="sm"
                        className="text-xs"
                        onClick={() => setActiveEditorSite(site)}
                        icon={<Sliders className="w-3.5 h-3.5" />}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={() => setActiveBuilderSite(site)}
                        icon={<Sparkles className="w-3.5 h-3.5 text-indigo-600" />}
                      >
                        AI
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={() => {
                          setSelectedWebsite(site);
                          onNavigateTab('marketing_preview');
                        }}
                        icon={<Megaphone className="w-3.5 h-3.5 text-indigo-600" />}
                        title="Market this business with AI"
                      >
                        Market
                      </Button>

                      {/* Publish / Republish modal trigger */}
                      <button
                        onClick={() => {
                          if (!canPublish) {
                            setPaywallModal({
                              isOpen: true,
                              triggerContext: 'publish',
                            });
                            return;
                          }
                          setPublishModalTab('storepilot');
                          setPublishingWebsite(site);
                        }}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          !canPublish
                            ? 'text-indigo-600 bg-indigo-50/70 hover:bg-indigo-100'
                            : pubStatus === 'published'
                            ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                            : pubStatus === 'changes_unpublished'
                            ? 'text-amber-800 bg-amber-50 hover:bg-amber-100'
                            : 'text-slate-500 hover:text-indigo-600 hover:bg-slate-200'
                        }`}
                        title={
                          !canPublish
                            ? 'Publish — Upgrade Required'
                            : pubStatus === 'published'
                            ? 'Website is live — manage publication'
                            : pubStatus === 'changes_unpublished'
                            ? 'Unpublished changes — click to republish'
                            : 'Publish website to a public URL'
                        }
                      >
                        <Globe className="w-3.5 h-3.5" />
                      </button>

                      {/* Custom Domain Settings button */}
                      <button
                        onClick={() => {
                          if (!canPublish) {
                            setPaywallModal({
                              isOpen: true,
                              triggerContext: 'publish',
                            });
                            return;
                          }
                          setPublishModalTab('custom_domain');
                          setPublishingWebsite(site);
                        }}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          site.customDomain
                            ? 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
                            : 'text-slate-500 hover:text-indigo-600 hover:bg-slate-200'
                        }`}
                        title={
                          site.customDomain
                            ? `Custom domain: ${site.customDomain} — manage settings`
                            : 'Connect a custom domain'
                        }
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                      </button>

                      {/* Copy live link / Upgrade to Share */}
                      {canPublish ? (
                        (pubStatus === 'published' || pubStatus === 'changes_unpublished') && (
                          <button
                            onClick={() => handleCopyLiveLink(site)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                            title={copiedSiteId === site.id ? 'Copied live link!' : 'Copy live website URL'}
                          >
                            {copiedSiteId === site.id ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )
                      ) : (
                        <button
                          onClick={() =>
                            setPaywallModal({
                              isOpen: true,
                              triggerContext: 'copy_link',
                            })
                          }
                          className="px-2 py-1 text-[11px] font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer flex items-center gap-1 border border-indigo-200"
                          title="Upgrade to share your website publicly"
                        >
                          <Lock className="w-3 h-3 text-indigo-500" />
                          <span>Upgrade to Share</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleOpenRename(site)}
                        className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        title="Rename Website"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDuplicate(site)}
                        className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        title="Duplicate Website"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setInspectingWebsite(site)}
                        className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        title="View Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => setDeletingSite(site)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete Website"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Rename Modal */}
      {renamingSite && (
        <Modal
          isOpen={!!renamingSite}
          onClose={() => setRenamingSite(null)}
          maxWidth="sm"
          title="Rename Website"
          description="Enter a new display name for your website project."
        >
          <form onSubmit={handleSaveRename} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Website Name
              </label>
              <input
                type="text"
                value={renameValue}
                onChange={(e) => {
                  setRenameValue(e.target.value);
                  if (renameError) setRenameError('');
                }}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                autoFocus
              />
              {renameError && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{renameError}</p>
              )}
            </div>

            <div className="flex justify-end items-center gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                type="button"
                onClick={() => setRenamingSite(null)}
              >
                Cancel
              </Button>
              <Button variant="primary" size="sm" type="submit">
                Save Name
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Confirmation Modal */}
      {deletingSite && (
        <Modal
          isOpen={!!deletingSite}
          onClose={() => setDeletingSite(null)}
          maxWidth="sm"
          title="Delete this website?"
          description="This action cannot be undone."
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to permanently delete <strong className="text-slate-900">&quot;{deletingSite.name}&quot;</strong>? This will remove all page sections, copy, products, and configurations.
            </p>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
              This will remove the project from your workspace library.
            </div>

            <div className="flex justify-end items-center gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setDeletingSite(null)}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={handleConfirmDelete}
                icon={<Trash2 className="w-3.5 h-3.5" />}
              >
                Delete Website
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Inspection Modal */}
      {inspectingWebsite && (
        <Modal
          isOpen={!!inspectingWebsite}
          onClose={() => setInspectingWebsite(null)}
          maxWidth="md"
          title={inspectingWebsite.name}
          description="Website Project Metadata & Configuration"
        >
          <div className="space-y-4">
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Business Category:</span>
                <span className="font-semibold text-slate-900">
                  {inspectingWebsite.businessType}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Target Address:</span>
                <span className="font-mono text-slate-900">
                  {inspectingWebsite.slug}.storepilot.ai
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Created Date:</span>
                <span className="text-slate-900">
                  {formattedDate(inspectingWebsite.createdAt)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Last Modified:</span>
                <span className="text-slate-900">
                  {formattedDate(inspectingWebsite.updatedAt)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Section Count:</span>
                <span className="text-emerald-700 font-semibold">
                  {inspectingWebsite.spec?.sections.length || 0} Sections
                </span>
              </div>
            </div>

            <div>
              <h5 className="text-xs font-bold text-slate-900 mb-1">
                Business Vision & Prompt Seed
              </h5>
              <p className="text-xs text-slate-600 bg-white border border-slate-200 rounded-lg p-3">
                {inspectingWebsite.description || 'No description entered.'}
              </p>
            </div>

            <div className="flex justify-end items-center gap-2 pt-2">
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  const target = inspectingWebsite;
                  setInspectingWebsite(null);
                  setActiveEditorSite(target);
                }}
                icon={<Sliders className="w-3.5 h-3.5" />}
              >
                Open in Visual Editor
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const target = inspectingWebsite;
                  setInspectingWebsite(null);
                  setActiveBuilderSite(target);
                }}
                icon={<Sparkles className="w-3.5 h-3.5" />}
              >
                Open in AI Builder
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const target = inspectingWebsite;
                  setInspectingWebsite(null);
                  handleDuplicate(target);
                }}
                icon={<Copy className="w-3.5 h-3.5" />}
              >
                Duplicate
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setInspectingWebsite(null)}
              >
                Close Details
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* AI Website Builder (For editing/refining specific website) */}
      {activeBuilderSite && (
        <AiWebsiteBuilder
          initialWebsite={activeBuilderSite}
          onClose={() => setActiveBuilderSite(null)}
          onSaved={() => setActiveBuilderSite(null)}
        />
      )}

      {/* Visual Website Editor (Phase 2) */}
      {activeEditorSite && (
        <VisualWebsiteEditor
          website={activeEditorSite}
          onClose={() => setActiveEditorSite(null)}
          onSaved={() => setActiveEditorSite(null)}
        />
      )}

      {/* Edit Website Project Modal */}
      {editingWebsite && (
        <Modal
          isOpen={!!editingWebsite}
          onClose={() => setEditingWebsite(null)}
          maxWidth="md"
          title={`Edit Project: ${editingWebsite.name}`}
          description="Update your website project settings, category, and metadata."
        >
          <form onSubmit={handleSaveEdit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Website Name
              </label>
              <Input
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business Category
              </label>
              <select
                value={editForm.businessType}
                onChange={(e) => setEditForm({ ...editForm, businessType: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                {BUSINESS_CATEGORIES.filter((c) => c !== 'All' && c !== 'Recent').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subdomain Slug
              </label>
              <div className="flex items-center">
                <Input
                  value={editForm.slug}
                  onChange={(e) => setEditForm({ ...editForm, slug: e.target.value })}
                  className="rounded-r-none"
                  required
                />
                <span className="px-3 py-2 bg-slate-100 border border-l-0 border-slate-300 text-xs text-slate-500 rounded-r-lg">
                  .storepilot.ai
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Description & Vision
              </label>
              <textarea
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div className="flex justify-end items-center gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                type="button"
                onClick={() => setEditingWebsite(null)}
              >
                Cancel
              </Button>
              <Button variant="primary" size="sm" type="submit">
                Save Changes
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Publish to StorePilot URL Modal */}
      {publishingWebsite && (
        <PublishModal
          website={publishingWebsite}
          isOpen={Boolean(publishingWebsite)}
          onClose={() => setPublishingWebsite(null)}
          initialTab={publishModalTab}
        />
      )}

      {/* Starter Plan Paywall Modal */}
      <UpgradePaywallModal
        isOpen={paywallModal.isOpen}
        onClose={() => setPaywallModal({ isOpen: false, triggerContext: 'general' })}
        onContinue={paywallModal.onContinue}
        triggerContext={paywallModal.triggerContext}
      />
    </div>
  );
};
