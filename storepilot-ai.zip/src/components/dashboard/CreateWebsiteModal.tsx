import React from 'react';
import { useWebsites } from '../../context/WebsitesContext';
import { AiWebsiteBuilder } from '../builder/AiWebsiteBuilder';

export const CreateWebsiteModal: React.FC = () => {
  const { isCreateModalOpen, closeCreateModal } = useWebsites();

  if (!isCreateModalOpen) return null;

  return (
    <AiWebsiteBuilder
      initialWebsite={null}
      onClose={closeCreateModal}
      onSaved={() => {
        closeCreateModal();
      }}
    />
  );
};
