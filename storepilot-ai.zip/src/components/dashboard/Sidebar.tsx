import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  Sliders,
  Palette,
  Megaphone,
  ShoppingBag,
  CreditCard,
  User,
  LogOut,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { ActiveDashboardTab } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useWebsites } from '../../context/WebsitesContext';
import { useSubscription } from '../../context/SubscriptionContext';

interface SidebarProps {
  activeTab: ActiveDashboardTab;
  onSelectTab: (tab: ActiveDashboardTab) => void;
  onReturnToLanding: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onReturnToLanding,
}) => {
  const { user, signOut } = useAuth();
  const { websites } = useWebsites();
  const { plan, isDeveloper } = useSubscription();

  const hasEcommerceSite = websites.some(
    (w) => w.spec?.siteType === 'ECOMMERCE' || w.spec?.sections?.some((s) => s.type === 'products')
  );

  const navigationItems: {
    id: ActiveDashboardTab;
    label: string;
    icon: React.ReactNode;
    tag?: string;
    tagColor?: string;
    isCommerceOnly?: boolean;
  }[] = [
    {
      id: 'overview',
      label: 'My Websites',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    ...(hasEcommerceSite
      ? [
          {
            id: 'orders' as ActiveDashboardTab,
            label: 'Orders & Sales',
            icon: <ShoppingBag className="w-4 h-4" />,
            tag: 'Live (Phase 6)',
            tagColor: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
            isCommerceOnly: true,
          },
        ]
      : []),
    {
      id: 'builder_preview',
      label: 'AI Website Builder',
      icon: <Sparkles className="w-4 h-4" />,
      tag: 'Live (Phase 1)',
    },
    {
      id: 'editor_preview',
      label: 'Visual Editor',
      icon: <Sliders className="w-4 h-4" />,
      tag: 'Live (Phase 2)',
    },
    {
      id: 'templates_preview',
      label: 'Templates',
      icon: <Palette className="w-4 h-4" />,
      tag: 'Live (Phase 3)',
      tagColor: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
    },
    {
      id: 'marketing_preview',
      label: 'Marketing',
      icon: <Megaphone className="w-4 h-4" />,
      tag: 'Live (Phase 5)',
      tagColor: 'bg-indigo-50 text-indigo-700 border border-indigo-200',
    },
    {
      id: 'subscription',
      label: 'Billing & Plans',
      icon: <CreditCard className="w-4 h-4" />,
      tag: isDeveloper ? 'Dev Access' : plan === 'agency' ? 'Agency ($79)' : plan === 'professional' ? 'Pro ($29)' : 'Starter ($0)',
      tagColor: isDeveloper
        ? 'bg-purple-50 text-purple-700 border border-purple-200'
        : plan === 'professional' || plan === 'agency'
        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
        : 'bg-slate-100 text-slate-700',
    },
    {
      id: 'profile',
      label: 'Account & Settings',
      icon: <User className="w-4 h-4" />,
    },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 min-h-screen">
      <div>
        {/* Brand header */}
        <div className="h-16 px-6 border-b border-slate-200 flex items-center justify-between">
          <button
            onClick={onReturnToLanding}
            className="flex items-center gap-2.5 text-left cursor-pointer group"
          >
            <span className="w-7 h-7 rounded-md bg-slate-900 text-white flex items-center justify-center font-bold text-xs">
              SP
            </span>
            <div>
              <div className="text-sm font-extrabold text-slate-900 tracking-tight group-hover:text-slate-700 transition-colors">
                StorePilot AI
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                Phase 0 Foundation
              </div>
            </div>
          </button>
        </div>

        {/* Navigation list */}
        <div className="px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Workspace
          </div>

          {navigationItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={isActive ? 'text-white' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>

                {item.tag && (
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-normal ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {item.tag}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer Profile & Actions */}
      <div className="p-3 border-t border-slate-200 space-y-2">
        <button
          onClick={onReturnToLanding}
          className="w-full flex items-center justify-between px-3 py-1.5 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <ExternalLink className="w-3.5 h-3.5" />
            Landing Page
          </span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        {user && (
          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
            <div
              className="flex items-center gap-2.5 overflow-hidden cursor-pointer"
              onClick={() => onSelectTab('profile')}
            >
              <div className="w-7 h-7 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center font-bold text-xs text-slate-700 shrink-0 overflow-hidden">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{user.displayName.charAt(0).toUpperCase()}</span>
                )}
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-slate-900 truncate flex items-center gap-1">
                  <span>{user.displayName}</span>
                </div>
                <div className="text-[10px] text-slate-500 truncate">
                  {user.isDemo || user.providerId === 'local_dev' ? (
                    <span className="text-amber-700 font-medium">Demo Mode (Dev Session)</span>
                  ) : (
                    user.email
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={() => signOut()}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
