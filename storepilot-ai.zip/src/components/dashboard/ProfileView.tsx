import React, { useState } from 'react';
import {
  User,
  Mail,
  Shield,
  Calendar,
  LogOut,
  Save,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

export const ProfileView: React.FC = () => {
  const { user, signOut, isFirebaseConfigured, openConfigModal, updateDisplayName } = useAuth();
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const isDemoUser = user?.isDemo || user?.email?.includes('.local') || user?.providerId === 'local_dev';

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) return;
    setIsSaving(true);
    try {
      await updateDisplayName(displayName.trim());
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2500);
    } catch (err) {
      console.error('Failed to update name:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const formattedDate = (iso?: string) => {
    if (!iso) return 'Today';
    try {
      return new Date(iso).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Today';
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-xs">
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
          Account Profile & Workspace Settings
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          Manage your personal credentials, session security, and workspace preferences.
        </p>

        {/* Demo Mode Notice Banner */}
        {isDemoUser && (
          <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">
                Development / Demo Evaluation Account Active
              </p>
              <p className="text-amber-800 leading-relaxed">
                You are currently signed into StorePilot AI using a simulated local development session. This is designed for testing and verifying Phase 0 functionality (landing page, dashboard, project management, and upcoming feature specifications) without needing live Firebase cloud credentials. It is isolated to your local browser environment.
              </p>
            </div>
          </div>
        )}

        {/* User Card */}
        <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-slate-200 border-2 border-white shadow-xs overflow-hidden shrink-0">
              <img
                src="/src/assets/images/avatar_founder_user_1790188742025.jpg"
                alt={user?.displayName || 'User'}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {user?.displayName || 'StorePilot Founder'}
              </h3>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                {user?.email}
              </p>
              <div className="mt-2 flex items-center gap-2">
                <span
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                    isFirebaseConfigured
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {isFirebaseConfigured
                    ? 'Firebase Cloud Authenticated'
                    : 'Development Session (Firebase Ready)'}
                </span>
              </div>
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => signOut()}
            icon={<LogOut className="w-3.5 h-3.5 text-rose-600" />}
          >
            Sign Out
          </Button>
        </div>

        {/* Edit Profile Form */}
        <form onSubmit={handleSave} className="mt-8 space-y-4 max-w-md">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Personal Details
          </h4>

          {isSaved && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Profile details updated successfully.</span>
            </div>
          )}

          <Input
            label="Full Name / Founder Title"
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            icon={<User className="w-4 h-4" />}
          />

          <Input
            label="Email Address"
            type="email"
            value={user?.email || ''}
            disabled
            helperText="Managed through your authentication identity provider."
            icon={<Mail className="w-4 h-4" />}
          />

          <div className="pt-2">
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSaving}
              icon={<Save className="w-3.5 h-3.5" />}
            >
              Save Profile Changes
            </Button>
          </div>
        </form>

        {/* Security & Architecture Audit */}
        <div className="mt-10 pt-6 border-t border-slate-200">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
            Authentication Infrastructure
          </h4>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-slate-400" />
                Session Provider:
              </span>
              <span className="font-mono font-semibold text-slate-900">
                {user?.providerId === 'firebase'
                  ? 'Firebase Auth (Cloud SDK)'
                  : 'Local Storage Dev Session'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-400" />
                Account Created:
              </span>
              <span className="text-slate-900 font-medium">
                {formattedDate(user?.createdAt)}
              </span>
            </div>

            <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between">
              <span className="text-slate-600">
                Need to connect your production Firebase credentials?
              </span>
              <button
                type="button"
                onClick={openConfigModal}
                className="text-xs font-semibold text-slate-900 hover:underline cursor-pointer"
              >
                Inspect Firebase Status
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
