import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { TopHeader } from './TopHeader';
import { OverviewView } from './OverviewView';
import { FutureFeatureView } from './FutureFeatureView';
import { ProfileView } from './ProfileView';
import { CreateWebsiteModal } from './CreateWebsiteModal';
import { FirebaseConfigStatusModal } from '../auth/FirebaseConfigStatusModal';
import { AiWebsiteBuilder } from '../builder/AiWebsiteBuilder';
import { VisualWebsiteEditor } from '../editor/VisualWebsiteEditor';
import { TemplatesView } from '../templates/TemplatesView';
import { MarketingStudioView } from '../marketing/MarketingStudioView';
import { OrdersView } from './OrdersView';
import { SubscriptionView } from '../subscription/SubscriptionView';
import { ActiveDashboardTab } from '../../types';
import { useWebsites } from '../../context/WebsitesContext';
import { Sparkles, Sliders, Plus } from 'lucide-react';
import { Button } from '../ui/Button';

interface DashboardLayoutProps {
  onReturnToLanding: () => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ onReturnToLanding }) => {
  const [activeTab, setActiveTab] = useState<ActiveDashboardTab>('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { websites, openCreateModal } = useWebsites();
  const [selectedEditorSiteId, setSelectedEditorSiteId] = useState<string | null>(null);

  const activeEditorWebsite =
    websites.find((w) => w.id === selectedEditorSiteId) || websites[0] || null;

  const getPageTitle = (tab: ActiveDashboardTab): string => {
    switch (tab) {
      case 'overview':
      case 'websites':
        return 'My Websites Workspace';
      case 'orders':
        return 'Orders & Customer Sales (Phase 6)';
      case 'builder_preview':
        return 'AI Website Builder (Phase 1)';
      case 'editor_preview':
        return 'Visual Website Editor (Phase 2)';
      case 'templates_preview':
        return 'Curated Templates (Phase 3)';
      case 'marketing_preview':
        return 'AI Marketing Studio (Phase 5)';
      case 'subscription':
        return 'Billing & Subscription Plans (Phase 9)';
      case 'profile':
      case 'settings':
        return 'Account & Profile Settings';
      default:
        return 'Workspace';
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
      case 'websites':
        return <OverviewView onNavigateTab={setActiveTab} />;
      case 'orders':
        return <OrdersView />;
      case 'builder_preview':
        return (
          <AiWebsiteBuilder
            initialWebsite={null}
            onClose={() => setActiveTab('overview')}
            onSaved={() => setActiveTab('overview')}
          />
        );
      case 'editor_preview':
        if (!activeEditorWebsite) {
          return (
            <div className="p-8 max-w-lg mx-auto text-center my-12 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mx-auto">
                <Sliders className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  No Websites Created Yet
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  To use the Visual Editor, first generate your website with StorePilot AI or create a project.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => setActiveTab('builder_preview')}
                  icon={<Sparkles className="w-4 h-4" />}
                >
                  Generate Website with AI
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={openCreateModal}
                  icon={<Plus className="w-4 h-4" />}
                >
                  Create Project
                </Button>
              </div>
            </div>
          );
        }
        return (
          <VisualWebsiteEditor
            website={activeEditorWebsite}
            onClose={() => setActiveTab('overview')}
            onSaved={() => setActiveTab('overview')}
          />
        );
      case 'templates_preview':
        return (
          <TemplatesView
            onOpenEditor={(website) => {
              setSelectedEditorSiteId(website.id);
              setActiveTab('editor_preview');
            }}
          />
        );
      case 'marketing_preview':
        return (
          <MarketingStudioView
            onNavigateTab={setActiveTab}
          />
        );
      case 'subscription':
        return <SubscriptionView />;
      case 'profile':
      case 'settings':
        return <ProfileView />;
      default:
        return <OverviewView onNavigateTab={setActiveTab} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onReturnToLanding={onReturnToLanding}
        />
      </div>

      {/* Mobile Sidebar Drawer */}
      {mobileSidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative z-10 w-64 max-w-[80vw] bg-white h-full shadow-2xl">
            <Sidebar
              activeTab={activeTab}
              onSelectTab={(tab) => {
                setActiveTab(tab);
                setMobileSidebarOpen(false);
              }}
              onReturnToLanding={() => {
                setMobileSidebarOpen(false);
                onReturnToLanding();
              }}
            />
          </div>
        </div>
      )}

      {/* Main Viewport Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopHeader
          title={getPageTitle(activeTab)}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        />

        <main className="flex-1 overflow-y-auto">{renderContent()}</main>
      </div>

      {/* Modals */}
      <CreateWebsiteModal />
      <FirebaseConfigStatusModal />
    </div>
  );
};
