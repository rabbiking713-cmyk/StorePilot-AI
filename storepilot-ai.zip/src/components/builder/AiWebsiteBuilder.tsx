import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowLeft,
  RotateCw,
  Save,
  Monitor,
  Tablet,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Wand2,
  Send,
  SlidersHorizontal,
  Layers,
  ChevronDown,
  Building2,
  HelpCircle,
  ExternalLink,
  Sliders,
} from 'lucide-react';
import { WebsiteSpec } from '../../types/websiteSpec';
import { Website } from '../../types';
import {
  AiWebsiteService,
  EXAMPLE_PROMPTS,
  QUICK_REFINEMENT_PROMPTS,
  AiStatusResult,
} from '../../services/ai/aiWebsiteService';
import { WebsiteRenderer } from '../preview/WebsiteRenderer';
import { DevicePreviewFrame } from '../preview/DevicePreviewFrame';
import { Button } from '../ui/Button';
import { VisualWebsiteEditor } from '../editor/VisualWebsiteEditor';
import { CommerceSetupModal } from '../commerce/CommerceSetupModal';
import { CommerceApiClient } from '../../services/commerce/commerceApiClient';
import { CommerceIntentDetectionResult, StorePilotProduct } from '../../types/commerce';
import { useAuth } from '../../context/AuthContext';
import { useWebsites } from '../../context/WebsitesContext';
import { useSubscription } from '../../context/SubscriptionContext';
import { WebsiteService } from '../../services/data/websiteService';

interface AiWebsiteBuilderProps {
  initialWebsite?: Website | null;
  onClose: () => void;
  onSaved?: (savedSite: Website) => void;
}

type ViewportMode = 'desktop' | 'tablet' | 'mobile';

export const AiWebsiteBuilder: React.FC<AiWebsiteBuilderProps> = ({
  initialWebsite,
  onClose,
  onSaved,
}) => {
  const { user } = useAuth();
  const { createWebsite, updateWebsite } = useWebsites();
  const { canAccess, plan: subPlan } = useSubscription();
  const hasAiAccess = canAccess('ai_builder');

  const [prompt, setPrompt] = useState<string>(
    initialWebsite?.originalPrompt ||
      'Build me a modern online clothing store for teenagers in Ghana. Use a clean premium design, showcase hoodies, sneakers and T-shirts, and include a homepage, products section, about section and contact section.'
  );
  const [businessCategory, setBusinessCategory] = useState<string>(
    initialWebsite?.businessType || 'Retail & Fashion'
  );

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [generationError, setGenerationError] = useState<string | null>(null);

  const [generatedSpec, setGeneratedSpec] = useState<WebsiteSpec | null>(
    initialWebsite?.spec || null
  );

  const [refinementInput, setRefinementInput] = useState<string>('');
  const [isRefining, setIsRefining] = useState<boolean>(false);

  const [viewport, setViewport] = useState<ViewportMode>('desktop');
  const [editorWebsite, setEditorWebsite] = useState<Website | null>(null);
  const [isSavedSuccess, setIsSavedSuccess] = useState<boolean>(false);
  const [savedProjectName, setSavedProjectName] = useState<string>('');

  const [aiStatus, setAiStatus] = useState<AiStatusResult | null>(null);

  // Phase 7A: Commerce Intent & Printify Modal State
  const [isCommerceModalOpen, setIsCommerceModalOpen] = useState<boolean>(false);
  const [detectedIntent, setDetectedIntent] = useState<CommerceIntentDetectionResult | null>(null);

  const isDemoSession =
    user?.isDemo || user?.email?.includes('.local') || user?.providerId === 'local_dev';

  useEffect(() => {
    // Check AI status on mount
    AiWebsiteService.getStatus().then((status) => {
      setAiStatus(status);
    });
  }, []);

  const handleGenerate = async (arg?: boolean | React.MouseEvent) => {
    const forceStandard = typeof arg === 'boolean' ? arg : false;
    if (!prompt.trim()) {
      setGenerationError('Please provide a prompt describing the business or website you want to generate.');
      return;
    }

    setGenerationError(null);

    // Phase 7A: Evaluate whether the user prompt requests an e-commerce store
    if (!forceStandard) {
      setGenerationStep('Analyzing business intent and website category...');
      setIsGenerating(true);

      try {
        const intent = await CommerceApiClient.detectIntent(prompt, businessCategory);
        if (intent.isCommerce) {
          setIsGenerating(false);
          setGenerationStep('');
          setDetectedIntent(intent);
          setIsCommerceModalOpen(true);
          return;
        }
      } catch (intentErr) {
        console.warn('Intent detection skipped:', intentErr);
      }
    }

    setIsGenerating(true);
    setGenerationStep('Connecting to Gemini 3.8 Flash model...');

    try {
      const stepTimer1 = setTimeout(() => {
        setGenerationStep('Synthesizing brand architecture, navigation tree, and visual theme...');
      }, 1200);

      const stepTimer2 = setTimeout(() => {
        setGenerationStep('Crafting custom copy, product catalog, testimonials, and contact details...');
      }, 2500);

      const spec = await AiWebsiteService.generateWebsite(prompt, businessCategory);

      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);

      setGeneratedSpec(spec);
    } catch (err: any) {
      console.error('Website generation error:', err);
      setGenerationError(err?.message || 'An unexpected error occurred during website generation.');
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  const handleCommerceProductsApproved = async (approved: StorePilotProduct[]) => {
    setIsCommerceModalOpen(false);
    setIsGenerating(true);
    setGenerationStep(`Constructing e-commerce storefront around ${approved.length} approved real products...`);

    try {
      const spec = await CommerceApiClient.generateStore({
        prompt,
        businessType: businessCategory,
        approvedProducts: approved,
      });
      setGeneratedSpec(spec);
    } catch (err: any) {
      console.error('Store generation failed:', err);
      setGenerationError(err?.message || 'Failed to generate e-commerce store.');
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  const handleSwitchToStandard = () => {
    setIsCommerceModalOpen(false);
    handleGenerate(true);
  };

  const handleRefine = async (customInstruction?: string) => {
    const instruction = customInstruction || refinementInput;
    if (!instruction.trim()) return;
    if (!generatedSpec) {
      setGenerationError('Please generate an initial website before refining.');
      return;
    }

    setGenerationError(null);
    setIsRefining(true);

    try {
      const updated = await AiWebsiteService.refineWebsite(generatedSpec, instruction);
      setGeneratedSpec(updated);
      setRefinementInput('');
    } catch (err: any) {
      console.error('Refinement error:', err);
      setGenerationError(err?.message || 'Failed to apply refinement instructions.');
    } finally {
      setIsRefining(false);
    }
  };

  const handleSaveProject = async () => {
    if (!generatedSpec) return;

    if (initialWebsite) {
      // Update existing website
      const updates = {
        name: generatedSpec.siteName || generatedSpec.businessName,
        businessType: generatedSpec.industry || initialWebsite.businessType,
        description: generatedSpec.businessDescription || initialWebsite.description,
        originalPrompt: prompt,
        spec: generatedSpec,
      };
      updateWebsite(initialWebsite.id, updates);
      await WebsiteService.saveWebsiteDirectly({
        ...initialWebsite,
        ...updates,
        updatedAt: new Date().toISOString(),
      });
      setSavedProjectName(generatedSpec.siteName);
      setIsSavedSuccess(true);
      setTimeout(() => setIsSavedSuccess(false), 3000);
      if (onSaved) {
        onSaved({
          ...initialWebsite,
          name: generatedSpec.siteName,
          spec: generatedSpec,
        });
      }
    } else {
      // Create new website
      const newSite = createWebsite({
        name: generatedSpec.siteName || generatedSpec.businessName,
        businessType: generatedSpec.industry || businessCategory,
        description: generatedSpec.businessDescription || prompt.slice(0, 140),
        originalPrompt: prompt,
        spec: generatedSpec,
        isDemo: isDemoSession,
      });
      await WebsiteService.saveWebsiteDirectly(newSite);
      setSavedProjectName(newSite.name);
      setIsSavedSuccess(true);
      setTimeout(() => setIsSavedSuccess(false), 3000);
      if (onSaved) {
        onSaved(newSite);
      }
    }
  };

  const handleOpenVisualEditor = () => {
    if (!generatedSpec) return;
    let target = initialWebsite;
    if (!target) {
      target = createWebsite({
        name: generatedSpec.siteName || generatedSpec.businessName,
        businessType: generatedSpec.industry || businessCategory,
        description: generatedSpec.businessDescription || prompt.slice(0, 140),
        originalPrompt: prompt,
        spec: generatedSpec,
        isDemo: isDemoSession,
      });
    } else {
      updateWebsite(target.id, {
        name: generatedSpec.siteName || generatedSpec.businessName,
        businessType: generatedSpec.industry || target.businessType,
        description: generatedSpec.businessDescription || target.description,
        originalPrompt: prompt,
        spec: generatedSpec,
      });
      target = { ...target, spec: generatedSpec, name: generatedSpec.siteName };
    }
    setEditorWebsite(target);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex flex-col bg-white">
      {/* Top Builder Bar */}
      <header className="h-14 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to Dashboard</span>
          </button>

          <span className="text-slate-300">|</span>

          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-900">
              Phase 1: AI Website Builder
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
              gemini-3.8-flash
            </span>
            {isDemoSession && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                Demo Dev Sandbox
              </span>
            )}
          </div>
        </div>

        {/* Viewport Toggles (When spec exists) */}
        {generatedSpec && (
          <div className="hidden md:flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setViewport('desktop')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                viewport === 'desktop'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Desktop</span>
            </button>
            <button
              onClick={() => setViewport('tablet')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                viewport === 'tablet'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>Tablet (768px)</span>
            </button>
            <button
              onClick={() => setViewport('mobile')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                viewport === 'mobile'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile (390px)</span>
            </button>
          </div>
        )}

        {/* Save / Close Actions */}
        <div className="flex items-center gap-2">
          {generatedSpec && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={handleOpenVisualEditor}
                icon={<Sliders className="w-3.5 h-3.5 text-indigo-600" />}
                className="text-xs border-indigo-200 text-indigo-700 hover:bg-indigo-50"
              >
                Edit Website
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleSaveProject}
                icon={<Save className="w-3.5 h-3.5" />}
                className="text-xs"
              >
                {isSavedSuccess ? 'Saved to Projects!' : 'Save Website Project'}
              </Button>
            </>
          )}
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 text-xs"
          >
            Close
          </button>
        </div>
      </header>

      {/* Main Split Builder Body */}
      <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 bg-slate-100">
        {/* LEFT PANE: Controls & Prompt Input */}
        <div className="lg:col-span-5 bg-white border-r border-slate-200 flex flex-col h-full overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Header Title */}
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              Create your website with AI
            </h2>
            <p className="mt-1 text-xs text-slate-500 leading-relaxed">
              Describe what you want to build. StorePilot AI will synthesize pages, copy, products, and a matching visual theme.
            </p>
          </div>

          {/* AI Status Alert if not configured */}
          {aiStatus && !aiStatus.configured && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">Gemini API Key Required</p>
                <p className="text-amber-800 leading-relaxed">
                  To generate real websites, please configure your <code>GEMINI_API_KEY</code> in the AI Studio Secrets panel.
                </p>
              </div>
            </div>
          )}

          {/* Error Notice */}
          {generationError && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-start gap-3">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">Generation Unsuccessful</p>
                <p className="text-rose-800 leading-relaxed">{generationError}</p>
                <button
                  onClick={handleGenerate}
                  className="mt-2 inline-flex items-center gap-1.5 text-rose-900 font-bold underline hover:no-underline cursor-pointer"
                >
                  <RotateCw className="w-3 h-3" />
                  Try Again
                </button>
              </div>
            </div>
          )}

          {/* Prompt Form */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
              Tell us about the website you want to build...
            </label>
            <div className="relative">
              <textarea
                rows={5}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. Build me a modern online clothing store for teenagers in Ghana. Showcase hoodies, sneakers, and t-shirts..."
                disabled={isGenerating || isRefining}
                className="w-full text-xs sm:text-sm p-3.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent text-slate-900 leading-relaxed resize-none shadow-xs disabled:bg-slate-50"
              />
            </div>

            <div className="flex items-center justify-between gap-3 pt-1">
              <span className="text-[11px] text-slate-400">
                Tip: Include business type, target audience, and key offerings.
              </span>
              <Button
                variant="primary"
                size="md"
                onClick={handleGenerate}
                isLoading={isGenerating}
                disabled={isGenerating || isRefining}
                icon={<Wand2 className="w-4 h-4" />}
                className="text-xs shrink-0"
              >
                {generatedSpec ? 'Regenerate Website' : 'Generate Website'}
              </Button>
            </div>
          </div>

          {/* Prompt Suggestions */}
          {!generatedSpec && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700">
                Example Prompts (Click to Use):
              </span>
              <div className="space-y-2">
                {EXAMPLE_PROMPTS.map((ex, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPrompt(ex.prompt);
                      setBusinessCategory(ex.category);
                    }}
                    className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/70 transition-all text-xs group cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-slate-800 font-semibold mb-1">
                      <span>{ex.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono px-2 py-0.5 rounded bg-slate-100">
                        {ex.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                      {ex.prompt}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Natural Language Refinement (Active when a spec is generated) */}
          {generatedSpec && (
            <div className="space-y-4 pt-4 border-t border-slate-200">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600" />
                  Refine with Natural Language
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  Tell Gemini what to adjust (e.g. &quot;make it more modern&quot;, &quot;use a luxury style&quot;, &quot;make colors more energetic&quot;, &quot;make homepage shorter&quot;).
                </p>
              </div>

              {/* Refinement input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={refinementInput}
                  onChange={(e) => setRefinementInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleRefine();
                    }
                  }}
                  disabled={isRefining || isGenerating}
                  placeholder="e.g. Make the colors more energetic and vibrant"
                  className="flex-1 text-xs px-3.5 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-900"
                />
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => handleRefine()}
                  isLoading={isRefining}
                  disabled={isRefining || !refinementInput.trim()}
                  icon={<Send className="w-3.5 h-3.5" />}
                  className="text-xs shrink-0"
                >
                  Refine
                </Button>
              </div>

              {/* Quick Refinement Chips */}
              <div className="space-y-2">
                <span className="text-[11px] font-semibold text-slate-400">
                  Quick adjustments:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_REFINEMENT_PROMPTS.map((chip, cIdx) => (
                    <button
                      key={cIdx}
                      type="button"
                      onClick={() => handleRefine(chip)}
                      disabled={isRefining}
                      className="text-[11px] px-2.5 py-1 rounded-full border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:border-slate-300 transition-colors cursor-pointer"
                    >
                      + {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* Generated Website Metadata Summary Card */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex justify-between font-medium">
                  <span className="text-slate-500">Site Name:</span>
                  <span className="font-bold text-slate-900">
                    {generatedSpec.siteName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Industry:</span>
                  <span className="text-slate-800">{generatedSpec.industry}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Style Mood:</span>
                  <span className="text-slate-800 font-semibold">
                    {generatedSpec.theme?.styleMood || 'Custom'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Color Palette:</span>
                  <div className="flex items-center gap-1.5">
                    <span
                      className="w-4 h-4 rounded-full border border-black/10"
                      style={{ backgroundColor: generatedSpec.theme?.primaryColor }}
                      title={`Primary: ${generatedSpec.theme?.primaryColor}`}
                    />
                    <span
                      className="w-4 h-4 rounded-full border border-black/10"
                      style={{ backgroundColor: generatedSpec.theme?.accentColor }}
                      title={`Accent: ${generatedSpec.theme?.accentColor}`}
                    />
                    <span
                      className="w-4 h-4 rounded-full border border-black/10"
                      style={{ backgroundColor: generatedSpec.theme?.backgroundColor }}
                      title={`Background: ${generatedSpec.theme?.backgroundColor}`}
                    />
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sections Count:</span>
                  <span className="font-mono text-slate-900 font-semibold">
                    {generatedSpec.sections.length} sections
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT PANE: Live Website Preview */}
        <div className="lg:col-span-7 flex flex-col h-full overflow-hidden bg-slate-100/70 p-4 sm:p-6">
          <div className="flex items-center justify-between pb-3 text-xs text-slate-500">
            <span className="font-semibold flex items-center gap-1.5 text-slate-700">
              <Monitor className="w-4 h-4 text-slate-500" />
              Live Website Preview
            </span>
            <span className="text-[11px] text-slate-400">
              {viewport === 'desktop' && 'Desktop (Responsive 100%)'}
              {viewport === 'tablet' && 'Tablet Viewport (768px)'}
              {viewport === 'mobile' && 'Mobile Viewport (390px)'}
            </span>
          </div>

          {/* Preview Container */}
          <div className="flex-1 overflow-y-auto flex items-start justify-center rounded-2xl bg-white border border-slate-300 shadow-sm relative">
            {/* Loading Overlay */}
            {isGenerating && (
              <div className="absolute inset-0 z-50 bg-white/95 backdrop-blur-xs flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 animate-spin">
                  <RotateCw className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900">
                    StorePilot AI is building your website...
                  </h3>
                  <p className="text-xs text-slate-600 max-w-sm leading-relaxed">
                    {generationStep || 'Processing your business brief with Gemini...'}
                  </p>
                </div>
                <div className="text-[11px] font-mono text-slate-400 bg-slate-50 px-3 py-1 rounded-full border border-slate-200">
                  Model: gemini-3.8-flash (Server-Side)
                </div>
              </div>
            )}

            {/* Refining Overlay */}
            {isRefining && (
              <div className="absolute inset-0 z-50 bg-white/80 backdrop-blur-xs flex flex-col items-center justify-center p-8 text-center space-y-3">
                <Wand2 className="w-8 h-8 text-indigo-600 animate-bounce" />
                <h4 className="text-sm font-bold text-slate-900">
                  Applying natural language refinements...
                </h4>
                <p className="text-xs text-slate-500">
                  Updating typography, color tones, and section copy
                </p>
              </div>
            )}

            {/* If spec exists: Render it */}
            {generatedSpec ? (
              <DevicePreviewFrame
                viewport={viewport}
                siteName={generatedSpec.siteName || 'Live Site'}
              >
                <WebsiteRenderer
                  spec={generatedSpec}
                  viewport={viewport}
                  isInteractive={true}
                />
              </DevicePreviewFrame>
            ) : (
              /* Empty Placeholder */
              <div className="p-8 sm:p-12 text-center my-auto space-y-4 max-w-md">
                <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                  <Sparkles className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-slate-800">
                  Your live website will render here
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Enter your business vision in the prompt on the left or select an example starter prompt, then click &quot;Generate Website&quot;.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Visual Website Editor Modal */}
      {editorWebsite && (
        <VisualWebsiteEditor
          website={editorWebsite}
          onClose={() => setEditorWebsite(null)}
          onSaved={(updated) => {
            setEditorWebsite(null);
            if (updated.spec) {
              setGeneratedSpec(updated.spec);
            }
          }}
        />
      )}

      {/* Phase 7A: Real Commerce & Printify Setup Experience */}
      <CommerceSetupModal
        isOpen={isCommerceModalOpen}
        onClose={() => setIsCommerceModalOpen(false)}
        initialPrompt={prompt}
        initialIntent={detectedIntent}
        onProductsApproved={handleCommerceProductsApproved}
        onSwitchToStandardBuilder={handleSwitchToStandard}
      />
    </div>
  );
};
