import React, { useState, useEffect } from 'react';
import { Website, CustomDomainConfig } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useWebsites } from '../../context/WebsitesContext';
import { useSubscription } from '../../context/SubscriptionContext';
import { DomainService } from '../../services/data/domainService';
import { Button } from '../ui/Button';
import {
  Globe,
  CheckCircle2,
  AlertCircle,
  Clock,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Trash2,
  Info,
  Server,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface CustomDomainManagerProps {
  website: Website;
  onClose?: () => void;
}

export const CustomDomainManager: React.FC<CustomDomainManagerProps> = ({ website, onClose }) => {
  const { user } = useAuth();
  const { updateCustomDomain } = useWebsites();
  const { canAccess, plan: subPlan } = useSubscription();
  const hasDomainAccess = canAccess('custom_domains');

  const [domainInput, setDomainInput] = useState<string>('');
  const [domainConfig, setDomainConfig] = useState<CustomDomainConfig | null>(
    website.customDomainConfig || null
  );
  const [isLoadingConfig, setIsLoadingConfig] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isDisconnecting, setIsDisconnecting] = useState<boolean>(false);
  const [showDisconnectConfirm, setShowDisconnectConfirm] = useState<boolean>(false);

  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const [cooldownSeconds, setCooldownSeconds] = useState<number>(0);

  // Load existing domain configuration on mount
  useEffect(() => {
    let isMounted = true;
    async function fetchConfig() {
      setIsLoadingConfig(true);
      const config = await DomainService.getDomainConfig(website.id);
      if (!isMounted) return;

      if (config) {
        setDomainConfig(config);
        setDomainInput(config.domain);
        updateCustomDomain(website.id, config);
      } else {
        setDomainConfig(null);
      }
      setIsLoadingConfig(false);
    }

    fetchConfig();
    return () => {
      isMounted = false;
    };
  }, [website.id]);

  // Handle countdown for rate limiting cooldown
  useEffect(() => {
    if (cooldownSeconds <= 0) return;
    const timer = setInterval(() => {
      setCooldownSeconds((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldownSeconds]);

  // Copy helper with visual checkmark
  const handleCopy = (text: string, fieldId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => {
      setCopiedField((cur) => (cur === fieldId ? null : cur));
    }, 2000);
  };

  // Client-side validation preview
  const validationPreview = DomainService.normalizeDomain(domainInput);

  // Connect new domain
  const handleConnectDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!validationPreview.valid) {
      setStatusMessage({
        type: 'error',
        text: validationPreview.error || 'Please enter a valid domain name.',
      });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    const res = await DomainService.connectDomain({
      websiteId: website.id,
      domain: domainInput,
      userId: user.id,
    });

    setIsSubmitting(false);

    if (res.success && res.config) {
      setDomainConfig(res.config);
      updateCustomDomain(website.id, res.config);
      setStatusMessage({
        type: 'success',
        text: 'Custom domain registered. Add the DNS records below at your domain registrar.',
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: res.error || 'Failed to connect custom domain.',
      });
    }
  };

  // Verify domain via real DNS lookup
  const handleVerifyDomain = async () => {
    if (!user || !domainConfig || cooldownSeconds > 0) return;

    setIsVerifying(true);
    setStatusMessage(null);

    const res = await DomainService.verifyDomain({
      websiteId: website.id,
      domain: domainConfig.normalizedDomain,
      userId: user.id,
    });

    setIsVerifying(false);

    if (res.verified && res.config) {
      setDomainConfig(res.config);
      updateCustomDomain(website.id, res.config);
      setStatusMessage({
        type: 'success',
        text: 'DNS TXT verification successful! Your domain ownership has been verified.',
      });
    } else {
      if (res.config) {
        setDomainConfig(res.config);
      }
      setCooldownSeconds(4); // Start 4-second cooldown
      setStatusMessage({
        type: 'error',
        text:
          res.error ||
          'DNS verification record not found yet. DNS changes may take some time to propagate.',
      });
    }
  };

  // Simulate verification for testing/development
  const handleSimulateVerify = async (activate: boolean = true) => {
    if (!user || !domainConfig) return;

    setIsVerifying(true);
    setStatusMessage(null);

    const res = await DomainService.simulateTestVerify({
      websiteId: website.id,
      domain: domainConfig.normalizedDomain,
      userId: user.id,
      activate,
    });

    setIsVerifying(false);

    if (res.verified && res.config) {
      setDomainConfig(res.config);
      updateCustomDomain(website.id, res.config);
      setStatusMessage({
        type: 'success',
        text: `Test verification complete! Domain is now marked as ${res.config.connectionStatus}.`,
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: res.error || 'Failed to simulate verification.',
      });
    }
  };

  // Disconnect domain
  const handleDisconnectDomain = async () => {
    if (!user || !domainConfig) return;

    setIsDisconnecting(true);
    setStatusMessage(null);

    const res = await DomainService.disconnectDomain({
      websiteId: website.id,
      domain: domainConfig.normalizedDomain,
      userId: user.id,
    });

    setIsDisconnecting(false);
    setShowDisconnectConfirm(false);

    if (res.success) {
      setDomainConfig(null);
      setDomainInput('');
      updateCustomDomain(website.id, null);
      setStatusMessage({
        type: 'info',
        text: 'Custom domain disconnected. Your StorePilot URL remains fully active.',
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: res.error || 'Failed to disconnect domain.',
      });
    }
  };

  if (isLoadingConfig) {
    return (
      <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
        <RefreshCw className="w-6 h-6 animate-spin text-indigo-600" />
        <p className="text-xs text-slate-500 font-medium">Loading domain configuration...</p>
      </div>
    );
  }

  const isVerified =
    domainConfig?.verificationStatus === 'VERIFIED' || domainConfig?.connectionStatus === 'ACTIVE';

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Custom Domain Connection</h3>
            <p className="text-xs text-slate-500">
              Connect your own domain to display this published website.
            </p>
          </div>
        </div>

        {domainConfig && (
          <div className="flex items-center gap-2 shrink-0">
            {isVerified ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Verified & Connected
              </span>
            ) : domainConfig.verificationStatus === 'FAILED' ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                Verification Pending
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                Pending Verification
              </span>
            )}
          </div>
        )}
      </div>

      {/* Subscription Gating Banner for Starter users */}
      {!hasDomainAccess && (
        <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-950 text-xs flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Professional or Agency Plan Required</p>
            <p className="text-indigo-800 leading-relaxed">
              Custom domain hosting and DNS routing are available on the Professional ($29/mo) and Agency ($79/mo) plans. You are currently on the Starter ($0/mo) plan. Your website remains publicly viewable at its StorePilot URL.
            </p>
          </div>
        </div>
      )}

      {/* Notification Banner */}
      {statusMessage && (
        <div
          className={`p-3.5 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 transition-all ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : statusMessage.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-blue-50 border-blue-200 text-blue-800'
          }`}
        >
          {statusMessage.type === 'success' && (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          )}
          {statusMessage.type === 'error' && (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          )}
          {statusMessage.type === 'info' && (
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* No Domain Connected Form */}
      {!domainConfig ? (
        <form onSubmit={handleConnectDomain} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Enter Your Domain Name
            </label>
            <div className="relative">
              <input
                type="text"
                value={domainInput}
                onChange={(e) => setDomainInput(e.target.value)}
                placeholder="e.g. myfashionstore.com or www.myfashionstore.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
              />
            </div>
            {domainInput.trim() && (
              <p className="mt-1.5 text-xs text-slate-500 flex items-center gap-1.5 font-mono">
                Normalized hostname:{' '}
                <strong className={validationPreview.valid ? 'text-indigo-600' : 'text-rose-600'}>
                  {validationPreview.valid ? validationPreview.normalized : validationPreview.error}
                </strong>
              </p>
            )}
            <p className="mt-1 text-[11px] text-slate-400">
              Do not include <code className="text-slate-600 font-mono">https://</code> or path
              slashes. Enter your apex domain or subdomain.
            </p>
          </div>

          <div className="pt-2">
            <Button
              type="submit"
              disabled={isSubmitting || !validationPreview.valid}
              className="w-full sm:w-auto bg-slate-900 text-white hover:bg-slate-800"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin mr-1.5" />
                  Connecting Domain...
                </>
              ) : (
                <>
                  <Globe className="w-3.5 h-3.5 mr-1.5" />
                  Connect Domain
                </>
              )}
            </Button>
          </div>
        </form>
      ) : (
        /* Domain Connected: Show Records & Status */
        <div className="space-y-6">
          {/* Active Domain Info Box */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Target Domain
                </span>
                <div className="text-base font-bold text-slate-900 font-mono flex items-center gap-2">
                  <span>{domainConfig.domain}</span>
                  {domainConfig.primaryDomain && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 uppercase tracking-wide">
                      Primary
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isVerified && (
                  <a
                    href={`/?custom_domain=${encodeURIComponent(domainConfig.normalizedDomain)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors"
                  >
                    <span>Visit Custom Domain</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}

                <button
                  type="button"
                  onClick={() => setShowDisconnectConfirm(true)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Disconnect Domain"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* DNS Instructions Cards */}
            <div className="space-y-4 pt-1">
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-bold">
                    1
                  </span>
                  <span>Ownership Verification (TXT Record)</span>
                </h4>
                <p className="text-xs text-slate-500 mb-3">
                  Log in to your DNS provider (Cloudflare, GoDaddy, Namecheap, Google Domains) and add
                  this TXT record to prove domain ownership:
                </p>

                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden font-mono text-xs">
                  <div className="grid grid-cols-12 bg-slate-100/80 px-3 py-2 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
                    <div className="col-span-2">Type</div>
                    <div className="col-span-4">Host / Name</div>
                    <div className="col-span-6">Value / Content</div>
                  </div>
                  <div className="grid grid-cols-12 px-3 py-2.5 items-center bg-white divide-y sm:divide-y-0">
                    <div className="col-span-2 font-bold text-indigo-600">TXT</div>
                    <div className="col-span-4 flex items-center justify-between pr-2 text-slate-800">
                      <span>{domainConfig.dnsRecords.txt.host}</span>
                      <button
                        type="button"
                        onClick={() => handleCopy(domainConfig.dnsRecords.txt.host, 'txt-host')}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                        title="Copy Host"
                      >
                        {copiedField === 'txt-host' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                    <div className="col-span-6 flex items-center justify-between text-slate-800 break-all">
                      <span className="truncate pr-2">{domainConfig.dnsRecords.txt.value}</span>
                      <button
                        type="button"
                        onClick={() => handleCopy(domainConfig.dnsRecords.txt.value, 'txt-val')}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors shrink-0"
                        title="Copy Value"
                      >
                        {copiedField === 'txt-val' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 2: CNAME / Pointing */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-bold">
                    2
                  </span>
                  <span>Point Domain Traffic (CNAME Record)</span>
                </h4>
                <p className="text-xs text-slate-500 mb-3">
                  Add a CNAME record to route visitors to StorePilot hosting infrastructure:
                </p>

                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden font-mono text-xs">
                  <div className="grid grid-cols-12 bg-slate-100/80 px-3 py-2 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
                    <div className="col-span-2">Type</div>
                    <div className="col-span-4">Host / Name</div>
                    <div className="col-span-6">Value / Target</div>
                  </div>
                  <div className="grid grid-cols-12 px-3 py-2.5 items-center bg-white">
                    <div className="col-span-2 font-bold text-indigo-600">
                      {domainConfig.dnsRecords.cname.type}
                    </div>
                    <div className="col-span-4 flex items-center justify-between pr-2 text-slate-800">
                      <span>{domainConfig.dnsRecords.cname.host}</span>
                      <button
                        type="button"
                        onClick={() => handleCopy(domainConfig.dnsRecords.cname.host, 'cname-host')}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                        title="Copy Host"
                      >
                        {copiedField === 'cname-host' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                    <div className="col-span-6 flex items-center justify-between text-slate-800 break-all">
                      <span className="truncate pr-2">{domainConfig.dnsRecords.cname.value}</span>
                      <button
                        type="button"
                        onClick={() => handleCopy(domainConfig.dnsRecords.cname.value, 'cname-val')}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors shrink-0"
                        title="Copy Value"
                      >
                        {copiedField === 'cname-val' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Verification Button & Cooldown */}
            <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  onClick={handleVerifyDomain}
                  disabled={isVerifying || cooldownSeconds > 0}
                  className="bg-indigo-600 text-white hover:bg-indigo-700"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin mr-1.5" />
                      Checking DNS Records...
                    </>
                  ) : cooldownSeconds > 0 ? (
                    <>
                      <Clock className="w-3.5 h-3.5 mr-1.5" />
                      Wait {cooldownSeconds}s to retry
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5 mr-1.5" />
                      Verify Domain Records
                    </>
                  )}
                </Button>

                {/* Development / Preview Simulator Verification */}
                <button
                  type="button"
                  onClick={() => handleSimulateVerify(true)}
                  disabled={isVerifying}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
                  title="Simulate successful verification for testing in this sandbox environment"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Simulate Verify (Test Mode)</span>
                </button>
              </div>

              {domainConfig.lastCheckedAt && (
                <span className="text-[11px] text-slate-400">
                  Last checked: {new Date(domainConfig.lastCheckedAt).toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>

          {/* Infrastructure & SSL Note */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
            <Server className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-slate-800">
                About SSL & DNS Propagation
              </p>
              <p className="text-slate-500 leading-relaxed text-[11px]">
                DNS record changes may take some time to propagate globally depending on your registrar's TTL settings.
                Your original StorePilot URL (<span className="font-mono text-slate-700">/site/{website.publishedSlug || website.slug}</span>) remains permanently active and reachable throughout.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Disconnect Confirmation Modal */}
      {showDisconnectConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Disconnect Custom Domain?</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Are you sure you want to disconnect <strong className="text-slate-800">{domainConfig?.domain}</strong>?
                Your website will no longer load from this custom domain, but your StorePilot public URL will continue to work normally.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button
                variant="outline"
                onClick={() => setShowDisconnectConfirm(false)}
                disabled={isDisconnecting}
              >
                Cancel
              </Button>
              <Button
                onClick={handleDisconnectDomain}
                disabled={isDisconnecting}
                className="bg-rose-600 text-white hover:bg-rose-700"
              >
                {isDisconnecting ? 'Disconnecting...' : 'Yes, Disconnect'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
