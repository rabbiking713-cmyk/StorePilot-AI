import React, { useState, useEffect } from 'react';
import { Website } from '../../types';
import { useWebsites } from '../../context/WebsitesContext';
import { WebsiteService } from '../../services/data/websiteService';
import { CustomDomainManager } from './CustomDomainManager';
import {
  Globe,
  CheckCircle2,
  Copy,
  ExternalLink,
  AlertTriangle,
  Loader2,
  X,
  RefreshCw,
  Trash2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { useSubscription } from '../../context/SubscriptionContext';
import { UpgradePaywallModal } from '../subscription/UpgradePaywallModal';

interface PublishModalProps {
  website: Website;
  isOpen: boolean;
  onClose: () => void;
  onPublished?: (publicUrl: string) => void;
  initialTab?: 'storepilot' | 'custom_domain';
}

export const PublishModal: React.FC<PublishModalProps> = ({
  website,
  isOpen,
  onClose,
  onPublished,
  initialTab = 'storepilot',
}) => {
  const { publishWebsite, unpublishWebsite } = useWebsites();
  const { canPublish } = useSubscription();
  const [showPaywallModal, setShowPaywallModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'storepilot' | 'custom_domain'>(initialTab);

  // Sync tab when initialTab changes
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  // Initial slug
  const initialSlug = (website.publishedSlug || website.slug || website.name)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

  const [slug, setSlug] = useState<string>(initialSlug);
  const [isCheckingSlug, setIsCheckingSlug] = useState<boolean>(false);
  const [slugStatus, setSlugStatus] = useState<{
    available: boolean;
    error?: string;
    suggestedSlug?: string;
    isCurrent?: boolean;
  }>({ available: true });

  const [isPublishing, setIsPublishing] = useState<boolean>(false);
  const [isUnpublishing, setIsUnpublishing] = useState<boolean>(false);
  const [showUnpublishConfirm, setShowUnpublishConfirm] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [publishedUrl, setPublishedUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Compute live host
  const hostOrigin =
    typeof window !== 'undefined' ? window.location.origin : 'https://storepilot.site';
  const liveUrlPreview = `${hostOrigin}/site/${slug}`;

  // Check publish status
  const currentPublishStatus = WebsiteService.getPublishStatus(website);
  const isAlreadyPublished = Boolean(website.publishedAt && website.publishedSlug);
  const hasUnpublishedChanges = currentPublishStatus === 'changes_unpublished';

  // Synchronize slug on modal open
  useEffect(() => {
    if (isOpen) {
      const s = (website.publishedSlug || website.slug || website.name)
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');
      setSlug(s);
      setErrorMessage(null);
      setPublishedUrl(
        isAlreadyPublished ? `${hostOrigin}/site/${website.publishedSlug}` : null
      );
      setShowUnpublishConfirm(false);
    }
  }, [isOpen, website.id, website.publishedSlug, website.publishedAt]);

  // Debounced slug check
  useEffect(() => {
    if (!isOpen || !slug.trim()) return;

    let timer = setTimeout(async () => {
      setIsCheckingSlug(true);
      const res = await WebsiteService.checkSlugAvailability(slug, website.id);
      setSlugStatus(res);
      setIsCheckingSlug(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [slug, isOpen, website.id]);

  if (!isOpen) return null;

  // Handle slug input change with auto-formatting
  const handleSlugChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const sanitized = raw
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '')
      .replace(/--+/g, '-');
    setSlug(sanitized);
  };

  // Publish action
  const handlePublish = async () => {
    if (!canPublish) {
      setShowPaywallModal(true);
      return;
    }

    if (!slug.trim()) {
      setErrorMessage('Please enter a valid URL slug.');
      return;
    }

    if (slug.length < 2 || slug.length > 60) {
      setErrorMessage('Slug must be between 2 and 60 characters long.');
      return;
    }

    if (!slugStatus.available && !slugStatus.isCurrent) {
      setErrorMessage(slugStatus.error || 'The requested URL slug is unavailable.');
      return;
    }

    setIsPublishing(true);
    setErrorMessage(null);

    try {
      const result = await publishWebsite(website.id, slug);
      setPublishedUrl(result.publicUrl);
      if (onPublished) {
        onPublished(result.publicUrl);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to publish website.');
    } finally {
      setIsPublishing(false);
    }
  };

  // Unpublish action
  const handleUnpublish = async () => {
    setIsUnpublishing(true);
    setErrorMessage(null);
    try {
      await unpublishWebsite(website.id);
      setPublishedUrl(null);
      setShowUnpublishConfirm(false);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to unpublish website.');
    } finally {
      setIsUnpublishing(false);
    }
  };

  // Copy link
  const handleCopy = async () => {
    if (!canPublish) {
      setShowPaywallModal(true);
      return;
    }

    const url = publishedUrl || liveUrlPreview;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  // Open in new tab
  const handleOpenLive = () => {
    const url = publishedUrl || liveUrlPreview;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isAlreadyPublished ? 'Publication Settings' : 'Publish Website'}
              </h3>
              <p className="text-[11px] text-slate-500 truncate max-w-[260px] sm:max-w-xs">
                {website.name}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-100 bg-slate-50/70 px-6 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('storepilot')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'storepilot'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>StorePilot URL</span>
            {isAlreadyPublished && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('custom_domain')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'custom_domain'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Custom Domain</span>
            {website.customDomain && (
              <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-600">
                {website.customDomain}
              </span>
            )}
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {activeTab === 'custom_domain' ? (
            <CustomDomainManager website={website} onClose={onClose} />
          ) : publishedUrl && !showUnpublishConfirm ? (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-emerald-900">
                    Your website is live on StorePilot!
                  </h4>
                  <p className="text-xs text-emerald-700 leading-relaxed">
                    Anyone can view this website without logging in. Future changes in your editor will remain private until you click Republish.
                  </p>
                </div>
              </div>

              {/* Public URL Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Public StorePilot URL
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 truncate select-all">
                    {publishedUrl}
                  </div>
                  {canPublish ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopy}
                      className="shrink-0 text-xs flex items-center gap-1.5"
                    >
                      {copied ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700 font-semibold">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowPaywallModal(true)}
                      className="shrink-0 text-xs flex items-center gap-1.5 border-indigo-200 text-indigo-700 bg-indigo-50 hover:bg-indigo-100"
                    >
                      <Lock className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Upgrade to Share</span>
                    </Button>
                  )}
                </div>
              </div>

              {/* SEO & Discoverability Highlights */}
              <div className="bg-indigo-50/70 border border-indigo-100 rounded-xl p-3.5 space-y-1.5 text-xs">
                <div className="flex items-center gap-2 font-bold text-indigo-900 text-xs">
                  <Globe className="w-4 h-4 text-indigo-600" />
                  <span>Google & Search Engine Discoverability</span>
                </div>
                <p className="text-[11px] text-indigo-700 leading-relaxed">
                  Your shop has been automatically submitted to the public XML sitemap (<span className="font-mono">/sitemap.xml</span>) with canonical URL tags, social sharing metadata, and Schema.org structured data. Search engines independently decide when to crawl and index pages.
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleOpenLive}
                  className="w-full sm:flex-1 text-xs flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Live Website</span>
                </Button>
                <Button
                  variant="outline"
                  size="md"
                  onClick={onClose}
                  className="w-full sm:w-auto text-xs"
                >
                  Done
                </Button>
              </div>

              {/* Connect Custom Domain Quick Action */}
              <button
                type="button"
                onClick={() => setActiveTab('custom_domain')}
                className="w-full text-xs font-semibold py-2.5 px-3.5 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 hover:bg-indigo-100 transition-colors flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Connect a custom domain (e.g. yourstore.com)</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-indigo-500" />
              </button>

              {/* Additional options toggle */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px]">
                  Version {website.publishedVersion || 1} • Published {new Date(website.publishedAt || Date.now()).toLocaleDateString()}
                </span>
                <button
                  type="button"
                  onClick={() => setShowUnpublishConfirm(true)}
                  className="text-rose-600 hover:text-rose-700 text-xs font-medium hover:underline cursor-pointer flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  Unpublish
                </button>
              </div>
            </div>
          ) : showUnpublishConfirm ? (
            /* Unpublish Confirmation Screen */
            <div className="space-y-4">
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-rose-900">
                    Unpublish &quot;{website.name}&quot;?
                  </h4>
                  <p className="text-xs text-rose-700 leading-relaxed">
                    This will take your website offline immediately. Visitors to <span className="font-mono">{liveUrlPreview}</span> will see a 404 page. Your draft in StorePilot remains safe and you can republish anytime.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowUnpublishConfirm(false)}
                  disabled={isUnpublishing}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleUnpublish}
                  disabled={isUnpublishing}
                  className="bg-rose-600 hover:bg-rose-700 text-white border-transparent text-xs flex items-center gap-1.5"
                >
                  {isUnpublishing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isUnpublishing ? 'Unpublishing...' : 'Yes, Unpublish Website'}</span>
                </Button>
              </div>
            </div>
          ) : (
            /* Standard Publish / Republish Form */
            <div className="space-y-4">
              {/* Starter Plan Notice Banner */}
              {!canPublish && (
                <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-950 text-xs flex items-start gap-2.5">
                  <Lock className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-bold">Publishing Requires an Upgrade</p>
                    <p className="text-indigo-800 leading-relaxed text-[11px]">
                      Starter users can design, build, and privately preview websites for free. To publish to a live public URL and share with the world, upgrade to Professional ($29/mo) or Agency ($79/mo).
                    </p>
                  </div>
                </div>
              )}

              {/* Publication Status Banner */}
              {isAlreadyPublished && (
                <div
                  className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs ${
                    hasUnpublishedChanges
                      ? 'bg-amber-50 border-amber-200 text-amber-900'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  }`}
                >
                  {hasUnpublishedChanges ? (
                    <RefreshCw className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-0.5">
                    <p className="font-bold">
                      {hasUnpublishedChanges
                        ? 'Changes Not Published'
                        : 'Website is Currently Live'}
                    </p>
                    <p className="text-[11px] leading-relaxed opacity-90">
                      {hasUnpublishedChanges
                        ? 'You have edits in your visual editor that have not been published yet. The public URL still shows the previously published snapshot.'
                        : 'The live public website is in sync with your latest draft.'}
                    </p>
                  </div>
                </div>
              )}

              {/* Slug configuration input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800 flex items-center justify-between">
                  <span>URL Slug</span>
                  {isCheckingSlug ? (
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Loader2 className="w-2.5 h-2.5 animate-spin" /> Checking...
                    </span>
                  ) : slugStatus.available ? (
                    <span className="text-[11px] text-emerald-600 flex items-center gap-1 font-medium">
                      <CheckCircle2 className="w-3 h-3" /> Available
                    </span>
                  ) : (
                    <span className="text-[11px] text-amber-600 flex items-center gap-1 font-medium">
                      <AlertTriangle className="w-3 h-3" /> Slug in use
                    </span>
                  )}
                </label>

                <div className="relative flex rounded-xl border border-slate-300 focus-within:border-indigo-600 focus-within:ring-1 focus-within:ring-indigo-600 overflow-hidden bg-slate-50">
                  <span className="inline-flex items-center px-3 text-xs text-slate-400 font-mono select-none border-r border-slate-200 bg-slate-100">
                    /site/
                  </span>
                  <input
                    type="text"
                    value={slug}
                    onChange={handleSlugChange}
                    placeholder="my-fashion-store"
                    className="flex-1 px-3 py-2 text-xs font-mono text-slate-900 bg-white placeholder:text-slate-400 focus:outline-none"
                  />
                </div>

                {/* Suggested slug button if conflict */}
                {!slugStatus.available && slugStatus.suggestedSlug && (
                  <div className="pt-1 flex items-center gap-2">
                    <span className="text-[11px] text-slate-500">Suggested:</span>
                    <button
                      type="button"
                      onClick={() => setSlug(slugStatus.suggestedSlug!)}
                      className="text-[11px] font-mono text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded border border-indigo-200 cursor-pointer"
                    >
                      {slugStatus.suggestedSlug}
                    </button>
                  </div>
                )}
              </div>

              {/* Full Live URL Preview */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Live Public URL Preview
                </span>
                <span className="text-xs font-mono text-indigo-600 break-all select-all block font-medium">
                  {liveUrlPreview}
                </span>
              </div>

              {/* Snapshot Explanation Card */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1 text-xs text-slate-600">
                <div className="flex items-center gap-1.5 font-bold text-slate-800 text-[11px]">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Draft vs. Published Snapshot</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Publishing creates a fixed snapshot of your current WebsiteSpec. You can continue editing your draft in StorePilot privately; your live website will only update when you click Republish.
                </p>
              </div>

              {/* Error message */}
              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Modal Actions */}
              <div className="pt-2 flex items-center justify-between gap-3">
                {isAlreadyPublished ? (
                  <button
                    type="button"
                    onClick={() => setShowUnpublishConfirm(true)}
                    className="text-xs text-rose-600 hover:text-rose-700 font-medium hover:underline cursor-pointer"
                  >
                    Unpublish website
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onClose}
                    disabled={isPublishing}
                    className="text-xs"
                  >
                    Cancel
                  </Button>
                  {!canPublish ? (
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => setShowPaywallModal(true)}
                      className="text-xs flex items-center gap-1.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Upgrade to Publish</span>
                    </Button>
                  ) : (
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={handlePublish}
                      disabled={isPublishing || (!slugStatus.available && !slugStatus.isCurrent)}
                      className="text-xs flex items-center gap-1.5 px-4"
                    >
                      {isPublishing ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Globe className="w-3.5 h-3.5" />
                      )}
                      <span>
                        {isPublishing
                          ? 'Publishing...'
                          : isAlreadyPublished
                          ? hasUnpublishedChanges
                            ? 'Republish Changes'
                            : 'Republish Website'
                          : 'Publish Website'}
                      </span>
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Starter Plan Paywall Modal */}
      <UpgradePaywallModal
        isOpen={showPaywallModal}
        onClose={() => setShowPaywallModal(false)}
        triggerContext="publish"
      />
    </div>
  );
};
