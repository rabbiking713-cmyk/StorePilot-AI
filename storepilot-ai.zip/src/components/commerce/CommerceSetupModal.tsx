import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Search,
  Check,
  X,
  AlertCircle,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Sliders,
  DollarSign,
  ArrowRight,
  CheckCircle2,
  Trash2,
  Loader2,
} from 'lucide-react';
import {
  CommerceIntentDetectionResult,
  PrintifyBlueprint,
  StorePilotProduct,
} from '../../types/commerce';
import { CommerceApiClient } from '../../services/commerce/commerceApiClient';

interface CommerceSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt: string;
  initialIntent: CommerceIntentDetectionResult | null;
  onProductsApproved: (approved: StorePilotProduct[]) => void;
  onSwitchToStandardBuilder: () => void;
}

export const CommerceSetupModal: React.FC<CommerceSetupModalProps> = ({
  isOpen,
  onClose,
  initialPrompt,
  initialIntent,
  onProductsApproved,
  onSwitchToStandardBuilder,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>(
    initialIntent?.detectedProductQuery || 'sneakers'
  );
  const [selectedStyle, setSelectedStyle] = useState<string>(
    initialIntent?.suggestedStyle || 'Clean & Modern'
  );
  const [targetAudience, setTargetAudience] = useState<string>(
    initialIntent?.targetAudience || 'Modern Consumers'
  );
  const [currencySymbol, setCurrencySymbol] = useState<string>('$');
  const [currencyCode, setCurrencyCode] = useState<string>('USD');

  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<PrintifyBlueprint[]>([]);
  const [totalFound, setTotalFound] = useState<number>(0);
  const [apiConfigured, setApiConfigured] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Selected for approval
  const [selectedBlueprintIds, setSelectedBlueprintIds] = useState<Set<number>>(new Set());
  const [customPrices, setCustomPrices] = useState<Record<number, number>>({});
  const [customTitles, setCustomTitles] = useState<Record<number, string>>({});

  // Approved products drawer
  const [approvedProducts, setApprovedProducts] = useState<StorePilotProduct[]>([]);

  useEffect(() => {
    if (isOpen) {
      if (initialIntent?.detectedProductQuery) {
        setSearchQuery(initialIntent.detectedProductQuery);
      }
      handleSearch(initialIntent?.detectedProductQuery || searchQuery || 'apparel');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSearch = async (overrideQuery?: string) => {
    const q = (overrideQuery !== undefined ? overrideQuery : searchQuery).trim();
    setIsSearching(true);
    setApiError(null);

    try {
      const res = await CommerceApiClient.searchCatalog(q, 24);
      setApiConfigured(res.configured);
      if (res.configured && res.success) {
        setSearchResults(res.products);
        setTotalFound(res.totalFound);
      } else {
        setSearchResults([]);
        setTotalFound(0);
        if (res.error) {
          setApiError(res.error);
        }
      }
    } catch (err: any) {
      setApiError(err?.message || 'Failed to search Printify catalog.');
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const toggleSelectBlueprint = (bp: PrintifyBlueprint) => {
    const next = new Set(selectedBlueprintIds);
    if (next.has(bp.id)) {
      next.delete(bp.id);
    } else {
      next.add(bp.id);
      if (!customPrices[bp.id]) {
        setCustomPrices((prev) => ({ ...prev, [bp.id]: 48.0 }));
      }
      if (!customTitles[bp.id]) {
        setCustomTitles((prev) => ({ ...prev, [bp.id]: bp.title }));
      }
    }
    setSelectedBlueprintIds(next);
  };

  const handleApproveSelected = () => {
    const newlyApproved: StorePilotProduct[] = [];
    const now = new Date().toISOString();

    for (const bp of searchResults) {
      if (selectedBlueprintIds.has(bp.id)) {
        // Prevent duplicate approval in list
        if (!approvedProducts.some((p) => p.printifyBlueprintId === bp.id)) {
          newlyApproved.push({
            id: `sp_prod_${bp.id}_${Date.now()}`,
            websiteId: 'pending_draft',
            ownerId: 'current_user',
            printifyBlueprintId: bp.id,
            printifyTitle: bp.title,
            printifyBrand: bp.brand,
            printifyModel: bp.model,
            storefrontTitle: customTitles[bp.id] || bp.title,
            storefrontDescription: bp.description || 'Premium print-on-demand product crafted with quality.',
            storefrontPrice: customPrices[bp.id] || 48.0,
            currency: currencyCode,
            currencySymbol: currencySymbol,
            images: bp.images.length > 0 ? bp.images : ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80'],
            isApproved: true,
            isFeatured: newlyApproved.length === 0,
            badge: newlyApproved.length === 0 ? 'Best Seller' : 'New',
            createdAt: now,
            updatedAt: now,
          });
        }
      }
    }

    setApprovedProducts((prev) => [...prev, ...newlyApproved]);
    setSelectedBlueprintIds(new Set());
  };

  const handleRemoveApproved = (blueprintId: number) => {
    setApprovedProducts((prev) => prev.filter((p) => p.printifyBlueprintId !== blueprintId));
  };

  const handleFinishAndBuild = () => {
    if (approvedProducts.length === 0) {
      alert('Please approve at least one product before building your e-commerce store.');
      return;
    }
    onProductsApproved(approvedProducts);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">Commerce & Product Engine</h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Phase 7A
                </span>
              </div>
              <p className="text-xs text-slate-300">
                AI detected e-commerce intent. Search and approve real catalog products for your website.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Intent Info Bar */}
        <div className="px-6 py-3 bg-amber-50/80 border-b border-amber-200/60 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Detected intent: <strong>Online Store (ECOMMERCE)</strong> for:{' '}
              <em className="text-amber-800">"{initialPrompt.slice(0, 70)}..."</em>
            </span>
          </div>
          <button
            type="button"
            onClick={onSwitchToStandardBuilder}
            className="text-amber-800 hover:text-amber-950 font-semibold underline flex items-center gap-1"
          >
            Not selling products? Switch to standard website builder
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Search & Configuration Bar */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/60 shrink-0">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-6">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                What are you selling? (Printify Catalog Search)
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="e.g. sneakers, hoodie, ceramic mug, tote bag..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-bold text-slate-700 mb-1">Style / Brand Mood</label>
              <select
                value={selectedStyle}
                onChange={(e) => setSelectedStyle(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="Clean & Modern">Clean & Modern</option>
                <option value="Streetwear & Urban">Streetwear & Urban</option>
                <option value="Luxury & Editorial">Luxury & Editorial</option>
                <option value="Warm & Artisanal">Warm & Artisanal</option>
                <option value="Bold & Energetic">Bold & Energetic</option>
              </select>
            </div>

            <div className="sm:col-span-3 flex items-end">
              <button
                type="button"
                onClick={() => handleSearch()}
                disabled={isSearching}
                className="w-full py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-sm shadow-xs flex items-center justify-center gap-2 transition-colors"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    Search Catalog
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* UNCONFIGURED PRINTIFY ALERT */}
          {!apiConfigured && (
            <div className="p-5 rounded-xl border border-amber-300 bg-amber-50/70 text-slate-800">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-2">
                  <h4 className="font-bold text-sm text-amber-900">
                    PRINTIFY INTEGRATION ARCHITECTURE IMPLEMENTED — REAL PRINTIFY API NOT VERIFIED BECAUSE CREDENTIALS ARE NOT CONFIGURED
                  </h4>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    StorePilot requires valid catalog credentials in the server environment to browse Printify's live catalog.
                    In accordance with StorePilot zero-fakery rules, no simulated or fictional products are invented.
                  </p>
                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <span className="text-[11px] font-mono bg-white px-2 py-1 rounded border border-amber-200 text-slate-700">
                      Server API Token required
                    </span>
                    <button
                      type="button"
                      onClick={onSwitchToStandardBuilder}
                      className="px-3 py-1.5 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-xs font-bold text-amber-900 transition-colors"
                    >
                      Continue with Standard Website Builder →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Search Results Area */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span>PRINTIFY REAL CATALOG RESULTS</span>
                  {totalFound > 0 && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                      {totalFound} available
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-500">
                  Select and review authentic products. Selected products require explicit approval before adding to your store.
                </p>
              </div>

              {selectedBlueprintIds.size > 0 && (
                <button
                  type="button"
                  onClick={handleApproveSelected}
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Check className="w-3.5 h-3.5" />
                  Approve Selected ({selectedBlueprintIds.size})
                </button>
              )}
            </div>

            {isSearching ? (
              <div className="py-16 text-center text-slate-400">
                <Loader2 className="w-8 h-8 animate-spin mx-auto text-indigo-500 mb-2" />
                <p className="text-xs font-medium">Querying real Printify catalog...</p>
              </div>
            ) : searchResults.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {searchResults.map((bp) => {
                  const isSelected = selectedBlueprintIds.has(bp.id);
                  const isAlreadyApproved = approvedProducts.some((p) => p.printifyBlueprintId === bp.id);

                  return (
                    <div
                      key={bp.id}
                      onClick={() => !isAlreadyApproved && toggleSelectBlueprint(bp)}
                      className={`relative rounded-xl border p-4 transition-all cursor-pointer flex flex-col justify-between ${
                        isAlreadyApproved
                          ? 'border-emerald-300 bg-emerald-50/40 opacity-80 cursor-default'
                          : isSelected
                          ? 'border-indigo-600 ring-2 ring-indigo-500/20 bg-indigo-50/20'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div>
                        {/* Thumbnail */}
                        <div className="relative aspect-4/3 rounded-lg overflow-hidden bg-slate-100 mb-3 flex items-center justify-center">
                          {bp.images && bp.images.length > 0 ? (
                            <img
                              src={bp.images[0]}
                              alt={bp.title}
                              className="w-full h-full object-contain p-2"
                              loading="lazy"
                            />
                          ) : (
                            <div className="text-xs text-slate-400 flex flex-col items-center gap-1">
                              <ShoppingBag className="w-6 h-6 opacity-40" />
                              <span>Catalog Preview</span>
                            </div>
                          )}
                          <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900/80 text-white">
                            ID #{bp.id}
                          </span>
                          {isAlreadyApproved && (
                            <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1">
                              <Check className="w-3 h-3" /> Approved
                            </span>
                          )}
                        </div>

                        {/* Info */}
                        <h4 className="font-bold text-xs text-slate-900 line-clamp-2 mb-1">
                          {bp.title}
                        </h4>
                        {(bp.brand || bp.model) && (
                          <p className="text-[11px] text-slate-500 mb-2">
                            {bp.brand} {bp.model && `• ${bp.model}`}
                          </p>
                        )}
                        {bp.description && (
                          <p className="text-[11px] text-slate-500 line-clamp-2 mb-3">
                            {bp.description}
                          </p>
                        )}
                      </div>

                      {/* Controls */}
                      <div className="pt-3 border-t border-slate-100 mt-2 flex items-center justify-between">
                        <div className="flex items-center gap-1 text-xs font-bold text-slate-700">
                          <span>{currencySymbol}</span>
                          <input
                            type="number"
                            min="1"
                            step="0.5"
                            value={customPrices[bp.id] || 48}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setCustomPrices((prev) => ({ ...prev, [bp.id]: val }));
                            }}
                            className="w-16 px-1.5 py-0.5 border border-slate-200 rounded text-xs text-right font-mono"
                          />
                        </div>

                        {!isAlreadyApproved && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSelectBlueprint(bp);
                            }}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                              isSelected
                                ? 'bg-indigo-600 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            }`}
                          >
                            {isSelected ? 'Selected' : 'Select'}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-12 text-center text-slate-400 bg-slate-50/50 rounded-xl border border-slate-100">
                <ShoppingBag className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-medium text-slate-600">
                  {apiConfigured
                    ? `No Printify products matched "${searchQuery}". Try searching for apparel, mugs, hoodies, or posters.`
                    : 'Connect catalog credentials on server to search live Printify catalog.'}
                </p>
              </div>
            )}
          </div>

          {/* APPROVED PRODUCTS TRAY */}
          {approvedProducts.length > 0 && (
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/30">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <h4 className="font-bold text-xs text-emerald-950 uppercase tracking-wide">
                    APPROVED PRODUCTS FOR YOUR WEBSITE ({approvedProducts.length})
                  </h4>
                </div>
                <span className="text-[11px] text-emerald-800">
                  These verified products will be built into your store.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {approvedProducts.map((prod) => (
                  <div
                    key={prod.printifyBlueprintId}
                    className="p-2.5 rounded-lg border border-emerald-200 bg-white flex items-center justify-between gap-3 shadow-2xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={prod.images[0]}
                        alt={prod.storefrontTitle}
                        className="w-10 h-10 rounded object-contain bg-slate-50 border border-slate-100 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {prod.storefrontTitle}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {prod.currencySymbol}
                          {prod.storefrontPrice.toFixed(2)} • ID #{prod.printifyBlueprintId}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveApproved(prod.printifyBlueprintId)}
                      className="p-1 text-slate-400 hover:text-red-500 transition-colors"
                      title="Remove approved product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-200 bg-white flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 hidden sm:inline">
              Approved products:{' '}
              <strong className="text-slate-800">{approvedProducts.length}</strong>
            </span>
            <button
              type="button"
              onClick={handleFinishAndBuild}
              disabled={approvedProducts.length === 0}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-bold text-xs shadow-sm flex items-center gap-2 transition-colors"
            >
              <span>Build My Store with Approved Products</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
