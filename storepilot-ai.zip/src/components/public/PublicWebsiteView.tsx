import React, { useState, useEffect } from 'react';
import { WebsiteSpec } from '../../types/websiteSpec';
import { WebsiteRenderer } from '../preview/WebsiteRenderer';
import { Globe, ArrowRight, AlertCircle, Loader2 } from 'lucide-react';
import { DomainService } from '../../services/data/domainService';
import { generateShopMetadata, getStorePilotPrimaryOrigin, ShopSeoMetadata } from '../../services/seo/seoService';
import { PublishedSiteRecord } from '../../types';
import { CartProvider } from '../../context/CartContext';
import { CartDrawer } from './CartDrawer';
import { CheckoutModal } from './CheckoutModal';
import { OrderConfirmationModal } from './OrderConfirmationModal';

interface PublicWebsiteViewProps {
  slug?: string;
  customDomain?: string;
}

interface PublishedSiteData {
  name: string;
  slug: string;
  description?: string;
  publishedAt: string;
  publishedVersion: number;
  spec: WebsiteSpec;
}

function updateOrCreateMetaTag(attrName: 'name' | 'property', attrValue: string, content: string | undefined) {
  if (typeof document === 'undefined') return;
  let tag = document.querySelector(`meta[${attrName}="${attrValue}"]`);
  if (!content) {
    if (tag) tag.remove();
    return;
  }
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute(attrName, attrValue);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
}

function updateOrCreateCanonical(url: string | undefined) {
  if (typeof document === 'undefined') return;
  let link = document.querySelector('link[rel="canonical"]');
  if (!url) {
    if (link) link.remove();
    return;
  }
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', url);
}

function updateJsonLd(jsonLd: Record<string, any> | undefined) {
  if (typeof document === 'undefined') return;
  const scriptId = 'storepilot-shop-jsonld';
  let script = document.getElementById(scriptId);
  if (!jsonLd) {
    if (script) script.remove();
    return;
  }
  if (!script) {
    script = document.createElement('script');
    script.id = scriptId;
    script.setAttribute('type', 'application/ld+json');
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify(jsonLd, null, 2);
}

function applyClientSeo(metadata: ShopSeoMetadata) {
  document.title = metadata.title;
  updateOrCreateMetaTag('name', 'description', metadata.description);
  updateOrCreateMetaTag('name', 'robots', metadata.robots);
  updateOrCreateCanonical(metadata.canonicalUrl);
  updateOrCreateMetaTag('property', 'og:title', metadata.ogTitle);
  updateOrCreateMetaTag('property', 'og:description', metadata.ogDescription);
  updateOrCreateMetaTag('property', 'og:type', metadata.ogType);
  updateOrCreateMetaTag('property', 'og:url', metadata.ogUrl);
  updateOrCreateMetaTag('property', 'og:site_name', metadata.ogSiteName);
  updateOrCreateMetaTag('property', 'og:image', metadata.ogImage);
  updateOrCreateMetaTag('name', 'twitter:card', metadata.twitterCard);
  updateOrCreateMetaTag('name', 'twitter:title', metadata.twitterTitle);
  updateOrCreateMetaTag('name', 'twitter:description', metadata.twitterDescription);
  updateOrCreateMetaTag('name', 'twitter:image', metadata.twitterImage);
  updateJsonLd(metadata.jsonLd);
}

function applyNoIndex(title = '404 — Shop Not Found | StorePilot') {
  document.title = title;
  updateOrCreateMetaTag('name', 'robots', 'noindex, nofollow');
  updateOrCreateCanonical(undefined);
  updateJsonLd(undefined);
}

export const PublicWebsiteView: React.FC<PublicWebsiteViewProps> = ({ slug, customDomain }) => {
  const [siteData, setSiteData] = useState<PublishedSiteData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isCustomDomainView, setIsCustomDomainView] = useState<boolean>(Boolean(customDomain));
  const [activeOrderReference, setActiveOrderReference] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    const params = new URLSearchParams(window.location.search);
    return (
      params.get('reference') ||
      params.get('trxref') ||
      params.get('order_ref') ||
      null
    );
  });

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    setError(null);

    async function fetchWebsite() {
      try {
        const origin = getStorePilotPrimaryOrigin(window.location.origin);

        if (customDomain) {
          setIsCustomDomainView(true);
          const lookup = await DomainService.lookupDomain(customDomain);
          if (!isMounted) return;

          if (!lookup.success || !lookup.site) {
            setError(
              lookup.error ||
                `The custom domain "${customDomain}" is connected, but the associated website is not yet published.`
            );
            setIsLoading(false);
            applyNoIndex('Domain Inactive | StorePilot');
            return;
          }

          setSiteData(lookup.site);
          setIsLoading(false);

          if (lookup.site.spec) {
            const fakeRecord: PublishedSiteRecord = {
              slug: lookup.site.slug,
              siteId: lookup.site.slug,
              userId: 'public',
              name: lookup.site.name,
              description: lookup.site.description,
              publishedSpec: lookup.site.spec,
              publishedAt: lookup.site.publishedAt || new Date().toISOString(),
              publishedVersion: lookup.site.publishedVersion || 1,
              status: 'published',
            };
            const meta = generateShopMetadata(fakeRecord, origin);
            applyClientSeo(meta);
          }
        } else if (slug) {
          setIsCustomDomainView(false);
          const response = await fetch(`/api/published/${encodeURIComponent(slug)}`);
          const result = await response.json().catch(() => ({}));

          if (!isMounted) return;

          if (!response.ok || !result.success || !result.site) {
            setError(
              result.error ||
                `The website "${slug}" could not be found. It may have been unpublished or the link might be mistyped.`
            );
            setIsLoading(false);
            applyNoIndex(`Shop Not Found | StorePilot`);
            return;
          }

          const data: PublishedSiteData = result.site;
          setSiteData(data);
          setIsLoading(false);

          // Update SEO metadata dynamically
          if (data.spec) {
            const record: PublishedSiteRecord = {
              slug: data.slug,
              siteId: data.slug,
              userId: 'public',
              name: data.name,
              description: data.description,
              publishedSpec: data.spec,
              publishedAt: data.publishedAt || new Date().toISOString(),
              publishedVersion: data.publishedVersion || 1,
              status: 'published',
            };
            const meta = generateShopMetadata(record, origin);
            applyClientSeo(meta);
          }
        }
      } catch (err: any) {
        if (!isMounted) return;
        setError(err?.message || 'Failed to connect to hosting service.');
        setIsLoading(false);
        applyNoIndex();
      }
    }

    fetchWebsite();

    return () => {
      isMounted = false;
      // Clean up metadata when leaving the public site view
      updateOrCreateMetaTag('name', 'robots', undefined);
      updateJsonLd(undefined);
    };
  }, [slug, customDomain]);

  // Loading State
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm mb-4 shadow-lg shadow-indigo-100 animate-pulse">
          SP
        </div>
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
          Loading website...
        </div>
        <p className="text-xs text-slate-400 mt-1 font-mono">
          {customDomain ? `https://${customDomain}` : `/site/${slug}`}
        </p>
      </div>
    );
  }

  // 404 / Error State
  if (error || !siteData || !siteData.spec) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200 p-8 shadow-sm text-center space-y-5">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-100 text-amber-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-7 h-7" />
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono">
              404 — Page Not Found
            </span>
            <h1 className="text-xl font-bold text-slate-900">
              {customDomain ? 'Custom Domain Inactive' : 'Website Not Found'}
            </h1>
            <p className="text-xs text-slate-600 leading-relaxed">
              {customDomain ? (
                <>
                  The domain <span className="font-mono font-semibold text-slate-800">{customDomain}</span> is either not configured, pending DNS verification, or the associated website hasn't been published yet.
                </>
              ) : (
                <>
                  The website at <span className="font-mono font-semibold text-slate-800">/site/{slug}</span> does not exist, may have been unpublished by its owner, or the URL address was mistyped.
                </>
              )}
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href="/"
              className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors w-full sm:w-auto"
            >
              <span>Build your own website</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
            <Globe className="w-3.5 h-3.5 text-indigo-500" />
            <span>StorePilot AI Hosting</span>
          </div>
        </div>
      </div>
    );
  }

  // Live Published Website Rendering (Custom Domain or StorePilot URL)
  return (
    <CartProvider>
      <div className="relative min-h-screen w-full bg-white">
        {/* 
          Standalone Website View:
          - Full viewport rendering
          - No editor controls, no builder panels, no admin UI
          - Interactive links and CTA smooth scrolling
        */}
        <WebsiteRenderer
          spec={siteData.spec}
          isInteractive={true}
          isEditorMode={false}
        />

        {/* Global Cart Slideout Drawer */}
        <CartDrawer primaryColor={siteData.spec.theme?.primaryColor} />

        {/* Secure Checkout Modal */}
        <CheckoutModal
          slug={siteData.slug}
          storeName={siteData.spec.businessName || siteData.name}
          primaryColor={siteData.spec.theme?.primaryColor}
          onOrderInitialized={(_orderId, ref) => {
            setActiveOrderReference(ref);
          }}
        />

        {/* Order Confirmation / Receipt Modal (also triggered after Paystack redirect) */}
        {activeOrderReference && (
          <OrderConfirmationModal
            orderReference={activeOrderReference}
            primaryColor={siteData.spec.theme?.primaryColor}
            onClose={() => {
              setActiveOrderReference(null);
              // Clean query parameter from URL without page reload
              if (typeof window !== 'undefined' && window.history.replaceState) {
                const url = new URL(window.location.href);
                url.searchParams.delete('reference');
                url.searchParams.delete('trxref');
                url.searchParams.delete('order_ref');
                window.history.replaceState({}, document.title, url.pathname + (url.search ? url.search : ''));
              }
            }}
          />
        )}

        {/* When viewed on custom domain, render completely clean (no StorePilot banner/badge) */}
        {!isCustomDomainView && (
          <aside
            aria-label="Website hosting attribution"
            className="fixed bottom-4 right-4 z-50 print:hidden"
          >
            <a
              href="/"
              className="group flex items-center gap-2 px-3 py-1.5 bg-slate-950/90 hover:bg-slate-950 text-white text-xs rounded-full shadow-lg border border-slate-700/60 backdrop-blur-md transition-all hover:scale-105"
              title="Generated with StorePilot AI"
            >
              <div className="w-4 h-4 rounded-full bg-indigo-500 flex items-center justify-center font-black text-[9px] text-white">
                SP
              </div>
              <span className="text-[11px] font-medium text-slate-300 group-hover:text-white transition-colors">
                Built with <strong className="text-white font-semibold">StorePilot AI</strong>
              </span>
            </a>
          </aside>
        )}
      </div>
    </CartProvider>
  );
};
