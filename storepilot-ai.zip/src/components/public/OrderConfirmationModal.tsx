import React, { useState, useEffect } from 'react';
import { StoreOrder } from '../../types/order';
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  ShoppingBag,
  ArrowLeft,
  RotateCw,
  Truck,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
} from 'lucide-react';

interface OrderConfirmationModalProps {
  orderReference: string;
  onClose: () => void;
  primaryColor?: string;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  orderReference,
  onClose,
  primaryColor = '#0f172a',
}) => {
  const [order, setOrder] = useState<StoreOrder | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAndVerifyOrder = async (isManualRefresh = false) => {
    if (isManualRefresh) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      // First attempt server-side Paystack verification
      const verifyRes = await fetch(`/api/checkout/verify/${encodeURIComponent(orderReference)}`);
      const verifyData = await verifyRes.json();

      if (verifyData.success && verifyData.order) {
        setOrder(verifyData.order);
      } else {
        // Fallback to order receipt retrieval if verify failed (e.g. unconfigured or non-Paystack)
        const orderRes = await fetch(`/api/checkout/order/${encodeURIComponent(orderReference)}`);
        const orderData = await orderRes.json();
        if (orderData.success && orderData.order) {
          setOrder(orderData.order);
        } else {
          setError(verifyData.error || orderData.error || 'Order record not found.');
        }
      }
    } catch (err: any) {
      console.error('Failed to verify order:', err);
      setError(err?.message || 'Failed to connect to order verification service.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    if (orderReference) {
      fetchAndVerifyOrder();
    }
  }, [orderReference]);

  if (!orderReference) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto select-text p-4 sm:p-6 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 z-10">
        {isLoading ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-12 h-12 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <p className="text-sm font-bold text-slate-800">
              Verifying order status with payment provider...
            </p>
            <p className="text-xs text-slate-500 font-mono">
              Ref: {orderReference}
            </p>
          </div>
        ) : error || !order ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Unable to Verify Order
            </h3>
            <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
              {error || 'Could not find a valid order record for this reference.'}
            </p>
            <button
              onClick={() => fetchAndVerifyOrder(true)}
              className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Retry Verification</span>
            </button>
          </div>
        ) : (
          <div>
            {/* Header Status Banner */}
            <div
              className={`p-6 text-center text-white ${
                order.paymentStatus === 'PAID'
                  ? 'bg-emerald-600'
                  : order.paymentStatus === 'PENDING'
                  ? 'bg-amber-600'
                  : 'bg-rose-600'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-3 shadow-inner">
                {order.paymentStatus === 'PAID' ? (
                  <CheckCircle2 className="w-7 h-7 text-white" />
                ) : order.paymentStatus === 'PENDING' ? (
                  <Clock className="w-7 h-7 text-white" />
                ) : (
                  <AlertCircle className="w-7 h-7 text-white" />
                )}
              </div>

              <span className="text-[10px] font-extrabold uppercase tracking-widest bg-white/20 px-2.5 py-0.5 rounded-full inline-block mb-1">
                Payment {order.paymentStatus}
              </span>

              <h2 className="text-lg sm:text-xl font-black">
                {order.paymentStatus === 'PAID'
                  ? 'Payment Confirmed & Order Placed!'
                  : order.paymentStatus === 'PENDING'
                  ? 'Payment Pending Provider Confirmation'
                  : 'Payment Not Completed'}
              </h2>

              <p className="text-xs text-white/90 mt-1">
                Order Reference: <strong className="font-mono">{order.orderReference}</strong>
              </p>
            </div>

            {/* Order Body Details */}
            <div className="p-6 space-y-6 text-xs text-slate-700">
              {/* If pending, show refresh helper */}
              {order.paymentStatus === 'PENDING' && (
                <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Awaiting authorization from Paystack/Mobile Money network.</span>
                  </div>
                  <button
                    onClick={() => fetchAndVerifyOrder(true)}
                    disabled={isRefreshing}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shrink-0 disabled:opacity-50"
                  >
                    <RotateCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
                    <span>{isRefreshing ? 'Checking...' : 'Refresh'}</span>
                  </button>
                </div>
              )}

              {/* Store & Date Info */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Store
                  </span>
                  <div className="text-sm font-bold text-slate-900">
                    {order.websiteName}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Date & Time
                  </span>
                  <div className="font-medium text-slate-600">
                    {new Date(order.createdAt).toLocaleDateString()} at{' '}
                    {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>

              {/* Purchased Items List */}
              <div className="space-y-3">
                <span className="font-bold uppercase text-[10px] tracking-wider text-slate-400 block">
                  Purchased Items ({order.items.length})
                </span>

                <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                  {order.items.map((item) => (
                    <div
                      key={item.productId}
                      className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-100 rounded-xl"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {item.imageUrl ? (
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            className="w-10 h-10 rounded-lg object-cover bg-white shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-slate-200 flex items-center justify-center shrink-0 text-slate-400">
                            <ShoppingBag className="w-4 h-4" />
                          </div>
                        )}
                        <div className="truncate">
                          <span className="font-bold text-slate-900 block truncate">
                            {item.name}
                          </span>
                          <span className="text-[11px] text-slate-500">
                            Qty: {item.quantity} × {item.priceFormatted}
                          </span>
                        </div>
                      </div>

                      <span className="font-extrabold text-slate-900 shrink-0">
                        {order.currencySymbol}
                        {(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Total */}
                <div className="pt-2 flex justify-between items-center text-sm font-extrabold text-slate-900 border-t border-slate-100">
                  <span>Total Amount</span>
                  <span className="text-base text-emerald-700">
                    {order.currencySymbol}
                    {order.total.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Delivery Details */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2">
                <span className="font-bold uppercase text-[10px] tracking-wider text-slate-400 block flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Customer & Fulfillment Information</span>
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 text-[11px]">Recipient:</span>
                    <p className="font-semibold text-slate-800">{order.customer.fullName}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Contact Email:</span>
                    <p className="font-semibold text-slate-800">{order.customer.email}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Phone Number:</span>
                    <p className="font-semibold text-slate-800">{order.customer.phone}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Delivery Location:</span>
                    <p className="font-semibold text-slate-800">
                      {order.customer.address}, {order.customer.city} ({order.customer.region})
                    </p>
                  </div>
                </div>

                {order.customer.notes && (
                  <div className="pt-2 border-t border-slate-200/60 text-[11px]">
                    <span className="text-slate-400">Order Note:</span>
                    <p className="italic text-slate-700">{order.customer.notes}</p>
                  </div>
                )}
              </div>

              {/* Shipment Tracking Information if Available */}
              {order.printifyOrder?.submissionStatus === 'SUBMITTED' && (
                <div className="bg-indigo-50/60 p-4 rounded-2xl border border-indigo-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold uppercase text-[10px] tracking-wider text-indigo-700 flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Live Shipment & Fulfillment</span>
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-indigo-100 text-indigo-800">
                      {order.printifyOrder.status}
                    </span>
                  </div>

                  {order.printifyOrder.trackingNumber ? (
                    <div className="text-xs space-y-1">
                      <div className="flex items-center justify-between text-slate-700">
                        <span>
                          Carrier: <strong>{order.printifyOrder.carrier || 'Standard Courier'}</strong>
                        </span>
                        {order.printifyOrder.trackingUrl && (
                          <a
                            href={order.printifyOrder.trackingUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-indigo-600 hover:text-indigo-800 font-bold inline-flex items-center gap-1 text-[11px]"
                          >
                            Track Package
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                      <div className="font-mono bg-white p-2 rounded-lg border border-indigo-100 text-slate-900 font-bold">
                        {order.printifyOrder.trackingNumber}
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-600">
                      Your order has been submitted to production. Tracking information will be updated once the package is dispatched.
                    </p>
                  )}
                </div>
              )}

              {/* Bottom Action */}
              <div className="pt-2">
                <button
                  onClick={onClose}
                  className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-white shadow-md hover:opacity-95 transition-opacity flex items-center justify-center gap-2 cursor-pointer"
                  style={{ backgroundColor: primaryColor }}
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Storefront</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
