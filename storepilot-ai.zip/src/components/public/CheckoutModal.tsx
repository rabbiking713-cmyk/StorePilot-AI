import React, { useState } from 'react';
import { useCart } from '../../context/CartContext';
import { CustomerFulfillmentDetails, CheckoutInitializeResponse } from '../../types/order';
import {
  X,
  Lock,
  ArrowRight,
  ShieldAlert,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Truck,
  CreditCard,
} from 'lucide-react';

interface CheckoutModalProps {
  slug: string;
  storeName: string;
  primaryColor?: string;
  onOrderInitialized?: (orderId: string, reference: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  slug,
  storeName,
  primaryColor = '#0f172a',
  onOrderInitialized,
}) => {
  const {
    items,
    subtotal,
    currencySymbol,
    isCheckoutOpen,
    closeCheckout,
    clearCart,
  } = useCart();

  const [formData, setFormData] = useState<CustomerFulfillmentDetails>({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    region: 'Greater Accra',
    notes: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unconfiguredAlert, setUnconfiguredAlert] = useState<string | null>(null);

  if (!isCheckoutOpen) return null;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setUnconfiguredAlert(null);

    // Client-side required field validations
    if (!formData.fullName.trim()) {
      setError('Please provide your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setError('Please enter a valid email address for your order receipt.');
      return;
    }
    if (!formData.phone.trim()) {
      setError('Please enter a phone number for delivery contact.');
      return;
    }
    if (!formData.address.trim()) {
      setError('Please provide your delivery address.');
      return;
    }
    if (!formData.city.trim()) {
      setError('Please provide your city.');
      return;
    }

    if (items.length === 0) {
      setError('Your cart is empty. Please add items before checking out.');
      return;
    }

    setIsSubmitting(true);

    try {
      // NOTE: We only send product IDs and quantities! Never authoritative prices.
      const payload = {
        slug,
        customer: formData,
        items: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
        })),
      };

      const response = await fetch('/api/checkout/initialize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data: CheckoutInitializeResponse = await response.json();

      if (!response.ok || !data.success) {
        if (!data.paystackConfigured) {
          // Honest unconfigured state
          setUnconfiguredAlert(
            data.error ||
              'PAYSTACK_SECRET_KEY is not configured on the server. Live payment processing is currently unavailable for this store.'
          );
        } else {
          setError(data.error || 'Failed to initialize payment with Paystack.');
        }
        setIsSubmitting(false);
        return;
      }

      // Successful Paystack checkout initialization!
      if (data.orderId && data.orderReference) {
        onOrderInitialized?.(data.orderId, data.orderReference);
      }

      // Redirect to real Paystack authorization URL if provided
      if (data.authorizationUrl) {
        clearCart();
        window.location.href = data.authorizationUrl;
      } else {
        setError('Payment gateway did not return a valid checkout URL.');
        setIsSubmitting(false);
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setError(err?.message || 'Unable to connect to the checkout server. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto select-text p-4 sm:p-6 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in"
        onClick={closeCheckout}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-8 z-10">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs font-bold"
              style={{ backgroundColor: primaryColor }}
            >
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Secure Checkout
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Order fulfillment for <strong className="text-slate-800">{storeName}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={closeCheckout}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
            title="Cancel checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleCheckoutSubmit} className="p-6 space-y-6">
          {/* Error Banner */}
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl flex items-start gap-3 text-xs">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold">Checkout Notice: </strong>
                <span>{error}</span>
              </div>
            </div>
          )}

          {/* Unconfigured Paystack Banner */}
          {unconfiguredAlert && (
            <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl flex items-start gap-3 text-xs">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <strong className="font-bold block">Payment Gateway Not Configured</strong>
                <p className="text-amber-800 leading-relaxed">
                  {unconfiguredAlert}
                </p>
                <p className="text-[11px] text-amber-700">
                  Store owners must add their live or sandbox <code className="bg-amber-100 px-1 rounded font-mono">PAYSTACK_SECRET_KEY</code> in server environment variables to process real transactions.
                </p>
              </div>
            </div>
          )}

          {/* Two-Column Grid: Delivery Form + Order Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: Customer Fulfillment Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                <Truck className="w-3.5 h-3.5 text-indigo-600" />
                <span>Delivery Information</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  name="fullName"
                  required
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="e.g. Kwame Mensah"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="you@domain.com"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Phone Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+233 24 000 0000"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Street Address / Delivery Location <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  name="address"
                  required
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="e.g. 14 Independence Ave, Apt 2B"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    City <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="city"
                    required
                    value={formData.city}
                    onChange={handleChange}
                    placeholder="e.g. Accra"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Region / State
                  </label>
                  <select
                    name="region"
                    value={formData.region}
                    onChange={handleChange}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all cursor-pointer"
                  >
                    <option value="Greater Accra">Greater Accra</option>
                    <option value="Ashanti">Ashanti</option>
                    <option value="Western">Western</option>
                    <option value="Central">Central</option>
                    <option value="Eastern">Eastern</option>
                    <option value="Volta">Volta</option>
                    <option value="Northern">Northern</option>
                    <option value="International">Other / International</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Delivery Notes (Optional)
                </label>
                <textarea
                  name="notes"
                  rows={2}
                  value={formData.notes}
                  onChange={handleChange}
                  placeholder="Gate code, landmark, or specific instructions..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all resize-none"
                />
              </div>
            </div>

            {/* Right: Authoritative Order Summary */}
            <div className="bg-slate-50/80 p-5 rounded-2xl border border-slate-200/80 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  <span>Order Items</span>
                  <span>{items.length} items</span>
                </div>

                <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                  {items.map((item) => (
                    <div
                      key={item.productId}
                      className="flex items-center justify-between text-xs py-1.5 border-b border-slate-200/60"
                    >
                      <div className="truncate pr-2">
                        <span className="font-bold text-slate-900 truncate block">
                          {item.name}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Qty: {item.quantity} × {currencySymbol}{item.numericPrice.toFixed(2)}
                        </span>
                      </div>
                      <span className="font-bold text-slate-800 shrink-0">
                        {currencySymbol}{(item.numericPrice * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Subtotals & Total */}
                <div className="pt-4 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal</span>
                    <span className="font-semibold text-slate-800">
                      {currencySymbol}{subtotal.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Standard Delivery</span>
                    <span className="text-emerald-700 font-semibold">Free</span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                    <span>Total Authoritative Amount</span>
                    <span>
                      {currencySymbol}{subtotal.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Details */}
              <div className="space-y-3 pt-2">
                <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div className="text-[11px] leading-tight">
                    <strong className="text-slate-900 font-bold block">
                      Paystack Secure Gateway
                    </strong>
                    <span className="text-slate-500">
                      Supports Mobile Money (MTN, Telecel, AT), Cards, & Bank Transfers
                    </span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 px-4 rounded-xl text-xs sm:text-sm font-bold text-white shadow-md hover:opacity-95 transition-opacity flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  style={{ backgroundColor: primaryColor }}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Connecting to Paystack...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>
                        Pay {currencySymbol}{subtotal.toFixed(2)} with Paystack
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
