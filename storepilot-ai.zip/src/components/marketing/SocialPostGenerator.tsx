import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  SocialPlatform,
  ContentGoal,
  MarketingTone,
  SocialPostResult,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Share2,
  Bookmark,
  Instagram,
  Facebook,
  Linkedin,
  Twitter,
  ArrowRight,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface SocialPostGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const PLATFORMS: { id: SocialPlatform; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'instagram', label: 'Instagram', icon: <Instagram className="w-4 h-4 text-pink-600" />, desc: 'Visual hooks, storytelling & hashtag blocks' },
  { id: 'facebook', label: 'Facebook', icon: <Facebook className="w-4 h-4 text-blue-600" />, desc: 'Community storytelling & conversation starter' },
  { id: 'linkedin', label: 'LinkedIn', icon: <Linkedin className="w-4 h-4 text-sky-700" />, desc: 'Professional insights & founder perspective' },
  { id: 'x', label: 'X (Twitter)', icon: <Twitter className="w-4 h-4 text-slate-800" />, desc: 'Concise, punchy hook under 280 characters' },
];

const GOALS: { id: ContentGoal; label: string }[] = [
  { id: 'promote_product', label: 'Promote Product' },
  { id: 'promote_service', label: 'Promote Service' },
  { id: 'build_awareness', label: 'Build Awareness' },
  { id: 'educational', label: 'Educational / Tips' },
  { id: 'announcement', label: 'Announcement' },
  { id: 'engagement', label: 'Audience Engagement' },
  { id: 'sale_promotion', label: 'Sale / Promotion' },
];

const TONES: MarketingTone[] = [
  'Professional',
  'Friendly',
  'Bold',
  'Luxury',
  'Casual',
  'Inspirational',
];

export const SocialPostGenerator: React.FC<SocialPostGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [platform, setPlatform] = useState<SocialPlatform>('instagram');
  const [goal, setGoal] = useState<ContentGoal>('promote_product');
  const [tone, setTone] = useState<MarketingTone>('Friendly');
  const [selectedProduct, setSelectedProduct] = useState<string>(
    context.products[0]?.name || ''
  );
  const [customInstruction, setCustomInstruction] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<SocialPostResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Edit mode state
  const [isEditing, setIsEditing] = useState(false);
  const [editedHeadline, setEditedHeadline] = useState('');
  const [editedBody, setEditedBody] = useState('');
  const [editedCta, setEditedCta] = useState('');
  const [editedHashtags, setEditedHashtags] = useState('');

  // Feedback states
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setCopied(false);
    setSaved(false);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'social_post',
        context,
        options: {
          platform,
          goal,
          tone,
          selectedProductName: selectedProduct || undefined,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const socialRes = genResult as SocialPostResult;
      setResult(socialRes);
      setEditedHeadline(socialRes.headline);
      setEditedBody(socialRes.body);
      setEditedCta(socialRes.cta);
      setEditedHashtags(socialRes.hashtags.join(' '));
      setIsEditing(false);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate post. Please check your AI connection.');
    } finally {
      setIsGenerating(false);
    }
  };

  const currentResult: SocialPostResult | null = result
    ? {
        ...result,
        headline: editedHeadline,
        body: editedBody,
        cta: editedCta,
        hashtags: editedHashtags.split(/\s+/).filter(Boolean),
      }
    : null;

  const handleCopyFullPost = async () => {
    if (!currentResult) return;
    const fullText = `${currentResult.headline}\n\n${currentResult.body}\n\n${currentResult.cta}\n\n${currentResult.hashtags.join(' ')}`;
    try {
      await navigator.clipboard.writeText(fullText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      // Fallback
    }
  };

  const handleSaveToHistory = () => {
    if (!currentResult) return;
    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'social_post',
      title: `${platform.toUpperCase()} Post: ${currentResult.headline.slice(0, 45)}...`,
      result: currentResult,
    });
    setSaved(true);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Share2 className="w-4 h-4 text-indigo-600" />
            Social Post Parameters
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Grounded directly in {context.businessName}&apos;s catalog and brand voice.
          </p>
        </div>

        {/* Platform Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Target Platform
          </label>
          <div className="grid grid-cols-2 gap-2">
            {PLATFORMS.map((p) => {
              const active = platform === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPlatform(p.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer text-left ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <span className="p-1 rounded-md bg-white shadow-2xs shrink-0">{p.icon}</span>
                  <div className="min-w-0">
                    <div className="truncate">{p.label}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Goal Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Content Goal
          </label>
          <select
            value={goal}
            onChange={(e) => setGoal(e.target.value as ContentGoal)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          >
            {GOALS.map((g) => (
              <option key={g.id} value={g.id}>
                {g.label}
              </option>
            ))}
          </select>
        </div>

        {/* Tone Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Brand Tone
          </label>
          <div className="flex flex-wrap gap-1.5">
            {TONES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Product Focus (From verified spec) */}
        {context.products.length > 0 && (
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center justify-between">
              <span>Verified Product Focus (Optional)</span>
              <span className="text-[10px] text-slate-400 font-normal">
                {context.products.length} products available
              </span>
            </label>
            <select
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            >
              <option value="">-- General Store / Brand Focus --</option>
              {context.products.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name} {p.price ? `(${p.price})` : ''}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Optional Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Additional Custom Directives (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Highlight our weekend hours, mention free curbside pickup, or ask a question at the end."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Crafting Social Post with Gemini...' : result ? 'Regenerate Social Post' : 'Generate Social Post'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 leading-relaxed">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-4">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <Share2 className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Generate Social Content</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Select your target platform and goal on the left. StorePilot AI will construct a tailored post using your actual website copy, products, and prices.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Synthesizing Social Post...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Analyzing {context.businessName}&apos;s verified catalog items and brand tone.
              </p>
            </div>
          </div>
        )}

        {result && currentResult && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header with actions */}
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2 bg-slate-50/50">
              <div className="flex items-center gap-2">
                <span className="capitalize px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1.5 shadow-2xs">
                  {PLATFORMS.find((p) => p.id === result.platform)?.icon}
                  {result.platform}
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs font-medium text-slate-600">{result.tone} Tone</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isEditing
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Done Editing' : 'Edit Post'}
                </button>

                <button
                  onClick={handleSaveToHistory}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Save to Library"
                >
                  {saved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                  {saved ? 'Saved' : 'Save'}
                </button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleCopyFullPost}
                  icon={copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                >
                  {copied ? 'Copied Full Post!' : 'Copy Post'}
                </Button>
              </div>
            </div>

            {/* Post Preview Display or Edit Form */}
            <div className="p-6 space-y-5">
              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700">Headline / Hook</label>
                    <input
                      type="text"
                      value={editedHeadline}
                      onChange={(e) => setEditedHeadline(e.target.value)}
                      className="mt-1 w-full text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700">Post Body</label>
                    <textarea
                      rows={6}
                      value={editedBody}
                      onChange={(e) => setEditedBody(e.target.value)}
                      className="mt-1 w-full text-xs font-normal bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 resize-y leading-relaxed"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-700">Call To Action (CTA)</label>
                      <input
                        type="text"
                        value={editedCta}
                        onChange={(e) => setEditedCta(e.target.value)}
                        className="mt-1 w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700">Hashtags</label>
                      <input
                        type="text"
                        value={editedHashtags}
                        onChange={(e) => setEditedHashtags(e.target.value)}
                        className="mt-1 w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Hook / Headline */}
                  <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Opening Hook
                    </div>
                    <div className="text-sm font-bold text-slate-900 leading-snug">
                      {currentResult.headline}
                    </div>
                  </div>

                  {/* Body */}
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                      Post Body
                    </div>
                    <div className="text-xs text-slate-700 whitespace-pre-line leading-relaxed font-sans bg-white p-4 border border-slate-100 rounded-xl">
                      {currentResult.body}
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 bg-indigo-50/70 p-3 rounded-xl border border-indigo-100">
                    <ArrowRight className="w-4 h-4 shrink-0 text-indigo-600" />
                    <span>{currentResult.cta}</span>
                  </div>

                  {/* Hashtags */}
                  {currentResult.hashtags.length > 0 && (
                    <div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                        Hashtags
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {currentResult.hashtags.map((h, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md text-[11px] font-mono font-medium bg-slate-100 text-slate-600"
                          >
                            {h.startsWith('#') ? h : `#${h}`}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer warning */}
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Ready for copy & paste. Never auto-posted.</span>
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCw className="w-3 h-3" /> Regenerate variation
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
