import React, { useState } from 'react';
import { SavedMarketingItem } from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Bookmark,
  Trash2,
  Copy,
  Check,
  Download,
  Clock,
  X,
  Share2,
  Video,
  Film,
  Target,
  Package,
  Calendar,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface MarketingHistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  items: SavedMarketingItem[];
  onRefreshItems: () => void;
}

export const MarketingHistoryDrawer: React.FC<MarketingHistoryDrawerProps> = ({
  isOpen,
  onClose,
  userId,
  items,
  onRefreshItems,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const getToolIcon = (toolType: string) => {
    switch (toolType) {
      case 'social_post':
        return <Share2 className="w-3.5 h-3.5 text-pink-600" />;
      case 'tiktok_reels':
        return <Video className="w-3.5 h-3.5 text-rose-500" />;
      case 'video_script':
        return <Film className="w-3.5 h-3.5 text-indigo-600" />;
      case 'ad_copy':
        return <Target className="w-3.5 h-3.5 text-blue-600" />;
      case 'product_promo':
        return <Package className="w-3.5 h-3.5 text-amber-600" />;
      case 'campaign_generator':
        return <Calendar className="w-3.5 h-3.5 text-emerald-600" />;
      default:
        return <Bookmark className="w-3.5 h-3.5 text-slate-600" />;
    }
  };

  const handleCopyItem = async (item: SavedMarketingItem) => {
    let text = JSON.stringify(item.result, null, 2);
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(item.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleDeleteItem = (itemId: string) => {
    MarketingService.deleteItem(userId, itemId);
    onRefreshItems();
  };

  const handleExportAllMarkdown = () => {
    if (items.length === 0) return;
    const content = items
      .map(
        (i) =>
          `# ${i.title}\nSite: ${i.websiteName} | Date: ${new Date(i.createdAt).toLocaleString()}\n\n\`\`\`json\n${JSON.stringify(
            i.result,
            null,
            2
          )}\n\`\`\`\n\n---\n`
      )
      .join('\n');

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `StorePilot_Marketing_Library_${Date.now()}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/40 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between transform transition-transform animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-600">
              <Bookmark className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Saved Marketing Library</h3>
              <p className="text-[11px] text-slate-500">{items.length} saved generations</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of items */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {items.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Bookmark className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No Saved Items Yet</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Click &ldquo;Save to Library&rdquo; on any generated social post, reels idea, script, or campaign to revisit it here anytime.
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs hover:border-slate-300 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="p-1 rounded bg-white border border-slate-200 shadow-2xs">
                      {getToolIcon(item.toolType)}
                    </span>
                    <span className="font-bold text-slate-900 truncate max-w-[200px]">
                      {item.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopyItem(item)}
                      className="p-1 text-slate-400 hover:text-slate-800 cursor-pointer"
                      title="Copy JSON"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                      title="Delete item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/60">
                  <span className="truncate max-w-[150px]">{item.websiteName}</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(item.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer actions */}
        {items.length > 0 && (
          <div className="p-4 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between gap-2">
            <button
              onClick={() => {
                if (window.confirm('Clear all saved marketing items?')) {
                  MarketingService.clearHistory(userId);
                  onRefreshItems();
                }
              }}
              className="text-xs text-red-600 hover:text-red-800 font-medium cursor-pointer"
            >
              Clear Library
            </button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleExportAllMarkdown}
              icon={<Download className="w-3.5 h-3.5" />}
            >
              Export as Markdown (.md)
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
