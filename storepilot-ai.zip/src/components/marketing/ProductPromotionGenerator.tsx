import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  ProductPromoRequest,
  PromoAngle,
  MarketingTone,
  ProductPromoResult,
  BusinessProductContext,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Package,
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Bookmark,
  Layers,
  ArrowRight,
  Tag,
  ShoppingBag,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface ProductPromotionGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const ANGLES: { id: PromoAngle; label: string; desc: string }[] = [
  { id: 'spotlight', label: 'Flagship Spotlight', desc: 'Focus on craftsmanship, design, and hero value' },
  { id: 'new_arrival', label: 'New Arrival Drop', desc: 'Curiosity and excitement for fresh items' },
  { id: 'best_seller', label: 'Best-Seller Proof', desc: 'Show why customer demand keeps this at the top' },
  { id: 'problem_solver', label: 'Direct Problem Solver', desc: 'Highlight how this removes daily friction' },
  { id: 'behind_craft', label: 'Behind the Craft', desc: 'Story of how it is sourced, roasted, or produced' },
  { id: 'limited_drop', label: 'Limited Run / Exclusive', desc: 'Emphasis on small batch and high demand' },
];

export const ProductPromotionGenerator: React.FC<ProductPromotionGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(
    context.products[0]?.id || ''
  );
  const [promoAngle, setPromoAngle] = useState<PromoAngle>('spotlight');
  const [tone, setTone] = useState<MarketingTone>('Luxury');
  const [customInstruction, setCustomInstruction] = useState('');

  // Selected Product reference
  const currentProduct: BusinessProductContext | undefined = context.products.find(
    (p) => p.id === selectedProductId
  ) || context.products[0];

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<ProductPromoResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Edit state
  const [isEditing, setIsEditing] = useState(false);
  const [editedFeedCopy, setEditedFeedCopy] = useState('');
  const [editedHook, setEditedHook] = useState('');
  const [editedCta, setEditedCta] = useState('');

  // Feedback states
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    if (!currentProduct && context.products.length > 0) return;
    setIsGenerating(true);
    setError(null);
    setCopiedKey(null);
    setSaved(false);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'product_promo',
        context,
        options: {
          productName: currentProduct?.name || context.businessName,
          productPrice: currentProduct?.price,
          productCategory: currentProduct?.category,
          productDescription: currentProduct?.description,
          promoAngle,
          tone,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const promoRes = genResult as ProductPromoResult;
      setResult(promoRes);
      setEditedFeedCopy(promoRes.feedPostCopy);
      setEditedHook(promoRes.hook);
      setEditedCta(promoRes.cta);
      setIsEditing(false);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate product promotion. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyFeed = async () => {
    if (!result) return;
    const full = `${editedHook || result.hook}\n\n${editedFeedCopy || result.feedPostCopy}\n\n${editedCta || result.cta}\n\n${result.hashtags.join(' ')}`;
    try {
      await navigator.clipboard.writeText(full);
      setCopiedKey('feed');
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleCopyStory = async () => {
    if (!result) return;
    const storyText = result.storySequence
      .map(
        (s) =>
          `[Slide ${s.slideNumber}: ${s.slideType.toUpperCase()}]\nVISUAL: ${s.visualCue}\nOVERLAY / STICKER: "${s.stickerOrText}"\nCAPTION: "${s.captionCue}"`
      )
      .join('\n\n');

    try {
      await navigator.clipboard.writeText(storyText);
      setCopiedKey('story');
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleSaveToHistory = () => {
    if (!result) return;
    const savedData: ProductPromoResult = {
      ...result,
      hook: editedHook || result.hook,
      feedPostCopy: editedFeedCopy || result.feedPostCopy,
      cta: editedCta || result.cta,
    };

    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'product_promo',
      title: `Product Promo: ${result.productName}`,
      result: savedData,
    });
    setSaved(true);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Package className="w-4 h-4 text-indigo-600" />
            Product Spotlight Parameters
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Focus promotion on an exact product or service from {context.businessName}&apos;s verified catalog.
          </p>
        </div>

        {/* Product Picker */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center justify-between">
            <span>Select Catalog Item</span>
            <span className="text-[10px] text-slate-400 font-normal">
              {context.products.length} items found in spec
            </span>
          </label>

          {context.products.length > 0 ? (
            <div className="space-y-2">
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              >
                {context.products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} {p.price ? `(${p.price})` : ''}
                  </option>
                ))}
              </select>

              {currentProduct && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{currentProduct.name}</span>
                    <span className="font-mono font-bold text-indigo-600">{currentProduct.price}</span>
                  </div>
                  <p className="text-slate-500 text-[11px] line-clamp-2">
                    {currentProduct.description}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800">
              No products found in this website&apos;s specification. General store promotion will be used.
            </div>
          )}
        </div>

        {/* Promotional Angle */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Promotional Hook Angle
          </label>
          <div className="grid grid-cols-2 gap-2">
            {ANGLES.map((a) => {
              const active = promoAngle === a.id;
              return (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => setPromoAngle(a.id)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-bold shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <div className="font-bold truncate">{a.label}</div>
                  <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{a.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tone */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Brand Tone
          </label>
          <div className="flex flex-wrap gap-1.5">
            {(['Luxury', 'Inspirational', 'Bold', 'Friendly', 'Professional', 'Casual'] as MarketingTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Offer / Packaging Notes (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Mention that each piece is hand-finished, emphasize gift-ready packaging, or note limited batch release."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Generating Product Campaign...' : result ? 'Regenerate Spotlight' : 'Generate Product Spotlight'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-4">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Spotlight a Product</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Select one of your store&apos;s real items to create a spotlight feed caption, high-converting opening hook, and a 3-slide story sequence.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Spotlighting Product...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Constructing authentic promotional copy for {currentProduct?.name || context.businessName}.
              </p>
            </div>
          </div>
        )}

        {result && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header Actions */}
            <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-900 shadow-2xs flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-indigo-600" />
                  {result.productName}
                </span>
                {result.productPrice && (
                  <span className="font-mono font-bold text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                    {result.productPrice}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isEditing
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Done Editing' : 'Edit Copy'}
                </button>

                <button
                  onClick={handleSaveToHistory}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Save to Library"
                >
                  {saved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                  {saved ? 'Saved' : 'Save'}
                </button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleCopyFeed}
                  icon={copiedKey === 'feed' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                >
                  {copiedKey === 'feed' ? 'Copied Feed Post!' : 'Copy Feed Post'}
                </Button>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-6 text-xs">
              {/* Hook & Value Prop */}
              <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">
                  Spotlight Hook & Core Value
                </div>
                {isEditing ? (
                  <input
                    type="text"
                    value={editedHook}
                    onChange={(e) => setEditedHook(e.target.value)}
                    className="w-full text-xs font-bold text-slate-900 bg-white border border-indigo-200 rounded p-1.5"
                  />
                ) : (
                  <div className="text-sm font-bold text-slate-900 leading-snug">
                    {editedHook || result.hook}
                  </div>
                )}
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {result.valueProposition}
                </p>
              </div>

              {/* Ready-to-Post Feed Caption */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider">
                    Full Feed Post Caption
                  </span>
                  <button
                    onClick={handleCopyFeed}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" /> Copy post
                  </button>
                </div>

                {isEditing ? (
                  <textarea
                    rows={6}
                    value={editedFeedCopy}
                    onChange={(e) => setEditedFeedCopy(e.target.value)}
                    className="w-full text-xs text-slate-800 p-3 bg-slate-50 border border-slate-200 rounded-xl font-sans leading-relaxed"
                  />
                ) : (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 whitespace-pre-line leading-relaxed font-sans">
                    {editedFeedCopy || result.feedPostCopy}
                  </div>
                )}
              </div>

              {/* 3-Slide Story Sequence */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-600" /> 3-Slide Story Sequence
                  </span>
                  <button
                    onClick={handleCopyStory}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKey === 'story' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" /> Copied Stories!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy Story Sequence
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {result.storySequence.map((slide, idx) => (
                    <div
                      key={slide.slideNumber || idx}
                      className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-2 shadow-2xs text-xs"
                    >
                      <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                        <span className="px-2 py-0.5 bg-slate-900 text-white rounded text-[10px] font-bold">
                          Slide {slide.slideNumber}
                        </span>
                        <span className="text-[10px] font-semibold text-indigo-600 uppercase">
                          {slide.slideType.replace('_', ' ')}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">Visual</span>
                        <p className="text-slate-700 text-[11px] leading-relaxed">
                          {slide.visualCue}
                        </p>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">
                          Sticker / Overlay
                        </span>
                        <p className="font-mono text-[10px] bg-slate-100 text-slate-800 p-1.5 rounded border border-slate-200">
                          {slide.stickerOrText}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Closing CTA & Hashtags */}
              <div className="flex items-center gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium">
                <ArrowRight className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>CTA: {editedCta || result.cta}</span>
              </div>

              {result.hashtags && result.hashtags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {result.hashtags.map((h, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-100 text-slate-600"
                    >
                      {h.startsWith('#') ? h : `#${h}`}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
