import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  TikTokReelsResult,
  TikTokReelsIdea,
  ShortVideoAngle,
  MarketingTone,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Video,
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Bookmark,
  Eye,
  Volume2,
  Type,
  Clapperboard,
  ArrowRight,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface TikTokReelsGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const ANGLES: { id: ShortVideoAngle; label: string; desc: string }[] = [
  { id: 'problem_solution', label: 'Problem vs Solution', desc: 'Highlight customer pain point and how your business fixes it' },
  { id: 'product_demo', label: 'Product Showcase / Demo', desc: 'Close-ups, unboxing, craft, and utility in action' },
  { id: 'behind_the_scenes', label: 'Behind the Scenes', desc: 'Workshop, kitchen, packaging orders, and day-in-the-life' },
  { id: 'hook_story', label: 'Curiosity Story Hook', desc: 'Open with a controversial or surprising question' },
  { id: 'myth_busting', label: 'Industry Myth Busting', desc: 'Educate your audience and establish trust' },
  { id: 'day_in_life', label: 'Founder Story & Passion', desc: 'Humanize your store with authentic creator narrative' },
];

export const TikTokReelsGenerator: React.FC<TikTokReelsGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [focusAngle, setFocusAngle] = useState<ShortVideoAngle>('problem_solution');
  const [tone, setTone] = useState<MarketingTone>('Bold');
  const [focusProduct, setFocusProduct] = useState<string>(
    context.products[0]?.name || ''
  );
  const [customInstruction, setCustomInstruction] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<TikTokReelsResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Active editing idea
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeIdeas, setActiveIdeas] = useState<TikTokReelsIdea[]>([]);

  // Feedback states
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setCopiedId(null);
    setSavedId(null);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'tiktok_reels',
        context,
        options: {
          focusAngle,
          tone,
          focusProduct: focusProduct || undefined,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const reelsRes = genResult as TikTokReelsResult;
      setResult(reelsRes);
      setActiveIdeas(reelsRes.ideas);
      setEditingId(null);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate video concepts. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdateIdeaField = (id: string, field: keyof TikTokReelsIdea, value: any) => {
    setActiveIdeas((prev) =>
      prev.map((idea) => (idea.id === id ? { ...idea, [field]: value } : idea))
    );
  };

  const handleCopyIdea = async (idea: TikTokReelsIdea) => {
    const text = `VIDEO CONCEPT: ${idea.title}
HOOK (First 2s): ${idea.hook}
CONCEPT: ${idea.concept}
WHAT TO SHOW: ${idea.whatToShow}
ON-SCREEN TEXT: ${idea.onScreenText}
VOICEOVER: ${idea.suggestedVoiceover}
CTA: ${idea.cta}

CAPTION:
${idea.caption}

HASHTAGS:
${idea.hashtags.join(' ')}`;

    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(idea.id);
      setTimeout(() => setCopiedId(null), 2200);
    } catch {
      // Fallback
    }
  };

  const handleSaveIdea = (idea: TikTokReelsIdea) => {
    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'tiktok_reels',
      title: `Reels Idea: ${idea.title}`,
      result: { ideas: [idea] },
    });
    setSavedId(idea.id);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSavedId(null), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Video className="w-4 h-4 text-rose-500" />
            TikTok & Reels Strategy
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Generate high-retention short-form video hooks & concepts for {context.businessName}.
          </p>
        </div>

        {/* Video Concept Angle */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Creative Angle
          </label>
          <div className="space-y-1.5">
            {ANGLES.map((a) => {
              const active = focusAngle === a.id;
              return (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => setFocusAngle(a.id)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-semibold shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <div className="font-semibold text-slate-900">{a.label}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{a.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Focus */}
        {context.products.length > 0 && (
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Feature Verified Product (Optional)
            </label>
            <select
              value={focusProduct}
              onChange={(e) => setFocusProduct(e.target.value)}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            >
              <option value="">-- General Store / Brand Focus --</option>
              {context.products.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name} {p.price ? `(${p.price})` : ''}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Brand Tone */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Delivery Tone
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(['Bold', 'Casual', 'Inspirational', 'Friendly', 'Luxury', 'Professional'] as MarketingTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium text-center transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Director Notes (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Focus on sound design, make the hook relatable to young professionals, or film in a vertical phone style."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Brainstorming Video Concepts...' : result ? 'Generate New Concepts' : 'Generate Video Ideas'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-5">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
              <Clapperboard className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Brainstorm Short-Form Videos</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Generate 3-4 structured video concepts complete with opening hooks, visual cues, on-screen text, voiceovers, and captions.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-rose-500 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Generating Viral Short-Form Concepts...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Synthesizing scroll-stopping hooks based on {context.businessName}&apos;s real store data.
              </p>
            </div>
          </div>
        )}

        {result && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Generated Video Concepts ({activeIdeas.length})
              </div>
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCw className="w-3.5 h-3.5" /> Regenerate all
              </button>
            </div>

            {activeIdeas.map((idea, index) => {
              const isEdit = editingId === idea.id;
              const isCopied = copiedId === idea.id;
              const isSaved = savedId === idea.id;

              return (
                <div
                  key={idea.id || index}
                  className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all hover:border-slate-300"
                >
                  {/* Card Header */}
                  <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-mono font-bold text-xs flex items-center justify-center shrink-0">
                        {index + 1}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">{idea.title}</h4>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setEditingId(isEdit ? null : idea.id)}
                        className={`p-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                          isEdit
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                        title={isEdit ? 'Save edits' : 'Edit concept'}
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleSaveIdea(idea)}
                        className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                        title="Save to Library"
                      >
                        {isSaved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                      </button>

                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleCopyIdea(idea)}
                        icon={isCopied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                      >
                        {isCopied ? 'Copied Idea!' : 'Copy Idea'}
                      </Button>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6 space-y-4 text-xs">
                    {/* Hook Section (Prominent) */}
                    <div className="p-4 bg-rose-50/60 border border-rose-100 rounded-xl space-y-1">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-rose-600 flex items-center gap-1">
                        <Clapperboard className="w-3 h-3" /> Scroll-Stopping Hook (First 2 Seconds)
                      </div>
                      {isEdit ? (
                        <input
                          type="text"
                          value={idea.hook}
                          onChange={(e) => handleUpdateIdeaField(idea.id, 'hook', e.target.value)}
                          className="w-full text-xs font-bold text-slate-900 bg-white border border-rose-200 rounded-lg p-2 focus:outline-hidden"
                        />
                      ) : (
                        <div className="text-sm font-extrabold text-slate-900 italic">
                          &ldquo;{idea.hook}&rdquo;
                        </div>
                      )}
                    </div>

                    {/* Breakdown Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Concept */}
                      <div className="space-y-1">
                        <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider">
                          Video Concept
                        </span>
                        {isEdit ? (
                          <textarea
                            rows={3}
                            value={idea.concept}
                            onChange={(e) => handleUpdateIdeaField(idea.id, 'concept', e.target.value)}
                            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        ) : (
                          <p className="text-slate-700 leading-relaxed">{idea.concept}</p>
                        )}
                      </div>

                      {/* What to show */}
                      <div className="space-y-1">
                        <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider flex items-center gap-1">
                          <Eye className="w-3 h-3 text-indigo-500" /> What to Show (Visual Direction)
                        </span>
                        {isEdit ? (
                          <textarea
                            rows={3}
                            value={idea.whatToShow}
                            onChange={(e) => handleUpdateIdeaField(idea.id, 'whatToShow', e.target.value)}
                            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        ) : (
                          <p className="text-slate-700 leading-relaxed">{idea.whatToShow}</p>
                        )}
                      </div>

                      {/* On-screen text */}
                      <div className="space-y-1">
                        <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider flex items-center gap-1">
                          <Type className="w-3 h-3 text-amber-500" /> On-Screen Text Overlay
                        </span>
                        {isEdit ? (
                          <input
                            type="text"
                            value={idea.onScreenText}
                            onChange={(e) => handleUpdateIdeaField(idea.id, 'onScreenText', e.target.value)}
                            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        ) : (
                          <p className="text-slate-900 font-mono text-[11px] bg-slate-100 px-2.5 py-1.5 rounded-lg border border-slate-200">
                            {idea.onScreenText}
                          </p>
                        )}
                      </div>

                      {/* Voiceover */}
                      <div className="space-y-1">
                        <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider flex items-center gap-1">
                          <Volume2 className="w-3 h-3 text-emerald-500" /> Suggested Voiceover
                        </span>
                        {isEdit ? (
                          <textarea
                            rows={2}
                            value={idea.suggestedVoiceover}
                            onChange={(e) => handleUpdateIdeaField(idea.id, 'suggestedVoiceover', e.target.value)}
                            className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        ) : (
                          <p className="text-slate-700 leading-relaxed italic">
                            &ldquo;{idea.suggestedVoiceover}&rdquo;
                          </p>
                        )}
                      </div>
                    </div>

                    {/* CTA & Caption */}
                    <div className="pt-2 border-t border-slate-100 space-y-2">
                      <div className="flex items-center gap-2 text-indigo-700 font-semibold">
                        <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>CTA: {idea.cta}</span>
                      </div>

                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1.5">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                          Ready-To-Post Caption & Hashtags
                        </div>
                        <p className="text-slate-700 whitespace-pre-line leading-relaxed">
                          {idea.caption}
                        </p>
                        <div className="flex flex-wrap gap-1 pt-1">
                          {idea.hashtags.map((h, hIdx) => (
                            <span
                              key={hIdx}
                              className="px-2 py-0.5 rounded text-[10px] font-mono bg-white border border-slate-200 text-slate-600"
                            >
                              {h.startsWith('#') ? h : `#${h}`}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
