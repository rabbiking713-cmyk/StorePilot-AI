import React, { useState, useEffect, useMemo } from 'react';
import { useWebsites } from '../../context/WebsitesContext';
import { useAuth } from '../../context/AuthContext';
import { Website, ActiveDashboardTab } from '../../types';
import {
  MarketingToolType,
  BusinessMarketingContext,
  SavedMarketingItem,
} from '../../types/marketing';
import { buildMarketingContext } from '../../services/marketing/marketingContextBuilder';
import { MarketingService } from '../../services/marketing/marketingService';
import { useSubscription } from '../../context/SubscriptionContext';
import { SocialPostGenerator } from './SocialPostGenerator';
import { TikTokReelsGenerator } from './TikTokReelsGenerator';
import { VideoScriptGenerator } from './VideoScriptGenerator';
import { AdCopyGenerator } from './AdCopyGenerator';
import { ProductPromotionGenerator } from './ProductPromotionGenerator';
import { CampaignGenerator } from './CampaignGenerator';
import { MarketingHistoryDrawer } from './MarketingHistoryDrawer';
import {
  Megaphone,
  Share2,
  Video,
  Film,
  Target,
  Package,
  Calendar,
  Sparkles,
  ChevronDown,
  Globe,
  Plus,
  Bookmark,
  ShieldAlert,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface MarketingStudioViewProps {
  onNavigateTab?: (tab: ActiveDashboardTab) => void;
  initialWebsiteId?: string | null;
}

const TOOLS: {
  id: MarketingToolType;
  label: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  tagColor?: string;
}[] = [
  {
    id: 'social_post',
    label: 'Social Post Generator',
    shortDesc: 'Instagram, Facebook, LinkedIn & X copy',
    icon: Share2,
  },
  {
    id: 'tiktok_reels',
    label: 'TikTok & Reels Ideas',
    shortDesc: 'Scroll-stopping hooks, visual concepts & voiceovers',
    icon: Video,
  },
  {
    id: 'video_script',
    label: 'Video Script Generator',
    shortDesc: 'Scene-by-scene commercials & product storyboards',
    icon: Film,
  },
  {
    id: 'ad_copy',
    label: 'Ad Copy Generator',
    shortDesc: 'Meta, Google Search, TikTok & LinkedIn paid ads',
    icon: Target,
  },
  {
    id: 'product_promo',
    label: 'Product Promotion',
    shortDesc: 'Feed spotlights & 3-slide story sequences for catalog items',
    icon: Package,
  },
  {
    id: 'campaign_generator',
    label: 'Marketing Campaign',
    shortDesc: 'Multi-day content calendar & launch rollouts',
    icon: Calendar,
  },
];

export const MarketingStudioView: React.FC<MarketingStudioViewProps> = ({
  onNavigateTab,
  initialWebsiteId,
}) => {
  const { websites, openCreateModal } = useWebsites();
  const { user } = useAuth();
  const { canAccess, plan: subPlan } = useSubscription();
  const hasMarketingAccess = canAccess('marketing_studio');

  // Selected website
  const [selectedSiteId, setSelectedSiteId] = useState<string>(
    initialWebsiteId || websites[0]?.id || ''
  );

  // Active marketing tool
  const [activeTool, setActiveTool] = useState<MarketingToolType>('social_post');

  // Library / Saved drawer
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [savedItems, setSavedItems] = useState<SavedMarketingItem[]>([]);

  // Keep selected site synced with available websites
  useEffect(() => {
    if (websites.length > 0 && (!selectedSiteId || !websites.some((w) => w.id === selectedSiteId))) {
      setSelectedSiteId(websites[0].id);
    }
  }, [websites, selectedSiteId]);

  // Load saved marketing items
  const loadSavedItems = () => {
    if (user?.id) {
      setSavedItems(MarketingService.getSavedItems(user.id));
    }
  };

  useEffect(() => {
    loadSavedItems();
  }, [user?.id]);

  const selectedWebsite: Website | undefined = websites.find(
    (w) => w.id === selectedSiteId
  ) || websites[0];

  // Build the strictly-grounded marketing context
  const marketingContext: BusinessMarketingContext | null = useMemo(() => {
    if (!selectedWebsite) return null;
    return buildMarketingContext(selectedWebsite);
  }, [selectedWebsite]);

  // If user has no websites at all, display a helpful empty state
  if (websites.length === 0) {
    return (
      <div className="p-8 max-w-2xl mx-auto my-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mx-auto shadow-2xs">
          <Megaphone className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            No Websites Found to Market
          </h2>
          <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
            StorePilot AI Marketing Studio turns your real website copy, products, and prices into high-converting marketing content. Create or generate your first website to unlock all marketing tools.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Button
            variant="primary"
            onClick={() => onNavigateTab && onNavigateTab('builder_preview')}
            icon={<Sparkles className="w-4 h-4" />}
          >
            Generate Website with AI
          </Button>
          <Button
            variant="outline"
            onClick={openCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            Create Website Manually
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* Top Header Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />
        <div className="absolute right-40 -bottom-20 w-60 h-60 rounded-full bg-violet-600/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <Megaphone className="w-3.5 h-3.5" />
              <span>StorePilot AI • Phase 5 Marketing Studio</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
              AI Marketing Studio
            </h1>
            <p className="text-sm md:text-base text-slate-300 max-w-xl font-normal">
              &ldquo;Turn your business into content people want to see.&rdquo;
            </p>
          </div>

          {/* Website Selector & Library Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
            {/* Website Selector Dropdown */}
            <div className="relative min-w-[240px]">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Active Store / Business
              </label>
              <div className="relative">
                <select
                  value={selectedSiteId}
                  onChange={(e) => setSelectedSiteId(e.target.value)}
                  className="w-full appearance-none bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-white rounded-xl px-4 py-2.5 pr-10 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-400 cursor-pointer shadow-inner transition-colors"
                >
                  {websites.map((site) => {
                    const statusText = site.publishStatus === 'published' ? '🟢 Live' : '⚪ Draft';
                    return (
                      <option key={site.id} value={site.id} className="bg-slate-900 text-white">
                        {site.name} ({site.businessType || 'Retail'}) — {statusText}
                      </option>
                    );
                  })}
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* Saved Library Trigger */}
            <div className="flex flex-col justify-end">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-transparent mb-1 select-none hidden sm:block">
                Action
              </label>
              <button
                onClick={() => setIsLibraryOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors"
              >
                <Bookmark className="w-4 h-4 text-amber-400" />
                <span>Saved Library</span>
                {savedItems.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-indigo-500 text-white text-[10px] font-mono font-bold">
                    {savedItems.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Selected Store Status Strip */}
        {selectedWebsite && marketingContext && (
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center gap-4 text-xs text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-semibold text-white">{marketingContext.businessName}</span>
            </div>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">{marketingContext.industry}</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">
              {marketingContext.products.length} Products in catalog
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">
              Tone: {marketingContext.themeMood}
            </span>
            {marketingContext.publishStatus === 'published' && (
              <>
                <span className="text-slate-600">•</span>
                <a
                  href={`/site/${marketingContext.publishedSlug || selectedWebsite.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-mono text-[11px] underline"
                >
                  <Globe className="w-3 h-3" /> /site/{marketingContext.publishedSlug || selectedWebsite.slug}
                </a>
              </>
            )}
          </div>
        )}
      </div>

      {/* Subscription Gating Banner for Starter users */}
      {!hasMarketingAccess && (
        <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-950 text-xs flex items-start gap-3 shadow-2xs">
          <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-sm">Professional or Agency Plan Required</p>
            <p className="text-indigo-800 leading-relaxed">
              AI Marketing Studio campaigns and copywriting generation are available on the Professional ($29/mo) and Agency ($79/mo) plans. You are currently on the Starter ($0/mo) plan. Upgrade your plan to generate and save social posts, video scripts, ad copy, and launch campaigns.
            </p>
          </div>
        </div>
      )}

      {/* Official Product Disclaimer */}
      <div className="px-4 py-3 bg-amber-50/80 border border-amber-200/80 rounded-2xl flex items-center gap-3 text-xs text-amber-900 shadow-2xs">
        <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
        <div className="leading-relaxed">
          <strong className="font-bold">Authentic Catalog Intelligence: </strong>
          StorePilot AI generates marketing content exclusively using {marketingContext?.businessName}&apos;s verified website copy, products, and prices. Never hallucinating unlisted items. Always review before sharing.
        </div>
      </div>

      {/* Tool Selector Tabs */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">
            Marketing Studio Tools
          </h2>
          <span className="text-xs text-slate-400 font-medium">
            Select a generator below
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {TOOLS.map((tool) => {
            const Icon = tool.icon;
            const active = activeTool === tool.id;
            return (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id)}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between h-32 group ${
                  active
                    ? 'border-indigo-600 bg-white ring-2 ring-indigo-500/20 shadow-md shadow-indigo-100/50'
                    : 'border-slate-200 hover:border-slate-300 bg-white shadow-2xs hover:shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between w-full">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                      active
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-700 group-hover:bg-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  {active && (
                    <span className="w-2 h-2 rounded-full bg-indigo-600" />
                  )}
                </div>

                <div>
                  <div className={`text-xs font-bold ${active ? 'text-indigo-900' : 'text-slate-900'}`}>
                    {tool.label}
                  </div>
                  <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                    {tool.shortDesc}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Marketing Tool Container */}
      {marketingContext && user && (
        <div className="pt-2">
          {activeTool === 'social_post' && (
            <SocialPostGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}

          {activeTool === 'tiktok_reels' && (
            <TikTokReelsGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}

          {activeTool === 'video_script' && (
            <VideoScriptGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}

          {activeTool === 'ad_copy' && (
            <AdCopyGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}

          {activeTool === 'product_promo' && (
            <ProductPromotionGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}

          {activeTool === 'campaign_generator' && (
            <CampaignGenerator
              context={marketingContext}
              userId={user.id}
              onSavedItem={loadSavedItems}
            />
          )}
        </div>
      )}

      {/* Saved Library Drawer */}
      {user && (
        <MarketingHistoryDrawer
          isOpen={isLibraryOpen}
          onClose={() => setIsLibraryOpen(false)}
          userId={user.id}
          items={savedItems}
          onRefreshItems={loadSavedItems}
        />
      )}
    </div>
  );
};
