import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  VideoScriptFormat,
  MarketingTone,
  VideoScriptResult,
  VideoScriptScene,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Film,
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Bookmark,
  Clock,
  CheckCircle2,
  Video,
  Mic,
  ArrowRight,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface VideoScriptGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const FORMATS: { id: VideoScriptFormat; label: string; duration: string; desc: string }[] = [
  { id: '15s_hook', label: '15s Fast Hook & CTA', duration: '15s', desc: 'Punchy for TikTok & Reels ads' },
  { id: '30s_promo', label: '30s Commercial Promo', duration: '30s', desc: 'Standard performance ad & product highlight' },
  { id: '60s_brand_story', label: '60s Brand Story', duration: '60s', desc: 'Founder narrative, mission, and customer transformation' },
  { id: 'product_deep_dive', label: 'Product Deep Dive', duration: '45s', desc: 'Material quality, craftsmanship, and unboxing' },
];

export const VideoScriptGenerator: React.FC<VideoScriptGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [format, setFormat] = useState<VideoScriptFormat>('30s_promo');
  const [tone, setTone] = useState<MarketingTone>('Professional');
  const [focusTopic, setFocusTopic] = useState<string>(
    context.products[0]?.name || ''
  );
  const [customInstruction, setCustomInstruction] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<VideoScriptResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Edit state
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedHook, setEditedHook] = useState('');
  const [editedCta, setEditedCta] = useState('');
  const [scenes, setScenes] = useState<VideoScriptScene[]>([]);

  // Feedback states
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setCopied(false);
    setSaved(false);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'video_script',
        context,
        options: {
          format,
          tone,
          focusTopicOrProduct: focusTopic || undefined,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const scriptRes = genResult as VideoScriptResult;
      setResult(scriptRes);
      setEditedTitle(scriptRes.title);
      setEditedHook(scriptRes.hook);
      setEditedCta(scriptRes.cta);
      setScenes(scriptRes.scenes);
      setIsEditing(false);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate video script. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdateScene = (index: number, field: keyof VideoScriptScene, value: any) => {
    setScenes((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  const handleCopyFullScript = async () => {
    if (!result) return;
    const sceneText = scenes
      .map(
        (s) =>
          `[Scene ${s.sceneNumber} (${s.timestamp})]\nVISUAL: ${s.visualCue}\nAUDIO / VOICEOVER: "${s.audioVoiceover}"\n${s.onScreenText ? `ON-SCREEN TEXT: ${s.onScreenText}\n` : ''}`
      )
      .join('\n\n');

    const fullScript = `TITLE: ${editedTitle || result.title}
DURATION: ${result.estimatedDuration}
HOOK: ${editedHook || result.hook}
PROBLEM: ${result.problem}
SOLUTION: ${result.solution}

SCENE BREAKDOWN:
${sceneText}

CALL TO ACTION: ${editedCta || result.cta}`;

    try {
      await navigator.clipboard.writeText(fullScript);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      // Fallback
    }
  };

  const handleSaveToHistory = () => {
    if (!result) return;
    const savedData: VideoScriptResult = {
      ...result,
      title: editedTitle || result.title,
      hook: editedHook || result.hook,
      cta: editedCta || result.cta,
      scenes,
    };

    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'video_script',
      title: `Script: ${savedData.title}`,
      result: savedData,
    });
    setSaved(true);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-600" />
            Video Commercial Script Parameters
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Build production-ready commercials with scene-by-scene visual direction & voiceovers.
          </p>
        </div>

        {/* Format Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Script Format & Duration
          </label>
          <div className="grid grid-cols-2 gap-2">
            {FORMATS.map((f) => {
              const active = format === f.id;
              return (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFormat(f.id)}
                  className={`p-3 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 shadow-2xs font-semibold'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between">
                    <span>{f.duration}</span>
                    <Clock className="w-3 h-3 text-slate-400" />
                  </div>
                  <div className="font-semibold text-slate-900 mt-1 truncate">{f.label}</div>
                  <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{f.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tone Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Tone & Style
          </label>
          <div className="flex flex-wrap gap-1.5">
            {(['Professional', 'Inspirational', 'Friendly', 'Bold', 'Luxury', 'Casual'] as MarketingTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Focus Item */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Topic or Verified Product Spotlight
          </label>
          <select
            value={focusTopic}
            onChange={(e) => setFocusTopic(e.target.value)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          >
            <option value="">-- General Brand / Value Proposition --</option>
            {context.products.map((p) => (
              <option key={p.id} value={p.name}>
                {p.name} {p.price ? `(${p.price})` : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Director / Production Notes (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Include a female voiceover, mention fast shipping, showcase close-up texture."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Drafting Commercial Script...' : result ? 'Regenerate Script' : 'Generate Video Script'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-4">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <Film className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Generate Video Script</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              StorePilot AI will structure a scene-by-scene storyboard with timestamps, shot framing, spoken audio, and on-screen graphics.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Writing Commercial Script...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Constructing cinematic cues grounded in {context.businessName}&apos;s verified store spec.
              </p>
            </div>
          </div>
        )}

        {result && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header Actions */}
            <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 shadow-2xs">
                  {result.estimatedDuration}
                </span>
                <span className="text-xs font-semibold text-slate-700">{result.title}</span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isEditing
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Done Editing' : 'Edit Script'}
                </button>

                <button
                  onClick={handleSaveToHistory}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Save to Library"
                >
                  {saved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                  {saved ? 'Saved' : 'Save'}
                </button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleCopyFullScript}
                  icon={copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                >
                  {copied ? 'Copied Full Script!' : 'Copy Script'}
                </Button>
              </div>
            </div>

            {/* Script Details */}
            <div className="p-6 space-y-6">
              {/* Executive Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl space-y-1">
                  <div className="font-bold text-[10px] uppercase tracking-wider text-amber-800">
                    Hook & Opening Scene
                  </div>
                  <div className="font-semibold text-slate-900 leading-snug">
                    {editedHook || result.hook}
                  </div>
                </div>

                <div className="p-3 bg-indigo-50/70 border border-indigo-200/80 rounded-xl space-y-1">
                  <div className="font-bold text-[10px] uppercase tracking-wider text-indigo-800">
                    Core Solution
                  </div>
                  <div className="text-slate-800 leading-snug">{result.solution}</div>
                </div>
              </div>

              {/* Benefits Pills */}
              {result.keyBenefits && result.keyBenefits.length > 0 && (
                <div className="space-y-1.5">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Featured Value Points
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {result.keyBenefits.map((b, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-slate-100 text-slate-700 font-medium"
                      >
                        <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Scene Breakdown */}
              <div className="space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Scene-By-Scene Storyboard ({scenes.length} Scenes)
                </div>

                <div className="space-y-3">
                  {scenes.map((scene, idx) => (
                    <div
                      key={scene.sceneNumber || idx}
                      className="p-4 bg-slate-50/80 border border-slate-200 rounded-xl space-y-3 text-xs"
                    >
                      <div className="flex items-center justify-between border-b border-slate-200/70 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 bg-slate-900 text-white rounded text-[10px] font-bold font-mono">
                            Scene {scene.sceneNumber}
                          </span>
                          <span className="font-mono text-[11px] text-slate-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {scene.timestamp}
                          </span>
                        </div>
                      </div>

                      {/* Visual & Audio Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Visual Cue */}
                        <div className="space-y-1">
                          <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider flex items-center gap-1">
                            <Video className="w-3 h-3 text-indigo-500" /> Visual Shot Direction
                          </span>
                          {isEditing ? (
                            <textarea
                              rows={2}
                              value={scene.visualCue}
                              onChange={(e) => handleUpdateScene(idx, 'visualCue', e.target.value)}
                              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
                            />
                          ) : (
                            <p className="text-slate-800 leading-relaxed font-sans">{scene.visualCue}</p>
                          )}
                        </div>

                        {/* Audio / Voiceover */}
                        <div className="space-y-1">
                          <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider flex items-center gap-1">
                            <Mic className="w-3 h-3 text-emerald-500" /> Voiceover / Spoken Audio
                          </span>
                          {isEditing ? (
                            <textarea
                              rows={2}
                              value={scene.audioVoiceover}
                              onChange={(e) => handleUpdateScene(idx, 'audioVoiceover', e.target.value)}
                              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
                            />
                          ) : (
                            <p className="text-slate-800 leading-relaxed italic">&ldquo;{scene.audioVoiceover}&rdquo;</p>
                          )}
                        </div>
                      </div>

                      {/* On-screen text if present */}
                      {(scene.onScreenText || isEditing) && (
                        <div className="pt-1 border-t border-slate-100 flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase text-slate-400 shrink-0">
                            Graphic Text:
                          </span>
                          {isEditing ? (
                            <input
                              type="text"
                              value={scene.onScreenText || ''}
                              onChange={(e) => handleUpdateScene(idx, 'onScreenText', e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded text-xs"
                            />
                          ) : (
                            <span className="font-mono text-[11px] text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                              {scene.onScreenText}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Call to action */}
              <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center gap-2 text-xs font-bold text-indigo-900">
                <ArrowRight className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Closing Call To Action: {editedCta || result.cta}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
