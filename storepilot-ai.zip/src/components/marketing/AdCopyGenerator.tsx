import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  AdPlatform,
  AdObjective,
  MarketingTone,
  AdCopyResult,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Target,
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Bookmark,
  ExternalLink,
  Layers,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface AdCopyGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const PLATFORMS: { id: AdPlatform; label: string; desc: string }[] = [
  { id: 'meta', label: 'Meta Ads (FB & IG)', desc: 'High-converting feeds, stories, and carousels' },
  { id: 'google', label: 'Google Search Ads', desc: 'Strict character constraints (<30 char headlines, <90 char desc)' },
  { id: 'tiktok', label: 'TikTok In-Feed Ads', desc: 'Authentic creator-style hook with urgent CTA' },
  { id: 'linkedin', label: 'LinkedIn Ads', desc: 'B2B, founders, executives & corporate decision makers' },
];

const OBJECTIVES: { id: AdObjective; label: string }[] = [
  { id: 'conversions', label: 'Conversions & Sales' },
  { id: 'traffic', label: 'Drive Website Traffic' },
  { id: 'awareness', label: 'Brand & Reach Awareness' },
  { id: 'retargeting', label: 'Retargeting Visitors' },
];

export const AdCopyGenerator: React.FC<AdCopyGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [platform, setPlatform] = useState<AdPlatform>('meta');
  const [objective, setObjective] = useState<AdObjective>('conversions');
  const [tone, setTone] = useState<MarketingTone>('Bold');
  const [focusProduct, setFocusProduct] = useState<string>(
    context.products[0]?.name || ''
  );
  const [customInstruction, setCustomInstruction] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<AdCopyResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Edit state
  const [isEditing, setIsEditing] = useState(false);
  const [primaryTexts, setPrimaryTexts] = useState<string[]>([]);
  const [headlines, setHeadlines] = useState<string[]>([]);
  const [descriptions, setDescriptions] = useState<string[]>([]);
  const [ctaButton, setCtaButton] = useState('');

  // Feedback states
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setCopiedKey(null);
    setSaved(false);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'ad_copy',
        context,
        options: {
          platform,
          objective,
          tone,
          focusProductOrOffer: focusProduct || undefined,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const adRes = genResult as AdCopyResult;
      setResult(adRes);
      setPrimaryTexts(adRes.primaryTexts || []);
      setHeadlines(adRes.headlines || []);
      setDescriptions(adRes.descriptions || []);
      setCtaButton(adRes.recommendedCtaButton || 'Shop Now');
      setIsEditing(false);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate ad copy. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyText = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleCopyFullCampaign = async () => {
    if (!result) return;
    const full = `AD PLATFORM: ${result.platform.toUpperCase()}
OBJECTIVE: ${result.objective}
RECOMMENDED CTA: ${ctaButton}
DISPLAY URL: ${result.displayUrlPath || 'storepilot.com'}

HEADLINES:
${headlines.map((h, i) => `${i + 1}. ${h}`).join('\n')}

PRIMARY TEXT VARIATIONS:
${primaryTexts.map((p, i) => `--- Variation ${i + 1} ---\n${p}`).join('\n\n')}

DESCRIPTIONS:
${descriptions.map((d, i) => `${i + 1}. ${d}`).join('\n')}

AUDIENCE TARGETING ANGLES:
${result.audienceTargetingAngles.map((a, i) => `- ${a}`).join('\n')}`;

    try {
      await navigator.clipboard.writeText(full);
      setCopiedKey('full');
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleSaveToHistory = () => {
    if (!result) return;
    const savedData: AdCopyResult = {
      ...result,
      primaryTexts,
      headlines,
      descriptions,
      recommendedCtaButton: ctaButton,
    };

    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'ad_copy',
      title: `${platform.toUpperCase()} Ad Campaign (${result.objective})`,
      result: savedData,
    });
    setSaved(true);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-600" />
            Ad Campaign Copy Parameters
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Generate high-CTR ad angles matching strict advertising network character guidelines.
          </p>
        </div>

        {/* Ad Platform */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Advertising Platform
          </label>
          <div className="grid grid-cols-2 gap-2">
            {PLATFORMS.map((p) => {
              const active = platform === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPlatform(p.id)}
                  className={`p-3 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-bold shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <div className="font-bold text-slate-900 truncate">{p.label}</div>
                  <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{p.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Objective */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Campaign Objective
          </label>
          <select
            value={objective}
            onChange={(e) => setObjective(e.target.value as AdObjective)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          >
            {OBJECTIVES.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))}
          </select>
        </div>

        {/* Tone */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Copy Tone
          </label>
          <div className="flex flex-wrap gap-1.5">
            {(['Bold', 'Professional', 'Friendly', 'Luxury', 'Casual', 'Inspirational'] as MarketingTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Verified Product */}
        {context.products.length > 0 && (
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Target Verified Product / Offer
            </label>
            <select
              value={focusProduct}
              onChange={(e) => setFocusProduct(e.target.value)}
              className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            >
              <option value="">-- General Store Offer --</option>
              {context.products.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name} {p.price ? `(${p.price})` : ''}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Ad Angle Notes (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Highlight free delivery over $50, focus on artisan quality, emphasize speed."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Synthesizing Ad Variations...' : result ? 'Regenerate Ad Copy' : 'Generate Ad Copy'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-4">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <Target className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Generate Paid Ads</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Generate ad copy variations with strict platform character limit compliance, headlines, descriptions, and audience targeting hooks.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Drafting Paid Ad Campaign...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Optimizing click-through rates and headlines for {context.businessName}.
              </p>
            </div>
          </div>
        )}

        {result && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header Actions */}
            <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 uppercase shadow-2xs">
                  {result.platform}
                </span>
                <span className="text-xs font-semibold text-slate-600 capitalize">
                  {result.objective.replace('_', ' ')}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isEditing
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Done Editing' : 'Edit Copy'}
                </button>

                <button
                  onClick={handleSaveToHistory}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Save to Library"
                >
                  {saved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                  {saved ? 'Saved' : 'Save'}
                </button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleCopyFullCampaign}
                  icon={copiedKey === 'full' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                >
                  {copiedKey === 'full' ? 'Copied All Ads!' : 'Copy All'}
                </Button>
              </div>
            </div>

            {/* Ad Content Display */}
            <div className="p-6 space-y-6 text-xs">
              {/* Recommended CTA & URL bar */}
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Recommended CTA Button:
                  </span>
                  <span className="px-2.5 py-1 bg-slate-900 text-white rounded-md font-bold text-xs">
                    {ctaButton}
                  </span>
                </div>
                <div className="font-mono text-[11px] text-slate-500 flex items-center gap-1">
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                  <span>/site/{context.publishedSlug || context.siteId}</span>
                </div>
              </div>

              {/* Headlines Block */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-600" /> High-Converting Headlines
                  </span>
                  {result.platform === 'google' && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono">
                      Google Search limit: ≤30 chars
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  {headlines.map((headline, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-3 group"
                    >
                      {isEditing ? (
                        <input
                          type="text"
                          value={headline}
                          onChange={(e) => {
                            const copy = [...headlines];
                            copy[idx] = e.target.value;
                            setHeadlines(copy);
                          }}
                          className="w-full font-bold text-slate-900 bg-white border border-slate-200 rounded p-1 text-xs"
                        />
                      ) : (
                        <div className="font-bold text-slate-900 leading-snug">
                          {headline}
                        </div>
                      )}

                      <button
                        onClick={() => handleCopyText(headline, `hl-${idx}`)}
                        className="p-1 text-slate-400 hover:text-slate-800 cursor-pointer shrink-0 transition-colors"
                        title="Copy headline"
                      >
                        {copiedKey === `hl-${idx}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Primary Texts Block */}
              <div className="space-y-2">
                <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-600" /> Primary Ad Body Copy Variations
                </span>

                <div className="space-y-3">
                  {primaryTexts.map((text, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-white border border-slate-200 rounded-xl space-y-2 shadow-2xs"
                    >
                      <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                        <span className="text-[10px] font-bold uppercase text-slate-400">
                          Variation {idx + 1}
                        </span>
                        <button
                          onClick={() => handleCopyText(text, `pt-${idx}`)}
                          className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedKey === `pt-${idx}` ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" /> Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" /> Copy variation
                            </>
                          )}
                        </button>
                      </div>

                      {isEditing ? (
                        <textarea
                          rows={4}
                          value={text}
                          onChange={(e) => {
                            const copy = [...primaryTexts];
                            copy[idx] = e.target.value;
                            setPrimaryTexts(copy);
                          }}
                          className="w-full text-xs text-slate-800 p-2 bg-slate-50 border border-slate-200 rounded-lg leading-relaxed font-sans"
                        />
                      ) : (
                        <p className="text-slate-800 whitespace-pre-line leading-relaxed font-sans">
                          {text}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Audience Targeting Angles */}
              {result.audienceTargetingAngles && result.audienceTargetingAngles.length > 0 && (
                <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1">
                    <Target className="w-3 h-3" /> Recommended Audience Targeting Angles
                  </div>
                  <ul className="space-y-1.5">
                    {result.audienceTargetingAngles.map((angle, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-slate-700">
                        <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                        <span>{angle}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
