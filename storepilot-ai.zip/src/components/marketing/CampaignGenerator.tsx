import React, { useState } from 'react';
import {
  BusinessMarketingContext,
  MarketingCampaignRequest,
  CampaignType,
  MarketingTone,
  MarketingCampaignResult,
  CampaignDayPlan,
} from '../../types/marketing';
import { MarketingService } from '../../services/marketing/marketingService';
import {
  Calendar,
  Sparkles,
  Copy,
  Check,
  RotateCw,
  Edit3,
  Bookmark,
  Layers,
  ArrowRight,
  Clock,
  Compass,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface CampaignGeneratorProps {
  context: BusinessMarketingContext;
  userId: string;
  onSavedItem?: () => void;
}

const CAMPAIGN_TYPES: { id: CampaignType; label: string; desc: string }[] = [
  { id: 'product_launch', label: 'Product Launch Sprint', desc: 'Build anticipation, unveil features, and convert eager shoppers' },
  { id: 'brand_awareness_sprint', label: 'Brand Awareness Blitz', desc: 'Tell founder story, values, craftsmanship, and community' },
  { id: 'limited_time_promo', label: 'Flash Promotion & Urgency', desc: 'Short sprint with high urgency and clear deadlines' },
  { id: 'educational_authority', label: 'Educational Authority Week', desc: 'Tips, how-tos, and establishing domain leadership' },
  { id: 'seasonal_push', label: 'Seasonal Holiday / Trend Push', desc: 'Connect catalog to holiday themes or seasonal transitions' },
];

export const CampaignGenerator: React.FC<CampaignGeneratorProps> = ({
  context,
  userId,
  onSavedItem,
}) => {
  const [campaignType, setCampaignType] = useState<CampaignType>('product_launch');
  const [durationDays, setDurationDays] = useState<3 | 5 | 7>(5);
  const [tone, setTone] = useState<MarketingTone>('Inspirational');
  const [mainFocus, setMainFocus] = useState<string>(
    context.products[0]?.name || ''
  );
  const [customInstruction, setCustomInstruction] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<MarketingCampaignResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Edit state
  const [isEditing, setIsEditing] = useState(false);
  const [days, setDays] = useState<CampaignDayPlan[]>([]);
  const [campaignName, setCampaignName] = useState('');

  // Feedback states
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setCopiedKey(null);
    setSaved(false);

    try {
      const { result: genResult } = await MarketingService.generateMarketing({
        toolType: 'campaign_generator',
        context,
        options: {
          campaignType,
          durationDays,
          tone,
          mainFocus: mainFocus || undefined,
          customInstruction: customInstruction.trim() || undefined,
        },
      });

      const campRes = genResult as MarketingCampaignResult;
      setResult(campRes);
      setCampaignName(campRes.campaignName);
      setDays(campRes.days || []);
      setIsEditing(false);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate campaign. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdateDay = (index: number, field: keyof CampaignDayPlan, value: any) => {
    setDays((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  const handleCopyDay = async (day: CampaignDayPlan) => {
    const text = `DAY ${day.dayNumber}: ${day.dayTitle}
RECOMMENDED CHANNEL: ${day.recommendedChannel}
FORMAT: ${day.contentFormat}
HOOK: ${day.hook}

POST DRAFT:
${day.fullDraft}

CTA: ${day.cta}`;

    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(`day-${day.dayNumber}`);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleCopyFullCampaign = async () => {
    if (!result) return;
    const schedule = days
      .map(
        (d) =>
          `========================================
DAY ${d.dayNumber}: ${d.dayTitle}
Channel: ${d.recommendedChannel} | Format: ${d.contentFormat}
Hook: "${d.hook}"
Draft:
${d.fullDraft}
CTA: ${d.cta}`
      )
      .join('\n\n');

    const full = `CAMPAIGN: ${campaignName || result.campaignName}
CONCEPT: ${result.concept}
DURATION: ${result.durationDays} Days
TARGET AUDIENCE: ${result.targetAudience}
CORE MESSAGE: ${result.coreMessage}

DAY-BY-DAY SCHEDULE:
${schedule}`;

    try {
      await navigator.clipboard.writeText(full);
      setCopiedKey('full');
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleSaveToHistory = () => {
    if (!result) return;
    const savedData: MarketingCampaignResult = {
      ...result,
      campaignName: campaignName || result.campaignName,
      days,
    };

    MarketingService.saveItem(userId, {
      websiteId: context.siteId,
      websiteName: context.siteName,
      toolType: 'campaign_generator',
      title: `Campaign: ${savedData.campaignName}`,
      result: savedData,
    });
    setSaved(true);
    if (onSavedItem) onSavedItem();
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Configuration Column */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600" />
            Marketing Campaign Architect
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Build integrated multi-day content campaigns with cohesive messaging across channels.
          </p>
        </div>

        {/* Campaign Type */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Campaign Objective & Strategy
          </label>
          <div className="space-y-1.5">
            {CAMPAIGN_TYPES.map((c) => {
              const active = campaignType === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCampaignType(c.id)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                    active
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-bold shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                  }`}
                >
                  <div className="font-bold text-slate-900">{c.label}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{c.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Duration Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Campaign Schedule Duration
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[3, 5, 7].map((daysCount) => {
              const active = durationDays === daysCount;
              return (
                <button
                  key={daysCount}
                  type="button"
                  onClick={() => setDurationDays(daysCount as 3 | 5 | 7)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                    active
                      ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  {daysCount} Days
                </button>
              );
            })}
          </div>
        </div>

        {/* Tone */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Campaign Tone
          </label>
          <div className="flex flex-wrap gap-1.5">
            {(['Inspirational', 'Bold', 'Professional', 'Friendly', 'Luxury', 'Casual'] as MarketingTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  tone === t
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Focus Item */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Main Subject or Product Focus (Optional)
          </label>
          <select
            value={mainFocus}
            onChange={(e) => setMainFocus(e.target.value)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          >
            <option value="">-- General Store Campaign --</option>
            {context.products.map((p) => (
              <option key={p.id} value={p.name}>
                {p.name} {p.price ? `(${p.price})` : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Campaign Directives (Optional)
          </label>
          <textarea
            value={customInstruction}
            onChange={(e) => setCustomInstruction(e.target.value)}
            placeholder="e.g. Schedule an email drop on Day 3, include an FAQ day before closing, or focus on eco-friendly sourcing."
            rows={2}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 placeholder:text-slate-400 resize-none"
          />
        </div>

        {/* Generate Button */}
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={handleGenerate}
          disabled={isGenerating}
          icon={isGenerating ? <RotateCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        >
          {isGenerating ? 'Structuring Multi-Day Campaign...' : result ? 'Regenerate Campaign' : 'Generate Marketing Campaign'}
        </Button>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
      </div>

      {/* Results Column */}
      <div className="lg:col-span-7 space-y-4">
        {!result && !isGenerating && (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <Calendar className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Ready to Plan Content Campaign</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              Design a complete multi-day schedule with daily themes, channel recommendations, copy drafts, and calls to action.
            </p>
          </div>
        )}

        {isGenerating && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
            <div className="w-10 h-10 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
            <div>
              <h4 className="text-sm font-bold text-slate-800">Orchestrating Campaign Schedule...</h4>
              <p className="text-xs text-slate-500 mt-1">
                Aligning {context.businessName}&apos;s verified value propositions into a {durationDays}-day rollout.
              </p>
            </div>
          </div>
        )}

        {result && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Header Actions */}
            <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-900 shadow-2xs">
                  {result.durationDays} Days
                </span>
                <span className="text-xs font-bold text-slate-800">
                  {campaignName || result.campaignName}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isEditing
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Done Editing' : 'Edit Schedule'}
                </button>

                <button
                  onClick={handleSaveToHistory}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Save to Library"
                >
                  {saved ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Bookmark className="w-3.5 h-3.5" />}
                  {saved ? 'Saved' : 'Save'}
                </button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleCopyFullCampaign}
                  icon={copiedKey === 'full' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                >
                  {copiedKey === 'full' ? 'Copied Full Campaign!' : 'Copy Entire Campaign'}
                </Button>
              </div>
            </div>

            {/* Campaign Brief */}
            <div className="p-6 space-y-6 text-xs">
              <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1">
                  <Compass className="w-3 h-3" /> Core Campaign Narrative & Theme
                </div>
                <div className="text-slate-800 leading-relaxed">
                  {result.concept}
                </div>
                <div className="text-[11px] text-slate-600 pt-1 border-t border-indigo-100/70">
                  <span className="font-semibold text-slate-900">Target Segment: </span>
                  {result.targetAudience}
                </div>
              </div>

              {/* Day-by-Day Schedule */}
              <div className="space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Day-by-Day Content Schedule ({days.length} Days)
                </div>

                <div className="space-y-4">
                  {days.map((day, idx) => (
                    <div
                      key={day.dayNumber || idx}
                      className="p-5 bg-slate-50/80 border border-slate-200 rounded-xl space-y-3"
                    >
                      {/* Day Header */}
                      <div className="flex items-center justify-between border-b border-slate-200 pb-2 flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 bg-slate-900 text-white rounded-md text-xs font-bold font-mono">
                            Day {day.dayNumber}
                          </span>
                          <span className="font-bold text-slate-900 text-xs">
                            {day.dayTitle}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-medium text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                            {day.recommendedChannel}
                          </span>
                          <button
                            onClick={() => handleCopyDay(day)}
                            className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                            title="Copy day draft"
                          >
                            {copiedKey === `day-${day.dayNumber}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Hook & Format */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
                        <div className="space-y-1">
                          <span className="font-bold text-slate-400 uppercase text-[10px]">
                            Content Format
                          </span>
                          <p className="text-slate-800 font-medium">{day.contentFormat}</p>
                        </div>

                        <div className="space-y-1">
                          <span className="font-bold text-slate-400 uppercase text-[10px]">
                            Post Hook
                          </span>
                          {isEditing ? (
                            <input
                              type="text"
                              value={day.hook}
                              onChange={(e) => handleUpdateDay(idx, 'hook', e.target.value)}
                              className="w-full text-xs font-semibold bg-white border border-slate-200 rounded p-1"
                            />
                          ) : (
                            <p className="text-slate-900 font-semibold italic">&ldquo;{day.hook}&rdquo;</p>
                          )}
                        </div>
                      </div>

                      {/* Post Draft */}
                      <div className="space-y-1">
                        <span className="font-bold text-slate-400 uppercase text-[10px]">
                          Ready Draft Copy
                        </span>
                        {isEditing ? (
                          <textarea
                            rows={3}
                            value={day.fullDraft}
                            onChange={(e) => handleUpdateDay(idx, 'fullDraft', e.target.value)}
                            className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2 font-sans leading-relaxed"
                          />
                        ) : (
                          <div className="p-3 bg-white border border-slate-200 rounded-lg text-slate-700 whitespace-pre-line leading-relaxed font-sans text-xs">
                            {day.fullDraft}
                          </div>
                        )}
                      </div>

                      {/* Day CTA */}
                      <div className="flex items-center gap-1.5 text-indigo-700 font-semibold text-[11px] pt-1">
                        <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>CTA: {day.cta}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
