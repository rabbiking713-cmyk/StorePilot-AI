/**
 * StorePilot AI — Commerce & Printify Product Models (Phase 7A)
 */

export type SiteType =
  | 'BLOG'
  | 'PORTFOLIO'
  | 'PERSONAL'
  | 'BUSINESS'
  | 'EDUCATION'
  | 'SERVICE'
  | 'CREATIVE'
  | 'ECOMMERCE';

export interface CommerceIntentDetectionResult {
  isCommerce: boolean;
  siteType: SiteType;
  confidence: number;
  detectedProductQuery?: string;
  suggestedStyle?: string;
  targetAudience?: string;
  reasoning: string;
}

export interface PrintifyBlueprintImage {
  src?: string;
  is_default?: boolean;
}

export interface PrintifyBlueprint {
  id: number;
  title: string;
  description?: string;
  brand?: string;
  model?: string;
  images: string[];
}

export interface PrintifySearchRequest {
  query: string;
  limit?: number;
}

export interface PrintifySearchResult {
  success: boolean;
  configured: boolean;
  query: string;
  totalFound: number;
  products: PrintifyBlueprint[];
  error?: string;
}

export interface StorePilotProduct {
  id: string;
  websiteId: string;
  ownerId: string;
  printifyBlueprintId: number;
  printifyPrintProviderId?: number;
  printifyVariantId?: number;
  printifyShopProductId?: string;
  printifyTitle: string;
  printifyBrand?: string;
  printifyModel?: string;
  storefrontTitle: string;
  storefrontDescription: string;
  storefrontPrice: number;
  currency: string;
  currencySymbol: string;
  images: string[];
  isApproved: boolean;
  isFeatured?: boolean;
  badge?: string;
  category?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CommerceConfig {
  enabled: boolean;
  provider: 'printify' | 'custom';
  currency: string;
  currencySymbol: string;
  approvedProductCount: number;
  approvedProducts: StorePilotProduct[];
}
