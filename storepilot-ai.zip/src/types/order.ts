export type OrderPaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'CANCELLED';

export type OrderFulfillmentStatus =
  | 'NEW'
  | 'PROCESSING'
  | 'SHIPPED'
  | 'COMPLETED'
  | 'CANCELLED';

export type PrintifySubmissionStatus =
  | 'NOT_SUBMITTED'
  | 'SUBMITTED'
  | 'SUBMISSION_FAILED'
  | 'SKIPPED_NON_PRINTIFY';

export interface PrintifyShipmentInfo {
  carrier: string;
  number: string;
  url?: string;
  deliveredAt?: string;
}

export interface PrintifyOrderFulfillment {
  orderId: string; // Real Printify order ID (e.g. 64a...)
  shopId: number;
  status: string; // Real Printify status: 'on-hold', 'pending', 'payment-not-received', 'processing', 'fulfilled', 'canceled'
  submissionStatus: PrintifySubmissionStatus;
  submissionError?: string;
  sentToProduction?: boolean;
  sentToProductionAt?: string;
  trackingNumber?: string;
  trackingUrl?: string;
  carrier?: string;
  shipments?: PrintifyShipmentInfo[];
  fulfilledAt?: string;
  createdAt: string;
  syncedAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number; // Authoritative unit price in major units (e.g. 24.00)
  priceFormatted: string; // e.g. "$24.00" or "GH₵ 24.00"
  quantity: number;
  imageUrl?: string;
  badge?: string;
  category?: string;
  printifyBlueprintId?: number;
  printifyPrintProviderId?: number;
  printifyVariantId?: number;
  printifyShopProductId?: string;
}

export interface CustomerFulfillmentDetails {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  region: string;
  notes?: string;
}

export interface StoreOrder {
  id: string; // e.g. ord_xxx
  orderReference: string; // Unique human-readable and payment reference (e.g. sp_ord_xxx)
  websiteId: string;
  websiteSlug: string;
  websiteName: string;
  ownerId: string; // User ID of the website owner (StorePilot SaaS customer)
  customer: CustomerFulfillmentDetails;
  items: OrderItem[];
  currency: string; // ISO currency code e.g. GHS, USD, EUR, NGN, GBP
  currencySymbol: string; // e.g. GH₵, $, €, £
  subtotal: number;
  total: number;
  totalInSubunits: number; // e.g. in pesewas or cents (total * 100)
  paymentStatus: OrderPaymentStatus;
  orderStatus: OrderFulfillmentStatus;
  paystackReference?: string;
  paystackChannel?: string;
  paidAt?: string;
  printifyOrder?: PrintifyOrderFulfillment;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  productId: string;
  name: string;
  price: string; // Raw price string from spec
  numericPrice: number;
  quantity: number;
  imageUrl?: string;
  badge?: string;
  category?: string;
}

export interface CheckoutInitializeRequest {
  slug: string;
  siteId?: string;
  customer: CustomerFulfillmentDetails;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
}

export interface CheckoutInitializeResponse {
  success: boolean;
  orderId?: string;
  orderReference?: string;
  authorizationUrl?: string;
  accessCode?: string;
  amount?: number;
  currency?: string;
  paystackConfigured: boolean;
  error?: string;
}

export interface OrderVerificationResponse {
  success: boolean;
  order?: StoreOrder;
  paymentStatus?: OrderPaymentStatus;
  verifiedWithPaystack: boolean;
  error?: string;
}
