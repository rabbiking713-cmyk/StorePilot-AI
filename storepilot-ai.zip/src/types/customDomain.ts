export type DomainVerificationStatus = 'PENDING_VERIFICATION' | 'VERIFIED' | 'FAILED';

export type DomainConnectionStatus =
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'CONFIGURING'
  | 'ACTIVE'
  | 'FAILED'
  | 'DISCONNECTED';

export type DomainSslStatus = 'pending' | 'active' | 'failed' | 'not_applicable';

export interface CustomDomainDnsRecord {
  type: 'TXT' | 'CNAME' | 'A' | 'ALIAS';
  host: string;
  value: string;
  description: string;
}

export interface CustomDomainConfig {
  id: string;
  userId: string;
  websiteId: string;
  domain: string;
  normalizedDomain: string;
  verificationToken: string;
  verificationStatus: DomainVerificationStatus;
  connectionStatus: DomainConnectionStatus;
  createdAt: string;
  verifiedAt?: string;
  lastCheckedAt?: string;
  sslStatus: DomainSslStatus;
  primaryDomain: boolean;
  dnsRecords: {
    txt: CustomDomainDnsRecord;
    cname: CustomDomainDnsRecord;
    apex?: CustomDomainDnsRecord;
  };
  errorMessage?: string;
  requiresHostMapping?: boolean;
}
