export type SubscriptionPlan = 'starter' | 'professional' | 'agency';

export type SubscriptionStatus =
  | 'active'
  | 'inactive'
  | 'past_due'
  | 'cancelled'
  | 'trialing';

export interface UserSubscriptionRecord {
  userId: string;
  email: string;
  displayName?: string;
  plan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  paystackCustomerCode?: string;
  paystackSubscriptionCode?: string;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  isDeveloper?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PlanFeature {
  text: string;
  included: boolean;
}

export interface PlanDefinition {
  id: SubscriptionPlan;
  name: string;
  badge: string;
  priceUsd: number;
  priceFormatted: string;
  billingPeriod: string;
  description: string;
  websiteLimit: number | 'unlimited';
  features: string[];
  primary: boolean;
}

export const STOREPILOT_PLANS: Record<SubscriptionPlan, PlanDefinition> = {
  starter: {
    id: 'starter',
    name: 'Starter',
    badge: 'Free Tier',
    priceUsd: 0,
    priceFormatted: '$0',
    billingPeriod: '/ month',
    description:
      'Everything you need to test the foundation and set up your initial business website project.',
    websiteLimit: 1,
    features: [
      'Responsive Web Application Dashboard',
      'Website project creation & management (1 active project)',
      'Persistent user session handling',
      'Firebase Cloud Auth architecture',
      'Phase 1 AI Builder priority waitlist',
    ],
    primary: false,
  },
  professional: {
    id: 'professional',
    name: 'Professional',
    badge: 'Most Popular',
    priceUsd: 29,
    priceFormatted: '$29',
    billingPeriod: '/ month',
    description:
      'AI website generation, custom domains, and automated marketing campaigns.',
    websiteLimit: 5,
    features: [
      'Natural Language Prompt Website Builder',
      'Custom domain hosting (.com / storepilot.ai)',
      'Visual block editor & style customizer',
      'AI Marketing Studio',
      'Paystack automated billing & renewals',
      'Up to 5 active business websites',
    ],
    primary: true,
  },
  agency: {
    id: 'agency',
    name: 'Agency / Studio',
    badge: 'Enterprise Scale',
    priceUsd: 79,
    priceFormatted: '$79',
    billingPeriod: '/ month',
    description:
      'Unlimited client websites, advanced brand kit memory, and digital marketplace seller access.',
    websiteLimit: 'unlimited',
    features: [
      'Unlimited active business websites',
      'White-label preview links',
      'Marketplace template selling access',
      'Multi-currency Paystack checkout',
      'Dedicated customer success channels',
      'All Professional features included',
    ],
    primary: false,
  },
};

export interface SubscriptionStatusResponse {
  success: boolean;
  plan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  isDeveloper: boolean;
  developerTier?: string;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  paystackCustomerCode?: string;
  paystackConfigured: boolean;
  websiteLimit: number | 'unlimited';
  error?: string;
}

export interface SubscriptionCheckoutResponse {
  success: boolean;
  authorizationUrl?: string;
  reference?: string;
  accessCode?: string;
  plan?: SubscriptionPlan;
  amount?: number;
  currency?: string;
  error?: string;
}
