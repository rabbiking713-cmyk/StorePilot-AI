import { SiteType, CommerceConfig } from './commerce';

export type ThemeMood =
  | 'Modern Minimalist'
  | 'Luxury & Editorial'
  | 'Warm & Artisanal'
  | 'Bold & Energetic'
  | 'Tech & Corporate'
  | 'Fresh & Organic';

export interface WebsiteTheme {
  primaryColor: string; // e.g. '#2563eb'
  accentColor: string; // e.g. '#f59e0b'
  backgroundColor: string; // e.g. '#ffffff' or '#f8fafc'
  textColor: string; // e.g. '#0f172a'
  fontFamily: 'sans' | 'serif' | 'mono';
  styleMood: ThemeMood | string;
}

export interface NavigationLink {
  id: string;
  label: string;
  targetSectionId: string;
}

export interface HeaderConfig {
  brandName: string;
  tagline?: string;
  navLinks: NavigationLink[];
  ctaButton?: {
    label: string;
    targetSectionId: string;
  };
}

export interface HeroSection {
  type: 'hero';
  id: string;
  hidden?: boolean;
  badge?: string;
  headline: string;
  subheadline: string;
  primaryCta: {
    label: string;
    targetSectionId?: string;
  };
  secondaryCta?: {
    label: string;
    targetSectionId?: string;
  };
  imageUrl?: string;
}

export interface FeatureItem {
  id: string;
  title: string;
  description: string;
  iconName?: 'Sparkles' | 'Shield' | 'Zap' | 'Truck' | 'Star' | 'Clock' | 'Check' | 'Heart';
}

export interface FeaturesSection {
  type: 'features';
  id: string;
  hidden?: boolean;
  title: string;
  subtitle?: string;
  items: FeatureItem[];
}

export interface ProductItem {
  id: string;
  name: string;
  price: string;
  category?: string;
  description: string;
  imageUrl?: string;
  badge?: string;
  printifyBlueprintId?: number;
  printifyPrintProviderId?: number;
  printifyVariantId?: number;
  printifyShopProductId?: string;
}

export interface ProductsSection {
  type: 'products';
  id: string;
  hidden?: boolean;
  title: string;
  subtitle?: string;
  currencySymbol?: string;
  items: ProductItem[];
  ctaLabel?: string;
}

export interface AboutSection {
  type: 'about';
  id: string;
  hidden?: boolean;
  title: string;
  headline: string;
  content: string;
  highlights?: string[];
  imageUrl?: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  rating?: number;
  avatarUrl?: string;
}

export interface TestimonialsSection {
  type: 'testimonials';
  id: string;
  hidden?: boolean;
  title: string;
  subtitle?: string;
  items: TestimonialItem[];
}

export interface CtaSection {
  type: 'cta';
  id: string;
  hidden?: boolean;
  headline: string;
  subheadline: string;
  buttonLabel: string;
  targetSectionId?: string;
}

export interface ContactSection {
  type: 'contact';
  id: string;
  hidden?: boolean;
  title: string;
  subtitle?: string;
  email?: string;
  phone?: string;
  address?: string;
  hours?: string;
  formEnabled?: boolean;
}

export type WebsiteSection =
  | HeroSection
  | FeaturesSection
  | ProductsSection
  | AboutSection
  | TestimonialsSection
  | CtaSection
  | ContactSection;

export interface FooterConfig {
  brandName: string;
  copyright: string;
  description?: string;
  quickLinks?: { label: string; href: string }[];
  socialLinks?: { platform: string; url: string }[];
}

export interface WebsiteSpec {
  siteName: string;
  businessName: string;
  tagline: string;
  businessDescription: string;
  industry: string;
  targetAudience: string;
  siteType?: SiteType;
  commerceConfig?: CommerceConfig;
  theme: WebsiteTheme;
  header: HeaderConfig;
  sections: WebsiteSection[];
  footer: FooterConfig;
}

export interface ThemePreset {
  id: string;
  name: string;
  mood: ThemeMood | string;
  description: string;
  theme: WebsiteTheme;
}
