import { WebsiteSpec } from './websiteSpec';

export type TemplateCategory =
  | 'Fashion'
  | 'Restaurant'
  | 'Beauty'
  | 'Real Estate'
  | 'Technology'
  | 'Photography'
  | 'Education'
  | 'Business'
  | 'Creative Portfolio'
  | 'Online Store';

export interface Template {
  id: string;
  name: string;
  category: TemplateCategory;
  description: string;
  thumbnailUrl: string;
  tags: string[];
  spec: WebsiteSpec;
  styleMood: string;
  featured?: boolean;
}
