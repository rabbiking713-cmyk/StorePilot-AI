export type MarketingToolType =
  | 'social_post'
  | 'tiktok_reels'
  | 'video_script'
  | 'ad_copy'
  | 'product_promo'
  | 'campaign_generator';

export type SocialPlatform = 'instagram' | 'facebook' | 'linkedin' | 'x';

export type ContentGoal =
  | 'promote_product'
  | 'promote_service'
  | 'build_awareness'
  | 'educational'
  | 'announcement'
  | 'engagement'
  | 'sale_promotion';

export type MarketingTone =
  | 'Professional'
  | 'Friendly'
  | 'Bold'
  | 'Luxury'
  | 'Casual'
  | 'Inspirational';

export interface BusinessProductContext {
  id: string;
  name: string;
  price: string;
  category?: string;
  description: string;
  badge?: string;
  imageUrl?: string;
}

export interface BusinessMarketingContext {
  siteId: string;
  siteName: string;
  businessName: string;
  tagline: string;
  businessDescription: string;
  industry: string;
  targetAudience: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroBadge?: string;
  products: BusinessProductContext[];
  features: Array<{ id?: string; title: string; description: string }>;
  aboutHeadline?: string;
  aboutContent?: string;
  aboutHighlights?: string[];
  callsToAction: string[];
  contactInfo?: {
    email?: string;
    phone?: string;
    address?: string;
    hours?: string;
  };
  themeMood?: string;
  primaryColor?: string;
  accentColor?: string;
  publishStatus: 'draft' | 'published' | 'changes_unpublished';
  publishedSlug?: string;
}

// ----------------------------------------------------------------------
// 1. Social Post
// ----------------------------------------------------------------------
export interface SocialPostRequest {
  platform: SocialPlatform;
  goal: ContentGoal;
  tone: MarketingTone;
  customInstruction?: string;
  selectedProductName?: string;
}

export interface SocialPostResult {
  platform: SocialPlatform;
  goal: ContentGoal;
  tone: MarketingTone;
  headline: string; // Hook
  body: string;
  cta: string;
  hashtags: string[];
}

// ----------------------------------------------------------------------
// 2. TikTok / Reels Ideas
// ----------------------------------------------------------------------
export type ShortVideoAngle =
  | 'hook_story'
  | 'product_demo'
  | 'behind_the_scenes'
  | 'problem_solution'
  | 'myth_busting'
  | 'day_in_life';

export interface TikTokReelsRequest {
  focusAngle?: ShortVideoAngle;
  tone?: MarketingTone;
  focusProduct?: string;
  customInstruction?: string;
}

export interface TikTokReelsIdea {
  id: string;
  title: string;
  hook: string;
  concept: string;
  whatToShow: string;
  onScreenText: string;
  suggestedVoiceover: string;
  cta: string;
  caption: string;
  hashtags: string[];
}

export interface TikTokReelsResult {
  ideas: TikTokReelsIdea[];
}

// ----------------------------------------------------------------------
// 3. Video Script
// ----------------------------------------------------------------------
export type VideoScriptFormat =
  | '15s_hook'
  | '30s_promo'
  | '60s_brand_story'
  | 'product_deep_dive';

export interface VideoScriptRequest {
  format: VideoScriptFormat;
  tone: MarketingTone;
  focusTopicOrProduct?: string;
  customInstruction?: string;
}

export interface VideoScriptScene {
  sceneNumber: number;
  timestamp: string; // e.g. "0:00 - 0:05"
  visualCue: string;
  audioVoiceover: string;
  onScreenText?: string;
}

export interface VideoScriptResult {
  title: string;
  format: VideoScriptFormat;
  estimatedDuration: string;
  hook: string;
  problem: string;
  solution: string;
  keyBenefits: string[];
  cta: string;
  scenes: VideoScriptScene[];
}

// ----------------------------------------------------------------------
// 4. Ad Copy
// ----------------------------------------------------------------------
export type AdPlatform = 'meta' | 'google' | 'tiktok' | 'linkedin';
export type AdObjective = 'conversions' | 'traffic' | 'awareness' | 'retargeting';

export interface AdCopyRequest {
  platform: AdPlatform;
  objective: AdObjective;
  tone: MarketingTone;
  focusProductOrOffer?: string;
  customInstruction?: string;
}

export interface AdCopyResult {
  platform: AdPlatform;
  objective: AdObjective;
  primaryTexts: string[]; // 2-3 variations
  headlines: string[]; // 3-4 punchy variations
  descriptions: string[]; // 2 variations
  recommendedCtaButton: string; // e.g. "Shop Now", "Learn More", "Get Offer"
  displayUrlPath?: string; // e.g. "storepilot.com/shop/artisan"
  audienceTargetingAngles: string[]; // 2-3 audience hooks
}

// ----------------------------------------------------------------------
// 5. Product Promotion
// ----------------------------------------------------------------------
export type PromoAngle =
  | 'spotlight'
  | 'new_arrival'
  | 'best_seller'
  | 'problem_solver'
  | 'behind_craft'
  | 'limited_drop';

export interface ProductPromoRequest {
  productName: string;
  productPrice?: string;
  productCategory?: string;
  productDescription?: string;
  promoAngle: PromoAngle;
  tone: MarketingTone;
  customInstruction?: string;
}

export interface ProductStorySlide {
  slideNumber: number;
  slideType: 'hook' | 'feature' | 'urgency_cta';
  visualCue: string;
  stickerOrText: string;
  captionCue: string;
}

export interface ProductPromoResult {
  productName: string;
  productPrice: string;
  hook: string;
  valueProposition: string;
  feedPostCopy: string;
  storySequence: ProductStorySlide[];
  cta: string;
  hashtags: string[];
}

// ----------------------------------------------------------------------
// 6. Marketing Campaign
// ----------------------------------------------------------------------
export type CampaignType =
  | 'product_launch'
  | 'brand_awareness_sprint'
  | 'seasonal_push'
  | 'educational_authority'
  | 'limited_time_promo';

export interface MarketingCampaignRequest {
  campaignType: CampaignType;
  durationDays: 3 | 5 | 7;
  tone: MarketingTone;
  mainFocus?: string;
  customInstruction?: string;
}

export interface CampaignDayPlan {
  dayNumber: number;
  dayTitle: string;
  recommendedChannel: string;
  contentFormat: string; // e.g. "Instagram Carousel", "Short Reel", "X Thread"
  hook: string;
  postSummary: string;
  fullDraft: string;
  cta: string;
}

export interface MarketingCampaignResult {
  campaignName: string;
  concept: string;
  campaignType: CampaignType;
  durationDays: number;
  targetAudience: string;
  coreMessage: string;
  days: CampaignDayPlan[];
}

// ----------------------------------------------------------------------
// Unified API Request / Response
// ----------------------------------------------------------------------
export interface GenerateMarketingPayload {
  toolType: MarketingToolType;
  context: BusinessMarketingContext;
  options:
    | SocialPostRequest
    | TikTokReelsRequest
    | VideoScriptRequest
    | AdCopyRequest
    | ProductPromoRequest
    | MarketingCampaignRequest;
}

export type MarketingOutputResult =
  | SocialPostResult
  | TikTokReelsResult
  | VideoScriptResult
  | AdCopyResult
  | ProductPromoResult
  | MarketingCampaignResult;

export interface GenerateMarketingResponse {
  success: boolean;
  toolType: MarketingToolType;
  result?: MarketingOutputResult;
  modelUsed?: string;
  error?: string;
}

// ----------------------------------------------------------------------
// Saved Marketing Item (History & Favorites)
// ----------------------------------------------------------------------
export interface SavedMarketingItem {
  id: string;
  userId: string;
  websiteId: string;
  websiteName: string;
  toolType: MarketingToolType;
  title: string;
  createdAt: string;
  result: MarketingOutputResult;
}
