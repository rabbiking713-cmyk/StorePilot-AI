import { WebsiteSpec } from './websiteSpec';
import { CustomDomainConfig } from './customDomain';

export * from './websiteSpec';
export * from './template';
export * from './customDomain';
export * from './marketing';
export * from './order';
export * from './commerce';
export * from './subscription';

export interface PublishedSiteRecord {
  slug: string;
  siteId: string;
  userId: string;
  userEmail?: string;
  name: string;
  description?: string;
  publishedSpec: WebsiteSpec;
  publishedAt: string;
  publishedVersion: number;
  status: 'published' | 'unpublished';
}

export interface UserSession {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  isAnonymous?: boolean;
  isDemo?: boolean;
  providerId: 'firebase' | 'local_dev' | 'google';
  createdAt: string;
}

export type WebsiteStatus = 'draft' | 'configured' | 'published';
export type PublishStatus = 'draft' | 'published' | 'changes_unpublished';

export interface Website {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  businessType: string;
  description: string;
  status: WebsiteStatus;
  createdAt: string;
  updatedAt: string;
  customDomain?: string;
  pagesCount: number;
  originalPrompt?: string;
  spec?: WebsiteSpec;
  isDemo?: boolean;

  // Phase 4A: Publishing fields
  publishStatus?: PublishStatus;
  publishedSlug?: string;
  publishedAt?: string;
  publishedSpec?: WebsiteSpec;
  publishedVersion?: number;

  // Phase 4B: Custom Domain fields
  customDomainConfig?: CustomDomainConfig;
}

export interface RoadmapPhase {
  phase: number;
  title: string;
  shortDesc: string;
  details: string;
  status: 'active' | 'upcoming';
  estimatedTiming?: string;
}

export type ActiveDashboardTab =
  | 'overview'
  | 'websites'
  | 'orders'
  | 'builder_preview'
  | 'editor_preview'
  | 'marketing_preview'
  | 'templates_preview'
  | 'subscription'
  | 'profile'
  | 'settings';
