import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem } from '../types/order';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  currencySymbol: string;
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  openCheckout: () => void;
  closeCheckout: () => void;
  addItem: (product: {
    id: string;
    name: string;
    price: string;
    imageUrl?: string;
    badge?: string;
    category?: string;
  }) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  setCurrencySymbol: (symbol: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

function parsePriceToNumber(priceStr: string | number): number {
  if (typeof priceStr === 'number') return Math.max(0, priceStr);
  if (!priceStr || typeof priceStr !== 'string') return 0;
  const cleaned = priceStr.replace(/[^0-9.]/g, '');
  const val = parseFloat(cleaned);
  return isNaN(val) ? 0 : Math.max(0, val);
}

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [currencySymbol, setCurrencySymbol] = useState('$');

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const subtotal = items.reduce(
    (sum, item) => sum + item.numericPrice * item.quantity,
    0
  );

  const addItem = (product: {
    id: string;
    name: string;
    price: string;
    imageUrl?: string;
    badge?: string;
    category?: string;
  }) => {
    const numPrice = parsePriceToNumber(product.price);
    setItems((prev) => {
      const existing = prev.find((i) => i.productId === product.id || i.name === product.name);
      if (existing) {
        return prev.map((i) =>
          i.productId === product.id || i.name === product.name
            ? { ...i, quantity: i.quantity + 1 }
            : i
        );
      }
      return [
        ...prev,
        {
          productId: product.id || product.name,
          name: product.name,
          price: product.price,
          numericPrice: numPrice,
          quantity: 1,
          imageUrl: product.imageUrl,
          badge: product.badge,
          category: product.category,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeItem = (productId: string) => {
    setItems((prev) => prev.filter((i) => i.productId !== productId && i.name !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }
    setItems((prev) =>
      prev.map((i) =>
        i.productId === productId || i.name === productId
          ? { ...i, quantity: Math.min(99, quantity) }
          : i
      )
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        currencySymbol,
        isCartOpen,
        isCheckoutOpen,
        openCart: () => setIsCartOpen(true),
        closeCart: () => setIsCartOpen(false),
        openCheckout: () => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        },
        closeCheckout: () => setIsCheckoutOpen(false),
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        setCurrencySymbol,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const useOptionalCart = (): CartContextType | null => {
  return useContext(CartContext) || null;
};
