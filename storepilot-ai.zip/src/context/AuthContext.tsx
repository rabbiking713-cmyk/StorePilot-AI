import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserSession } from '../types';
import { AuthService } from '../services/auth/authService';
import { WebsiteService } from '../services/data/websiteService';

interface AuthContextType {
  user: UserSession | null;
  isLoading: boolean;
  isFirebaseConfigured: boolean;
  missingFirebaseKeys: string[];
  isAuthModalOpen: boolean;
  authModalMode: 'signin' | 'signup';
  isConfigModalOpen: boolean;
  openAuthModal: (mode?: 'signin' | 'signup') => void;
  closeAuthModal: () => void;
  openConfigModal: () => void;
  closeConfigModal: () => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  signInAsDemoFounder: () => Promise<void>;
  updateDisplayName: (newName: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'signup'>('signin');
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);

  const isFirebaseConfigured = AuthService.isCloudConfigured();
  const missingFirebaseKeys = AuthService.getMissingConfigKeys();

  useEffect(() => {
    const unsubscribe = AuthService.subscribeAuthState((currentUser) => {
      if (!currentUser) {
        WebsiteService.clearMemoryCache();
      }
      setUser(currentUser);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAuthModal = (mode: 'signin' | 'signup' = 'signin') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openConfigModal = () => {
    setIsConfigModalOpen(true);
  };

  const closeConfigModal = () => {
    setIsConfigModalOpen(false);
  };

  const signInWithGoogle = async () => {
    try {
      setIsLoading(true);
      const loggedUser = await AuthService.signInWithGoogle();
      setUser(loggedUser);
      setIsAuthModalOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    try {
      setIsLoading(true);
      const loggedUser = await AuthService.signInWithEmail(email, pass);
      setUser(loggedUser);
      setIsAuthModalOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name: string) => {
    try {
      setIsLoading(true);
      const loggedUser = await AuthService.signUpWithEmail(email, pass, name);
      setUser(loggedUser);
      setIsAuthModalOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const signInAsDemoFounder = async () => {
    try {
      setIsLoading(true);
      const demoUser = await AuthService.signInAsDemoFounder();
      setUser(demoUser);
      setIsAuthModalOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const updateDisplayName = async (newName: string) => {
    const updated = await AuthService.updateDisplayName(newName);
    setUser(updated);
  };

  const signOut = async () => {
    try {
      setIsLoading(true);
      WebsiteService.clearMemoryCache();
      await AuthService.signOut();
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isFirebaseConfigured,
        missingFirebaseKeys,
        isAuthModalOpen,
        authModalMode,
        isConfigModalOpen,
        openAuthModal,
        closeAuthModal,
        openConfigModal,
        closeConfigModal,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signInAsDemoFounder,
        updateDisplayName,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
