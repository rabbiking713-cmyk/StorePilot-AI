import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Website, Template, CustomDomainConfig } from '../types';
import { WebsiteSpec } from '../types/websiteSpec';
import { WebsiteService } from '../services/data/websiteService';
import { useAuth } from './AuthContext';

interface WebsitesContextType {
  websites: Website[];
  isLoading: boolean;
  selectedWebsite: Website | null;
  setSelectedWebsite: (site: Website | null) => void;
  createWebsite: (payload: {
    name: string;
    businessType: string;
    description: string;
    originalPrompt?: string;
    spec?: WebsiteSpec;
    isDemo?: boolean;
  }) => Website;
  createFromTemplate: (template: Template) => Website;
  duplicateWebsite: (siteId: string) => Website;
  renameWebsite: (siteId: string, newName: string) => void;
  deleteWebsite: (siteId: string) => void;
  updateWebsite: (siteId: string, updates: Partial<Website>) => void;
  publishWebsite: (
    siteId: string,
    customSlug?: string
  ) => Promise<{ website: Website; publicUrl: string }>;
  unpublishWebsite: (siteId: string) => Promise<Website>;
  updateCustomDomain: (siteId: string, config: CustomDomainConfig | null) => Website;
  refreshWebsites: () => void;
  isCreateModalOpen: boolean;
  openCreateModal: () => void;
  closeCreateModal: () => void;
}

const WebsitesContext = createContext<WebsitesContextType | undefined>(undefined);

export const WebsitesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [websites, setWebsites] = useState<Website[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedWebsite, setSelectedWebsite] = useState<Website | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);

  const isDemoSession = user?.isDemo || user?.email?.includes('.local') || user?.providerId === 'local_dev';

  useEffect(() => {
    let isMounted = true;
    if (user?.id) {
      setIsLoading(true);
      const cached = WebsiteService.getCachedWebsitesForUser(user.id);
      if (cached && cached.length > 0) {
        setWebsites(cached);
        if (!selectedWebsite) {
          setSelectedWebsite(cached[0]);
        }
      }
      WebsiteService.fetchWebsitesForUser(user.id).then((serverSites) => {
        if (!isMounted) return;
        setWebsites(serverSites);
        if (serverSites.length > 0) {
          setSelectedWebsite((curr) => {
            if (!curr) return serverSites[0];
            const found = serverSites.find((s) => s.id === curr.id);
            return found || serverSites[0];
          });
        }
        setIsLoading(false);
      }).catch(() => {
        if (isMounted) setIsLoading(false);
      });
    } else {
      setWebsites([]);
      setSelectedWebsite(null);
      setIsLoading(false);
    }
    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  const openCreateModal = () => setIsCreateModalOpen(true);
  const closeCreateModal = () => setIsCreateModalOpen(false);

  const createWebsite = (payload: {
    name: string;
    businessType: string;
    description: string;
    originalPrompt?: string;
    spec?: WebsiteSpec;
    isDemo?: boolean;
  }): Website => {
    if (!user) throw new Error('Must be logged in to create a website');
    const newSite = WebsiteService.createWebsite(user.id, payload);
    const updated = [newSite, ...websites];
    setWebsites(updated);
    setSelectedWebsite(newSite);
    closeCreateModal();
    return newSite;
  };

  const createFromTemplate = (template: Template): Website => {
    if (!user) throw new Error('Must be logged in to create a website');
    const newSite = WebsiteService.createWebsiteFromTemplate(user.id, template, isDemoSession);
    const updated = [newSite, ...websites];
    setWebsites(updated);
    setSelectedWebsite(newSite);
    return newSite;
  };

  const duplicateWebsite = (siteId: string): Website => {
    if (!user) throw new Error('Must be logged in to duplicate a website');
    const duplicated = WebsiteService.duplicateWebsite(user.id, siteId);
    const updated = [duplicated, ...websites];
    setWebsites(updated);
    setSelectedWebsite(duplicated);
    return duplicated;
  };

  const renameWebsite = (siteId: string, newName: string) => {
    if (!user) return;
    const updated = WebsiteService.renameWebsite(user.id, siteId, newName);
    setWebsites(updated);
    if (selectedWebsite?.id === siteId) {
      const found = updated.find((s) => s.id === siteId);
      if (found) setSelectedWebsite(found);
    }
  };

  const deleteWebsite = (siteId: string) => {
    if (!user) return;
    const remaining = WebsiteService.deleteWebsite(user.id, siteId);
    setWebsites(remaining);
    if (selectedWebsite?.id === siteId) {
      setSelectedWebsite(remaining.length > 0 ? remaining[0] : null);
    }
  };

  const updateWebsite = (siteId: string, updates: Partial<Website>) => {
    if (!user) return;
    const updated = WebsiteService.updateWebsite(user.id, siteId, updates);
    setWebsites(updated);
    if (selectedWebsite?.id === siteId) {
      const found = updated.find((s) => s.id === siteId);
      if (found) setSelectedWebsite(found);
    }
  };

  const publishWebsite = async (
    siteId: string,
    customSlug?: string
  ): Promise<{ website: Website; publicUrl: string }> => {
    if (!user) throw new Error('Must be logged in to publish a website');
    const result = await WebsiteService.publishWebsite(
      user.id,
      siteId,
      customSlug,
      user.email
    );
    // Refresh user's websites list
    const updatedSites = WebsiteService.getWebsitesForUser(user.id);
    setWebsites(updatedSites);
    if (selectedWebsite?.id === siteId) {
      setSelectedWebsite(result.website);
    }
    return result;
  };

  const unpublishWebsite = async (siteId: string): Promise<Website> => {
    if (!user) throw new Error('Must be logged in to unpublish a website');
    const unpublished = await WebsiteService.unpublishWebsite(user.id, siteId);
    const updatedSites = WebsiteService.getWebsitesForUser(user.id);
    setWebsites(updatedSites);
    if (selectedWebsite?.id === siteId) {
      setSelectedWebsite(unpublished);
    }
    return unpublished;
  };

  const updateCustomDomain = (siteId: string, config: CustomDomainConfig | null): Website => {
    if (!user) throw new Error('Must be logged in to update custom domain');
    const updated = WebsiteService.updateCustomDomain(user.id, siteId, config);
    const updatedSites = WebsiteService.getWebsitesForUser(user.id);
    setWebsites(updatedSites);
    if (selectedWebsite?.id === siteId) {
      setSelectedWebsite(updated);
    }
    return updated;
  };

  const refreshWebsites = () => {
    if (user) {
      const userSites = WebsiteService.getWebsitesForUser(user.id);
      setWebsites(userSites);
    }
  };

  return (
    <WebsitesContext.Provider
      value={{
        websites,
        isLoading,
        selectedWebsite,
        setSelectedWebsite,
        createWebsite,
        createFromTemplate,
        duplicateWebsite,
        renameWebsite,
        deleteWebsite,
        updateWebsite,
        publishWebsite,
        unpublishWebsite,
        updateCustomDomain,
        refreshWebsites,
        isCreateModalOpen,
        openCreateModal,
        closeCreateModal,
      }}
    >
      {children}
    </WebsitesContext.Provider>
  );
};

export const useWebsites = (): WebsitesContextType => {
  const context = useContext(WebsitesContext);
  if (!context) {
    throw new Error('useWebsites must be used within a WebsitesProvider');
  }
  return context;
};
