import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { SubscriptionApiClient } from '../services/subscription/subscriptionApiClient';
import {
  SubscriptionPlan,
  SubscriptionStatus,
  SubscriptionStatusResponse,
} from '../types/subscription';

interface SubscriptionContextType {
  plan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  isDeveloper: boolean;
  developerTier?: string;
  isLoading: boolean;
  isUpgrading: boolean;
  paystackConfigured: boolean;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  websiteLimit: number | 'unlimited';
  hasActivePaidPlan: boolean;
  canPublish: boolean;
  canAccess: (feature: 'publish' | 'ai_builder' | 'marketing_studio' | 'custom_domains' | 'agency_tier') => boolean;
  refreshSubscription: () => Promise<void>;
  upgradeToPlan: (plan: 'professional' | 'agency') => Promise<{ success: boolean; authorizationUrl?: string; error?: string }>;
  cancelSubscription: () => Promise<{ success: boolean; error?: string }>;
  verificationMessage: string | null;
  clearVerificationMessage: () => void;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const SubscriptionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [subData, setSubData] = useState<SubscriptionStatusResponse>({
    success: true,
    plan: 'starter',
    subscriptionStatus: 'active',
    isDeveloper: false,
    paystackConfigured: false,
    websiteLimit: 1,
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isUpgrading, setIsUpgrading] = useState<boolean>(false);
  const [verificationMessage, setVerificationMessage] = useState<string | null>(null);

  const fetchStatus = useCallback(async () => {
    if (!user) {
      setSubData({
        success: true,
        plan: 'starter',
        subscriptionStatus: 'active',
        isDeveloper: false,
        paystackConfigured: false,
        websiteLimit: 1,
      });
      setIsLoading(false);
      return;
    }

    try {
      const data = await SubscriptionApiClient.getStatus();
      setSubData(data);
    } catch (err) {
      console.error('[SubscriptionContext] Error fetching status:', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  // Initial fetch and handle return from Paystack checkout callback
  useEffect(() => {
    let isMounted = true;

    async function init() {
      if (!user) {
        setIsLoading(false);
        return;
      }

      setIsLoading(true);

      // Check if URL has Paystack reference callback
      if (typeof window !== 'undefined') {
        const params = new URLSearchParams(window.location.search);
        const ref = params.get('reference') || params.get('trxref');
        if (ref && (params.get('subscription_callback') || ref.startsWith('sub_'))) {
          try {
            const verifyRes = await SubscriptionApiClient.verifyPayment(ref);
            if (verifyRes.success && isMounted) {
              setVerificationMessage(
                `Payment verified! Your ${verifyRes.plan ? verifyRes.plan.toUpperCase() : ''} subscription is now active.`
              );
              // Clean up URL parameters
              window.history.replaceState({}, document.title, window.location.pathname);
            } else if (isMounted && verifyRes.error) {
              setVerificationMessage(`Payment verification notice: ${verifyRes.error}`);
            }
          } catch (err: any) {
            console.warn('[SubscriptionContext] Auto-verification warning:', err);
          }
        }
      }

      await fetchStatus();
    }

    init();

    return () => {
      isMounted = false;
    };
  }, [user, fetchStatus]);

  const canAccess = useCallback(
    (feature: 'publish' | 'ai_builder' | 'marketing_studio' | 'custom_domains' | 'agency_tier'): boolean => {
      // Internal developer testing accounts have full agency-tier access
      if (subData.isDeveloper) return true;

      // Starter ($0/mo) users can experience the builder and preview drafts privately
      if (feature === 'ai_builder') return true;

      // Paid features require active subscription
      if (subData.subscriptionStatus !== 'active') return false;

      if (feature === 'agency_tier') {
        return subData.plan === 'agency';
      }

      // Professional and Agency have access to publishing, marketing studio, and custom domains
      return subData.plan === 'professional' || subData.plan === 'agency';
    },
    [subData]
  );

  const upgradeToPlan = async (
    targetPlan: 'professional' | 'agency'
  ): Promise<{ success: boolean; authorizationUrl?: string; error?: string }> => {
    setIsUpgrading(true);
    try {
      const res = await SubscriptionApiClient.initializeCheckout(targetPlan);
      if (res.success && res.authorizationUrl) {
        // Redirect to Paystack secure checkout
        window.location.href = res.authorizationUrl;
        return { success: true, authorizationUrl: res.authorizationUrl };
      }
      return { success: false, error: res.error || 'Failed to initialize Paystack checkout.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Payment initiation error.' };
    } finally {
      setIsUpgrading(false);
    }
  };

  const cancelSubscription = async (): Promise<{ success: boolean; error?: string }> => {
    setIsUpgrading(true);
    try {
      const res = await SubscriptionApiClient.cancelSubscription();
      if (res.success) {
        await fetchStatus();
      }
      return res;
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to cancel subscription.' };
    } finally {
      setIsUpgrading(false);
    }
  };

  const hasActivePaidPlan =
    subData.isDeveloper ||
    (subData.subscriptionStatus === 'active' &&
      (subData.plan === 'professional' || subData.plan === 'agency'));

  return (
    <SubscriptionContext.Provider
      value={{
        plan: subData.plan,
        subscriptionStatus: subData.subscriptionStatus,
        isDeveloper: subData.isDeveloper,
        developerTier: subData.developerTier,
        isLoading,
        isUpgrading,
        paystackConfigured: subData.paystackConfigured,
        currentPeriodStart: subData.currentPeriodStart,
        currentPeriodEnd: subData.currentPeriodEnd,
        websiteLimit: subData.websiteLimit,
        hasActivePaidPlan,
        canPublish: hasActivePaidPlan,
        canAccess,
        refreshSubscription: fetchStatus,
        upgradeToPlan,
        cancelSubscription,
        verificationMessage,
        clearVerificationMessage: () => setVerificationMessage(null),
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = (): SubscriptionContextType => {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};
