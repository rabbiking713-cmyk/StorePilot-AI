import { ThemePreset, WebsiteSection } from '../types/websiteSpec';

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'modern-minimalist',
    name: 'Modern Minimalist',
    mood: 'Modern Minimalist',
    description: 'Crisp typography, clean monochrome tones, and razor-sharp clarity.',
    theme: {
      primaryColor: '#0f172a',
      accentColor: '#3b82f6',
      backgroundColor: '#ffffff',
      textColor: '#0f172a',
      fontFamily: 'sans',
      styleMood: 'Modern Minimalist',
    },
  },
  {
    id: 'luxury-editorial',
    name: 'Luxury & Editorial',
    mood: 'Luxury & Editorial',
    description: 'Warm ivory background, rich charcoal, gold accents, and serif elegance.',
    theme: {
      primaryColor: '#1c1917',
      accentColor: '#b45309',
      backgroundColor: '#fbfaf8',
      textColor: '#1c1917',
      fontFamily: 'serif',
      styleMood: 'Luxury & Editorial',
    },
  },
  {
    id: 'bold-energetic',
    name: 'Bold & Energetic',
    mood: 'Bold & Energetic',
    description: 'High-octane electric orange, vibrant contrast, and punchy contemporary aesthetic.',
    theme: {
      primaryColor: '#ea580c',
      accentColor: '#db2777',
      backgroundColor: '#ffffff',
      textColor: '#09090b',
      fontFamily: 'sans',
      styleMood: 'Bold & Energetic',
    },
  },
  {
    id: 'clean-modern',
    name: 'Clean Tech & SaaS',
    mood: 'Clean Modern',
    description: 'Deep indigo, vibrant cyan accents, and balanced slate background.',
    theme: {
      primaryColor: '#4f46e5',
      accentColor: '#06b6d4',
      backgroundColor: '#f8fafc',
      textColor: '#0f172a',
      fontFamily: 'sans',
      styleMood: 'Tech & Corporate',
    },
  },
  {
    id: 'warm-artisanal',
    name: 'Warm & Artisanal',
    mood: 'Warm & Artisanal',
    description: 'Earthy terracotta, warm clay tones, organic textures, and serif headings.',
    theme: {
      primaryColor: '#78350f',
      accentColor: '#d97706',
      backgroundColor: '#fefcf8',
      textColor: '#292524',
      fontFamily: 'serif',
      styleMood: 'Warm & Artisanal',
    },
  },
  {
    id: 'professional-corporate',
    name: 'Corporate & Trust',
    mood: 'Professional',
    description: 'Deep ocean navy, clean royal blue accents, and pristine contrast.',
    theme: {
      primaryColor: '#0369a1',
      accentColor: '#2563eb',
      backgroundColor: '#ffffff',
      textColor: '#0f172a',
      fontFamily: 'sans',
      styleMood: 'Tech & Corporate',
    },
  },
  {
    id: 'fresh-organic',
    name: 'Fresh & Organic',
    mood: 'Fresh & Organic',
    description: 'Lush forest emerald, natural sage, and healthy botanical vibrancy.',
    theme: {
      primaryColor: '#15803d',
      accentColor: '#65a30d',
      backgroundColor: '#f7fee7',
      textColor: '#14532d',
      fontFamily: 'sans',
      styleMood: 'Fresh & Organic',
    },
  },
  {
    id: 'creative-studio',
    name: 'Creative & Vibrant',
    mood: 'Creative Studio',
    description: 'Striking royal purple, hot rose, and expressive visual flair.',
    theme: {
      primaryColor: '#7c3aed',
      accentColor: '#f43f5e',
      backgroundColor: '#ffffff',
      textColor: '#18181b',
      fontFamily: 'sans',
      styleMood: 'Bold & Energetic',
    },
  },
];

export interface CuratedImageCategory {
  id: string;
  label: string;
  images: {
    title: string;
    url: string;
    thumbnail: string;
  }[];
}

export const CURATED_IMAGE_LIBRARY: CuratedImageCategory[] = [
  {
    id: 'fashion',
    label: 'Fashion & Apparel',
    images: [
      {
        title: 'Streetwear Model Hoodie',
        url: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Minimalist Sneaker Showcase',
        url: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Urban Jacket & Street Style',
        url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Graphic Tee Fashion',
        url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Premium Watch & Accessories',
        url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=300&q=80',
      },
    ],
  },
  {
    id: 'tech',
    label: 'Tech & Digital',
    images: [
      {
        title: 'Modern Laptop Desk Setup',
        url: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Software Development & Code',
        url: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Minimalist Workspace Architecture',
        url: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Mobile Phone UI in Hand',
        url: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=300&q=80',
      },
    ],
  },
  {
    id: 'artisanal',
    label: 'Crafts & Artisanal',
    images: [
      {
        title: 'Ceramic Pottery Wheel',
        url: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Handmade Glazed Cups',
        url: 'https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Woodworking Craftsman Studio',
        url: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Textile Weaving Fabric',
        url: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=300&q=80',
      },
    ],
  },
  {
    id: 'food',
    label: 'Food, Dining & Cafe',
    images: [
      {
        title: 'Artisan Espresso Pour',
        url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Fresh Baked Sourdough Bread',
        url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Gourmet Plated Dish',
        url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Cozy Coffeehouse Ambience',
        url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=300&q=80',
      },
    ],
  },
  {
    id: 'corporate',
    label: 'Business & Consulting',
    images: [
      {
        title: 'Executive Team Meeting',
        url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Modern Highrise Architecture',
        url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=300&q=80',
      },
      {
        title: 'Strategic Consultation Discussion',
        url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1200&q=80',
        thumbnail: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      },
    ],
  },
];

export const createDefaultSection = (
  type: 'hero' | 'features' | 'products' | 'about' | 'testimonials' | 'cta' | 'contact',
  businessName: string
): WebsiteSection => {
  const timestamp = Date.now();
  switch (type) {
    case 'hero':
      return {
        type: 'hero',
        id: `hero-${timestamp}`,
        badge: 'Welcome to Excellence',
        headline: `Empowering Your World with ${businessName}`,
        subheadline: `Discover premium quality, modern craftsmanship, and exceptional attention to detail built for your lifestyle.`,
        primaryCta: { label: 'Explore Offerings', targetSectionId: 'products' },
        secondaryCta: { label: 'Learn More', targetSectionId: 'about' },
        imageUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
      };
    case 'features':
      return {
        type: 'features',
        id: `features-${timestamp}`,
        title: 'Why Choose Us',
        subtitle: 'Engineered for exceptional standards and uncompromising satisfaction.',
        items: [
          {
            id: `f1-${timestamp}`,
            title: 'Unrivaled Quality',
            description: 'Every product and service meets rigorous standards before reaching you.',
            iconName: 'Shield',
          },
          {
            id: `f2-${timestamp}`,
            title: 'Express Delivery',
            description: 'Fast, secure turnaround delivered directly to your doorstep.',
            iconName: 'Truck',
          },
          {
            id: `f3-${timestamp}`,
            title: '24/7 Dedicated Support',
            description: 'Our customer success team is available to assist you whenever you need us.',
            iconName: 'Star',
          },
        ],
      };
    case 'products':
      return {
        type: 'products',
        id: `products-${timestamp}`,
        title: 'Featured Collection',
        subtitle: 'Hand-picked items designed to exceed your expectations.',
        currencySymbol: '$',
        items: [
          {
            id: `p1-${timestamp}`,
            name: `${businessName} Signature Edition`,
            price: '89.00',
            category: 'Bestseller',
            badge: 'Popular',
            description: 'Our flagship offering, crafted with premium materials for everyday reliability.',
            imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
          },
          {
            id: `p2-${timestamp}`,
            name: `${businessName} Essential Classic`,
            price: '55.00',
            category: 'Essentials',
            badge: 'New',
            description: 'Timeless design meeting modern functional durability.',
            imageUrl: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
          },
        ],
      };
    case 'about':
      return {
        type: 'about',
        id: `about-${timestamp}`,
        title: 'Our Story',
        headline: `Passionate about bringing the best to our community`,
        content: `At ${businessName}, we believe in creating experiences that resonate. Founded with a vision to redefine standard quality, we blend authentic passion with modern innovation.`,
        highlights: [
          'Ethically sourced materials and production',
          'Locally crafted with global design standards',
          'Dedicated to 100% customer satisfaction',
        ],
        imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80',
      };
    case 'testimonials':
      return {
        type: 'testimonials',
        id: `testimonials-${timestamp}`,
        title: 'What Our Clients Say',
        subtitle: 'Real reviews from people who love what we do.',
        items: [
          {
            id: `t1-${timestamp}`,
            author: 'Sarah Mensah',
            role: 'Verified Customer',
            quote: `${businessName} exceeded every expectation. The quality and customer experience are unmatched.`,
            rating: 5,
            avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
          },
          {
            id: `t2-${timestamp}`,
            author: 'David Osei',
            role: 'Creative Director',
            quote: 'Clean, reliable, and truly premium. I have recommended them to all my colleagues.',
            rating: 5,
            avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
          },
        ],
      };
    case 'cta':
      return {
        type: 'cta',
        id: `cta-${timestamp}`,
        headline: `Ready to experience ${businessName}?`,
        subheadline: 'Join hundreds of satisfied customers who trust us every single day.',
        buttonLabel: 'Get Started Today',
        targetSectionId: 'contact',
      };
    case 'contact':
      return {
        type: 'contact',
        id: `contact-${timestamp}`,
        title: 'Get In Touch',
        subtitle: 'Have a question or custom inquiry? We would love to hear from you.',
        email: 'hello@' + businessName.toLowerCase().replace(/[^a-z0-9]/g, '') + '.com',
        phone: '+233 24 123 4567',
        address: '12 Independence Avenue, Accra, Ghana',
        hours: 'Monday – Saturday: 9:00 AM – 7:00 PM',
        formEnabled: true,
      };
  }
};
