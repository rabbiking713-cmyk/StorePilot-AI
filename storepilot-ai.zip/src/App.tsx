import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { WebsitesProvider } from './context/WebsitesContext';
import { SubscriptionProvider } from './context/SubscriptionContext';
import { LandingPage } from './components/landing/LandingPage';
import { DashboardLayout } from './components/dashboard/DashboardLayout';
import { PublicWebsiteView } from './components/public/PublicWebsiteView';

function getPublicSlugFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  const path = window.location.pathname;
  if (path.startsWith('/site/')) {
    const parts = path.replace('/site/', '').split('/');
    const slug = parts[0]?.trim();
    return slug || null;
  }
  return null;
}

function getCustomDomainFromUrl(): string | null {
  if (typeof window === 'undefined') return null;

  // Support query parameter for testing/previewing in sandbox: ?custom_domain=mybrand.com
  const urlParams = new URLSearchParams(window.location.search);
  const simulatedDomain = urlParams.get('custom_domain');
  if (simulatedDomain) return simulatedDomain.toLowerCase().trim();

  const host = window.location.hostname.toLowerCase().trim();
  if (
    !host ||
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host.endsWith('.run.app') ||
    host.endsWith('.storepilot.ai')
  ) {
    return null;
  }

  return host;
}

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard'>('landing');
  const [publicSlug, setPublicSlug] = useState<string | null>(getPublicSlugFromUrl());
  const [customDomain, setCustomDomain] = useState<string | null>(getCustomDomainFromUrl());

  // Listen to popstate for browser navigation (e.g. Back/Forward)
  useEffect(() => {
    const handleLocationChange = () => {
      setPublicSlug(getPublicSlugFromUrl());
      setCustomDomain(getCustomDomainFromUrl());
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // When visiting via custom domain, render standalone website view directly
  // No auth required, no dashboard, no editor controls
  if (customDomain) {
    return <PublicWebsiteView customDomain={customDomain} />;
  }

  // When visiting a public site (/site/:slug), render standalone website view directly
  // No auth required, no dashboard, no editor controls
  if (publicSlug) {
    return <PublicWebsiteView slug={publicSlug} />;
  }

  // When user signs in, switch to dashboard
  useEffect(() => {
    if (user && currentView === 'landing') {
      setCurrentView('dashboard');
    } else if (!user && currentView === 'dashboard') {
      setCurrentView('landing');
    }
  }, [user]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4">
        <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm mb-3 animate-pulse">
          SP
        </div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Initializing StorePilot AI...
        </p>
      </div>
    );
  }

  if (currentView === 'dashboard' && user) {
    return (
      <DashboardLayout
        onReturnToLanding={() => setCurrentView('landing')}
      />
    );
  }

  return (
    <LandingPage
      onGoToDashboard={() => setCurrentView('dashboard')}
    />
  );
};

export default function App() {
  return (
    <AuthProvider>
      <SubscriptionProvider>
        <WebsitesProvider>
          <AppContent />
        </WebsitesProvider>
      </SubscriptionProvider>
    </AuthProvider>
  );
}
