import { WebsiteSpec, ProductsSection, HeroSection, FeaturesSection, AboutSection, ContactSection } from '../../types/websiteSpec';
import { PublishedSiteRecord } from '../../types';

export interface ShopSeoMetadata {
  title: string;
  description: string;
  canonicalUrl: string;
  ogTitle: string;
  ogDescription: string;
  ogType: string;
  ogUrl: string;
  ogSiteName: string;
  ogImage?: string;
  twitterCard: 'summary_large_image' | 'summary';
  twitterTitle: string;
  twitterDescription: string;
  twitterImage?: string;
  robots: string;
  jsonLd: Record<string, any>;
}

/**
 * Resolves the primary StorePilot origin based on configured environment variables,
 * incoming request headers, or default domain.
 */
export function getStorePilotPrimaryOrigin(reqHostOrOrigin?: string): string {
  // 1. Explicit StorePilot primary domain environment variable
  if (process.env.STOREPILOT_PRIMARY_DOMAIN) {
    let domain = process.env.STOREPILOT_PRIMARY_DOMAIN.trim();
    if (!domain.startsWith('http://') && !domain.startsWith('https://')) {
      domain = `https://${domain}`;
    }
    return domain.replace(/\/+$/, '');
  }

  // 2. Cloud Run / AI Studio injected application URL
  if (process.env.PUBLIC_APP_URL) {
    return process.env.PUBLIC_APP_URL.trim().replace(/\/+$/, '');
  }
  if (process.env.APP_URL) {
    let appUrl = process.env.APP_URL.trim();
    if (!appUrl.startsWith('http://') && !appUrl.startsWith('https://')) {
      appUrl = `https://${appUrl}`;
    }
    return appUrl.replace(/\/+$/, '');
  }

  // 3. Request origin or host parameter
  if (reqHostOrOrigin) {
    let origin = reqHostOrOrigin.trim();
    if (!origin.startsWith('http://') && !origin.startsWith('https://')) {
      origin = `https://${origin}`;
    }
    return origin.replace(/\/+$/, '');
  }

  // 4. Default StorePilot production domain
  return 'https://storepilot.com';
}

/**
 * Maps common currency symbols to ISO 4217 currency codes for schema.org
 */
function mapCurrencySymbolToCode(symbol?: string): string {
  if (!symbol) return 'USD';
  switch (symbol.trim()) {
    case 'GH₵':
    case 'GHS':
      return 'GHS';
    case '€':
    case 'EUR':
      return 'EUR';
    case '£':
    case 'GBP':
      return 'GBP';
    case '¥':
    case 'JPY':
      return 'JPY';
    case 'C$':
    case 'CAD':
      return 'CAD';
    case 'A$':
    case 'AUD':
      return 'AUD';
    case '$':
    case 'USD':
    default:
      return 'USD';
  }
}

/**
 * Extracts a primary image for OpenGraph and Twitter cards from published site sections
 */
function extractPrimaryImage(spec?: WebsiteSpec): string | undefined {
  if (!spec?.sections) return undefined;

  // 1. Check Hero Section image
  const hero = spec.sections.find((s) => s.type === 'hero') as HeroSection | undefined;
  if (hero?.imageUrl) return hero.imageUrl;

  // 2. Check first product with image
  const products = spec.sections.find((s) => s.type === 'products') as ProductsSection | undefined;
  if (products?.items) {
    const itemWithImg = products.items.find((item) => Boolean(item.imageUrl));
    if (itemWithImg?.imageUrl) return itemWithImg.imageUrl;
  }

  // 3. Check About section image
  const about = spec.sections.find((s) => s.type === 'about') as AboutSection | undefined;
  if (about?.imageUrl) return about.imageUrl;

  return undefined;
}

/**
 * Generates unique, search-engine-ready SEO metadata for a published StorePilot shop.
 */
export function generateShopMetadata(
  site: PublishedSiteRecord,
  primaryOrigin: string
): ShopSeoMetadata {
  const spec = site.publishedSpec;
  const brandName = (spec?.siteName || spec?.businessName || site.name || 'Shop').trim();
  const tagline = (spec?.tagline || '').trim();
  const industry = (spec?.industry || '').trim();

  // Page Title (30-60 characters optimal, branded, non-generic)
  let title = '';
  if (tagline && `${brandName} – ${tagline} | StorePilot`.length <= 60) {
    title = `${brandName} – ${tagline} | StorePilot`;
  } else if (industry && `${brandName} – ${industry} | StorePilot`.length <= 60) {
    title = `${brandName} – ${industry} | StorePilot`;
  } else {
    title = `${brandName} | StorePilot`;
  }

  // Meta Description (120-160 characters optimal)
  let rawDesc = (
    spec?.businessDescription ||
    site.description ||
    spec?.tagline ||
    `Explore ${brandName} on StorePilot. High quality products and exceptional service.`
  ).trim();

  // Ensure clean length without truncation in the middle of words
  let description = rawDesc;
  if (description.length > 155) {
    description = description.slice(0, 152).trim() + '...';
  } else if (description.length < 50) {
    description = `${description} Explore catalog, shop online, and connect with ${brandName} on StorePilot.`;
  }

  const canonicalUrl = `${primaryOrigin.replace(/\/+$/, '')}/site/${site.slug}`;
  const ogImage = extractPrimaryImage(spec);

  const jsonLd = generateJsonLd(site, primaryOrigin);

  return {
    title,
    description,
    canonicalUrl,
    ogTitle: title,
    ogDescription: description,
    ogType: 'website',
    ogUrl: canonicalUrl,
    ogSiteName: `${brandName} on StorePilot`,
    ogImage,
    twitterCard: ogImage ? 'summary_large_image' : 'summary',
    twitterTitle: title,
    twitterDescription: description,
    twitterImage: ogImage,
    robots: 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1',
    jsonLd,
  };
}

/**
 * Generates Schema.org structured data (JSON-LD) for a published shop.
 * Includes only authentic information from WebsiteSpec; does not invent missing data.
 */
export function generateJsonLd(
  site: PublishedSiteRecord,
  primaryOrigin: string
): Record<string, any> {
  const spec = site.publishedSpec;
  const canonicalUrl = `${primaryOrigin.replace(/\/+$/, '')}/site/${site.slug}`;
  const brandName = (spec?.siteName || spec?.businessName || site.name || 'Store').trim();
  const description = (spec?.businessDescription || site.description || spec?.tagline || '').trim();
  const heroImage = extractPrimaryImage(spec);

  // Find products section
  const productsSection = spec?.sections?.find((s) => s.type === 'products') as ProductsSection | undefined;
  const currencyCode = mapCurrencySymbolToCode(productsSection?.currencySymbol);

  // Find contact section if available
  const contactSection = spec?.sections?.find((s) => s.type === 'contact') as ContactSection | undefined;

  const graph: any[] = [];

  // 1. WebSite Entity
  graph.push({
    '@type': 'WebSite',
    '@id': `${canonicalUrl}#website`,
    url: canonicalUrl,
    name: brandName,
    description: description || undefined,
    publisher: {
      '@type': 'Organization',
      name: 'StorePilot',
      url: primaryOrigin,
    },
  });

  // 2. Store / OnlineStore Entity
  const storeEntity: Record<string, any> = {
    '@type': 'OnlineStore',
    '@id': `${canonicalUrl}#store`,
    name: brandName,
    description: description || undefined,
    url: canonicalUrl,
    image: heroImage || undefined,
  };

  if (contactSection) {
    if (contactSection.email) {
      storeEntity.email = contactSection.email;
    }
    if (contactSection.phone) {
      storeEntity.telephone = contactSection.phone;
    }
    if (contactSection.address) {
      storeEntity.address = {
        '@type': 'PostalAddress',
        streetAddress: contactSection.address,
      };
    }
    if (contactSection.hours) {
      storeEntity.openingHours = contactSection.hours;
    }
  }

  graph.push(storeEntity);

  // 3. Real Products (Omit any missing fields - never fabricate prices or ratings)
  if (productsSection?.items && productsSection.items.length > 0) {
    const productEntities = productsSection.items.map((item, idx) => {
      const productObj: Record<string, any> = {
        '@type': 'Product',
        '@id': `${canonicalUrl}#product-${item.id || idx}`,
        name: item.name,
        url: canonicalUrl,
      };

      if (item.description) {
        productObj.description = item.description;
      }
      if (item.imageUrl) {
        productObj.image = item.imageUrl;
      }
      if (item.category) {
        productObj.category = item.category;
      }

      // If item price is provided in the spec, parse real numeric price
      if (item.price) {
        const numeric = parseFloat(String(item.price).replace(/[^0-9.]/g, ''));
        if (!isNaN(numeric) && numeric > 0) {
          productObj.offers = {
            '@type': 'Offer',
            price: numeric.toFixed(2),
            priceCurrency: currencyCode,
            availability: 'https://schema.org/InStock',
            url: canonicalUrl,
          };
        }
      }

      return productObj;
    });

    graph.push(...productEntities);
  }

  return {
    '@context': 'https://schema.org',
    '@graph': graph,
  };
}

/**
 * Generates an SEO-rich, semantic HTML crawl snapshot for search engines and social bots.
 * Contains one H1, section H2s, product H3s, image alt tags, and crawlable links.
 */
export function generateSemanticHtmlSnapshot(
  site: PublishedSiteRecord,
  primaryOrigin: string
): string {
  const spec = site.publishedSpec;
  const canonicalUrl = `${primaryOrigin.replace(/\/+$/, '')}/site/${site.slug}`;
  const brandName = escapeHtml(spec?.siteName || spec?.businessName || site.name);
  const tagline = spec?.tagline ? escapeHtml(spec.tagline) : '';

  // Extract sections
  const hero = spec?.sections?.find((s) => s.type === 'hero') as HeroSection | undefined;
  const features = spec?.sections?.find((s) => s.type === 'features') as FeaturesSection | undefined;
  const products = spec?.sections?.find((s) => s.type === 'products') as ProductsSection | undefined;
  const about = spec?.sections?.find((s) => s.type === 'about') as AboutSection | undefined;
  const contact = spec?.sections?.find((s) => s.type === 'contact') as ContactSection | undefined;

  let html = `
<div id="storepilot-public-shop" class="storepilot-shop-container">
  <header class="shop-header">
    <div class="brand-bar">
      <strong class="brand-name">${brandName}</strong>
      ${tagline ? `<span class="brand-tagline">${tagline}</span>` : ''}
    </div>
    <nav class="shop-nav" aria-label="Shop Navigation">
      <a href="#hero">Home</a>
      ${products ? `<a href="#products">Products</a>` : ''}
      ${about ? `<a href="#about">About</a>` : ''}
      ${contact ? `<a href="#contact">Contact</a>` : ''}
    </nav>
  </header>

  <main class="shop-main">
    <!-- Hero Section with Primary H1 -->
    <section id="hero" class="shop-section shop-hero">
      ${hero?.badge ? `<div class="hero-badge">${escapeHtml(hero.badge)}</div>` : ''}
      <h1 class="hero-headline">${escapeHtml(hero?.headline || brandName)}</h1>
      ${hero?.subheadline ? `<p class="hero-subheadline">${escapeHtml(hero.subheadline)}</p>` : ''}
      ${
        hero?.imageUrl
          ? `<div class="hero-media"><img src="${escapeHtml(hero.imageUrl)}" alt="${escapeHtml(hero.headline || brandName)}" loading="eager" /></div>`
          : ''
      }
    </section>
`;

  // Features Section
  if (features && features.items?.length) {
    html += `
    <section id="features" class="shop-section shop-features">
      <h2>${escapeHtml(features.title || 'Features & Benefits')}</h2>
      ${features.subtitle ? `<p class="section-subtitle">${escapeHtml(features.subtitle)}</p>` : ''}
      <div class="features-grid">
        ${features.items
          .map(
            (feat) => `
          <div class="feature-item">
            <h3>${escapeHtml(feat.title)}</h3>
            <p>${escapeHtml(feat.description)}</p>
          </div>`
          )
          .join('\n')}
      </div>
    </section>`;
  }

  // Products Section
  if (products && products.items?.length) {
    const symbol = products.currencySymbol || '$';
    html += `
    <section id="products" class="shop-section shop-products">
      <h2>${escapeHtml(products.title || 'Our Products')}</h2>
      ${products.subtitle ? `<p class="section-subtitle">${escapeHtml(products.subtitle)}</p>` : ''}
      <div class="products-grid">
        ${products.items
          .map(
            (prod) => `
          <article class="product-card">
            ${
              prod.imageUrl
                ? `<img src="${escapeHtml(prod.imageUrl)}" alt="${escapeHtml(prod.name)}" loading="lazy" />`
                : ''
            }
            <h3>${escapeHtml(prod.name)}</h3>
            ${prod.price ? `<p class="product-price"><strong>${escapeHtml(symbol)}${escapeHtml(prod.price)}</strong></p>` : ''}
            ${prod.description ? `<p class="product-desc">${escapeHtml(prod.description)}</p>` : ''}
            ${prod.badge ? `<span class="product-badge">${escapeHtml(prod.badge)}</span>` : ''}
          </article>`
          )
          .join('\n')}
      </div>
    </section>`;
  }

  // About Section
  if (about) {
    html += `
    <section id="about" class="shop-section shop-about">
      <h2>${escapeHtml(about.title || 'About Our Business')}</h2>
      ${about.headline ? `<p class="about-headline"><strong>${escapeHtml(about.headline)}</strong></p>` : ''}
      ${about.content ? `<div class="about-content">${escapeHtml(about.content)}</div>` : ''}
      ${
        about.imageUrl
          ? `<img src="${escapeHtml(about.imageUrl)}" alt="${escapeHtml(about.title || brandName)}" loading="lazy" />`
          : ''
      }
    </section>`;
  }

  // Contact Section
  if (contact) {
    html += `
    <section id="contact" class="shop-section shop-contact">
      <h2>${escapeHtml(contact.title || 'Contact Us')}</h2>
      ${contact.subtitle ? `<p class="section-subtitle">${escapeHtml(contact.subtitle)}</p>` : ''}
      <div class="contact-details">
        ${contact.email ? `<p>Email: <a href="mailto:${escapeHtml(contact.email)}">${escapeHtml(contact.email)}</a></p>` : ''}
        ${contact.phone ? `<p>Phone: <a href="tel:${escapeHtml(contact.phone)}">${escapeHtml(contact.phone)}</a></p>` : ''}
        ${contact.address ? `<p>Address: <span class="address">${escapeHtml(contact.address)}</span></p>` : ''}
        ${contact.hours ? `<p>Hours: <span>${escapeHtml(contact.hours)}</span></p>` : ''}
      </div>
    </section>`;
  }

  html += `
  </main>

  <footer class="shop-footer">
    <p>&copy; ${new Date().getFullYear()} ${brandName}. All rights reserved.</p>
    <p>Powered by <a href="${escapeHtml(primaryOrigin)}" rel="nofollow">StorePilot AI</a>.</p>
    <link rel="canonical" href="${escapeHtml(canonicalUrl)}" />
  </footer>
</div>`;

  return html;
}

/**
 * Injects SEO tags, OpenGraph metadata, JSON-LD, and semantic snapshot into an HTML document.
 */
export function injectSeoIntoHtml(
  htmlTemplate: string,
  site: PublishedSiteRecord | null,
  primaryOrigin: string,
  is404 = false
): string {
  if (is404 || !site || site.status !== 'published') {
    let html = htmlTemplate;
    // Strip default tags
    html = html.replace(/<meta\s+property="og:[^"]*"\s+content="[^"]*"\s*\/?>\s*/gi, '');
    html = html.replace(/<meta\s+name="twitter:[^"]*"\s+content="[^"]*"\s*\/?>\s*/gi, '');
    html = html.replace(/<meta\s+name="robots"\s+content="[^"]*"\s*\/?>\s*/gi, '');
    html = html.replace(/<link\s+rel="canonical"\s+href="[^"]*"\s*\/?>\s*/gi, '');

    const title = '404 — Shop Not Found | StorePilot';
    const desc = 'The requested StorePilot shop was not found, has been unpublished, or the link is incorrect.';

    html = html.replace(/<title>.*?<\/title>/i, `<title>${title}</title>`);
    html = html.replace(/<meta name="description" content=".*?"\s*\/?>/i, `<meta name="description" content="${desc}" />`);

    const noindexMeta = `
    <meta name="robots" content="noindex, nofollow" />
    <meta property="og:title" content="${title}" />
    <meta property="og:description" content="${desc}" />
    `;
    return html.replace('</head>', `${noindexMeta}\n</head>`);
  }

  const metadata = generateShopMetadata(site, primaryOrigin);

  let html = htmlTemplate;

  // Strip default placeholder tags so that only unique shop metadata is present
  html = html.replace(/<meta\s+property="og:[^"]*"\s+content="[^"]*"\s*\/?>\s*/gi, '');
  html = html.replace(/<meta\s+name="twitter:[^"]*"\s+content="[^"]*"\s*\/?>\s*/gi, '');
  html = html.replace(/<meta\s+name="robots"\s+content="[^"]*"\s*\/?>\s*/gi, '');
  html = html.replace(/<link\s+rel="canonical"\s+href="[^"]*"\s*\/?>\s*/gi, '');

  // 1. Replace Title
  html = html.replace(/<title>.*?<\/title>/i, `<title>${escapeHtml(metadata.title)}</title>`);

  // 2. Replace or Inject Description
  if (/<meta name="description"/i.test(html)) {
    html = html.replace(
      /<meta name="description" content=".*?"\s*\/?>/i,
      `<meta name="description" content="${escapeHtml(metadata.description)}" />`
    );
  }

  // 3. Construct Complete SEO Head Tags
  const headTags = [
    `<link rel="canonical" href="${escapeHtml(metadata.canonicalUrl)}" />`,
    `<meta name="robots" content="${escapeHtml(metadata.robots)}" />`,
    `<meta property="og:type" content="${escapeHtml(metadata.ogType)}" />`,
    `<meta property="og:title" content="${escapeHtml(metadata.ogTitle)}" />`,
    `<meta property="og:description" content="${escapeHtml(metadata.ogDescription)}" />`,
    `<meta property="og:url" content="${escapeHtml(metadata.ogUrl)}" />`,
    `<meta property="og:site_name" content="${escapeHtml(metadata.ogSiteName)}" />`,
    metadata.ogImage ? `<meta property="og:image" content="${escapeHtml(metadata.ogImage)}" />` : '',
    `<meta name="twitter:card" content="${escapeHtml(metadata.twitterCard)}" />`,
    `<meta name="twitter:title" content="${escapeHtml(metadata.twitterTitle)}" />`,
    `<meta name="twitter:description" content="${escapeHtml(metadata.twitterDescription)}" />`,
    metadata.twitterImage ? `<meta name="twitter:image" content="${escapeHtml(metadata.twitterImage)}" />` : '',
    `<script type="application/ld+json">\n${JSON.stringify(metadata.jsonLd, null, 2)}\n</script>`,
  ]
    .filter(Boolean)
    .join('\n    ');

  html = html.replace('</head>', `    ${headTags}\n  </head>`);

  // 4. Inject Crawlable Semantic HTML Snapshot inside #root
  // When search engines fetch the raw HTML, they immediately see full semantic shop content
  const snapshotHtml = generateSemanticHtmlSnapshot(site, primaryOrigin);
  html = html.replace(
    '<div id="root"></div>',
    `<div id="root">${snapshotHtml}</div>`
  );

  return html;
}

/**
 * Generates an XML sitemap of all public published StorePilot shops.
 * Strictly excludes drafts, unpublished websites, and admin routes.
 */
export function generateSitemapXml(
  sites: PublishedSiteRecord[],
  primaryOrigin: string
): string {
  const base = primaryOrigin.replace(/\/+$/, '');
  const activeSites = sites.filter((s) => s.status === 'published' && s.slug);

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

  // Root platform landing page
  xml += `  <url>\n`;
  xml += `    <loc>${escapeXml(base)}/</loc>\n`;
  xml += `    <changefreq>daily</changefreq>\n`;
  xml += `    <priority>1.0</priority>\n`;
  xml += `  </url>\n`;

  // Each active published shop
  for (const site of activeSites) {
    const loc = `${base}/site/${site.slug}`;
    const lastMod = site.publishedAt ? new Date(site.publishedAt).toISOString() : new Date().toISOString();
    xml += `  <url>\n`;
    xml += `    <loc>${escapeXml(loc)}</loc>\n`;
    xml += `    <lastmod>${escapeXml(lastMod)}</lastmod>\n`;
    xml += `    <changefreq>weekly</changefreq>\n`;
    xml += `    <priority>0.8</priority>\n`;
    xml += `  </url>\n`;
  }

  xml += `</urlset>`;
  return xml;
}

/**
 * Generates standard robots.txt with sitemap reference and indexing instructions.
 */
export function generateRobotsTxt(primaryOrigin: string): string {
  const base = primaryOrigin.replace(/\/+$/, '');
  return `# StorePilot AI Robots.txt
# Public published shops are crawlable and indexable
User-agent: *
Allow: /
Allow: /site/
Disallow: /api/
Disallow: /dashboard
Disallow: /editor

# Reference to official public sitemap
Sitemap: ${base}/sitemap.xml
`;
}

function escapeHtml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function escapeXml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
