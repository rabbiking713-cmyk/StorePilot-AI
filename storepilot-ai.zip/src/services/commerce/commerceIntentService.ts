import {
  CommerceIntentDetectionResult,
  PrintifyBlueprint,
  SiteType,
} from '../../types/commerce';

/**
 * Service to detect commerce intent from natural language prompts
 * and rank real catalog products without inventing fictional items.
 */
export class CommerceIntentService {
  /**
   * Rule-based fallback classifier when Gemini API is offline or unconfigured
   */
  public static classifyWithRules(prompt: string, businessType?: string): CommerceIntentDetectionResult {
    const text = `${prompt} ${businessType || ''}`.toLowerCase();

    // Explicit Non-Commerce Signals
    const isPortfolio = /\b(portfolio|showcase my work|photographer|photography|designer portfolio|architect|resume|cv)\b/i.test(text);
    const isBlog = /\b(blog|articles|news|journal|writing|travel blog|food blog)\b/i.test(text);
    const isPersonal = /\b(personal website|biography|about me|speaker|author profile)\b/i.test(text);
    const isEducation = /\b(school|course|curriculum|academy|education|university|tutorial)\b/i.test(text);
    const isService = /\b(dentist|dental|law firm|legal|accounting|consulting|agency|clinic|cleaning service|barber|plumber)\b/i.test(text);
    const isCreative = /\b(band|music band|fan club|creative project|game|podcast|gallery)\b/i.test(text);

    // Explicit Commerce Signals (Selling physical or merchandise products)
    const isCommerceSignal =
      /\b(store|shop|selling|sell|ecommerce|e-commerce|sneakers|shoes|hoodies|t-shirts|shirts|apparel|clothing brand|merch|merchandise|print on demand|print-on-demand|products for sale|buy online)\b/i.test(text);

    if (isPortfolio && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'PORTFOLIO',
        confidence: 0.95,
        reasoning: 'User requested a portfolio showcase without product sales.',
      };
    }

    if (isBlog && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'BLOG',
        confidence: 0.95,
        reasoning: 'User requested a content publication or blog platform.',
      };
    }

    if (isPersonal && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'PERSONAL',
        confidence: 0.9,
        reasoning: 'User requested a personal bio/profile website.',
      };
    }

    if (isEducation && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'EDUCATION',
        confidence: 0.9,
        reasoning: 'User requested an educational or institutional website.',
      };
    }

    if (isService && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'SERVICE',
        confidence: 0.9,
        reasoning: 'User requested a client service or agency business website.',
      };
    }

    if (isCreative && !isCommerceSignal) {
      return {
        isCommerce: false,
        siteType: 'CREATIVE',
        confidence: 0.85,
        reasoning: 'User requested a creative or media project site.',
      };
    }

    if (isCommerceSignal) {
      // Extract candidate product search query from prompt
      let detectedQuery = 'apparel';
      if (/sneakers|shoes/i.test(text)) detectedQuery = 'sneakers';
      else if (/hoodie|hoodies/i.test(text)) detectedQuery = 'hoodie';
      else if (/t-shirt|tshirts|tee|t-shirts/i.test(text)) detectedQuery = 't-shirt';
      else if (/mug|mugs|drinkware/i.test(text)) detectedQuery = 'mug';
      else if (/bag|backpack|tote/i.test(text)) detectedQuery = 'tote bag';
      else if (/hat|cap|beanie/i.test(text)) detectedQuery = 'cap';

      return {
        isCommerce: true,
        siteType: 'ECOMMERCE',
        confidence: 0.95,
        detectedProductQuery: detectedQuery,
        suggestedStyle: 'Modern / Premium',
        reasoning: 'Prompt explicitly requests an online store or selling physical merchandise.',
      };
    }

    // Default to general business if no special signals
    return {
      isCommerce: false,
      siteType: 'BUSINESS',
      confidence: 0.8,
      reasoning: 'Standard business informational website.',
    };
  }
}
