import { PrintifyBlueprint, PrintifySearchResult } from '../../types/commerce';

const PRINTIFY_BASE_URL = 'https://api.printify.com/v1';

/**
 * Server-Side Printify Catalog Service (Phase 7A)
 *
 * Connects directly to the official Printify v1 Catalog API.
 * The PRINTIFY_API_KEY is strictly server-side and never exposed to the client.
 * Does not simulate or manufacture fake products.
 */
export class PrintifyService {
  private static cachedBlueprints: { data: PrintifyBlueprint[]; fetchedAt: number } | null = null;
  private static readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minute cache to protect Printify rate limits (100 req/min)

  public static isConfigured(): boolean {
    const key = process.env.PRINTIFY_API_KEY;
    return typeof key === 'string' && key.trim().length > 0;
  }

  private static getApiKey(): string | null {
    const key = process.env.PRINTIFY_API_KEY;
    if (!key || key.trim() === '') {
      return null;
    }
    return key.trim();
  }

  private static getHeaders(apiKey: string): HeadersInit {
    return {
      Authorization: `Bearer ${apiKey}`,
      'User-Agent': 'StorePilot-AI-Engine/1.0',
      'Content-Type': 'application/json',
    };
  }

  /**
   * Search real Printify catalog blueprints based on merchant query terms.
   * If credentials are not configured, returns configured: false without fake data.
   */
  public static async searchCatalog(
    query: string,
    limit: number = 20
  ): Promise<PrintifySearchResult> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return {
        success: false,
        configured: false,
        query,
        totalFound: 0,
        products: [],
        error:
          'PRINTIFY_API_KEY is not configured on the server. Please add your Printify API key to the server environment.',
      };
    }

    const trimmedQuery = query.trim().toLowerCase();

    try {
      const allBlueprints = await this.fetchAllBlueprints(apiKey);

      if (!trimmedQuery) {
        return {
          success: true,
          configured: true,
          query,
          totalFound: allBlueprints.length,
          products: allBlueprints.slice(0, limit),
        };
      }

      const queryTokens = trimmedQuery.split(/\s+/).filter(Boolean);

      // Filter real catalog items by matching title, description, brand, or model
      const matched = allBlueprints.filter((bp) => {
        const target = `${bp.title} ${bp.description || ''} ${bp.brand || ''} ${bp.model || ''}`.toLowerCase();
        return queryTokens.every((token) => target.includes(token));
      });

      return {
        success: true,
        configured: true,
        query,
        totalFound: matched.length,
        products: matched.slice(0, limit),
      };
    } catch (err: any) {
      console.error('[PrintifyService] Catalog search failed:', err);
      return {
        success: false,
        configured: true,
        query,
        totalFound: 0,
        products: [],
        error: err?.message || 'Failed to search Printify catalog.',
      };
    }
  }

  /**
   * Fetch all real catalog blueprints from Printify API with caching
   */
  public static async fetchAllBlueprints(apiKey: string): Promise<PrintifyBlueprint[]> {
    const now = Date.now();
    if (this.cachedBlueprints && now - this.cachedBlueprints.fetchedAt < this.CACHE_TTL_MS) {
      return this.cachedBlueprints.data;
    }

    const url = `${PRINTIFY_BASE_URL}/catalog/blueprints.json`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders(apiKey),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          throw new Error('Invalid or unauthorized Printify API credentials.');
        }
        if (response.status === 429) {
          throw new Error('Printify catalog rate limit exceeded. Please wait a moment and try again.');
        }
        throw new Error(`Printify API returned HTTP status ${response.status}: ${response.statusText}`);
      }

      const rawList = await response.json();
      if (!Array.isArray(rawList)) {
        throw new Error('Unexpected response format from Printify catalog endpoint.');
      }

      const blueprints: PrintifyBlueprint[] = rawList.map((item: any) => ({
        id: Number(item.id),
        title: String(item.title || 'Untitled Product'),
        description: item.description ? String(item.description) : undefined,
        brand: item.brand ? String(item.brand) : undefined,
        model: item.model ? String(item.model) : undefined,
        images: Array.isArray(item.images)
          ? item.images
              .map((img: any) => (typeof img === 'string' ? img : img?.src || ''))
              .filter(Boolean)
          : [],
      }));

      this.cachedBlueprints = {
        data: blueprints,
        fetchedAt: now,
      };

      return blueprints;
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        throw new Error('Printify API request timed out after 12 seconds.');
      }
      throw err;
    }
  }

  /**
   * Fetch specific blueprint details from Printify API
   */
  public static async getBlueprintDetails(
    blueprintId: number
  ): Promise<{ success: boolean; configured: boolean; product?: PrintifyBlueprint; error?: string }> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      return {
        success: false,
        configured: false,
        error: 'PRINTIFY_API_KEY is not configured on the server.',
      };
    }

    if (!blueprintId || isNaN(blueprintId) || blueprintId <= 0) {
      return {
        success: false,
        configured: true,
        error: 'Invalid Printify blueprint ID.',
      };
    }

    const url = `${PRINTIFY_BASE_URL}/catalog/blueprints/${blueprintId}.json`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders(apiKey),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        if (response.status === 404) {
          return {
            success: false,
            configured: true,
            error: `Printify product with ID ${blueprintId} was not found in catalog.`,
          };
        }
        throw new Error(`Printify API error (${response.status}): ${response.statusText}`);
      }

      const item = await response.json();
      const product: PrintifyBlueprint = {
        id: Number(item.id),
        title: String(item.title || 'Untitled Product'),
        description: item.description ? String(item.description) : undefined,
        brand: item.brand ? String(item.brand) : undefined,
        model: item.model ? String(item.model) : undefined,
        images: Array.isArray(item.images)
          ? item.images
              .map((img: any) => (typeof img === 'string' ? img : img?.src || ''))
              .filter(Boolean)
          : [],
      };

      return {
        success: true,
        configured: true,
        product,
      };
    } catch (err: any) {
      clearTimeout(timeoutId);
      return {
        success: false,
        configured: true,
        error: err?.message || 'Failed to retrieve Printify product details.',
      };
    }
  }
}
