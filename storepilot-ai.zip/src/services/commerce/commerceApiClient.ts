import {
  CommerceIntentDetectionResult,
  PrintifySearchResult,
  PrintifyBlueprint,
  StorePilotProduct,
} from '../../types/commerce';
import { WebsiteSpec } from '../../types/websiteSpec';
import { AuthService } from '../auth/authService';

export class CommerceApiClient {
  private static async getAuthHeaders(): Promise<HeadersInit> {
    const token = await AuthService.getIdToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  /**
   * Detect whether a website prompt has e-commerce intent
   */
  public static async detectIntent(
    prompt: string,
    businessType?: string
  ): Promise<CommerceIntentDetectionResult> {
    try {
      const res = await fetch('/api/commerce/detect-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, businessType }),
      });
      if (!res.ok) {
        throw new Error(`Intent check failed (${res.status})`);
      }
      return await res.json();
    } catch (err: any) {
      console.warn('[CommerceApiClient] Fallback intent:', err);
      // Default to non-commerce safe fallback
      return {
        isCommerce: false,
        siteType: 'BUSINESS',
        confidence: 0.5,
        reasoning: 'Fallback classification due to connection error.',
      };
    }
  }

  /**
   * Search real Printify catalog blueprints via server proxy
   */
  public static async searchCatalog(
    query: string,
    limit: number = 20
  ): Promise<PrintifySearchResult> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/commerce/printify/search', {
      method: 'POST',
      headers,
      body: JSON.stringify({ query, limit }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      return {
        success: false,
        configured: errData.configured ?? true,
        query,
        totalFound: 0,
        products: [],
        error: errData.error || `Catalog search failed (${res.status})`,
      };
    }

    return await res.json();
  }

  /**
   * Get single blueprint details from Printify
   */
  public static async getProductDetails(
    id: number
  ): Promise<{ success: boolean; configured: boolean; product?: PrintifyBlueprint; error?: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/commerce/printify/product/${id}`, {
      method: 'GET',
      headers,
    });
    return await res.json();
  }

  /**
   * Retrieve approved products for a website
   */
  public static async getApprovedProducts(websiteId?: string): Promise<StorePilotProduct[]> {
    const url = websiteId ? `/api/commerce/products?websiteId=${encodeURIComponent(websiteId)}` : '/api/commerce/products';
    const headers = await this.getAuthHeaders();
    const res = await fetch(url, {
      method: 'GET',
      headers,
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.products || [];
  }

  /**
   * Explicitly approve selected products
   */
  public static async approveProducts(
    websiteId: string,
    products: Partial<StorePilotProduct>[]
  ): Promise<StorePilotProduct[]> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/commerce/products/approve', {
      method: 'POST',
      headers,
      body: JSON.stringify({ websiteId, products }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to approve products.');
    }
    const data = await res.json();
    return data.products || [];
  }

  /**
   * Update product storefront presentation
   */
  public static async updateProduct(
    productId: string,
    updates: Partial<StorePilotProduct>
  ): Promise<StorePilotProduct> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/commerce/products/${productId}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update product.');
    }
    const data = await res.json();
    return data.product;
  }

  /**
   * Delete an approved product
   */
  public static async deleteProduct(productId: string): Promise<boolean> {
    const headers = await this.getAuthHeaders();
    const res = await fetch(`/api/commerce/products/${productId}`, {
      method: 'DELETE',
      headers,
    });
    return res.ok;
  }

  /**
   * Generate complete e-commerce WebsiteSpec from approved products
   */
  public static async generateStore(params: {
    prompt: string;
    businessType?: string;
    approvedProducts: StorePilotProduct[];
    currency?: string;
    currencySymbol?: string;
  }): Promise<WebsiteSpec> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/commerce/generate-store', {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    });

    const data = await res.json();
    if (!res.ok || !data.success || !data.spec) {
      throw new Error(data.error || 'Failed to generate e-commerce store.');
    }
    return data.spec;
  }
}
