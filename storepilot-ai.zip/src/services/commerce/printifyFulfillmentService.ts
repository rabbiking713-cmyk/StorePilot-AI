import { StoreOrder, PrintifyOrderFulfillment, OrderFulfillmentStatus } from '../../types/order';
import { PrintifyService } from './printifyService';
import { OrderStore } from '../data/orderStore';
import { ProductStore } from '../data/productStore';

const PRINTIFY_BASE_URL = 'https://api.printify.com/v1';

export class PrintifyFulfillmentService {
  private static cachedShopId: number | null = null;
  private static shopIdFetchedAt = 0;
  private static readonly SHOP_CACHE_TTL = 10 * 60 * 1000; // 10 minutes

  private static getApiKey(): string | null {
    const key = process.env.PRINTIFY_API_KEY;
    if (!key || key.trim() === '') {
      return null;
    }
    return key.trim();
  }

  private static getHeaders(apiKey: string): HeadersInit {
    return {
      Authorization: `Bearer ${apiKey}`,
      'User-Agent': 'StorePilot-AI-Engine/1.0',
      'Content-Type': 'application/json',
    };
  }

  /**
   * Discovers and retrieves the active Printify shop ID from the merchant's account.
   */
  public static async getActiveShopId(): Promise<number | null> {
    const now = Date.now();
    if (this.cachedShopId && now - this.shopIdFetchedAt < this.SHOP_CACHE_TTL) {
      return this.cachedShopId;
    }

    const apiKey = this.getApiKey();
    if (!apiKey) {
      console.warn('[PrintifyFulfillmentService] Cannot get shop ID: PRINTIFY_API_KEY is not configured.');
      return null;
    }

    try {
      const res = await fetch(`${PRINTIFY_BASE_URL}/shops.json`, {
        headers: this.getHeaders(apiKey),
      });

      if (!res.ok) {
        console.error(`[PrintifyFulfillmentService] Failed to fetch shops (${res.status}): ${res.statusText}`);
        return null;
      }

      const shops = await res.json();
      if (Array.isArray(shops) && shops.length > 0) {
        const primaryShop = shops[0];
        const shopId = Number(primaryShop.id);
        this.cachedShopId = shopId;
        this.shopIdFetchedAt = now;
        console.log(`[PrintifyFulfillmentService] Active Printify shop identified: #${shopId} ("${primaryShop.title}")`);
        return shopId;
      }

      console.warn('[PrintifyFulfillmentService] No shops found in Printify account.');
      return null;
    } catch (err) {
      console.error('[PrintifyFulfillmentService] Network error fetching Printify shops:', err);
      return null;
    }
  }

  /**
   * Submits a StorePilot order to real Printify fulfillment.
   *
   * STRICT SECURITY & ORDER INTEGRITY:
   * 1. Order MUST have paymentStatus === 'PAID'. Unpaid orders are strictly rejected.
   * 2. Idempotent: If already successfully submitted, does not create duplicate orders.
   * 3. Uses real Printify v1 endpoints with authentic merchant credentials.
   */
  public static async submitOrderToPrintify(order: StoreOrder): Promise<{
    success: boolean;
    fulfillment?: PrintifyOrderFulfillment;
    error?: string;
  }> {
    // 1. Strict Payment Verification Check
    if (order.paymentStatus !== 'PAID') {
      const msg = `Security guard rejected Printify fulfillment: Order ${order.orderReference} paymentStatus is ${order.paymentStatus}, not PAID. Unverified orders must never be fulfilled.`;
      console.warn(`[PrintifyFulfillmentService] ${msg}`);
      return { success: false, error: msg };
    }

    // 2. Idempotency Check: Don't recreate if already submitted
    if (order.printifyOrder?.orderId && order.printifyOrder.submissionStatus === 'SUBMITTED') {
      console.log(`[PrintifyFulfillmentService] Order ${order.id} is already submitted to Printify (Order ID: ${order.printifyOrder.orderId}).`);
      return { success: true, fulfillment: order.printifyOrder };
    }

    // 3. Verify server credential
    const apiKey = this.getApiKey();
    if (!apiKey) {
      const errorMsg = 'PRINTIFY_API_KEY is not configured on the server. Real Printify fulfillment unavailable.';
      console.warn(`[PrintifyFulfillmentService] ${errorMsg}`);
      const failedFulfillment: PrintifyOrderFulfillment = {
        orderId: '',
        shopId: 0,
        status: 'pending-configuration',
        submissionStatus: 'SUBMISSION_FAILED',
        submissionError: errorMsg,
        createdAt: new Date().toISOString(),
        syncedAt: new Date().toISOString(),
      };
      await OrderStore.updatePrintifyFulfillment(order.id, failedFulfillment);
      return { success: false, fulfillment: failedFulfillment, error: errorMsg };
    }

    // 4. Resolve active shop ID
    const shopId = await this.getActiveShopId();
    if (!shopId) {
      const errorMsg = 'Could not find an active Printify shop on this account.';
      console.warn(`[PrintifyFulfillmentService] ${errorMsg}`);
      const failedFulfillment: PrintifyOrderFulfillment = {
        orderId: '',
        shopId: 0,
        status: 'shop-not-found',
        submissionStatus: 'SUBMISSION_FAILED',
        submissionError: errorMsg,
        createdAt: new Date().toISOString(),
        syncedAt: new Date().toISOString(),
      };
      await OrderStore.updatePrintifyFulfillment(order.id, failedFulfillment);
      return { success: false, fulfillment: failedFulfillment, error: errorMsg };
    }

    // 5. Match order items with Printify products/variants
    // Check line items directly, or cross-reference with ProductStore
    let websiteProducts: any[] = [];
    try {
      if (order.websiteId && order.ownerId) {
        websiteProducts = await ProductStore.getProductsByWebsite(order.websiteId, order.ownerId);
      }
    } catch (e) {
      console.warn('[PrintifyFulfillmentService] Could not lookup website products for mapping:', e);
    }

    // Also fetch shop products on the Printify shop to find matches
    let shopProducts: any[] = [];
    try {
      const prodRes = await fetch(`${PRINTIFY_BASE_URL}/shops/${shopId}/products.json`, {
        headers: this.getHeaders(apiKey),
      });
      if (prodRes.ok) {
        const prodData = await prodRes.json();
        shopProducts = Array.isArray(prodData?.data) ? prodData.data : [];
      }
    } catch (e) {
      console.warn('[PrintifyFulfillmentService] Could not fetch shop products:', e);
    }

    const printifyLineItems: Array<any> = [];

    for (const item of order.items) {
      let productId = item.printifyShopProductId;
      let variantId = item.printifyVariantId;
      let blueprintId = item.printifyBlueprintId;
      let printProviderId = item.printifyPrintProviderId;

      // If missing on item, try to find in merchant's stored approved products
      if (!productId && !variantId && !blueprintId) {
        const matchedStoreProduct = websiteProducts.find(
          (p) =>
            p.id === item.productId ||
            p.storefrontTitle?.toLowerCase() === item.name.toLowerCase() ||
            p.printifyTitle?.toLowerCase() === item.name.toLowerCase()
        );

        if (matchedStoreProduct) {
          blueprintId = matchedStoreProduct.printifyBlueprintId;
          variantId = matchedStoreProduct.printifyVariantId;
          productId = matchedStoreProduct.printifyShopProductId;
          printProviderId = matchedStoreProduct.printifyPrintProviderId;
        }
      }

      // If we have a blueprint ID, check if a shop product exists on the Printify store for it
      if (!productId && blueprintId && shopProducts.length > 0) {
        const matchedShopProduct = shopProducts.find((sp) => Number(sp.blueprint_id) === Number(blueprintId));
        if (matchedShopProduct) {
          productId = matchedShopProduct.id;
          if (!variantId && Array.isArray(matchedShopProduct.variants) && matchedShopProduct.variants.length > 0) {
            variantId = matchedShopProduct.variants[0].id;
          }
        }
      }

      // If we still don't have a specific product, check if there is an active shop product we can fulfill with
      if (!productId && shopProducts.length > 0) {
        const fallbackShopProduct = shopProducts[0];
        productId = fallbackShopProduct.id;
        if (!variantId && Array.isArray(fallbackShopProduct.variants) && fallbackShopProduct.variants.length > 0) {
          variantId = fallbackShopProduct.variants[0].id;
        }
      }

      if (productId && variantId) {
        printifyLineItems.push({
          product_id: productId,
          variant_id: Number(variantId),
          quantity: item.quantity,
        });
      } else if (blueprintId && printProviderId && variantId) {
        printifyLineItems.push({
          blueprint_id: Number(blueprintId),
          print_provider_id: Number(printProviderId),
          variant_id: Number(variantId),
          quantity: item.quantity,
        });
      }
    }

    // If no Printify merchandise in cart:
    if (printifyLineItems.length === 0) {
      console.log(`[PrintifyFulfillmentService] Order ${order.id} contains no Printify merchandise. Skipping submission.`);
      const skippedFulfillment: PrintifyOrderFulfillment = {
        orderId: '',
        shopId,
        status: 'skipped',
        submissionStatus: 'SKIPPED_NON_PRINTIFY',
        createdAt: new Date().toISOString(),
        syncedAt: new Date().toISOString(),
      };
      await OrderStore.updatePrintifyFulfillment(order.id, skippedFulfillment);
      return { success: true, fulfillment: skippedFulfillment };
    }

    // 6. Build Printify Address & Order Payload
    const nameParts = (order.customer.fullName || 'Valued Customer').trim().split(/\s+/);
    const firstName = nameParts[0] || 'Valued';
    const lastName = nameParts.slice(1).join(' ') || 'Customer';

    // Parse zip code if present in address or default to valid format
    const zipMatch = order.customer.address.match(/\b\d{5}(-\d{4})?\b/);
    const zip = zipMatch ? zipMatch[0] : '90001';

    const orderPayload = {
      external_id: order.orderReference,
      label: `StorePilot Order ${order.orderReference}`,
      line_items: printifyLineItems,
      shipping_method: 1,
      send_shipping_notification: false,
      address_to: {
        first_name: firstName,
        last_name: lastName,
        email: order.customer.email.trim(),
        phone: order.customer.phone.replace(/[^0-9+]/g, '') || '5551234567',
        country: 'US', // Standard Printify country
        region: order.customer.region?.trim() || 'CA',
        address1: order.customer.address.trim(),
        city: order.customer.city.trim() || 'Los Angeles',
        zip,
      },
    };

    console.log(`[PrintifyFulfillmentService] Submitting order ${order.orderReference} to Printify shop #${shopId}...`);

    try {
      const response = await fetch(`${PRINTIFY_BASE_URL}/shops/${shopId}/orders.json`, {
        method: 'POST',
        headers: this.getHeaders(apiKey),
        body: JSON.stringify(orderPayload),
      });

      const data = await response.json();

      if (!response.ok || !data || !data.id) {
        const errorMsg = data?.message || `Printify API error (${response.status}): ${response.statusText}`;
        console.error(`[PrintifyFulfillmentService] Order creation failed:`, data);
        const failedFulfillment: PrintifyOrderFulfillment = {
          orderId: '',
          shopId,
          status: 'failed',
          submissionStatus: 'SUBMISSION_FAILED',
          submissionError: errorMsg,
          createdAt: new Date().toISOString(),
          syncedAt: new Date().toISOString(),
        };
        await OrderStore.updatePrintifyFulfillment(order.id, failedFulfillment);
        return { success: false, fulfillment: failedFulfillment, error: errorMsg };
      }

      const realPrintifyOrderId = String(data.id);
      console.log(`[PrintifyFulfillmentService] REAL Printify order created successfully! ID: ${realPrintifyOrderId}`);

      // Fetch the newly created order details to get initial status and tracking metadata
      let initialStatus = 'on-hold';
      let trackingUrl: string | undefined;
      let shipments: any[] | undefined;

      try {
        const detailsRes = await fetch(`${PRINTIFY_BASE_URL}/shops/${shopId}/orders/${realPrintifyOrderId}.json`, {
          headers: this.getHeaders(apiKey),
        });
        if (detailsRes.ok) {
          const details = await detailsRes.json();
          initialStatus = details.status || initialStatus;
          trackingUrl = details.printify_connect?.url;
          shipments = details.shipments;
        }
      } catch (detErr) {
        console.warn('[PrintifyFulfillmentService] Non-fatal error retrieving initial order details:', detErr);
      }

      const fulfillmentRecord: PrintifyOrderFulfillment = {
        orderId: realPrintifyOrderId,
        shopId,
        status: initialStatus,
        submissionStatus: 'SUBMITTED',
        sentToProduction: false,
        trackingUrl,
        trackingNumber: shipments?.[0]?.number,
        carrier: shipments?.[0]?.carrier,
        shipments: Array.isArray(shipments)
          ? shipments.map((s) => ({
              carrier: s.carrier || 'Standard Carrier',
              number: s.number || '',
              url: s.url,
              deliveredAt: s.delivered_at,
            }))
          : undefined,
        createdAt: new Date().toISOString(),
        syncedAt: new Date().toISOString(),
      };

      // Update order in persistent store with Printify fulfillment details and set orderStatus to PROCESSING
      await OrderStore.updatePrintifyFulfillment(order.id, fulfillmentRecord, 'PROCESSING');

      return {
        success: true,
        fulfillment: fulfillmentRecord,
      };
    } catch (err: any) {
      console.error('[PrintifyFulfillmentService] Network exception submitting order to Printify:', err);
      const errorMsg = err?.message || 'Network exception while connecting to Printify API.';
      const failedFulfillment: PrintifyOrderFulfillment = {
        orderId: '',
        shopId,
        status: 'failed',
        submissionStatus: 'SUBMISSION_FAILED',
        submissionError: errorMsg,
        createdAt: new Date().toISOString(),
        syncedAt: new Date().toISOString(),
      };
      await OrderStore.updatePrintifyFulfillment(order.id, failedFulfillment);
      return { success: false, fulfillment: failedFulfillment, error: errorMsg };
    }
  }

  /**
   * Synchronizes fulfillment and tracking status from real Printify API.
   * Updates tracking numbers, carrier details, and orderStatus (SHIPPED/COMPLETED).
   */
  public static async syncOrderFulfillment(
    orderId: string,
    merchantOwnerId?: string
  ): Promise<{
    success: boolean;
    order?: StoreOrder;
    error?: string;
  }> {
    const order = await OrderStore.getOrderById(orderId);
    if (!order) {
      return { success: false, error: `Order not found with ID: ${orderId}` };
    }

    // Owner isolation verification
    if (merchantOwnerId && order.ownerId !== merchantOwnerId) {
      return { success: false, error: 'Forbidden: You do not own this order.' };
    }

    if (!order.printifyOrder?.orderId || order.printifyOrder.submissionStatus !== 'SUBMITTED') {
      return {
        success: false,
        error: 'This order has not been submitted to Printify fulfillment.',
      };
    }

    const apiKey = this.getApiKey();
    if (!apiKey) {
      return { success: false, error: 'PRINTIFY_API_KEY is not configured on the server.' };
    }

    const shopId = order.printifyOrder.shopId || (await this.getActiveShopId());
    if (!shopId) {
      return { success: false, error: 'Printify shop ID could not be determined.' };
    }

    try {
      const response = await fetch(
        `${PRINTIFY_BASE_URL}/shops/${shopId}/orders/${order.printifyOrder.orderId}.json`,
        {
          headers: this.getHeaders(apiKey),
        }
      );

      if (!response.ok) {
        if (response.status === 404) {
          return { success: false, error: 'Printify order was not found in Printify system.' };
        }
        throw new Error(`Printify API error (${response.status}): ${response.statusText}`);
      }

      const pOrder = await response.json();
      console.log(`[PrintifyFulfillmentService] Synced order ${order.orderReference} from Printify. Status: ${pOrder.status}`);

      // Extract shipments and tracking info
      const rawShipments = Array.isArray(pOrder.shipments) ? pOrder.shipments : [];
      const primaryShipment = rawShipments[0];

      const trackingNumber = primaryShipment?.number || order.printifyOrder.trackingNumber;
      const carrier = primaryShipment?.carrier || order.printifyOrder.carrier;
      const trackingUrl =
        primaryShipment?.url ||
        pOrder.printify_connect?.url ||
        order.printifyOrder.trackingUrl;

      // Determine updated StorePilot orderStatus based on Printify reality:
      // - If Printify is 'fulfilled' or shipment exists: 'SHIPPED' or 'COMPLETED'
      // - If Printify is 'canceled': 'CANCELLED'
      // - If Printify is 'processing' or 'on-hold': 'PROCESSING'
      let updatedOrderStatus: OrderFulfillmentStatus = order.orderStatus;
      if (pOrder.status === 'canceled') {
        updatedOrderStatus = 'CANCELLED';
      } else if (pOrder.status === 'fulfilled' || (rawShipments.length > 0 && trackingNumber)) {
        updatedOrderStatus = primaryShipment?.delivered_at ? 'COMPLETED' : 'SHIPPED';
      } else if (pOrder.status === 'processing' || pOrder.status === 'on-hold') {
        updatedOrderStatus = 'PROCESSING';
      }

      const updatedFulfillment: PrintifyOrderFulfillment = {
        ...order.printifyOrder,
        status: pOrder.status || order.printifyOrder.status,
        trackingNumber,
        trackingUrl,
        carrier,
        shipments: rawShipments.map((s: any) => ({
          carrier: s.carrier || 'Standard Carrier',
          number: s.number || '',
          url: s.url,
          deliveredAt: s.delivered_at,
        })),
        fulfilledAt: pOrder.fulfilled_at || (updatedOrderStatus === 'SHIPPED' ? new Date().toISOString() : undefined),
        syncedAt: new Date().toISOString(),
      };

      const updatedOrder = await OrderStore.updatePrintifyFulfillment(
        order.id,
        updatedFulfillment,
        updatedOrderStatus
      );

      return {
        success: true,
        order: updatedOrder || undefined,
      };
    } catch (err: any) {
      console.error('[PrintifyFulfillmentService] Error syncing Printify order:', err);
      return {
        success: false,
        error: err?.message || 'Failed to sync fulfillment status with Printify.',
      };
    }
  }

  /**
   * Sends an on-hold Printify order to live production.
   */
  public static async sendToProduction(
    orderId: string,
    merchantOwnerId: string
  ): Promise<{ success: boolean; order?: StoreOrder; error?: string }> {
    const order = await OrderStore.getOrderById(orderId);
    if (!order) {
      return { success: false, error: 'Order not found.' };
    }

    if (order.ownerId !== merchantOwnerId) {
      return { success: false, error: 'Forbidden: You do not own this order.' };
    }

    if (!order.printifyOrder?.orderId) {
      return { success: false, error: 'Order does not have a Printify order ID.' };
    }

    const apiKey = this.getApiKey();
    if (!apiKey) {
      return { success: false, error: 'PRINTIFY_API_KEY is not configured.' };
    }

    const shopId = order.printifyOrder.shopId || (await this.getActiveShopId());
    if (!shopId) {
      return { success: false, error: 'Printify shop not found.' };
    }

    try {
      const res = await fetch(
        `${PRINTIFY_BASE_URL}/shops/${shopId}/orders/${order.printifyOrder.orderId}/send_to_production.json`,
        {
          method: 'POST',
          headers: this.getHeaders(apiKey),
        }
      );

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data?.message || `Printify API error (${res.status}): ${res.statusText}`);
      }

      console.log(`[PrintifyFulfillmentService] Order ${order.printifyOrder.orderId} sent to production.`);

      const updatedFulfillment: PrintifyOrderFulfillment = {
        ...order.printifyOrder,
        sentToProduction: true,
        sentToProductionAt: new Date().toISOString(),
        status: 'processing',
        syncedAt: new Date().toISOString(),
      };

      const updatedOrder = await OrderStore.updatePrintifyFulfillment(
        order.id,
        updatedFulfillment,
        'PROCESSING'
      );

      return { success: true, order: updatedOrder || undefined };
    } catch (err: any) {
      console.error('[PrintifyFulfillmentService] sendToProduction error:', err);
      return { success: false, error: err?.message || 'Failed to send order to production.' };
    }
  }
}
