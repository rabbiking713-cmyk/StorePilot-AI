import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../../firebase-applet-config.json';

export interface FirebaseConnectionDetails {
  isConfigured: boolean;
  projectId?: string;
  authDomain?: string;
  storageBucket?: string;
  firestoreDatabaseId?: string;
  missingKeys: string[];
}

const isConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);

export const firebaseConfigState: FirebaseConnectionDetails = {
  isConfigured,
  projectId: firebaseConfig.projectId,
  authDomain: firebaseConfig.authDomain,
  storageBucket: firebaseConfig.storageBucket,
  firestoreDatabaseId: firebaseConfig.firestoreDatabaseId,
  missingKeys: isConfigured ? [] : ['apiKey', 'projectId'],
};

const app: FirebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth: Auth = getAuth(app);
export const db: Firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export const getFirebaseApp = (): FirebaseApp => app;
export const getFirebaseAuth = (): Auth => auth;
export const getFirebaseDb = (): Firestore => db;

// Connection test on boot as mandated by Firebase skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

if (typeof window !== 'undefined') {
  testConnection().catch(() => {});
}
