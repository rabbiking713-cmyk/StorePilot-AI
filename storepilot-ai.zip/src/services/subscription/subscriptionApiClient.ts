import { authenticatedFetch } from '../auth/apiClient';
import {
  SubscriptionStatusResponse,
  SubscriptionCheckoutResponse,
  SubscriptionPlan,
} from '../../types/subscription';

export class SubscriptionApiClient {
  /**
   * Fetch current user's authoritative subscription status from server
   */
  public static async getStatus(): Promise<SubscriptionStatusResponse> {
    try {
      const res = await authenticatedFetch('/api/subscription/status');
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          plan: 'starter',
          subscriptionStatus: 'active',
          isDeveloper: false,
          paystackConfigured: false,
          websiteLimit: 1,
          error: data.error || 'Failed to retrieve subscription status.',
        };
      }
      return data;
    } catch (err: any) {
      console.error('[SubscriptionApiClient] getStatus error:', err);
      return {
        success: false,
        plan: 'starter',
        subscriptionStatus: 'active',
        isDeveloper: false,
        paystackConfigured: false,
        websiteLimit: 1,
        error: err.message || 'Network error retrieving subscription status.',
      };
    }
  }

  /**
   * Initialize Paystack checkout session for a plan upgrade
   */
  public static async initializeCheckout(
    plan: SubscriptionPlan,
    callbackUrl?: string
  ): Promise<SubscriptionCheckoutResponse> {
    try {
      const res = await authenticatedFetch('/api/subscription/initialize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          plan,
          callbackUrl,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || 'Failed to initialize subscription checkout.',
        };
      }

      return data;
    } catch (err: any) {
      console.error('[SubscriptionApiClient] initializeCheckout error:', err);
      return {
        success: false,
        error: err.message || 'Network error initiating subscription checkout.',
      };
    }
  }

  /**
   * Verify completed payment reference server-side
   */
  public static async verifyPayment(
    reference: string
  ): Promise<{ success: boolean; plan?: SubscriptionPlan; error?: string }> {
    try {
      const res = await authenticatedFetch(`/api/subscription/verify/${encodeURIComponent(reference)}`);
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || 'Payment verification failed.',
        };
      }
      return data;
    } catch (err: any) {
      console.error('[SubscriptionApiClient] verifyPayment error:', err);
      return {
        success: false,
        error: err.message || 'Network error verifying payment.',
      };
    }
  }

  /**
   * Cancel active paid subscription
   */
  public static async cancelSubscription(): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await authenticatedFetch('/api/subscription/cancel', {
        method: 'POST',
      });
      const data = await res.json();
      return data;
    } catch (err: any) {
      return {
        success: false,
        error: err.message || 'Network error cancelling subscription.',
      };
    }
  }
}
