import crypto from 'crypto';
import { SubscriptionPlan, STOREPILOT_PLANS } from '../../types/subscription';
import { SubscriptionStore } from '../data/subscriptionStore';

const PAYSTACK_API_BASE = 'https://api.paystack.co';

export class PaystackSubscriptionService {
  /**
   * Helper to retrieve Paystack secret key from server environment
   */
  public static getSecretKey(): string | null {
    const key = process.env.PAYSTACK_SECRET_KEY?.trim();
    if (!key || key === 'sk_test_...' || key === 'sk_live_...') {
      return null;
    }
    return key;
  }

  public static isPaystackConfigured(): boolean {
    return Boolean(this.getSecretKey());
  }

  /**
   * Verifies incoming webhook HMAC SHA-512 signature using PAYSTACK_SECRET_KEY
   */
  public static verifyWebhookSignature(rawBody: string, signature?: string): boolean {
    const secret = this.getSecretKey();
    if (!secret || !signature) {
      return false;
    }
    try {
      const hash = crypto.createHmac('sha512', secret).update(rawBody).digest('hex');
      return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(signature));
    } catch (err) {
      console.warn('[PaystackSubscriptionService] Signature verification exception:', err);
      return false;
    }
  }

  /**
   * Authoritative price in USD subunits (cents).
   * Professional: $29/mo = 2900 cents
   * Agency: $79/mo = 7900 cents
   */
  public static getAuthoritativeAmount(plan: SubscriptionPlan): number {
    switch (plan) {
      case 'professional':
        return 2900;
      case 'agency':
        return 7900;
      default:
        throw new Error(`Plan ${plan} does not require a paid subscription.`);
    }
  }

  /**
   * Initializes a Paystack checkout transaction for recurring StorePilot SaaS subscription.
   */
  public static async initializeCheckout(
    userId: string,
    email: string,
    plan: SubscriptionPlan,
    callbackUrl?: string
  ): Promise<{
    success: boolean;
    authorizationUrl?: string;
    reference?: string;
    accessCode?: string;
    error?: string;
    paystackConfigured: boolean;
  }> {
    // 1. Check developer exemption
    if (SubscriptionStore.isDeveloperAccount(email, userId)) {
      return {
        success: false,
        paystackConfigured: this.isPaystackConfigured(),
        error: 'Developer accounts have internal testing access (Agency Tier) and do not require Paystack billing.',
      };
    }

    // 2. Validate plan
    if (plan !== 'professional' && plan !== 'agency') {
      return {
        success: false,
        paystackConfigured: this.isPaystackConfigured(),
        error: 'Invalid plan selected. Only Professional ($29/mo) and Agency ($79/mo) can be subscribed.',
      };
    }

    const secretKey = this.getSecretKey();
    if (!secretKey) {
      return {
        success: false,
        paystackConfigured: false,
        error:
          'Paystack payment gateway is not configured on the server. Please set the PAYSTACK_SECRET_KEY environment secret.',
      };
    }

    const amountInSubunits = this.getAuthoritativeAmount(plan);
    const reference = `sub_${plan}_${userId.slice(0, 8)}_${Date.now()}`;

    try {
      const payload = {
        email,
        amount: amountInSubunits,
        currency: 'USD',
        reference,
        callback_url: callbackUrl,
        metadata: {
          userId,
          email,
          plan,
          type: 'storepilot_saas_subscription',
          planName: STOREPILOT_PLANS[plan].name,
          priceUsd: STOREPILOT_PLANS[plan].priceUsd,
          initiatedAt: new Date().toISOString(),
        },
      };

      const response = await fetch(`${PAYSTACK_API_BASE}/transaction/initialize`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok || !data.status) {
        return {
          success: false,
          paystackConfigured: true,
          error: data.message || 'Failed to initialize Paystack subscription checkout.',
        };
      }

      return {
        success: true,
        paystackConfigured: true,
        authorizationUrl: data.data.authorization_url,
        reference: data.data.reference,
        accessCode: data.data.access_code,
      };
    } catch (err: any) {
      console.error('[PaystackSubscriptionService] Checkout initialization error:', err);
      return {
        success: false,
        paystackConfigured: true,
        error: err.message || 'Network error communicating with Paystack.',
      };
    }
  }

  /**
   * Verifies initial subscription transaction reference with Paystack API.
   * Activates subscription in Firestore upon authoritative verification.
   */
  public static async verifyPayment(
    reference: string,
    expectedUserId: string
  ): Promise<{
    success: boolean;
    plan?: SubscriptionPlan;
    status?: string;
    currentPeriodEnd?: string;
    error?: string;
  }> {
    const secretKey = this.getSecretKey();
    if (!secretKey) {
      return {
        success: false,
        error: 'Paystack is not configured on the server.',
      };
    }

    try {
      const response = await fetch(
        `${PAYSTACK_API_BASE}/transaction/verify/${encodeURIComponent(reference)}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${secretKey}`,
          },
        }
      );

      const json = await response.json();

      if (!response.ok || !json.status || !json.data) {
        return {
          success: false,
          error: json.message || 'Payment verification failed with Paystack.',
        };
      }

      const tx = json.data;

      // 1. Verify status is success
      if (tx.status !== 'success') {
        return {
          success: false,
          error: `Transaction has not succeeded. Current status: ${tx.status}`,
        };
      }

      // 2. Verify metadata association
      const metadata = tx.metadata || {};
      if (metadata.type !== 'storepilot_saas_subscription') {
        return {
          success: false,
          error: 'Invalid transaction type: This transaction is not a StorePilot SaaS subscription.',
        };
      }

      if (metadata.userId !== expectedUserId) {
        return {
          success: false,
          error: 'Transaction user mismatch: This payment does not belong to your account.',
        };
      }

      const plan: SubscriptionPlan = metadata.plan;
      if (plan !== 'professional' && plan !== 'agency') {
        return {
          success: false,
          error: 'Invalid plan associated with transaction.',
        };
      }

      // 3. Verify amount strictly
      const expectedAmount = this.getAuthoritativeAmount(plan);
      if (tx.amount < expectedAmount) {
        return {
          success: false,
          error: `Amount paid (${tx.amount}) is less than required plan price (${expectedAmount}).`,
        };
      }

      // 4. Calculate period (30 days)
      const now = new Date();
      const periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

      // 5. Update subscription state in Firestore
      const updated = await SubscriptionStore.updateSubscription(expectedUserId, {
        plan,
        subscriptionStatus: 'active',
        paystackCustomerCode: tx.customer?.customer_code,
        paystackSubscriptionCode: tx.reference,
        currentPeriodStart: now.toISOString(),
        currentPeriodEnd: periodEnd.toISOString(),
      });

      console.log(`[PaystackSubscriptionService] User ${expectedUserId} successfully activated plan: ${plan}`);

      return {
        success: true,
        plan: updated.plan,
        status: updated.subscriptionStatus,
        currentPeriodEnd: updated.currentPeriodEnd,
      };
    } catch (err: any) {
      console.error('[PaystackSubscriptionService] Verification exception:', err);
      return {
        success: false,
        error: err.message || 'Payment verification failed.',
      };
    }
  }

  /**
   * Handles incoming Paystack webhook events to synchronize subscription state
   */
  public static async handleWebhookEvent(
    event: any
  ): Promise<{ handled: boolean; message: string }> {
    const eventType = event?.event;
    const data = event?.data;

    if (!eventType || !data) {
      return { handled: false, message: 'Invalid webhook payload structure' };
    }

    // Only process events related to StorePilot SaaS subscriptions
    const metadata = data.metadata || {};
    if (metadata.type !== 'storepilot_saas_subscription') {
      return { handled: false, message: 'Event is not a StorePilot SaaS subscription' };
    }

    const userId = metadata.userId;
    const plan: SubscriptionPlan = metadata.plan;

    if (!userId || !plan) {
      return { handled: false, message: 'Missing userId or plan in metadata' };
    }

    console.log(`[PaystackSubscriptionWebhook] Processing ${eventType} for user ${userId}, plan ${plan}`);

    switch (eventType) {
      case 'charge.success': {
        const expectedAmount = this.getAuthoritativeAmount(plan);
        if (data.amount >= expectedAmount) {
          const now = new Date();
          const periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

          await SubscriptionStore.updateSubscription(userId, {
            plan,
            subscriptionStatus: 'active',
            paystackCustomerCode: data.customer?.customer_code,
            paystackSubscriptionCode: data.reference,
            currentPeriodStart: now.toISOString(),
            currentPeriodEnd: periodEnd.toISOString(),
          });

          return { handled: true, message: `Subscription activated/renewed for user ${userId}` };
        }
        return { handled: false, message: 'Charge amount mismatch' };
      }

      case 'invoice.payment_failed': {
        await SubscriptionStore.updateSubscription(userId, {
          subscriptionStatus: 'past_due',
        });
        return { handled: true, message: `Marked subscription past_due for user ${userId}` };
      }

      case 'subscription.disable':
      case 'subscription.not_renew': {
        await SubscriptionStore.updateSubscription(userId, {
          subscriptionStatus: 'cancelled',
        });
        return { handled: true, message: `Subscription cancelled for user ${userId}` };
      }

      case 'subscription.expiring_cards': {
        console.warn(`[PaystackSubscriptionWebhook] Customer card expiring for user ${userId}`);
        return { handled: true, message: `Card expiring notification logged for user ${userId}` };
      }

      default:
        return { handled: true, message: `Event ${eventType} received and acknowledged` };
    }
  }

  /**
   * User requests subscription cancellation. Sets status to 'cancelled'.
   * Data is preserved (websites, products, orders remain intact).
   */
  public static async cancelSubscription(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      await SubscriptionStore.cancelSubscription(userId);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to cancel subscription.' };
    }
  }
}
