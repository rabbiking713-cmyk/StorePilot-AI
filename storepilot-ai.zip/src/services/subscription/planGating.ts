import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from '../auth/serverAuth';
import { SubscriptionStore } from '../data/subscriptionStore';
import { SubscriptionPlan } from '../../types/subscription';

/**
 * Express middleware to enforce authoritative server-side plan gating.
 *
 * Verifies:
 * 1. User is authenticated (req.user exists)
 * 2. Checks developer exemption for the 3 official testing accounts
 * 3. Fetches user's subscription record from SubscriptionStore
 * 4. Checks that subscription is 'active'
 * 5. Checks required plan tier (professional vs agency)
 *
 * Rejects unauthorized users with 403 Forbidden.
 */
export function requirePlan(minPlan: 'professional' | 'agency') {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user || !req.user.uid) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: Authentication required.',
        });
      }

      const { uid, email } = req.user;

      // 1. Developer Exemption Check (Enforced Server-Side)
      if (SubscriptionStore.isDeveloperAccount(email, uid)) {
        // Register UID for future lookups
        if (email) {
          SubscriptionStore.registerDeveloperUid(uid, email);
        }
        return next();
      }

      // 2. Fetch Authoritative Subscription Record
      const subscription = await SubscriptionStore.getSubscription(uid, email);

      // 3. Active Subscription Status Check
      if (subscription.subscriptionStatus !== 'active') {
        const requiredPlanName = minPlan === 'agency' ? 'Agency / Studio' : 'Professional or Agency';
        return res.status(403).json({
          success: false,
          error: `An active ${requiredPlanName} subscription is required.`,
          code: 'SUBSCRIPTION_REQUIRED',
          requiredPlan: minPlan,
          currentPlan: subscription.plan,
          currentStatus: subscription.subscriptionStatus,
        });
      }

      // 4. Plan Hierarchy Check
      // Starter = 0, Professional = 1, Agency = 2
      const PLAN_RANKS: Record<SubscriptionPlan, number> = {
        starter: 0,
        professional: 1,
        agency: 2,
      };

      const userRank = PLAN_RANKS[subscription.plan] ?? 0;
      const requiredRank = PLAN_RANKS[minPlan] ?? 1;

      if (userRank < requiredRank) {
        const requiredPlanName = minPlan === 'agency' ? 'Agency / Studio' : 'Professional';
        return res.status(403).json({
          success: false,
          error: `An active ${requiredPlanName} subscription is required.`,
          code: 'PLAN_UPGRADE_REQUIRED',
          requiredPlan: minPlan,
          currentPlan: subscription.plan,
        });
      }

      // User has verified access
      next();
    } catch (err: any) {
      console.error('[PlanGating] Error checking plan:', err);
      return res.status(500).json({
        success: false,
        error: 'Failed to verify subscription permissions.',
      });
    }
  };
}

/**
 * Middleware to check website count limits based on current subscription plan:
 * Starter: 1 website
 * Professional: 5 websites
 * Agency / Developer: Unlimited
 */
export async function checkWebsiteCreationLimit(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  try {
    if (!req.user || !req.user.uid) {
      return res.status(401).json({
        success: false,
        error: 'Unauthorized: Authentication required.',
      });
    }

    const { uid, email } = req.user;
    const check = await SubscriptionStore.canCreateWebsite(uid, email);

    if (!check.allowed) {
      return res.status(403).json({
        success: false,
        error: check.reason || 'Website limit reached for your current plan.',
        code: 'WEBSITE_LIMIT_REACHED',
        limit: check.limit,
        current: check.current,
        plan: check.plan,
      });
    }

    next();
  } catch (err: any) {
    console.error('[PlanGating] Error checking website creation limit:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to verify website creation limit.',
    });
  }
}
