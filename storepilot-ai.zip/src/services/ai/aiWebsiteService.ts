import { WebsiteSpec } from '../../types/websiteSpec';
import { authenticatedFetch } from '../auth/apiClient';

export interface AiStatusResult {
  configured: boolean;
  model: string;
  provider: string;
}

export interface GenerateWebsiteResponse {
  success: boolean;
  spec?: WebsiteSpec;
  error?: string;
  model?: string;
}

export const EXAMPLE_PROMPTS = [
  {
    title: 'Teen Clothing Store (Ghana)',
    prompt:
      'Build me a modern online clothing store for teenagers in Ghana. Use a clean premium design, showcase hoodies, sneakers and T-shirts, and include a homepage, products section, about section and contact section.',
    category: 'Retail & Fashion',
  },
  {
    title: 'Artisanal Ceramic Studio',
    prompt:
      'An artisanal ceramic studio and craft pottery shop in Portland called "Clay & Kin". Warm organic minimalism, showcasing handmade mugs, vases, and weekend pottery workshops.',
    category: 'Artisanal & Crafts',
  },
  {
    title: 'SaaS Analytics Platform',
    prompt:
      'A sleek B2B SaaS platform called "MetricsPulse" offering real-time financial analytics, churn monitoring, and revenue forecasting for modern ecommerce founders.',
    category: 'Technology & SaaS',
  },
  {
    title: 'Nordic Specialty Coffee Roastery',
    prompt:
      'A specialty coffee bar and micro-roastery in Copenhagen called "Nordic Roast", featuring single-origin beans, breakfast cafe menu, barista workshops, and beans delivery.',
    category: 'Dining & Specialty Food',
  },
];

export const QUICK_REFINEMENT_PROMPTS = [
  'Make it more modern and minimalist',
  'Use a luxury and high-end editorial style',
  'Make the colors more vibrant and energetic',
  'Make the homepage and copy punchier and shorter',
  'Add a prominent customer reviews and social proof section',
  'Add a detailed services and pricing tier section',
];

export class AiWebsiteService {
  /**
   * Check status of Gemini configuration on the backend
   */
  public static async getStatus(): Promise<AiStatusResult> {
    try {
      const response = await fetch('/api/ai-status');
      if (!response.ok) {
        throw new Error(`Status check returned ${response.status}`);
      }
      return await response.json();
    } catch {
      return {
        configured: false,
        model: 'gemini-3.8-flash',
        provider: 'Google AI Studio / Gemini API',
      };
    }
  }

  /**
   * Generate a structured website specification from natural language prompt
   */
  public static async generateWebsite(
    prompt: string,
    businessType?: string
  ): Promise<WebsiteSpec> {
    const trimmed = prompt.trim();
    if (!trimmed) {
      throw new Error('Please enter a description for the website you want to generate.');
    }

    const response = await authenticatedFetch('/api/generate-website', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: trimmed,
        businessType,
      }),
    });

    const data: GenerateWebsiteResponse = await response.json();

    if (!response.ok || !data.success || !data.spec) {
      const errorMessage =
        data.error ||
        (response.status === 503
          ? 'GEMINI_API_KEY is not configured in the server environment. Please set GEMINI_API_KEY in the AI Studio Secrets panel.'
          : 'Failed to generate website specification with Gemini.');
      throw new Error(errorMessage);
    }

    return data.spec;
  }

  /**
   * Refine an existing website specification using natural language feedback
   */
  public static async refineWebsite(
    currentSpec: WebsiteSpec,
    refinementPrompt: string
  ): Promise<WebsiteSpec> {
    const trimmed = refinementPrompt.trim();
    if (!trimmed) {
      throw new Error('Please enter instructions for refining the website.');
    }

    const response = await authenticatedFetch('/api/refine-website', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        currentSpec,
        refinementPrompt: trimmed,
      }),
    });

    const data: GenerateWebsiteResponse = await response.json();

    if (!response.ok || !data.success || !data.spec) {
      const errorMessage =
        data.error ||
        'Failed to refine website specification with Gemini.';
      throw new Error(errorMessage);
    }

    return data.spec;
  }
}

export const refineWebsite = AiWebsiteService.refineWebsite;
export const REFINEMENT_CHIPS = QUICK_REFINEMENT_PROMPTS;
