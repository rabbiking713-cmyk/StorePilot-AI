import crypto from 'crypto';
import { WebsiteSpec, ProductsSection } from '../../types/websiteSpec';
import {
  StoreOrder,
  OrderItem,
  CustomerFulfillmentDetails,
  CheckoutInitializeResponse,
  OrderVerificationResponse,
} from '../../types/order';
import { OrderStore } from '../data/orderStore';
import { PrintifyFulfillmentService } from '../commerce/printifyFulfillmentService';

export class CheckoutService {
  /**
   * Safe parser for prices formatted as strings (e.g. "$22.00", "GH₵ 45.50", "₵25", "19.99")
   */
  public static parsePrice(priceStr: string | number): number {
    if (typeof priceStr === 'number') {
      return Math.max(0, priceStr);
    }
    if (!priceStr || typeof priceStr !== 'string') {
      return 0;
    }
    // Remove all characters except digits and decimal point
    const cleaned = priceStr.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleaned);
    return isNaN(val) ? 0 : Math.max(0, val);
  }

  /**
   * Detects standard ISO currency code from currency symbol or string
   */
  public static resolveCurrency(currencySymbol?: string): { code: string; symbol: string } {
    const sym = (currencySymbol || '$').trim();
    if (sym === 'GH₵' || sym === '₵' || sym.toLowerCase().includes('ghs')) {
      return { code: 'GHS', symbol: 'GH₵' };
    }
    if (sym === '₦' || sym.toLowerCase().includes('ngn')) {
      return { code: 'NGN', symbol: '₦' };
    }
    if (sym === '€') {
      return { code: 'EUR', symbol: '€' };
    }
    if (sym === '£') {
      return { code: 'GBP', symbol: '£' };
    }
    return { code: 'USD', symbol: '$' };
  }

  /**
   * Validates cart line items against authoritative published WebsiteSpec.
   * Calculates subtotal and total exclusively server-side.
   */
  public static validateAndPriceCart(
    spec: WebsiteSpec,
    rawItems: Array<{ productId: string; quantity: number }>
  ): {
    lineItems: OrderItem[];
    subtotal: number;
    total: number;
    totalInSubunits: number;
    currency: string;
    currencySymbol: string;
  } {
    if (!Array.isArray(rawItems) || rawItems.length === 0) {
      throw new Error('Your cart is empty. Please add items before checking out.');
    }

    // Find products section in the authoritative spec
    const prodSec = spec.sections?.find((s) => s.type === 'products') as ProductsSection | undefined;
    const catalog = prodSec?.items || [];

    if (catalog.length === 0) {
      throw new Error('This store has no active products available for purchase.');
    }

    const { code: currency, symbol: currencySymbol } = this.resolveCurrency(prodSec?.currencySymbol);

    const lineItems: OrderItem[] = [];
    let subtotal = 0;

    for (const raw of rawItems) {
      if (!raw || typeof raw !== 'object' || !raw.productId) {
        throw new Error('Invalid cart item payload.');
      }
      const rawQty = Number(raw.quantity);
      if (!Number.isFinite(rawQty) || rawQty <= 0) {
        throw new Error(`Invalid quantity for product "${raw.productId}". Quantity must be a positive integer.`);
      }
      const qty = Math.min(999, Math.floor(rawQty));

      // Authoritative catalog lookup by ID or exact name
      const catalogItem = catalog.find(
        (p) => p.id === raw.productId || p.name === raw.productId
      );

      if (!catalogItem) {
        throw new Error(`Product with ID "${raw.productId}" does not exist in this store's catalog.`);
      }

      // Server-side authoritative unit price extraction
      const unitPrice = this.parsePrice(catalogItem.price);
      if (unitPrice <= 0) {
        throw new Error(`Product "${catalogItem.name}" has an invalid price.`);
      }

      const itemTotal = unitPrice * qty;
      subtotal += itemTotal;

      lineItems.push({
        productId: catalogItem.id || catalogItem.name,
        name: catalogItem.name,
        price: unitPrice,
        priceFormatted: `${currencySymbol}${unitPrice.toFixed(2)}`,
        quantity: qty,
        imageUrl: catalogItem.imageUrl,
        badge: catalogItem.badge,
        category: catalogItem.category,
        printifyBlueprintId: catalogItem.printifyBlueprintId,
        printifyPrintProviderId: catalogItem.printifyPrintProviderId,
        printifyVariantId: catalogItem.printifyVariantId,
        printifyShopProductId: catalogItem.printifyShopProductId,
      });
    }

    // Round to 2 decimal places
    subtotal = Math.round(subtotal * 100) / 100;
    const total = subtotal; // No hidden fees
    const totalInSubunits = Math.round(total * 100);

    return {
      lineItems,
      subtotal,
      total,
      totalInSubunits,
      currency,
      currencySymbol,
    };
  }

  /**
   * Initializes a Paystack checkout transaction.
   * If PAYSTACK_SECRET_KEY is absent, safely creates the PENDING order record and reports unconfigured state.
   */
  public static async initializeCheckout(params: {
    siteId: string;
    siteSlug: string;
    siteName: string;
    ownerId: string;
    spec: WebsiteSpec;
    customer: CustomerFulfillmentDetails;
    rawItems: Array<{ productId: string; quantity: number }>;
    originUrl: string;
  }): Promise<CheckoutInitializeResponse> {
    const { siteId, siteSlug, siteName, ownerId, spec, customer, rawItems, originUrl } = params;

    // Validate customer fulfillment details
    if (!customer.fullName?.trim()) throw new Error('Customer full name is required.');
    if (!customer.email?.trim() || !customer.email.includes('@')) throw new Error('A valid email address is required.');
    if (!customer.phone?.trim()) throw new Error('Customer phone number is required.');
    if (!customer.address?.trim()) throw new Error('Delivery address is required.');
    if (!customer.city?.trim()) throw new Error('City is required.');

    // 1. Authoritative server-side validation and pricing
    const { lineItems, subtotal, total, totalInSubunits, currency, currencySymbol } =
      this.validateAndPriceCart(spec, rawItems);

    // 2. Generate unique order ID and human-readable reference
    const orderId = `ord_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const orderReference = `sp_ord_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;

    // 3. Create persistent order record (PENDING)
    const newOrder: StoreOrder = {
      id: orderId,
      orderReference,
      websiteId: siteId,
      websiteSlug: siteSlug,
      websiteName: siteName,
      ownerId,
      customer: {
        fullName: customer.fullName.trim(),
        email: customer.email.trim().toLowerCase(),
        phone: customer.phone.trim(),
        address: customer.address.trim(),
        city: customer.city.trim(),
        region: customer.region?.trim() || 'N/A',
        notes: customer.notes?.trim() || undefined,
      },
      items: lineItems,
      currency,
      currencySymbol,
      subtotal,
      total,
      totalInSubunits,
      paymentStatus: 'PENDING',
      orderStatus: 'NEW',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await OrderStore.createOrder(newOrder);
    } catch (persistErr: any) {
      console.error('[CheckoutService] Order creation rejected due to storage error:', persistErr);
      return {
        success: false,
        paystackConfigured: Boolean(process.env.PAYSTACK_SECRET_KEY),
        orderId,
        orderReference,
        amount: total,
        currency,
        error: persistErr?.message || 'Production order storage is unavailable. Order could not be created safely.',
      };
    }

    // 4. Paystack Gateway Integration
    const paystackSecretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackSecretKey || paystackSecretKey.trim() === '') {
      console.warn(
        `[CheckoutService] Notice: PAYSTACK_SECRET_KEY is not configured in server environment. Order ${orderReference} saved as PENDING.`
      );
      return {
        success: false,
        paystackConfigured: false,
        orderId,
        orderReference,
        amount: total,
        currency,
        error:
          'PAYSTACK_SECRET_KEY is not configured on the server. Please configure your Paystack secret key in your environment to process live payments.',
      };
    }

    try {
      const callbackUrl = `${originUrl}/site/${siteSlug}?order_ref=${encodeURIComponent(orderReference)}`;

      const paystackPayload = {
        email: customer.email.trim().toLowerCase(),
        amount: totalInSubunits,
        currency,
        reference: orderReference,
        callback_url: callbackUrl,
        metadata: {
          orderId,
          orderReference,
          websiteId: siteId,
          websiteSlug: siteSlug,
          ownerId,
          customerName: customer.fullName.trim(),
          customerPhone: customer.phone.trim(),
        },
      };

      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${paystackSecretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(paystackPayload),
      });

      const data = await response.json();

      if (!response.ok || !data.status || !data.data) {
        console.error('[CheckoutService] Paystack initialization returned error:', data);
        return {
          success: false,
          paystackConfigured: true,
          orderId,
          orderReference,
          error: data.message || 'Payment gateway initialization failed. Please try again.',
        };
      }

      return {
        success: true,
        paystackConfigured: true,
        orderId,
        orderReference,
        authorizationUrl: data.data.authorization_url,
        accessCode: data.data.access_code,
        amount: total,
        currency,
      };
    } catch (err: any) {
      console.error('[CheckoutService] Network error calling Paystack initialize:', err);
      return {
        success: false,
        paystackConfigured: true,
        orderId,
        orderReference,
        error: 'Unable to reach payment gateway. Please check internet connection and try again.',
      };
    }
  }

  /**
   * Verifies payment with Paystack server-side before marking order as PAID.
   */
  public static async verifyPayment(reference: string): Promise<OrderVerificationResponse> {
    const order = await OrderStore.getOrderByReference(reference);
    if (!order) {
      return {
        success: false,
        verifiedWithPaystack: false,
        error: `Order not found with reference: ${reference}`,
      };
    }

    // Idempotent: If already PAID, return verified order
    if (order.paymentStatus === 'PAID') {
      return {
        success: true,
        order,
        paymentStatus: 'PAID',
        verifiedWithPaystack: true,
      };
    }

    const paystackSecretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackSecretKey) {
      return {
        success: false,
        order,
        paymentStatus: order.paymentStatus,
        verifiedWithPaystack: false,
        error: 'PAYSTACK_SECRET_KEY is not configured on the server. Real payment verification unavailable.',
      };
    }

    try {
      const response = await fetch(
        `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${paystackSecretKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();

      if (!response.ok || !data.status || !data.data) {
        return {
          success: false,
          order,
          paymentStatus: order.paymentStatus,
          verifiedWithPaystack: true,
          error: data.message || 'Transaction could not be verified by Paystack.',
        };
      }

      const tx = data.data;

      // Validate that the paid amount and currency match authoritative order total
      if (tx.status === 'success') {
        if (
          tx.currency &&
          order.currency &&
          tx.currency.toUpperCase() !== order.currency.toUpperCase()
        ) {
          console.warn(
            `[CheckoutService] Currency mismatch: Paid in ${tx.currency}, expected ${order.currency}`
          );
          await OrderStore.updatePaymentStatus(reference, 'FAILED');
          return {
            success: false,
            paymentStatus: 'FAILED',
            verifiedWithPaystack: true,
            error: 'Transaction currency does not match the order currency.',
          };
        }

        if (tx.amount < order.totalInSubunits) {
          console.warn(
            `[CheckoutService] Suspicious payment: Paid ${tx.amount} < Required ${order.totalInSubunits}`
          );
          await OrderStore.updatePaymentStatus(reference, 'FAILED');
          return {
            success: false,
            paymentStatus: 'FAILED',
            verifiedWithPaystack: true,
            error: 'Paid amount was less than the required order total.',
          };
        }

        // Successfully verified payment with Paystack!
        const updated = await OrderStore.updatePaymentStatus(reference, 'PAID', {
          paystackReference: tx.reference,
          channel: tx.channel,
          paidAt: tx.paid_at || new Date().toISOString(),
        });

        // Trigger real Printify fulfillment exclusively upon verified payment
        if (updated) {
          try {
            await PrintifyFulfillmentService.submitOrderToPrintify(updated);
          } catch (fulfillErr) {
            console.error('[CheckoutService] Printify fulfillment submission error:', fulfillErr);
          }
        }

        const refreshedOrder = (await OrderStore.getOrderByReference(reference)) || updated || order;

        return {
          success: true,
          order: refreshedOrder,
          paymentStatus: 'PAID',
          verifiedWithPaystack: true,
        };
      } else if (tx.status === 'failed') {
        const updated = await OrderStore.updatePaymentStatus(reference, 'FAILED');
        return {
          success: false,
          order: updated || order,
          paymentStatus: 'FAILED',
          verifiedWithPaystack: true,
          error: tx.gateway_response || 'Payment was declined by payment provider.',
        };
      } else if (tx.status === 'abandoned') {
        const updated = await OrderStore.updatePaymentStatus(reference, 'CANCELLED');
        return {
          success: false,
          order: updated || order,
          paymentStatus: 'CANCELLED',
          verifiedWithPaystack: true,
          error: 'Payment was cancelled or abandoned by the customer.',
        };
      }

      // Still pending
      return {
        success: true,
        order,
        paymentStatus: 'PENDING',
        verifiedWithPaystack: true,
      };
    } catch (err: any) {
      console.error('[CheckoutService] Error verifying Paystack transaction:', err);
      return {
        success: false,
        order,
        paymentStatus: order.paymentStatus,
        verifiedWithPaystack: false,
        error: 'Failed to connect to Paystack verification service.',
      };
    }
  }

  /**
   * Verifies authenticity of Paystack webhook signature using HMAC SHA-512
   */
  public static verifyWebhookSignature(rawBody: string, signature?: string): boolean {
    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!secretKey || !signature) return false;
    try {
      const hash = crypto.createHmac('sha512', secretKey).update(rawBody).digest('hex');
      return hash === signature;
    } catch {
      return false;
    }
  }
}
