import {
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged as firebaseOnAuthStateChanged,
  sendPasswordResetEmail as firebaseSendPasswordResetEmail,
  User as FirebaseUser,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, firebaseConfigState } from '../firebase/firebaseConfig';
import { UserSession } from '../../types';

const DEMO_USER_STORAGE_KEY = 'storepilot_demo_user_session';

export class AuthService {
  private static demoUserListeners: Array<(user: UserSession | null) => void> = [];

  public static isCloudConfigured(): boolean {
    return firebaseConfigState.isConfigured;
  }

  public static getMissingConfigKeys(): string[] {
    return firebaseConfigState.missingKeys;
  }

  /**
   * Helper to retrieve active local demo user if any
   */
  public static getStoredDemoUser(): UserSession | null {
    if (typeof window === 'undefined') return null;
    try {
      const data = sessionStorage.getItem(DEMO_USER_STORAGE_KEY);
      if (data) {
        return JSON.parse(data) as UserSession;
      }
    } catch {
      // Ignore storage errors
    }
    return null;
  }

  private static setStoredDemoUser(user: UserSession | null): void {
    if (typeof window === 'undefined') return;
    try {
      if (user) {
        sessionStorage.setItem(DEMO_USER_STORAGE_KEY, JSON.stringify(user));
      } else {
        sessionStorage.removeItem(DEMO_USER_STORAGE_KEY);
      }
    } catch {
      // Ignore storage errors
    }
    // Notify listeners
    this.demoUserListeners.forEach((fn) => fn(user));
  }

  /**
   * Maps Firebase User to StorePilot UserSession
   */
  public static mapFirebaseUser(user: FirebaseUser): UserSession {
    return {
      id: user.uid,
      email: user.email || 'user@storepilot.ai',
      displayName: user.displayName || user.email?.split('@')[0] || 'StorePilot Merchant',
      photoURL: user.photoURL || undefined,
      isAnonymous: user.isAnonymous,
      providerId: user.providerData?.[0]?.providerId === 'google.com' ? 'google' : 'firebase',
      createdAt: user.metadata.creationTime || new Date().toISOString(),
    };
  }

  /**
   * Retrieve current user's Firebase ID token for authenticating backend API calls
   */
  public static async getIdToken(forceRefresh = false): Promise<string | null> {
    if (auth.currentUser) {
      return auth.currentUser.getIdToken(forceRefresh);
    }
    const demo = this.getStoredDemoUser();
    if (demo) {
      return `demo-session-token:${demo.id}`;
    }
    return null;
  }

  /**
   * Syncs user profile metadata to Firestore users/{uid} document
   */
  public static async syncUserProfile(user: FirebaseUser, customDisplayName?: string): Promise<void> {
    if (!user || !user.uid) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      const existingSnap = await getDoc(userRef);
      const now = new Date().toISOString();

      const profileData: Record<string, any> = {
        uid: user.uid,
        email: user.email || '',
        displayName: customDisplayName || user.displayName || user.email?.split('@')[0] || 'StorePilot Merchant',
        updatedAt: now,
      };

      if (user.photoURL) {
        profileData.photoURL = user.photoURL;
      }

      if (!existingSnap.exists()) {
        profileData.createdAt = user.metadata.creationTime || now;
      }

      await setDoc(userRef, profileData, { merge: true });
    } catch (err) {
      console.warn('[AuthService] Profile sync warning (non-fatal):', err);
    }
  }

  /**
   * Sign In with Google
   */
  public static async signInWithGoogle(): Promise<UserSession> {
    this.setStoredDemoUser(null);
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const result = await signInWithPopup(auth, provider);
    await this.syncUserProfile(result.user);
    return this.mapFirebaseUser(result.user);
  }

  /**
   * Sign In with Email and Password
   */
  public static async signInWithEmail(email: string, pass: string): Promise<UserSession> {
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !pass) {
      throw new Error('Please enter both email and password.');
    }

    this.setStoredDemoUser(null);
    const result = await signInWithEmailAndPassword(auth, trimmedEmail, pass);
    await this.syncUserProfile(result.user);
    return this.mapFirebaseUser(result.user);
  }

  /**
   * Sign Up with Email and Password
   */
  public static async signUpWithEmail(
    email: string,
    pass: string,
    displayName: string
  ): Promise<UserSession> {
    const trimmedEmail = email.trim();
    const trimmedName = displayName.trim();

    if (!trimmedEmail || !pass) {
      throw new Error('Please enter both email and password.');
    }
    if (pass.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }

    this.setStoredDemoUser(null);
    const result = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
    if (trimmedName && result.user) {
      await updateProfile(result.user, { displayName: trimmedName });
    }
    await this.syncUserProfile(result.user, trimmedName);
    return this.mapFirebaseUser(result.user);
  }

  /**
   * Launch Sandbox Demo Founder Session
   */
  public static async signInAsDemoFounder(): Promise<UserSession> {
    const demoUser: UserSession = {
      id: 'demo-founder-uid',
      email: 'founder@storepilot.ai',
      displayName: 'Demo Merchant',
      providerId: 'local_dev',
      isAnonymous: false,
      createdAt: new Date().toISOString(),
    };
    this.setStoredDemoUser(demoUser);
    return demoUser;
  }

  /**
   * Send Password Reset Email
   */
  public static async sendPasswordReset(email: string): Promise<void> {
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      throw new Error('Please enter your account email address.');
    }
    await firebaseSendPasswordResetEmail(auth, trimmedEmail);
  }

  /**
   * Update Display Name
   */
  public static async updateDisplayName(newDisplayName: string): Promise<UserSession> {
    const trimmed = newDisplayName.trim();
    if (!trimmed) {
      throw new Error('Display name cannot be empty.');
    }

    if (auth.currentUser) {
      await updateProfile(auth.currentUser, { displayName: trimmed });
      await this.syncUserProfile(auth.currentUser, trimmed);
      return this.mapFirebaseUser(auth.currentUser);
    }

    const demo = this.getStoredDemoUser();
    if (demo) {
      const updated: UserSession = { ...demo, displayName: trimmed };
      this.setStoredDemoUser(updated);
      return updated;
    }

    throw new Error('No authenticated user session found to update.');
  }

  /**
   * Sign Out
   */
  public static async signOut(): Promise<void> {
    this.setStoredDemoUser(null);
    await firebaseSignOut(auth);
  }

  /**
   * Listen to Firebase Auth & Demo session state changes
   */
  public static subscribeAuthState(callback: (user: UserSession | null) => void): () => void {
    this.demoUserListeners.push(callback);

    const unsubscribeFirebase = firebaseOnAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        callback(this.mapFirebaseUser(firebaseUser));
      } else {
        const demo = this.getStoredDemoUser();
        callback(demo);
      }
    });

    // Initial check
    if (!auth.currentUser) {
      const demo = this.getStoredDemoUser();
      if (demo) {
        callback(demo);
      }
    }

    return () => {
      unsubscribeFirebase();
      this.demoUserListeners = this.demoUserListeners.filter((fn) => fn !== callback);
    };
  }
}
