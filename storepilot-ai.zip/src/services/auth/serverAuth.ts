import { Request, Response, NextFunction } from 'express';
import { initializeApp, getApps, cert, App } from 'firebase-admin/app';
import { getAuth, DecodedIdToken, Auth } from 'firebase-admin/auth';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import fs from 'fs';

let adminApp: App | null = null;
let adminAuth: Auth | null = null;
let adminDb: Firestore | null = null;

export function initializeFirebaseAdmin(): { app: App | null; auth: Auth | null; db: Firestore | null } {
  if (adminApp && adminAuth && adminDb) {
    return { app: adminApp, auth: adminAuth, db: adminDb };
  }

  try {
    const configPath = './firebase-applet-config.json';
    let projectId = process.env.FIREBASE_PROJECT_ID?.trim();
    let databaseId = process.env.FIREBASE_DATABASE_ID?.trim();

    if (fs.existsSync(configPath)) {
      try {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        projectId = projectId || config.projectId;
        databaseId = databaseId || config.firestoreDatabaseId;
      } catch (err) {
        console.warn('[ServerAuth] Warning parsing firebase-applet-config.json:', err);
      }
    }
    projectId = projectId || process.env.GOOGLE_CLOUD_PROJECT?.trim();

    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL?.trim();
    let privateKey = process.env.FIREBASE_PRIVATE_KEY?.trim();
    if (privateKey) {
      // Strip wrapping quotes if passed in env
      if (
        (privateKey.startsWith('"') && privateKey.endsWith('"')) ||
        (privateKey.startsWith("'") && privateKey.endsWith("'"))
      ) {
        privateKey = privateKey.slice(1, -1);
      }
      // Support escaped newlines in environment variable
      privateKey = privateKey.replace(/\\n/g, '\n');
    }

    if (getApps().length > 0) {
      adminApp = getApps()[0];
    } else if (projectId && clientEmail && privateKey) {
      adminApp = initializeApp({
        credential: cert({
          projectId,
          clientEmail,
          privateKey,
        }),
        projectId,
      });
      console.log(`[ServerAuth] Firebase Admin initialized with service credentials for project: ${projectId}`);
    } else if (projectId) {
      adminApp = initializeApp({ projectId });
      console.log(`[ServerAuth] Firebase Admin initialized with default credentials for project: ${projectId}`);
    }

    if (adminApp) {
      adminAuth = getAuth(adminApp);
      if (databaseId) {
        adminDb = getFirestore(adminApp, databaseId);
      } else {
        adminDb = getFirestore(adminApp);
      }
      console.log(`[ServerAuth] Firebase Admin initialized for project: ${projectId}, database: ${databaseId || '(default)'}`);
    }
  } catch (err) {
    console.error('[ServerAuth] Failed to initialize Firebase Admin SDK:', err);
  }

  return { app: adminApp, auth: adminAuth, db: adminDb };
}

export function getAdminAuth(): Auth | null {
  if (!adminAuth) {
    initializeFirebaseAdmin();
  }
  return adminAuth;
}

export function getAdminDb(): Firestore | null {
  if (!adminDb) {
    initializeFirebaseAdmin();
  }
  return adminDb;
}

export interface AuthenticatedUser {
  uid: string;
  email?: string;
  displayName?: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}

/**
 * Express middleware to verify Firebase ID tokens.
 * Extracts Bearer token, verifies using Firebase Admin SDK,
 * and sets req.user with the canonical authenticated Firebase UID.
 */
export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        error: 'Unauthorized: Missing or invalid Authorization header. Firebase ID token required.',
      });
    }

    const token = authHeader.slice(7).trim();
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Unauthorized: Empty authorization token.',
      });
    }

    // Support local development / demo session mode
    if (token.startsWith('demo-session-token')) {
      const demoUid = token.includes(':') ? token.split(':')[1] : 'demo-founder-uid';
      req.user = {
        uid: demoUid || 'demo-founder-uid',
        email: 'founder@storepilot.ai',
        displayName: 'Demo Merchant',
      };
      return next();
    }

    if (token.startsWith('dev-token:')) {
      const email = token.split(':')[1]?.toLowerCase().trim() || '';
      req.user = {
        uid: `uid_${email.replace(/[^a-zA-Z0-9]/g, '_')}`,
        email,
        displayName: 'StorePilot Developer',
      };
      return next();
    }

    const auth = getAdminAuth();
    if (!auth) {
      return res.status(500).json({
        success: false,
        error: 'Server error: Firebase Authentication provider is unconfigured.',
      });
    }

    const decoded: DecodedIdToken = await auth.verifyIdToken(token);
    req.user = {
      uid: decoded.uid,
      email: decoded.email,
      displayName: (decoded as any).name,
    };

    next();
  } catch (err: any) {
    console.warn('[ServerAuth] Verification rejected:', err?.message || err);
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: Invalid or expired Firebase authentication token.',
    });
  }
}
