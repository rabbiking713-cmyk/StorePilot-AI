import fs from 'fs';
import path from 'path';
import { SavedMarketingItem } from '../../types/marketing';
import { getAdminDb } from '../auth/serverAuth';
import { sanitizeForFirestore } from './websiteService';

const DATA_DIR = path.join(process.cwd(), 'data');
const MARKETING_FILE = path.join(DATA_DIR, 'marketing.json');
const COLLECTION_NAME = 'marketingItems';

export class MarketingStore {
  private static itemsMap = new Map<string, SavedMarketingItem>();
  private static isLoaded = false;

  private static ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (err) {
        console.warn('[MarketingStore] Failed to create data dir:', err);
      }
    }
  }

  public static async initialize(): Promise<void> {
    if (this.isLoaded) return;
    this.isLoaded = true;
    this.ensureDataDir();

    try {
      if (fs.existsSync(MARKETING_FILE)) {
        const raw = fs.readFileSync(MARKETING_FILE, 'utf8');
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && item.id && item.userId) {
              this.itemsMap.set(item.id, item);
            }
          }
          console.log(`[MarketingStore] Loaded ${this.itemsMap.size} saved marketing item(s) from local cache.`);
        }
      }
    } catch (err) {
      console.warn('[MarketingStore] Failed to load marketing file:', err);
    }

    // Auto-migrate local disk items to Cloud Firestore if not already present
    const adminDb = getAdminDb();
    if (adminDb && this.itemsMap.size > 0) {
      try {
        for (const [id, item] of this.itemsMap.entries()) {
          const docRef = adminDb.collection(COLLECTION_NAME).doc(id);
          const snap = await docRef.get();
          if (!snap.exists) {
            await docRef.set(sanitizeForFirestore(item));
            console.log(`[MarketingStore] Migrated marketing item "${id}" to Cloud Firestore.`);
          }
        }
      } catch (migrationErr) {
        console.warn('[MarketingStore] Migration to Firestore warning:', migrationErr);
      }
    }
  }

  private static persist(): void {
    this.ensureDataDir();
    try {
      const list = Array.from(this.itemsMap.values());
      fs.writeFileSync(MARKETING_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (err) {
      // In serverless / read-only filesystem, file persist is non-fatal
    }
  }

  public static async getItemsByUser(userId: string): Promise<SavedMarketingItem[]> {
    await this.initialize();

    // 1. Authoritative Firestore query
    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        const snap = await adminDb
          .collection(COLLECTION_NAME)
          .where('userId', '==', userId)
          .get();

        const firestoreItems: SavedMarketingItem[] = [];
        snap.forEach((doc) => {
          const data = doc.data() as SavedMarketingItem;
          if (data && data.userId === userId) {
            firestoreItems.push(data);
            this.itemsMap.set(data.id, data);
          }
        });

        firestoreItems.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        return firestoreItems;
      } catch (err) {
        console.warn('[MarketingStore] Firestore query failed, falling back to local store:', err);
      }
    }

    // 2. Local fallback
    return Array.from(this.itemsMap.values())
      .filter((item) => item.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public static async saveItem(item: SavedMarketingItem): Promise<SavedMarketingItem> {
    await this.initialize();
    this.itemsMap.set(item.id, item);
    this.persist();

    // Authoritative Firestore persistence
    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        await adminDb
          .collection(COLLECTION_NAME)
          .doc(item.id)
          .set(sanitizeForFirestore(item));
        console.log(`[MarketingStore] Persisted marketing item ${item.id} to Firestore.`);
      } catch (err) {
        console.warn('[MarketingStore] Firestore write error:', err);
      }
    }

    return item;
  }

  public static async deleteItem(itemId: string, userId: string): Promise<boolean> {
    await this.initialize();
    const existing = this.itemsMap.get(itemId);
    if (existing && existing.userId !== userId) {
      throw new Error('Forbidden: You do not own this marketing item.');
    }
    this.itemsMap.delete(itemId);
    this.persist();

    // Authoritative Firestore delete
    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        const docRef = adminDb.collection(COLLECTION_NAME).doc(itemId);
        const snap = await docRef.get();
        if (snap.exists) {
          const data = snap.data();
          if (data && data.userId !== userId) {
            throw new Error('Forbidden: You do not own this marketing item.');
          }
          await docRef.delete();
          console.log(`[MarketingStore] Deleted marketing item ${itemId} from Firestore.`);
        }
      } catch (err: any) {
        if (err?.message?.includes('Forbidden')) throw err;
        console.warn('[MarketingStore] Firestore delete error:', err);
      }
    }

    return true;
  }
}
