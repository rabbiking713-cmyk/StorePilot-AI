import fs from 'fs';
import path from 'path';
import { Firestore } from '@google-cloud/firestore';
import { StorePilotProduct } from '../../types/commerce';

const COLLECTION_NAME = 'storeProducts';
const DATA_DIR = path.join(process.cwd(), 'data');
const DEV_PRODUCTS_FILE = path.join(DATA_DIR, 'products.dev.json');

/**
 * ProductStore provides durable, authoritative server-side storage for StorePilot products.
 *
 * PRODUCTION ARCHITECTURE:
 * - Authoritative Database: Google Cloud Firestore (collection: 'storeProducts').
 * - Ephemeral file/disk fallback is strictly disabled in production.
 * - Strict tenant/merchant isolation: queries must match authenticated ownerId.
 *
 * DEVELOPMENT ARCHITECTURE:
 * - Connects to Firestore if configured, otherwise uses isolated dev sandbox file (data/products.dev.json).
 */
export class ProductStore {
  private static firestore: Firestore | null = null;
  private static isInitialized = false;
  private static firestoreAvailable = false;
  private static firestoreError: string | null = null;

  private static devMemoryProducts = new Map<string, StorePilotProduct>();

  public static isProduction(): boolean {
    return process.env.NODE_ENV === 'production';
  }

  public static isFirestoreActive(): boolean {
    return this.firestoreAvailable && this.firestore !== null;
  }

  public static getFirestoreStatus(): { available: boolean; error: string | null } {
    return { available: this.firestoreAvailable, error: this.firestoreError };
  }

  public static async initialize(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    if (this.isProduction()) {
      try {
        const projectId =
          process.env.FIREBASE_PROJECT_ID ||
          process.env.VITE_FIREBASE_PROJECT_ID ||
          process.env.GOOGLE_CLOUD_PROJECT ||
          process.env.GCP_PROJECT;

        const options: any = {};
        if (projectId) {
          options.projectId = projectId;
        }

        this.firestore = new Firestore(options);
        const probe = await this.firestore.collection(COLLECTION_NAME).limit(1).get();
        this.firestoreAvailable = true;
        this.firestoreError = null;
        console.log(`[ProductStore] Cloud Firestore connected. Accessible products: ${probe.size}`);
      } catch (err: any) {
        this.firestoreAvailable = false;
        this.firestoreError = err?.message || 'Firestore connection failed.';
        console.error(
          `[ProductStore] CRITICAL PRODUCTION ERROR: Cloud Firestore is unavailable (${this.firestoreError}). ` +
          `Local file storage is disabled in production to guarantee data durability.`
        );
      }
    } else {
      try {
        const projectId =
          process.env.FIREBASE_PROJECT_ID ||
          process.env.VITE_FIREBASE_PROJECT_ID ||
          process.env.GOOGLE_CLOUD_PROJECT ||
          process.env.GCP_PROJECT;

        if (projectId) {
          this.firestore = new Firestore({ projectId });
          const probe = await this.firestore.collection(COLLECTION_NAME).limit(1).get();
          this.firestoreAvailable = true;
          this.firestoreError = null;
          console.log(`[ProductStore] Development Firestore connected. Accessible products: ${probe.size}`);
        } else {
          this.firestoreAvailable = false;
          this.firestoreError = 'No Firestore project configured in development.';
        }
      } catch (err: any) {
        this.firestoreAvailable = false;
        this.firestoreError = err?.message || 'Development Firestore offline';
      }

      this.loadDevDiskProducts();
    }
  }

  private static loadDevDiskProducts(): void {
    if (this.isProduction()) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DEV_PRODUCTS_FILE)) {
        const raw = fs.readFileSync(DEV_PRODUCTS_FILE, 'utf-8');
        const products: StorePilotProduct[] = JSON.parse(raw);
        this.devMemoryProducts = new Map(products.map((p) => [p.id, p]));
        console.log(`[ProductStore] Loaded ${this.devMemoryProducts.size} product(s) for local dev sandbox.`);
      }
    } catch (err) {
      console.error('[ProductStore] Failed to load development products from disk:', err);
    }
  }

  private static saveDevDiskProducts(): void {
    if (this.isProduction()) {
      console.error('[ProductStore] Security violation prevented: Attempted to write products to local disk in production.');
      return;
    }
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const records = Array.from(this.devMemoryProducts.values());
      fs.writeFileSync(DEV_PRODUCTS_FILE, JSON.stringify(records, null, 2), 'utf-8');
    } catch (err) {
      console.error('[ProductStore] Failed to save development products to disk:', err);
    }
  }

  /**
   * Save an approved product to durable storage
   */
  public static async saveProduct(product: StorePilotProduct): Promise<StorePilotProduct> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        throw new Error(
          `Production database unavailable: Cloud Firestore is not connected (${this.firestoreError || 'offline'}). Refusing ephemeral storage.`
        );
      }
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(product.id).set(product);
        return product;
      } catch (err: any) {
        throw new Error(`Cloud Firestore write failed for product ${product.id}: ${err?.message || 'DB error'}`);
      }
    }

    // Development sandbox
    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(product.id).set(product);
      } catch (err) {
        console.warn('[ProductStore] Dev Firestore write failed, using sandbox file:', err);
      }
    }

    this.devMemoryProducts.set(product.id, product);
    this.saveDevDiskProducts();
    return product;
  }

  /**
   * Save multiple approved products
   */
  public static async saveProducts(products: StorePilotProduct[]): Promise<StorePilotProduct[]> {
    for (const p of products) {
      await this.saveProduct(p);
    }
    return products;
  }

  /**
   * Get products for a specific website with STRICT MERCHANT OWNERSHIP ISOLATION
   */
  public static async getProductsByWebsite(
    websiteId: string,
    ownerId: string
  ): Promise<StorePilotProduct[]> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        console.error(`[ProductStore] Cloud Firestore unavailable in production.`);
        return [];
      }
      try {
        const snap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('websiteId', '==', websiteId)
          .where('ownerId', '==', ownerId)
          .get();

        const results: StorePilotProduct[] = [];
        snap.forEach((doc) => {
          results.push(doc.data() as StorePilotProduct);
        });
        return results;
      } catch (err) {
        console.error(`[ProductStore] Firestore query error for website ${websiteId}:`, err);
        return [];
      }
    }

    // Development lookup
    const results: StorePilotProduct[] = [];
    for (const p of this.devMemoryProducts.values()) {
      if (p.websiteId === websiteId && p.ownerId === ownerId) {
        results.push(p);
      }
    }
    return results;
  }

  /**
   * Get all approved products owned by a specific merchant (OWNER ISOLATION)
   */
  public static async getProductsByOwner(ownerId: string): Promise<StorePilotProduct[]> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        return [];
      }
      try {
        const snap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('ownerId', '==', ownerId)
          .get();

        const results: StorePilotProduct[] = [];
        snap.forEach((doc) => {
          results.push(doc.data() as StorePilotProduct);
        });
        return results;
      } catch (err) {
        console.error(`[ProductStore] Firestore error for owner ${ownerId}:`, err);
        return [];
      }
    }

    // Development lookup
    const results: StorePilotProduct[] = [];
    for (const p of this.devMemoryProducts.values()) {
      if (p.ownerId === ownerId) {
        results.push(p);
      }
    }
    return results;
  }

  /**
   * Lookup product by ID (ENFORCES OWNER ISOLATION)
   */
  public static async getProductById(
    productId: string,
    ownerId: string
  ): Promise<StorePilotProduct | null> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        return null;
      }
      try {
        const doc = await this.firestore.collection(COLLECTION_NAME).doc(productId).get();
        if (doc.exists) {
          const product = doc.data() as StorePilotProduct;
          if (product.ownerId === ownerId) {
            return product;
          }
          console.warn(`[ProductStore] Tenant violation: owner ${ownerId} attempted access to product ${productId} owned by ${product.ownerId}`);
          return null; // Deny access to foreign product
        }
        return null;
      } catch (err) {
        console.error(`[ProductStore] Firestore error fetching product ${productId}:`, err);
        return null;
      }
    }

    // Development lookup
    const product = this.devMemoryProducts.get(productId);
    if (!product) return null;
    if (product.ownerId !== ownerId) {
      console.warn(`[ProductStore] Dev tenant violation: owner ${ownerId} requested product owned by ${product.ownerId}`);
      return null;
    }
    return product;
  }

  /**
   * Update product storefront presentation while preserving Printify link
   */
  public static async updateProduct(
    productId: string,
    ownerId: string,
    updates: Partial<StorePilotProduct>
  ): Promise<StorePilotProduct | null> {
    const existing = await this.getProductById(productId, ownerId);
    if (!existing) {
      throw new Error(`Product not found or access denied for product ID: ${productId}`);
    }

    // Disallow overwriting critical Printify identity
    const updated: StorePilotProduct = {
      ...existing,
      storefrontTitle: updates.storefrontTitle ?? existing.storefrontTitle,
      storefrontDescription: updates.storefrontDescription ?? existing.storefrontDescription,
      storefrontPrice: typeof updates.storefrontPrice === 'number' ? updates.storefrontPrice : existing.storefrontPrice,
      isApproved: typeof updates.isApproved === 'boolean' ? updates.isApproved : existing.isApproved,
      isFeatured: typeof updates.isFeatured === 'boolean' ? updates.isFeatured : existing.isFeatured,
      badge: updates.badge ?? existing.badge,
      category: updates.category ?? existing.category,
      updatedAt: new Date().toISOString(),
    };

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        throw new Error('Production database is unavailable.');
      }
      await this.firestore.collection(COLLECTION_NAME).doc(productId).update({
        storefrontTitle: updated.storefrontTitle,
        storefrontDescription: updated.storefrontDescription,
        storefrontPrice: updated.storefrontPrice,
        isApproved: updated.isApproved,
        isFeatured: updated.isFeatured,
        badge: updated.badge,
        category: updated.category,
        updatedAt: updated.updatedAt,
      });
      return updated;
    }

    // Development update
    this.devMemoryProducts.set(productId, updated);
    this.saveDevDiskProducts();

    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(productId).update({
          storefrontTitle: updated.storefrontTitle,
          storefrontDescription: updated.storefrontDescription,
          storefrontPrice: updated.storefrontPrice,
          isApproved: updated.isApproved,
          isFeatured: updated.isFeatured,
          badge: updated.badge,
          category: updated.category,
          updatedAt: updated.updatedAt,
        });
      } catch (err) {
        console.warn('[ProductStore] Dev Firestore update failed:', err);
      }
    }

    return updated;
  }

  /**
   * Delete an approved product (ENFORCES OWNER ISOLATION)
   */
  public static async deleteProduct(productId: string, ownerId: string): Promise<boolean> {
    const existing = await this.getProductById(productId, ownerId);
    if (!existing) {
      throw new Error(`Product not found or access denied for product ID: ${productId}`);
    }

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        throw new Error('Production database is unavailable.');
      }
      await this.firestore.collection(COLLECTION_NAME).doc(productId).delete();
      return true;
    }

    this.devMemoryProducts.delete(productId);
    this.saveDevDiskProducts();

    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(productId).delete();
      } catch (err) {
        console.warn('[ProductStore] Dev Firestore delete failed:', err);
      }
    }

    return true;
  }
}
