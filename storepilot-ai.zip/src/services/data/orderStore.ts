import fs from 'fs';
import path from 'path';
import { Firestore } from '@google-cloud/firestore';
import {
  StoreOrder,
  OrderPaymentStatus,
  OrderFulfillmentStatus,
  PrintifyOrderFulfillment,
} from '../../types/order';

const COLLECTION_NAME = 'storeOrders';
const DATA_DIR = path.join(process.cwd(), 'data');
const DEV_ORDERS_FILE = path.join(DATA_DIR, 'orders.dev.json');
const LEGACY_ORDERS_FILE = path.join(DATA_DIR, 'orders.json');

/**
 * OrderStore provides durable, authoritative server-side storage for StorePilot customer orders.
 *
 * PRODUCTION ARCHITECTURE:
 * - Authoritative Database: Google Cloud Firestore (collection: 'storeOrders').
 * - Ephemeral file/disk fallback is STRICTLY DISABLED in production.
 * - If Firestore is unreachable, unconfigured, or offline, orders fail safely rather than silently saving locally.
 * - Never reports an order as durably stored if it exists only in local process memory or files.
 *
 * DEVELOPMENT ARCHITECTURE:
 * - If Firestore is configured and connected, it can be utilized.
 * - Otherwise, falls back to isolated development sandbox file (data/orders.dev.json) for dev/testing only.
 */
export class OrderStore {
  private static firestore: Firestore | null = null;
  private static isInitialized = false;
  private static firestoreAvailable = false;
  private static firestoreError: string | null = null;

  // Local development / testing orders (strictly isolated to non-production)
  private static devMemoryOrders = new Map<string, StoreOrder>();

  public static isProduction(): boolean {
    return process.env.NODE_ENV === 'production';
  }

  public static isFirestoreActive(): boolean {
    return this.firestoreAvailable && this.firestore !== null;
  }

  public static getFirestoreStatus(): { available: boolean; error: string | null } {
    return { available: this.firestoreAvailable, error: this.firestoreError };
  }

  public static getStorageBackend(): string {
    if (this.isProduction()) {
      return this.firestoreAvailable ? 'Cloud Firestore (Authoritative)' : 'Cloud Firestore (Unavailable)';
    }
    return this.firestoreAvailable ? 'Cloud Firestore (Dev Mode)' : 'Local JSON Sandbox (Dev/Test Only)';
  }

  /**
   * Initializes the persistent Firestore connection or development sandbox.
   */
  public static async initialize(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    if (this.isProduction()) {
      // In PRODUCTION: Local JSON fallback is strictly disabled.
      // Cloud Firestore is the sole authoritative datastore.
      try {
        const projectId =
          process.env.FIREBASE_PROJECT_ID ||
          process.env.VITE_FIREBASE_PROJECT_ID ||
          process.env.GOOGLE_CLOUD_PROJECT ||
          process.env.GCP_PROJECT;

        const options: any = {};
        if (projectId) {
          options.projectId = projectId;
        }

        this.firestore = new Firestore(options);
        const probe = await this.firestore.collection(COLLECTION_NAME).limit(1).get();
        this.firestoreAvailable = true;
        this.firestoreError = null;
        console.log(`[OrderStore] Production Cloud Firestore connected successfully. Accessible orders: ${probe.size}`);
      } catch (err: any) {
        this.firestoreAvailable = false;
        this.firestoreError = err?.message || 'Firestore connection failed.';
        console.error(
          `[OrderStore] CRITICAL PRODUCTION ERROR: Cloud Firestore is unavailable (${this.firestoreError}). ` +
          `Local JSON storage fallback is disabled in production to guarantee order durability and prevent data loss.`
        );
      }
    } else {
      // In DEVELOPMENT / TESTING:
      // Try connecting to Firestore if credentials/project are configured, otherwise use dev sandbox.
      try {
        const projectId =
          process.env.FIREBASE_PROJECT_ID ||
          process.env.VITE_FIREBASE_PROJECT_ID ||
          process.env.GOOGLE_CLOUD_PROJECT ||
          process.env.GCP_PROJECT;

        if (projectId) {
          this.firestore = new Firestore({ projectId });
          const probe = await this.firestore.collection(COLLECTION_NAME).limit(1).get();
          this.firestoreAvailable = true;
          this.firestoreError = null;
          console.log(`[OrderStore] Development Firestore connected. Accessible orders: ${probe.size}`);
        } else {
          this.firestoreAvailable = false;
          this.firestoreError = 'No Firestore project configured in development.';
        }
      } catch (err: any) {
        this.firestoreAvailable = false;
        this.firestoreError = err?.message || 'Development Firestore offline';
      }

      this.loadDevDiskOrders();
    }
  }

  // --------------------------------------------------------------------------
  // Development Sandbox Helpers (Strictly Prohibited & Inactive in Production)
  // --------------------------------------------------------------------------
  private static loadDevDiskOrders(): void {
    if (this.isProduction()) {
      console.warn('[OrderStore] Refusing to load local JSON files in production mode.');
      return;
    }
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const targetFile = fs.existsSync(DEV_ORDERS_FILE)
        ? DEV_ORDERS_FILE
        : fs.existsSync(LEGACY_ORDERS_FILE)
        ? LEGACY_ORDERS_FILE
        : null;

      if (targetFile) {
        const raw = fs.readFileSync(targetFile, 'utf-8');
        const orders: StoreOrder[] = JSON.parse(raw);
        this.devMemoryOrders = new Map(orders.map((o) => [o.id, o]));
        console.log(`[OrderStore] Loaded ${this.devMemoryOrders.size} order(s) for local development sandbox.`);
      }
    } catch (err) {
      console.error('[OrderStore] Failed to load development orders from disk:', err);
    }
  }

  private static saveDevDiskOrders(): void {
    if (this.isProduction()) {
      console.error(
        '[OrderStore] Security violation prevented: Attempted to write order to local disk in production mode.'
      );
      return;
    }
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const records = Array.from(this.devMemoryOrders.values());
      fs.writeFileSync(DEV_ORDERS_FILE, JSON.stringify(records, null, 2), 'utf-8');
    } catch (err) {
      console.error('[OrderStore] Failed to save development orders to disk:', err);
    }
  }

  // --------------------------------------------------------------------------
  // Authoritative Order Persistence Operations
  // --------------------------------------------------------------------------

  /**
   * Save a newly placed customer order.
   * In production: Firestore MUST be authoritative. Fails safely if Firestore is unavailable.
   */
  public static async createOrder(order: StoreOrder): Promise<StoreOrder> {
    await this.initialize();

    if (this.isProduction()) {
      // IN PRODUCTION: Firestore is authoritative.
      // Must NOT silently fallback to local JSON or ephemeral memory!
      if (!this.firestoreAvailable || !this.firestore) {
        const errorMsg = `Production order storage unavailable: Cloud Firestore is not connected (${this.firestoreError || 'unavailable'}). Refusing to store order in ephemeral memory or local disk.`;
        console.error(`[OrderStore] ${errorMsg}`);
        throw new Error(errorMsg);
      }

      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).set(order);
        console.log(`[OrderStore] Order ${order.id} (${order.orderReference}) durably saved to Cloud Firestore.`);
        return order;
      } catch (err: any) {
        const errorMsg = `Cloud Firestore write failed for order ${order.id}: ${err?.message || 'Unknown database write error'}`;
        console.error(`[OrderStore] ${errorMsg}`);
        throw new Error(errorMsg);
      }
    }

    // DEVELOPMENT / SANDBOX ONLY:
    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).set(order);
      } catch (err) {
        console.warn('[OrderStore] Development Firestore write failed, using dev disk sandbox:', err);
      }
    }

    this.devMemoryOrders.set(order.id, order);
    this.saveDevDiskOrders();
    return order;
  }

  /**
   * Lookup order by internal order ID.
   * In production: Reads authoritatively from Cloud Firestore.
   */
  public static async getOrderById(orderId: string): Promise<StoreOrder | null> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        console.error(`[OrderStore] Cannot lookup order ${orderId}: Cloud Firestore is unavailable in production.`);
        return null;
      }
      try {
        const doc = await this.firestore.collection(COLLECTION_NAME).doc(orderId).get();
        if (doc.exists) {
          return doc.data() as StoreOrder;
        }
        return null;
      } catch (err) {
        console.error(`[OrderStore] Firestore error fetching order ${orderId}:`, err);
        return null;
      }
    }

    // Development lookup
    if (this.devMemoryOrders.has(orderId)) {
      return this.devMemoryOrders.get(orderId)!;
    }

    if (this.firestoreAvailable && this.firestore) {
      try {
        const doc = await this.firestore.collection(COLLECTION_NAME).doc(orderId).get();
        if (doc.exists) {
          const data = doc.data() as StoreOrder;
          this.devMemoryOrders.set(orderId, data);
          return data;
        }
      } catch (err) {
        console.warn('[OrderStore] Dev Firestore getOrderById error:', err);
      }
    }

    return null;
  }

  /**
   * Lookup order by unique human/Paystack reference (e.g. sp_ord_xxx or paystack reference).
   * In production: Queries Cloud Firestore directly.
   */
  public static async getOrderByReference(reference: string): Promise<StoreOrder | null> {
    await this.initialize();
    const cleanRef = reference.trim();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        console.error(`[OrderStore] Cannot lookup reference ${cleanRef}: Cloud Firestore is unavailable in production.`);
        return null;
      }
      try {
        // Query by orderReference
        const snap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('orderReference', '==', cleanRef)
          .limit(1)
          .get();

        if (!snap.empty) {
          return snap.docs[0].data() as StoreOrder;
        }

        // Query by paystackReference
        const paystackSnap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('paystackReference', '==', cleanRef)
          .limit(1)
          .get();

        if (!paystackSnap.empty) {
          return paystackSnap.docs[0].data() as StoreOrder;
        }

        return null;
      } catch (err) {
        console.error(`[OrderStore] Firestore error querying order reference ${cleanRef}:`, err);
        return null;
      }
    }

    // Development lookup
    for (const order of this.devMemoryOrders.values()) {
      if (order.orderReference === cleanRef || order.paystackReference === cleanRef) {
        return order;
      }
    }

    if (this.firestoreAvailable && this.firestore) {
      try {
        const snap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('orderReference', '==', cleanRef)
          .limit(1)
          .get();

        if (!snap.empty) {
          const data = snap.docs[0].data() as StoreOrder;
          this.devMemoryOrders.set(data.id, data);
          return data;
        }
      } catch (err) {
        console.warn('[OrderStore] Dev Firestore getOrderByReference error:', err);
      }
    }

    return null;
  }

  /**
   * Retrieve all orders for a specific store owner (STRICT OWNER ISOLATION).
   * In production: Queries Cloud Firestore collection for matching ownerId.
   */
  public static async getOrdersByOwner(ownerId: string): Promise<StoreOrder[]> {
    await this.initialize();

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        console.error(`[OrderStore] Cannot list orders for owner ${ownerId}: Cloud Firestore is unavailable in production.`);
        return [];
      }
      try {
        const snap = await this.firestore
          .collection(COLLECTION_NAME)
          .where('ownerId', '==', ownerId)
          .get();

        const orders: StoreOrder[] = [];
        snap.forEach((doc) => {
          orders.push(doc.data() as StoreOrder);
        });

        // Strict owner isolation + sorted newest first
        orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return orders;
      } catch (err) {
        console.error(`[OrderStore] Firestore error listing orders for owner ${ownerId}:`, err);
        return [];
      }
    }

    // Development lookup
    const results: StoreOrder[] = [];
    for (const order of this.devMemoryOrders.values()) {
      if (order.ownerId === ownerId) {
        results.push(order);
      }
    }

    results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return results;
  }

  /**
   * Update payment status (ONLY callable via server-side verification / webhook).
   * In production: Updates authoritative Cloud Firestore record.
   */
  public static async updatePaymentStatus(
    reference: string,
    paymentStatus: OrderPaymentStatus,
    paystackData?: {
      paystackReference?: string;
      channel?: string;
      paidAt?: string;
    }
  ): Promise<StoreOrder | null> {
    const order = await this.getOrderByReference(reference);
    if (!order) return null;

    // Idempotency: If already marked as PAID and incoming status is PAID, return as-is
    if (order.paymentStatus === 'PAID' && paymentStatus === 'PAID') {
      return order;
    }

    const updated: StoreOrder = {
      ...order,
      paymentStatus,
      paystackReference: paystackData?.paystackReference || order.paystackReference || reference,
      paystackChannel: paystackData?.channel || order.paystackChannel,
      paidAt: paystackData?.paidAt || (paymentStatus === 'PAID' ? new Date().toISOString() : order.paidAt),
      updatedAt: new Date().toISOString(),
    };

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        const errorMsg = `Cannot update payment status for order ${order.id}: Cloud Firestore is unavailable in production.`;
        console.error(`[OrderStore] ${errorMsg}`);
        throw new Error(errorMsg);
      }
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update({
          paymentStatus,
          paystackReference: updated.paystackReference,
          paystackChannel: updated.paystackChannel,
          paidAt: updated.paidAt,
          updatedAt: updated.updatedAt,
        });
        console.log(`[OrderStore] Production payment status updated to ${paymentStatus} for order ${order.id}`);
        return updated;
      } catch (err: any) {
        console.error(`[OrderStore] Firestore updatePaymentStatus failed:`, err);
        throw new Error(`Failed to update payment status in Cloud Firestore: ${err?.message || 'Database error'}`);
      }
    }

    // Development sandbox update
    this.devMemoryOrders.set(order.id, updated);
    this.saveDevDiskOrders();

    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update({
          paymentStatus,
          paystackReference: updated.paystackReference,
          paystackChannel: updated.paystackChannel,
          paidAt: updated.paidAt,
          updatedAt: updated.updatedAt,
        });
      } catch (err) {
        console.warn('[OrderStore] Dev Firestore updatePaymentStatus error:', err);
      }
    }

    return updated;
  }

  /**
   * Update fulfillment/order status (Store owners can update fulfillment, NOT payment status).
   * In production: Updates authoritative Cloud Firestore record.
   */
  public static async updateOrderStatus(
    orderId: string,
    ownerId: string,
    orderStatus: OrderFulfillmentStatus
  ): Promise<StoreOrder | null> {
    const order = await this.getOrderById(orderId);
    if (!order) {
      throw new Error(`Order not found with id: ${orderId}`);
    }

    // Strict owner verification
    if (order.ownerId !== ownerId) {
      throw new Error('Forbidden: You do not own the website associated with this order.');
    }

    const updated: StoreOrder = {
      ...order,
      orderStatus,
      updatedAt: new Date().toISOString(),
    };

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        throw new Error('Cannot update order status: Cloud Firestore is unavailable in production.');
      }
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update({
          orderStatus,
          updatedAt: updated.updatedAt,
        });
        return updated;
      } catch (err: any) {
        throw new Error(`Failed to update order status in Cloud Firestore: ${err?.message || 'Database error'}`);
      }
    }

    // Development sandbox update
    this.devMemoryOrders.set(order.id, updated);
    this.saveDevDiskOrders();

    if (this.firestoreAvailable && this.firestore) {
      try {
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update({
          orderStatus,
          updatedAt: updated.updatedAt,
        });
      } catch (err) {
        console.warn('[OrderStore] Dev Firestore updateOrderStatus error:', err);
      }
    }

    return updated;
  }

  /**
   * Update Printify fulfillment data and sync status for an order.
   */
  public static async updatePrintifyFulfillment(
    orderId: string,
    printifyOrder: PrintifyOrderFulfillment,
    newOrderStatus?: OrderFulfillmentStatus
  ): Promise<StoreOrder | null> {
    const order = await this.getOrderById(orderId);
    if (!order) {
      throw new Error(`Order not found with id: ${orderId}`);
    }

    const updated: StoreOrder = {
      ...order,
      printifyOrder,
      orderStatus: newOrderStatus || order.orderStatus,
      updatedAt: new Date().toISOString(),
    };

    if (this.isProduction()) {
      if (!this.firestoreAvailable || !this.firestore) {
        throw new Error('Cannot update Printify fulfillment: Cloud Firestore is unavailable in production.');
      }
      try {
        const updatePayload: any = {
          printifyOrder,
          updatedAt: updated.updatedAt,
        };
        if (newOrderStatus) {
          updatePayload.orderStatus = newOrderStatus;
        }
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update(updatePayload);
        return updated;
      } catch (err: any) {
        throw new Error(`Failed to update Printify fulfillment in Cloud Firestore: ${err?.message || 'Database error'}`);
      }
    }

    // Development sandbox update
    this.devMemoryOrders.set(order.id, updated);
    this.saveDevDiskOrders();

    if (this.firestoreAvailable && this.firestore) {
      try {
        const updatePayload: any = {
          printifyOrder,
          updatedAt: updated.updatedAt,
        };
        if (newOrderStatus) {
          updatePayload.orderStatus = newOrderStatus;
        }
        await this.firestore.collection(COLLECTION_NAME).doc(order.id).update(updatePayload);
      } catch (err) {
        console.warn('[OrderStore] Dev Firestore updatePrintifyFulfillment error:', err);
      }
    }

    return updated;
  }
}
