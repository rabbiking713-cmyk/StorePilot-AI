import { CustomDomainConfig } from '../../types/customDomain';
import { WebsiteSpec } from '../../types/websiteSpec';
import { authenticatedFetch } from '../auth/apiClient';

export interface DomainLookupResult {
  success: boolean;
  verified?: boolean;
  config?: CustomDomainConfig;
  site?: {
    name: string;
    slug: string;
    description?: string;
    publishedAt: string;
    publishedVersion: number;
    spec: WebsiteSpec;
  } | null;
  error?: string;
}

export class DomainService {
  /**
   * Client-side normalization and validation for instantaneous UI feedback
   */
  static normalizeDomain(raw: string): { valid: boolean; normalized: string; error?: string } {
    if (!raw || typeof raw !== 'string') {
      return { valid: false, normalized: '', error: 'Domain name cannot be empty.' };
    }

    let cleaned = raw.trim().toLowerCase();
    cleaned = cleaned.replace(/^https?:\/\//i, '');
    cleaned = cleaned.split('/')[0].split('?')[0].split('#')[0];
    cleaned = cleaned.split(':')[0];
    cleaned = cleaned.replace(/^\.+|\.+$/g, '');

    if (!cleaned) {
      return { valid: false, normalized: '', error: 'Domain name cannot be empty.' };
    }

    if (cleaned.length > 253) {
      return { valid: false, normalized: '', error: 'Domain is too long (maximum 253 characters).' };
    }

    if (cleaned === 'localhost' || /^(\d{1,3}\.){3}\d{1,3}$/.test(cleaned)) {
      return { valid: false, normalized: '', error: 'IP addresses and localhost cannot be connected.' };
    }

    if (cleaned.endsWith('.storepilot.ai') || cleaned === 'storepilot.ai' || cleaned.endsWith('.run.app')) {
      return { valid: false, normalized: '', error: 'Please enter an external domain that you own.' };
    }

    const domainRegex = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
    if (!domainRegex.test(cleaned)) {
      return {
        valid: false,
        normalized: '',
        error: 'Invalid domain syntax. Example: mybrand.com or www.mybrand.com',
      };
    }

    return { valid: true, normalized: cleaned };
  }

  /**
   * Get domain configuration for a given website
   */
  static async getDomainConfig(websiteId: string): Promise<CustomDomainConfig | null> {
    try {
      const res = await fetch(`/api/domains/website/${encodeURIComponent(websiteId)}`);
      if (!res.ok) return null;
      const data = await res.json();
      return data.success ? data.config : null;
    } catch (err) {
      console.error('Failed to get domain config:', err);
      return null;
    }
  }

  /**
   * Connect / register a custom domain
   */
  static async connectDomain(params: {
    websiteId: string;
    domain: string;
    userId: string;
  }): Promise<{ success: boolean; config?: CustomDomainConfig; error?: string; message?: string }> {
    try {
      const res = await authenticatedFetch('/api/domains/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to connect custom domain.' };
      }
      return { success: true, config: data.config, message: data.message };
    } catch (err: any) {
      console.error('Error connecting custom domain:', err);
      return { success: false, error: err?.message || 'Network error connecting custom domain.' };
    }
  }

  /**
   * Verify domain ownership via real DNS TXT lookup
   */
  static async verifyDomain(params: {
    websiteId: string;
    domain: string;
    userId: string;
  }): Promise<{ success: boolean; verified: boolean; config?: CustomDomainConfig; error?: string; message?: string }> {
    try {
      const res = await authenticatedFetch('/api/domains/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (res.status === 429) {
        return { success: false, verified: false, error: data.error || 'Please wait a moment before checking again.' };
      }
      if (!res.ok || !data.success) {
        return {
          success: false,
          verified: false,
          config: data.config,
          error: data.error || 'DNS verification record not detected yet.',
        };
      }
      return { success: true, verified: true, config: data.config, message: data.message };
    } catch (err: any) {
      console.error('Error verifying domain:', err);
      return { success: false, verified: false, error: err?.message || 'Network error during verification.' };
    }
  }

  /**
   * Set domain as primary
   */
  static async setPrimaryDomain(params: {
    websiteId: string;
    domain: string;
    userId: string;
    isPrimary: boolean;
  }): Promise<{ success: boolean; config?: CustomDomainConfig; error?: string }> {
    try {
      const res = await authenticatedFetch('/api/domains/set-primary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      return data.success ? { success: true, config: data.config } : { success: false, error: data.error };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }

  /**
   * Disconnect domain
   */
  static async disconnectDomain(params: {
    websiteId: string;
    domain: string;
    userId: string;
  }): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await authenticatedFetch('/api/domains/disconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      return data.success ? { success: true, message: data.message } : { success: false, error: data.error };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }

  /**
   * Lookup website by custom domain hostname
   */
  static async lookupDomain(hostname: string): Promise<DomainLookupResult> {
    try {
      const res = await fetch(`/api/domains/lookup/${encodeURIComponent(hostname)}`);
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Domain not found' };
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to lookup domain' };
    }
  }

  /**
   * Simulate test verification in development/testing mode
   */
  static async simulateTestVerify(params: {
    websiteId: string;
    domain: string;
    userId: string;
    activate?: boolean;
  }): Promise<{ success: boolean; verified: boolean; config?: CustomDomainConfig; error?: string }> {
    try {
      const res = await fetch('/api/domains/test-simulate-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      return data;
    } catch (err: any) {
      return { success: false, verified: false, error: err?.message };
    }
  }
}
