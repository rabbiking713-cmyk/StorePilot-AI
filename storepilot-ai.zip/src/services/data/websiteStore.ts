import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Website, WebsiteSpec } from '../../types';

const DATA_DIR = path.join(process.cwd(), 'data');
const WEBSITES_FILE = path.join(DATA_DIR, 'websites.json');

const STARTER_SPEC: WebsiteSpec = {
  siteName: 'Aura Artisan Coffee',
  businessName: 'Aura Artisan Coffee Roasters',
  tagline: 'Single-origin beans, roasted with intention.',
  businessDescription:
    'Specialty micro-roastery and neighborhood espresso bar featuring ethically sourced single-origin coffees, handcrafted brews, and fresh daily pastries.',
  industry: 'Specialty Dining & Cafe',
  targetAudience: 'Coffee enthusiasts, neighborhood creatives, and quality-minded founders.',
  theme: {
    primaryColor: '#78350f',
    accentColor: '#d97706',
    backgroundColor: '#fffbeb',
    textColor: '#1c1917',
    fontFamily: 'serif',
    styleMood: 'Warm & Artisanal',
  },
  header: {
    brandName: 'AURA',
    tagline: 'Artisan Coffee Roasters',
    navLinks: [
      { id: 'n1', label: 'Our Story', targetSectionId: 'about' },
      { id: 'n2', label: 'Coffee Beans', targetSectionId: 'products' },
      { id: 'n3', label: 'Roasting Craft', targetSectionId: 'features' },
      { id: 'n4', label: 'Visit Us', targetSectionId: 'contact' },
    ],
    ctaButton: {
      label: 'Order Beans',
      targetSectionId: 'products',
    },
  },
  sections: [
    {
      type: 'hero',
      id: 'hero',
      badge: 'Direct-Trade Micro-Lots',
      headline: 'Exceptional coffee for mindful mornings.',
      subheadline:
        'Sourced transparently from high-elevation family farms in Ethiopia, Colombia, and Costa Rica. Small-batch roasted in Portland every Tuesday.',
      primaryCta: { label: 'Explore Coffees', targetSectionId: 'products' },
      secondaryCta: { label: 'Visit the Roastery', targetSectionId: 'contact' },
      imageUrl:
        'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80',
    },
    {
      type: 'features',
      id: 'features',
      title: 'The Aura Standard',
      subtitle: 'Uncompromising quality from cherry to cup.',
      items: [
        {
          id: 'f1',
          title: 'Direct-Origin Traceability',
          description:
            'We pay 80% above Fair Trade minimums directly to farm cooperatives, supporting sustainable agroforestry.',
          iconName: 'Heart',
        },
        {
          id: 'f2',
          title: 'Precision Micro-Batch Roasting',
          description:
            'Every lot is profiled on our vintage cast-iron roaster to highlight terroir, stone fruit sweetness, and floral aromatics.',
          iconName: 'Zap',
        },
        {
          id: 'f3',
          title: 'Fresh to Your Door',
          description:
            'Shipped within 24 hours of roasting in 100% compostable, nitrogen-flushed valve bags.',
          iconName: 'Truck',
        },
      ],
    },
    {
      type: 'products',
      id: 'products',
      title: 'Current Seasonal Harvests',
      subtitle: 'Selected single-origin coffees available whole-bean or custom ground.',
      currencySymbol: '$',
      ctaLabel: 'Add to Cart',
      items: [
        {
          id: 'p1',
          name: 'Yirgacheffe Gedeb Organic',
          price: '22.00',
          category: 'Single Origin',
          badge: 'Staff Favorite',
          description: 'Bergamot, jasmine blossom, wild honey, and sweet lemon marmalade.',
          imageUrl:
            'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
        },
        {
          id: 'p2',
          name: 'Huila San Agustin Pink Bourbon',
          price: '24.00',
          category: 'Limited Micro-Lot',
          badge: 'Rare Harvest',
          description: 'White peach, ripe raspberry, cacao nibs, and silky brown sugar mouthfeel.',
          imageUrl:
            'https://images.unsplash.com/photo-1587734195503-904fca47e0e9?auto=format&fit=crop&w=800&q=80',
        },
        {
          id: 'p3',
          name: 'Aura Signature House Espresso',
          price: '19.50',
          category: 'House Blend',
          badge: 'Best Seller',
          description: 'Rich dark chocolate, hazelnut praline, and candied orange zest.',
          imageUrl:
            'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=800&q=80',
        },
      ],
    },
    {
      type: 'about',
      id: 'about',
      title: 'Our Roots',
      headline: 'Rooted in reverence for the ritual.',
      content:
        'Aura started in 2021 inside a repurposed timber warehouse. Our goal was simple: create an unpretentious space where great coffee meets genuine hospitality.\n\nWe roast in small batches, cup every batch rigorously, and treat coffee not as commodity fuel, but as a botanical craft.',
      highlights: [
        'Certified B-Corp pending & Carbon-Neutral roasting',
        'Transparent farm gate prices published annually',
        'Free community cupping sessions every Saturday',
      ],
      imageUrl:
        'https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=80',
    },
    {
      type: 'testimonials',
      id: 'testimonials',
      title: 'Loved by Purists & Cafes',
      subtitle: 'What coffee critics and regular visitors say about Aura.',
      items: [
        {
          id: 't1',
          quote:
            'The Yirgacheffe Gedeb is easily the cleanest washed Ethiopian coffee I have tasted this year. Incredible clarity and florality.',
          author: 'Marcus Vance',
          role: 'Editor, Specialty Coffee Review',
          rating: 5,
        },
        {
          id: 't2',
          quote:
            'Our design agency has Aura on subscription every Monday. The whole studio smells divine and the beans never fail to impress.',
          author: 'Elena Gomez',
          role: 'Founder, Forma Design Studio',
          rating: 5,
        },
      ],
    },
    {
      type: 'cta',
      id: 'cta',
      headline: 'Fresh coffee delivered on your schedule.',
      subheadline:
        'Subscribe to monthly roaster picks and save 15% on every bag. Pause or cancel anytime with one click.',
      buttonLabel: 'Start Coffee Subscription',
      targetSectionId: 'products',
    },
    {
      type: 'contact',
      id: 'contact',
      title: 'Visit Our Roastery & Espresso Bar',
      subtitle: 'Come say hello, drink a pour-over, and watch our roaster in action.',
      email: 'hello@auracoffee.store',
      phone: '+1 (503) 555-0194',
      address: '428 SE Industrial Way, Portland, OR 97214',
      hours: 'Mon - Fri: 7am - 4pm | Sat - Sun: 8am - 5pm',
      formEnabled: true,
    },
  ],
  footer: {
    brandName: 'AURA Artisan Coffee Roasters',
    copyright: `© ${new Date().getFullYear()} Aura Artisan Coffee. Powered by StorePilot AI.`,
    description: 'Direct-trade specialty coffees roasted with care in Portland, Oregon.',
    quickLinks: [
      { label: 'Shop Coffee', href: '#products' },
      { label: 'Our Story', href: '#about' },
      { label: 'Wholesale Inquiries', href: '#contact' },
    ],
  },
};

export class WebsiteStore {
  private static websitesMap = new Map<string, Website>();
  private static isLoaded = false;

  private static ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (err) {
        console.warn('[WebsiteStore] Failed to create data dir:', err);
      }
    }
  }

  public static initialize(): void {
    if (this.isLoaded) return;
    this.isLoaded = true;
    this.ensureDataDir();

    try {
      if (fs.existsSync(WEBSITES_FILE)) {
        const raw = fs.readFileSync(WEBSITES_FILE, 'utf8');
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && item.id && item.ownerId) {
              this.websitesMap.set(item.id, item);
            }
          }
          console.log(`[WebsiteStore] Loaded ${this.websitesMap.size} website project(s) from persistent storage.`);
        }
      }
    } catch (err) {
      console.warn('[WebsiteStore] Failed to load websites file:', err);
    }
  }

  private static persist(): void {
    this.ensureDataDir();
    try {
      const list = Array.from(this.websitesMap.values());
      fs.writeFileSync(WEBSITES_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (err) {
      console.error('[WebsiteStore] Error persisting websites:', err);
    }
  }

  /**
   * Retrieves all websites belonging to the authenticated Firebase UID.
   * If the user has 0 websites, provisions a starter website so their dashboard is ready.
   */
  public static async getWebsitesByOwner(ownerId: string): Promise<Website[]> {
    this.initialize();
    const userSites = Array.from(this.websitesMap.values()).filter((s) => s.ownerId === ownerId);

    if (userSites.length === 0) {
      const now = new Date().toISOString();
      const starterId = `site_${ownerId.slice(0, 8)}_starter`;
      const starterSite: Website = {
        id: starterId,
        ownerId,
        name: 'Aura Artisan Coffee',
        slug: 'aura-coffee',
        businessType: 'Retail & Cafe',
        description: 'Specialty micro-roastery and neighborhood espresso bar featuring single-origin beans and seasonal pastries.',
        status: 'draft',
        pagesCount: 3,
        createdAt: now,
        updatedAt: now,
        customDomain: 'auracoffee.store',
        originalPrompt: 'A specialty micro-roastery and neighborhood espresso bar called Aura Artisan Coffee featuring single-origin beans and seasonal pastries.',
        spec: STARTER_SPEC,
      };

      this.websitesMap.set(starterId, starterSite);
      this.persist();
      return [starterSite];
    }

    return userSites.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  public static async getWebsiteById(id: string, ownerId: string): Promise<Website | null> {
    this.initialize();
    const site = this.websitesMap.get(id);
    if (!site || site.ownerId !== ownerId) {
      return null;
    }
    return site;
  }

  public static async upsertWebsite(website: Website): Promise<Website> {
    this.initialize();
    this.websitesMap.set(website.id, website);
    this.persist();
    return website;
  }

  public static async createWebsite(
    ownerId: string,
    payload: {
      id?: string;
      name: string;
      businessType: string;
      description: string;
      originalPrompt?: string;
      spec?: WebsiteSpec;
      isDemo?: boolean;
    }
  ): Promise<Website> {
    this.initialize();
    const siteId = payload.id || `site_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const slug = payload.name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'my-store';

    const now = new Date().toISOString();
    const newSite: Website = {
      id: siteId,
      ownerId, // Server authoritative from verified Firebase UID
      name: payload.name.trim(),
      slug,
      businessType: payload.businessType.trim() || 'General Business',
      description: payload.description.trim(),
      status: 'draft',
      pagesCount: 1,
      originalPrompt: payload.originalPrompt,
      spec: payload.spec,
      isDemo: Boolean(payload.isDemo),
      createdAt: now,
      updatedAt: now,
    };

    this.websitesMap.set(siteId, newSite);
    this.persist();
    return newSite;
  }

  public static async updateWebsite(
    id: string,
    ownerId: string,
    updates: Partial<Omit<Website, 'id' | 'ownerId' | 'createdAt'>>
  ): Promise<Website> {
    this.initialize();
    const existing = this.websitesMap.get(id);
    if (!existing) {
      throw new Error('Website not found.');
    }
    if (existing.ownerId !== ownerId) {
      throw new Error('Forbidden: You do not have permission to update this website.');
    }

    const updated: Website = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.websitesMap.set(id, updated);
    this.persist();
    return updated;
  }

  public static async deleteWebsite(id: string, ownerId: string): Promise<boolean> {
    this.initialize();
    const existing = this.websitesMap.get(id);
    if (!existing) {
      return false;
    }
    if (existing.ownerId !== ownerId) {
      throw new Error('Forbidden: You do not have permission to delete this website.');
    }

    this.websitesMap.delete(id);
    this.persist();
    return true;
  }

  public static async duplicateWebsite(id: string, ownerId: string): Promise<Website> {
    this.initialize();
    const existing = this.websitesMap.get(id);
    if (!existing) {
      throw new Error('Website not found.');
    }
    if (existing.ownerId !== ownerId) {
      throw new Error('Forbidden: You do not have permission to duplicate this website.');
    }

    const newId = `site_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const now = new Date().toISOString();
    const cloned: Website = {
      ...existing,
      id: newId,
      ownerId,
      name: `${existing.name} (Copy)`,
      slug: `${existing.slug}-copy`,
      status: 'draft',
      publishStatus: 'draft',
      publishedSlug: undefined,
      publishedAt: undefined,
      customDomain: undefined,
      customDomainConfig: undefined,
      createdAt: now,
      updatedAt: now,
    };

    this.websitesMap.set(newId, cloned);
    this.persist();
    return cloned;
  }
}
