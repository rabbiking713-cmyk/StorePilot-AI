import {
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  where,
} from 'firebase/firestore';
import { db, auth } from '../firebase/firebaseConfig';
import { Website, CustomDomainConfig } from '../../types';
import { WebsiteSpec } from '../../types/websiteSpec';
import { AuthService } from '../auth/authService';

const WEBSITES_STORAGE_KEY_PREFIX = 'storepilot_sites_';

const STARTER_SPEC: WebsiteSpec = {
  siteName: 'Aura Artisan Coffee',
  businessName: 'Aura Artisan Coffee Roasters',
  tagline: 'Single-origin beans, roasted with intention.',
  businessDescription:
    'Specialty micro-roastery and neighborhood espresso bar featuring ethically sourced single-origin coffees, handcrafted brews, and fresh daily pastries.',
  industry: 'Specialty Dining & Cafe',
  targetAudience: 'Coffee enthusiasts, neighborhood creatives, and quality-minded founders.',
  theme: {
    primaryColor: '#78350f',
    accentColor: '#d97706',
    backgroundColor: '#fffbeb',
    textColor: '#1c1917',
    fontFamily: 'serif',
    styleMood: 'Warm & Artisanal',
  },
  header: {
    brandName: 'AURA',
    tagline: 'Artisan Coffee Roasters',
    navLinks: [
      { id: 'n1', label: 'Our Story', targetSectionId: 'about' },
      { id: 'n2', label: 'Coffee Beans', targetSectionId: 'products' },
      { id: 'n3', label: 'Roasting Craft', targetSectionId: 'features' },
      { id: 'n4', label: 'Visit Us', targetSectionId: 'contact' },
    ],
    ctaButton: {
      label: 'Order Beans',
      targetSectionId: 'products',
    },
  },
  sections: [
    {
      type: 'hero',
      id: 'hero',
      badge: 'Direct-Trade Micro-Lots',
      headline: 'Exceptional coffee for mindful mornings.',
      subheadline:
        'Sourced transparently from high-elevation family farms in Ethiopia, Colombia, and Costa Rica. Small-batch roasted in Portland every Tuesday.',
      primaryCta: { label: 'Explore Coffees', targetSectionId: 'products' },
      secondaryCta: { label: 'Visit the Roastery', targetSectionId: 'contact' },
      imageUrl:
        'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80',
    },
    {
      type: 'features',
      id: 'features',
      title: 'The Aura Standard',
      subtitle: 'Uncompromising quality from cherry to cup.',
      items: [
        {
          id: 'f1',
          title: 'Direct-Origin Traceability',
          description:
            'We pay 80% above Fair Trade minimums directly to farm cooperatives, supporting sustainable agroforestry.',
          iconName: 'Heart',
        },
        {
          id: 'f2',
          title: 'Precision Micro-Batch Roasting',
          description:
            'Every lot is profiled on our vintage cast-iron roaster to highlight terroir, stone fruit sweetness, and floral aromatics.',
          iconName: 'Zap',
        },
        {
          id: 'f3',
          title: 'Fresh to Your Door',
          description:
            'Shipped within 24 hours of roasting in 100% compostable, nitrogen-flushed valve bags.',
          iconName: 'Truck',
        },
      ],
    },
    {
      type: 'products',
      id: 'products',
      title: 'Current Seasonal Harvests',
      subtitle: 'Selected single-origin coffees available whole-bean or custom ground.',
      currencySymbol: '$',
      ctaLabel: 'Add to Cart',
      items: [
        {
          id: 'p1',
          name: 'Yirgacheffe Gedeb Organic',
          price: '22.00',
          category: 'Single Origin',
          badge: 'Staff Favorite',
          description: 'Bergamot, jasmine blossom, wild honey, and sweet lemon marmalade.',
          imageUrl:
            'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
        },
        {
          id: 'p2',
          name: 'Huila San Agustin Pink Bourbon',
          price: '24.00',
          category: 'Limited Micro-Lot',
          badge: 'Rare Harvest',
          description: 'White peach, ripe raspberry, cacao nibs, and silky brown sugar mouthfeel.',
          imageUrl:
            'https://images.unsplash.com/photo-1587734195503-904fca47e0e9?auto=format&fit=crop&w=800&q=80',
        },
        {
          id: 'p3',
          name: 'Aura Signature House Espresso',
          price: '19.50',
          category: 'House Blend',
          badge: 'Best Seller',
          description: 'Rich dark chocolate, hazelnut praline, and candied orange zest.',
          imageUrl:
            'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=800&q=80',
        },
      ],
    },
    {
      type: 'about',
      id: 'about',
      title: 'Our Roots',
      headline: 'Rooted in reverence for the ritual.',
      content:
        'Aura started in 2021 inside a repurposed timber warehouse. Our goal was simple: create an unpretentious space where great coffee meets genuine hospitality.\n\nWe roast in small batches, cup every batch rigorously, and treat coffee not as commodity fuel, but as a botanical craft.',
      highlights: [
        'Certified B-Corp pending & Carbon-Neutral roasting',
        'Transparent farm gate prices published annually',
        'Free community cupping sessions every Saturday',
      ],
      imageUrl:
        'https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=80',
    },
    {
      type: 'testimonials',
      id: 'testimonials',
      title: 'Loved by Purists & Cafes',
      subtitle: 'What coffee critics and regular visitors say about Aura.',
      items: [
        {
          id: 't1',
          quote:
            'The Yirgacheffe Gedeb is easily the cleanest washed Ethiopian coffee I have tasted this year. Incredible clarity and florality.',
          author: 'Marcus Vance',
          role: 'Editor, Specialty Coffee Review',
          rating: 5,
        },
        {
          id: 't2',
          quote:
            'Our design agency has Aura on subscription every Monday. The whole studio smells divine and the beans never fail to impress.',
          author: 'Elena Gomez',
          role: 'Founder, Forma Design Studio',
          rating: 5,
        },
      ],
    },
    {
      type: 'cta',
      id: 'cta',
      headline: 'Fresh coffee delivered on your schedule.',
      subheadline:
        'Subscribe to monthly roaster picks and save 15% on every bag. Pause or cancel anytime with one click.',
      buttonLabel: 'Start Coffee Subscription',
      targetSectionId: 'products',
    },
    {
      type: 'contact',
      id: 'contact',
      title: 'Visit Our Roastery & Espresso Bar',
      subtitle: 'Come say hello, drink a pour-over, and watch our roaster in action.',
      email: 'hello@auracoffee.store',
      phone: '+1 (503) 555-0194',
      address: '428 SE Industrial Way, Portland, OR 97214',
      hours: 'Mon - Fri: 7am - 4pm | Sat - Sun: 8am - 5pm',
      formEnabled: true,
    },
  ],
  footer: {
    brandName: 'AURA Artisan Coffee Roasters',
    copyright: '© 2026 Aura Artisan Coffee. Powered by StorePilot AI.',
    description: 'Direct-trade specialty coffees roasted with care in Portland, Oregon.',
    quickLinks: [
      { label: 'Shop Coffee', href: '#products' },
      { label: 'Our Story', href: '#about' },
      { label: 'Wholesale Inquiries', href: '#contact' },
    ],
  },
};

/**
 * Recursively strips undefined fields from an object so that Firestore setDoc
 * will never fail with "Unsupported field value: undefined".
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as any;
  }
  if (typeof data === 'object' && data !== null) {
    const cleaned: Record<string, any> = {};
    for (const [key, val] of Object.entries(data)) {
      if (val !== undefined) {
        cleaned[key] = sanitizeForFirestore(val);
      }
    }
    return cleaned as T;
  }
  return data;
}

export class WebsiteService {
  private static memoryCache = new Map<string, Website[]>();

  public static clearMemoryCache(userId?: string): void {
    if (userId) {
      this.memoryCache.delete(userId);
    } else {
      this.memoryCache.clear();
    }
  }

  public static getCachedWebsitesForUser(userId: string): Website[] | null {
    if (this.memoryCache.has(userId)) {
      return this.memoryCache.get(userId)!;
    }
    return null;
  }

  /**
   * Direct authoritative Cloud Firestore write using authenticated client SDK
   */
  public static async saveWebsiteDirectly(website: Website): Promise<void> {
    const canonicalOwnerId = auth.currentUser?.uid || website.ownerId;
    const pristine = sanitizeForFirestore({
      ...website,
      ownerId: canonicalOwnerId,
      updatedAt: new Date().toISOString(),
    });
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        await setDoc(doc(db, 'websites', website.id), pristine);
        console.log(`[WebsiteService] Saved website ${website.id} to Cloud Firestore.`);
      } catch (err) {
        console.error('[WebsiteService] Error in saveWebsiteDirectly:', err);
        throw err;
      }
    }
  }

  private static async getAuthHeaders(): Promise<Record<string, string>> {
    const token = await AuthService.getIdToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  /**
   * Fetches authoritative user websites directly from Cloud Firestore.
   * Cross-device persistence: Any device logged into this Firebase account
   * queries Firestore using the authenticated Firebase UID.
   */
  public static async fetchWebsitesForUser(userId: string): Promise<Website[]> {
    if (!userId) return [];

    // Ensure Firebase auth state is ready
    try {
      if (typeof auth.authStateReady === 'function') {
        await auth.authStateReady();
      }
    } catch {
      // ignore
    }

    const currentUser = auth.currentUser;
    // 1. Direct Cloud Firestore query using Firebase Client SDK & Auth identity
    if (currentUser && currentUser.uid === userId) {
      try {
        const q = query(collection(db, 'websites'), where('ownerId', '==', userId));
        const querySnapshot = await getDocs(q);
        const firestoreSites: Website[] = [];
        querySnapshot.forEach((docSnap) => {
          const data = docSnap.data() as Website;
          if (data && data.id && data.ownerId === userId) {
            firestoreSites.push(data);
          }
        });

        // Sort by updatedAt descending
        firestoreSites.sort((a, b) => new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime());

        if (firestoreSites.length === 0) {
          // New merchant account: Provision authoritative initial starter site directly in Cloud Firestore
          const starterId = `site_${userId.slice(0, 8)}_starter`;
          const starterSite: Website = {
            id: starterId,
            ownerId: userId,
            name: 'Aura Artisan Coffee',
            slug: 'aura-coffee',
            businessType: 'Retail & Cafe',
            description: 'Specialty micro-roastery and neighborhood espresso bar featuring single-origin beans and seasonal pastries.',
            status: 'draft',
            pagesCount: 3,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            customDomain: 'auracoffee.store',
            originalPrompt: 'A specialty micro-roastery and neighborhood espresso bar called Aura Artisan Coffee featuring single-origin beans and seasonal pastries.',
            spec: STARTER_SPEC,
          };

          try {
            await setDoc(doc(db, 'websites', starterId), sanitizeForFirestore(starterSite));
            firestoreSites.push(starterSite);
          } catch (seedErr) {
            console.warn('[WebsiteService] Initial starter site Firestore write warning:', seedErr);
            firestoreSites.push(starterSite);
          }
        }

        this.memoryCache.set(userId, firestoreSites);
        return firestoreSites;
      } catch (firestoreErr) {
        console.warn('[WebsiteService] Firestore read warning, checking fallback server sync:', firestoreErr);
      }
    }

    // 2. Secondary server sync fallback (for local demo or offline state)
    try {
      const headers = await this.getAuthHeaders();
      const res = await fetch('/api/websites', { headers });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.websites)) {
          this.memoryCache.set(userId, data.websites);
          return data.websites;
        }
      }
    } catch (err) {
      console.warn('[WebsiteService] Server fetch failed:', err);
    }

    return this.getWebsitesForUser(userId);
  }

  /**
   * Synchronous cached retrieval for active UI sessions
   */
  public static getWebsitesForUser(userId: string): Website[] {
    if (this.memoryCache.has(userId)) {
      return this.memoryCache.get(userId)!;
    }

    // For demo accounts, seed in-memory starter
    if (userId === 'demo-founder-uid' || userId.includes('demo')) {
      const demoStarter: Website = {
        id: `site_demo_starter`,
        ownerId: userId,
        name: 'Aura Artisan Coffee',
        slug: 'aura-coffee',
        businessType: 'Retail & Cafe',
        description: 'Specialty micro-roastery and neighborhood espresso bar featuring single-origin beans and seasonal pastries.',
        status: 'draft',
        pagesCount: 3,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        customDomain: 'auracoffee.store',
        originalPrompt: 'A specialty micro-roastery and neighborhood espresso bar called Aura Artisan Coffee featuring single-origin beans and seasonal pastries.',
        spec: STARTER_SPEC,
        isDemo: true,
      };
      this.memoryCache.set(userId, [demoStarter]);
      return [demoStarter];
    }

    return [];
  }

  public static saveWebsitesForUser(userId: string, sites: Website[]): void {
    this.memoryCache.set(userId, sites);
  }

  /**
   * Creates a new website and writes directly to Cloud Firestore with ownerId = currentUser.uid
   */
  public static createWebsite(
    userId: string,
    payload: {
      name: string;
      businessType: string;
      description: string;
      originalPrompt?: string;
      spec?: WebsiteSpec;
      isDemo?: boolean;
    }
  ): Website {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const slug = payload.name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'my-store';

    const newSiteId = 'site_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    const now = new Date().toISOString();

    const newSite: Website = {
      id: newSiteId,
      ownerId: canonicalOwnerId,
      name: payload.name.trim(),
      slug,
      businessType: payload.businessType.trim() || 'General Business',
      description: payload.description.trim(),
      status: 'draft',
      pagesCount: 1,
      originalPrompt: payload.originalPrompt,
      spec: payload.spec,
      isDemo: payload.isDemo,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [newSite, ...sites];
    this.memoryCache.set(canonicalOwnerId, updated);

    // 1. Authoritative Cloud Firestore persistence directly from authenticated client SDK
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', newSite.id), sanitizeForFirestore(newSite))
          .then(() => {
            console.log(`[WebsiteService] Successfully saved website ${newSite.id} to Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to write website to Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error writing website to Firestore:', syncErr);
      }
    }

    // 2. Concurrently persist to server in background
    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch('/api/websites', {
          method: 'POST',
          headers,
          body: JSON.stringify({ ...payload, id: newSite.id }),
        });
      } catch (e) {
        console.warn('[WebsiteService] Server creation sync failed:', e);
      }
    })();

    return newSite;
  }

  /**
   * Deletes a website directly in Cloud Firestore and updates local state
   */
  public static deleteWebsite(userId: string, siteId: string): Website[] {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const filtered = sites.filter((s) => s.id !== siteId);
    this.memoryCache.set(canonicalOwnerId, filtered);

    // 1. Authoritative Cloud Firestore delete
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        deleteDoc(doc(db, 'websites', siteId))
          .then(() => {
            console.log(`[WebsiteService] Successfully deleted website ${siteId} from Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to delete website from Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error deleting website from Firestore:', syncErr);
      }
    }

    // 2. Concurrently notify server in background
    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch(`/api/websites/${encodeURIComponent(siteId)}`, {
          method: 'DELETE',
          headers,
        });
      } catch (e) {
        console.warn('[WebsiteService] Server delete sync failed:', e);
      }
    })();

    return filtered;
  }

  /**
   * Updates a website directly in Cloud Firestore
   */
  public static updateWebsite(
    userId: string,
    siteId: string,
    updates: Partial<Omit<Website, 'id' | 'createdAt'>>
  ): Website[] {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    let updatedTarget: Website | null = null;

    const updated = sites.map((s) => {
      if (s.id === siteId) {
        const updatedSite: Website = {
          ...s,
          ...updates,
          ownerId: canonicalOwnerId,
          updatedAt: new Date().toISOString(),
        };
        updatedSite.publishStatus = WebsiteService.getPublishStatus(updatedSite);
        updatedTarget = updatedSite;
        return updatedSite;
      }
      return s;
    });

    this.memoryCache.set(canonicalOwnerId, updated);

    // 1. Authoritative Cloud Firestore update
    if (updatedTarget && auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', siteId), sanitizeForFirestore(updatedTarget))
          .then(() => {
            console.log(`[WebsiteService] Successfully updated website ${siteId} in Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to update website in Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error updating website in Firestore:', syncErr);
      }
    }

    // 2. Concurrently persist updates to server in background
    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch(`/api/websites/${encodeURIComponent(siteId)}`, {
          method: 'PATCH',
          headers,
          body: JSON.stringify(updates),
        });
      } catch (e) {
        console.warn('[WebsiteService] Server update sync failed:', e);
      }
    })();

    return updated;
  }

  public static getPublishStatus(site: Website): 'draft' | 'published' | 'changes_unpublished' {
    if (!site.publishedAt || !site.publishedSpec) {
      return 'draft';
    }
    const currentSpecStr = JSON.stringify(site.spec || {});
    const publishedSpecStr = JSON.stringify(site.publishedSpec || {});
    if (currentSpecStr !== publishedSpecStr) {
      return 'changes_unpublished';
    }
    return 'published';
  }

  public static async checkSlugAvailability(
    slug: string,
    siteId?: string,
    userId?: string
  ): Promise<{ available: boolean; error?: string; suggestedSlug?: string; isCurrent?: boolean }> {
    try {
      const params = new URLSearchParams({
        slug: slug.trim(),
        siteId: siteId || '',
        userId: userId || '',
      });
      const res = await fetch(`/api/check-slug?${params.toString()}`);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        return {
          available: false,
          error: data.error || 'Failed to check slug availability.',
        };
      }
      return await res.json();
    } catch {
      return {
        available: true,
      };
    }
  }

  public static async publishWebsite(
    userId: string,
    siteId: string,
    customSlug?: string,
    userEmail?: string
  ): Promise<{ website: Website; publicUrl: string }> {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const site = sites.find((s) => s.id === siteId);
    if (!site) {
      throw new Error(`Website not found: ${siteId}`);
    }
    if (!site.spec) {
      throw new Error('Cannot publish a website without a specification (spec).');
    }

    const slugToUse = (customSlug || site.publishedSlug || site.slug || site.name)
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

    const headers = await this.getAuthHeaders();
    const response = await fetch('/api/publish', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        siteId: site.id,
        slug: slugToUse,
        spec: site.spec,
        name: site.name,
        description: site.description,
        userEmail,
      }),
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to publish website to server.');
    }

    // Save pristine snapshot to user's website record
    const pristineSnapshot: WebsiteSpec = JSON.parse(JSON.stringify(site.spec));
    let publishedTarget: Website | null = null;
    const updatedSites = sites.map((s) => {
      if (s.id === siteId) {
        const publishedSite: Website = {
          ...s,
          ownerId: canonicalOwnerId,
          status: 'published',
          publishStatus: 'published',
          publishedSlug: result.slug,
          publishedAt: result.publishedAt,
          publishedSpec: pristineSnapshot,
          publishedVersion: result.publishedVersion,
          updatedAt: new Date().toISOString(),
        };
        publishedTarget = publishedSite;
        return publishedSite;
      }
      return s;
    });

    this.memoryCache.set(canonicalOwnerId, updatedSites);

    // Save updated published state directly to Cloud Firestore
    if (publishedTarget && auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', siteId), sanitizeForFirestore(publishedTarget))
          .then(() => {
            console.log(`[WebsiteService] Successfully synced published website ${siteId} to Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to sync published website state to Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error syncing published website to Firestore:', syncErr);
      }
    }

    return {
      website: publishedTarget || site,
      publicUrl: result.publicUrl,
    };
  }

  public static async unpublishWebsite(
    userId: string,
    siteId: string
  ): Promise<Website> {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const site = sites.find((s) => s.id === siteId);
    if (!site) {
      throw new Error(`Website not found: ${siteId}`);
    }

    const headers = await this.getAuthHeaders();
    const response = await fetch('/api/unpublish', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        siteId: site.id,
        slug: site.publishedSlug,
      }),
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.success) {
      throw new Error(result.error || 'Failed to unpublish website on server.');
    }

    let unpublishedTarget: Website | null = null;
    const updatedSites = sites.map((s) => {
      if (s.id === siteId) {
        const unpublishedSite: Website = {
          ...s,
          ownerId: canonicalOwnerId,
          status: 'draft',
          publishStatus: 'draft',
          publishedSlug: undefined,
          publishedAt: undefined,
          publishedSpec: undefined,
          publishedVersion: undefined,
          updatedAt: new Date().toISOString(),
        };
        unpublishedTarget = unpublishedSite;
        return unpublishedSite;
      }
      return s;
    });

    this.memoryCache.set(canonicalOwnerId, updatedSites);

    // Update state directly in Cloud Firestore
    if (unpublishedTarget && auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', siteId), sanitizeForFirestore(unpublishedTarget))
          .then(() => {
            console.log(`[WebsiteService] Successfully synced unpublished website ${siteId} to Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to sync unpublished state to Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error syncing unpublished state to Firestore:', syncErr);
      }
    }

    return unpublishedTarget || site;
  }

  public static duplicateWebsite(userId: string, siteId: string): Website {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const original = sites.find((s) => s.id === siteId);
    if (!original) {
      throw new Error(`Website not found: ${siteId}`);
    }

    const clonedSpec: WebsiteSpec | undefined = original.spec
      ? JSON.parse(JSON.stringify(original.spec))
      : undefined;

    const baseName = original.name.replace(/\s+Copy(\s+\d+)?$/i, '');
    const copyCount = sites.filter((s) => s.name.startsWith(baseName)).length;
    const newName = `${baseName} Copy${copyCount > 1 ? ` ${copyCount}` : ''}`;
    const slug = newName
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

    const newId = 'site_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    const duplicatedSite: Website = {
      id: newId,
      ownerId: canonicalOwnerId,
      name: newName,
      slug: slug || `${original.slug}-copy`,
      businessType: original.businessType,
      description: original.description,
      status: 'draft',
      pagesCount: original.pagesCount,
      originalPrompt: original.originalPrompt,
      spec: clonedSpec
        ? {
            ...clonedSpec,
            siteName: newName,
            businessName: clonedSpec.businessName || newName,
          }
        : undefined,
      isDemo: original.isDemo,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updated = [duplicatedSite, ...sites];
    this.memoryCache.set(canonicalOwnerId, updated);

    // Save directly to Cloud Firestore
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', duplicatedSite.id), sanitizeForFirestore(duplicatedSite))
          .then(() => {
            console.log(`[WebsiteService] Successfully duplicated website ${duplicatedSite.id} in Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to duplicate website in Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error duplicating website in Firestore:', syncErr);
      }
    }

    // Concurrently duplicate on server in background
    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch(`/api/websites/${encodeURIComponent(siteId)}/duplicate`, {
          method: 'POST',
          headers,
        });
      } catch (e) {
        console.warn('[WebsiteService] Server duplicate sync failed:', e);
      }
    })();

    return duplicatedSite;
  }

  public static renameWebsite(userId: string, siteId: string, newName: string): Website[] {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const trimmed = newName.trim();
    if (!trimmed) {
      throw new Error('Website name cannot be empty');
    }
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    let renamedTarget: Website | null = null;

    const updated = sites.map((s) => {
      if (s.id === siteId) {
        const slug = trimmed
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '');
        const updatedSpec = s.spec
          ? {
              ...s.spec,
              siteName: trimmed,
              businessName: s.spec.businessName || trimmed,
            }
          : undefined;

        const renamedSite: Website = {
          ...s,
          name: trimmed,
          slug: slug || s.slug,
          spec: updatedSpec,
          updatedAt: new Date().toISOString(),
        };
        renamedTarget = renamedSite;
        return renamedSite;
      }
      return s;
    });

    this.memoryCache.set(canonicalOwnerId, updated);

    // Update directly in Cloud Firestore
    if (renamedTarget && auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', siteId), sanitizeForFirestore(renamedTarget))
          .then(() => {
            console.log(`[WebsiteService] Successfully renamed website ${siteId} in Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to rename website in Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error renaming website in Firestore:', syncErr);
      }
    }

    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch(`/api/websites/${encodeURIComponent(siteId)}`, {
          method: 'PATCH',
          headers,
          body: JSON.stringify({ name: trimmed }),
        });
      } catch (e) {}
    })();

    return updated;
  }

  public static createWebsiteFromTemplate(
    userId: string,
    template: {
      name: string;
      category: string;
      description: string;
      spec: WebsiteSpec;
    },
    isDemo?: boolean
  ): Website {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const clonedSpec: WebsiteSpec = JSON.parse(JSON.stringify(template.spec));
    const newName = `${template.name} — Copy`;
    const slug = newName
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');

    const newId = 'site_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    const newSite: Website = {
      id: newId,
      ownerId: canonicalOwnerId,
      name: newName,
      slug: slug || 'template-site',
      businessType: template.category,
      description: template.description,
      status: 'draft',
      pagesCount: 1,
      originalPrompt: `Generated from template: ${template.name}`,
      spec: {
        ...clonedSpec,
        siteName: newName,
      },
      isDemo,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updated = [newSite, ...sites];
    this.memoryCache.set(canonicalOwnerId, updated);

    // Write directly to Cloud Firestore
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', newSite.id), sanitizeForFirestore(newSite))
          .then(() => {
            console.log(`[WebsiteService] Successfully saved template website ${newSite.id} to Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to save template website to Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error saving template website to Firestore:', syncErr);
      }
    }

    (async () => {
      try {
        const headers = await this.getAuthHeaders();
        await fetch('/api/websites', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            id: newSite.id,
            name: newName,
            businessType: template.category,
            description: template.description,
            originalPrompt: `Generated from template: ${template.name}`,
            spec: clonedSpec,
            isDemo,
          }),
        });
      } catch (e) {}
    })();

    return newSite;
  }

  public static updateCustomDomain(
    userId: string,
    siteId: string,
    config: CustomDomainConfig | null
  ): Website {
    const canonicalOwnerId = auth.currentUser?.uid || userId;
    const sites = this.getWebsitesForUser(canonicalOwnerId);
    const target = sites.find((s) => s.id === siteId);
    if (!target) {
      throw new Error('Website not found.');
    }

    const updatedSite: Website = {
      ...target,
      customDomain: config && config.connectionStatus !== 'DISCONNECTED' ? config.domain : undefined,
      customDomainConfig: config && config.connectionStatus !== 'DISCONNECTED' ? config : undefined,
      updatedAt: new Date().toISOString(),
    };

    const updatedSites = sites.map((s) => (s.id === siteId ? updatedSite : s));
    this.memoryCache.set(canonicalOwnerId, updatedSites);

    // Write directly to Cloud Firestore
    if (auth.currentUser && auth.currentUser.uid === canonicalOwnerId) {
      try {
        setDoc(doc(db, 'websites', siteId), sanitizeForFirestore(updatedSite))
          .then(() => {
            console.log(`[WebsiteService] Successfully updated custom domain on website ${siteId} in Firestore.`);
          })
          .catch((err) => {
            console.error('[WebsiteService] Failed to update custom domain in Firestore:', err);
          });
      } catch (syncErr) {
        console.error('[WebsiteService] Synchronous error updating custom domain in Firestore:', syncErr);
      }
    }

    return updatedSite;
  }
}
