import fs from 'fs';
import path from 'path';
import { Firestore } from '@google-cloud/firestore';
import { CustomDomainConfig } from '../../types/customDomain';

const COLLECTION_NAME = 'customDomains';
const DATA_DIR = path.join(process.cwd(), 'data');
const DEV_DOMAINS_FILE = path.join(DATA_DIR, 'custom_domains.dev.json');

export interface DomainStoreResult<T> {
  success: boolean;
  data?: T;
  error?: string;
  statusCode?: number;
}

/**
 * CustomDomainStore provides durable storage for StorePilot custom domains.
 * In production, it requires Cloud Firestore as the authoritative, shared datastore.
 * In development, if Firestore is not available, it uses an isolated development file.
 */
export class CustomDomainStore {
  private static firestore: Firestore | null = null;
  private static isInitialized = false;
  private static firestoreAvailable = false;
  private static firestoreError: string | null = null;

  // In-memory read-through cache (with short TTL to allow multi-instance freshness)
  private static cache = new Map<string, { config: CustomDomainConfig | null; cachedAt: number }>();
  private static readonly CACHE_TTL_MS = 5000; // 5 seconds max cache

  public static isProduction(): boolean {
    return process.env.NODE_ENV === 'production';
  }

  /**
   * Initializes the persistent Firestore connection.
   */
  public static async initialize(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    try {
      const projectId =
        process.env.FIREBASE_PROJECT_ID ||
        process.env.VITE_FIREBASE_PROJECT_ID ||
        process.env.GOOGLE_CLOUD_PROJECT ||
        process.env.GCP_PROJECT;

      const options: any = {};
      if (projectId) {
        options.projectId = projectId;
      }

      this.firestore = new Firestore(options);

      // Verify whether the Firestore API is actually enabled and accessible on GCP
      const probe = await this.firestore.collection(COLLECTION_NAME).limit(1).get();
      this.firestoreAvailable = true;
      this.firestoreError = null;
      console.log(`[CustomDomainStore] Firestore connected successfully. Accessible docs: ${probe.size}`);
    } catch (err: any) {
      this.firestoreAvailable = false;
      this.firestoreError = err?.message || 'Firestore connection failed.';

      if (this.isProduction()) {
        console.error(
          `[CustomDomainStore] CRITICAL: Firestore is unavailable in production (${this.firestoreError}). ` +
          `Ephemeral file persistence is disabled in production to guarantee data durability.`
        );
      } else {
        console.warn(
          `[CustomDomainStore] Notice: Firestore is not available in local development (${err?.code || 'offline'}). ` +
          `Using development sandbox storage (${DEV_DOMAINS_FILE}). This sandbox is disabled in production.`
        );
        this.ensureDevStoreExists();
      }
    }
  }

  public static isFirestoreActive(): boolean {
    return this.firestoreAvailable && this.firestore !== null;
  }

  public static getFirestoreStatus(): { available: boolean; error: string | null } {
    return { available: this.firestoreAvailable, error: this.firestoreError };
  }

  // ----------------------------------------------------
  // Development Sandbox Helpers (Disabled in Production)
  // ----------------------------------------------------
  private static ensureDevStoreExists(): void {
    if (this.isProduction()) return;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (!fs.existsSync(DEV_DOMAINS_FILE)) {
        // Seed from existing legacy file if present for development continuity
        const legacyFile = path.join(DATA_DIR, 'custom_domains.json');
        if (fs.existsSync(legacyFile)) {
          fs.copyFileSync(legacyFile, DEV_DOMAINS_FILE);
        } else {
          fs.writeFileSync(DEV_DOMAINS_FILE, '[]', 'utf-8');
        }
      }
    } catch (err) {
      console.warn('[CustomDomainStore] Failed to initialize dev store:', err);
    }
  }

  private static readDevDomains(): Map<string, CustomDomainConfig> {
    if (this.isProduction()) {
      throw new Error('Local file storage is forbidden in production environments.');
    }
    try {
      if (fs.existsSync(DEV_DOMAINS_FILE)) {
        const raw = fs.readFileSync(DEV_DOMAINS_FILE, 'utf-8');
        const list: CustomDomainConfig[] = JSON.parse(raw);
        return new Map(list.map((r) => [r.normalizedDomain.toLowerCase(), r]));
      }
    } catch (err) {
      console.warn('[CustomDomainStore] Error reading dev domains:', err);
    }
    return new Map();
  }

  private static writeDevDomains(map: Map<string, CustomDomainConfig>): void {
    if (this.isProduction()) {
      throw new Error('Local file storage is forbidden in production environments.');
    }
    try {
      this.ensureDevStoreExists();
      const list = Array.from(map.values());
      fs.writeFileSync(DEV_DOMAINS_FILE, JSON.stringify(list, null, 2), 'utf-8');
    } catch (err) {
      console.error('[CustomDomainStore] Error writing dev domains:', err);
    }
  }

  // ----------------------------------------------------
  // Core Persistent Datastore Operations
  // ----------------------------------------------------

  /**
   * Retrieves a domain config by its normalized domain name.
   */
  public static async getDomain(normalizedDomain: string): Promise<CustomDomainConfig | null> {
    const key = normalizedDomain.toLowerCase().trim();

    // Check memory cache
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.cachedAt < this.CACHE_TTL_MS) {
      return cached.config;
    }

    if (this.firestoreAvailable && this.firestore) {
      const docRef = this.firestore.collection(COLLECTION_NAME).doc(key);
      const snapshot = await docRef.get();
      if (!snapshot.exists) {
        this.cache.set(key, { config: null, cachedAt: Date.now() });
        return null;
      }
      const config = snapshot.data() as CustomDomainConfig;
      this.cache.set(key, { config, cachedAt: Date.now() });
      return config;
    }

    if (this.isProduction()) {
      throw new Error(
        `Production datastore (Firestore) is not configured or accessible. Local fallback is disabled in production.`
      );
    }

    const devMap = this.readDevDomains();
    const result = devMap.get(key) || null;
    this.cache.set(key, { config: result, cachedAt: Date.now() });
    return result;
  }

  /**
   * Retrieves active domain config for a specific websiteId.
   */
  public static async getDomainByWebsiteId(websiteId: string): Promise<CustomDomainConfig | null> {
    if (this.firestoreAvailable && this.firestore) {
      const snapshot = await this.firestore
        .collection(COLLECTION_NAME)
        .where('websiteId', '==', websiteId)
        .where('connectionStatus', '!=', 'DISCONNECTED')
        .limit(1)
        .get();

      if (snapshot.empty) return null;
      return snapshot.docs[0].data() as CustomDomainConfig;
    }

    if (this.isProduction()) {
      throw new Error(`Production datastore (Firestore) is unavailable.`);
    }

    const devMap = this.readDevDomains();
    for (const conf of devMap.values()) {
      if (conf.websiteId === websiteId && conf.connectionStatus !== 'DISCONNECTED') {
        return conf;
      }
    }
    return null;
  }

  /**
   * Connects a new domain atomically, enforcing cross-user uniqueness.
   */
  public static async connectDomain(
    newConfig: CustomDomainConfig
  ): Promise<DomainStoreResult<CustomDomainConfig>> {
    const normalized = newConfig.normalizedDomain.toLowerCase().trim();
    const altDomain = normalized.startsWith('www.')
      ? normalized.replace(/^www\./, '')
      : `www.${normalized}`;

    if (this.firestoreAvailable && this.firestore) {
      const firestore = this.firestore;
      const primaryDocRef = firestore.collection(COLLECTION_NAME).doc(normalized);
      const altDocRef = firestore.collection(COLLECTION_NAME).doc(altDomain);

      try {
        const result = await firestore.runTransaction(async (transaction) => {
          const primarySnap = await transaction.get(primaryDocRef);
          const altSnap = await transaction.get(altDocRef);

          // Check primary domain conflict
          if (primarySnap.exists) {
            const existing = primarySnap.data() as CustomDomainConfig;
            if (existing.connectionStatus !== 'DISCONNECTED') {
              if (existing.websiteId !== newConfig.websiteId || existing.userId !== newConfig.userId) {
                return {
                  conflict: true,
                  error: 'This domain is already connected to another StorePilot website.',
                  statusCode: 409,
                };
              }
              // Already connected to this website
              return { success: true, config: existing, alreadyConnected: true };
            }
          }

          // Check www / apex alias conflict
          if (altSnap.exists) {
            const altExisting = altSnap.data() as CustomDomainConfig;
            if (altExisting.connectionStatus !== 'DISCONNECTED') {
              if (altExisting.websiteId !== newConfig.websiteId || altExisting.userId !== newConfig.userId) {
                return {
                  conflict: true,
                  error: 'This domain (or its www/root alias) is already connected to another StorePilot website.',
                  statusCode: 409,
                };
              }
            }
          }

          // Write new domain config atomically
          transaction.set(primaryDocRef, newConfig);
          return { success: true, config: newConfig };
        });

        if (result.conflict) {
          return {
            success: false,
            error: result.error,
            statusCode: result.statusCode || 409,
          };
        }

        // Invalidate cache
        this.cache.delete(normalized);
        this.cache.delete(altDomain);

        return { success: true, data: result.config };
      } catch (err: any) {
        console.error('[CustomDomainStore] Firestore transaction error during connect:', err);
        return {
          success: false,
          error: `Database transaction failed: ${err.message}`,
          statusCode: 500,
        };
      }
    }

    // In production without Firestore, fail clearly
    if (this.isProduction()) {
      return {
        success: false,
        error:
          'Durable datastore (Firestore) is not configured in production. Ephemeral file storage is disabled to prevent data loss across Cloud Run instances.',
        statusCode: 503,
      };
    }

    // Development sandbox mode
    const devMap = this.readDevDomains();

    const existing = devMap.get(normalized);
    if (existing && existing.connectionStatus !== 'DISCONNECTED') {
      if (existing.websiteId !== newConfig.websiteId || existing.userId !== newConfig.userId) {
        return {
          success: false,
          error: 'This domain is already connected to another StorePilot website.',
          statusCode: 409,
        };
      }
      return { success: true, data: existing };
    }

    const altExisting = devMap.get(altDomain);
    if (altExisting && altExisting.connectionStatus !== 'DISCONNECTED') {
      if (altExisting.websiteId !== newConfig.websiteId || altExisting.userId !== newConfig.userId) {
        return {
          success: false,
          error: 'This domain (or its www/root alias) is already connected to another StorePilot website.',
          statusCode: 409,
        };
      }
    }

    // Remove previous domain mapping for this website if exists
    for (const [d, conf] of devMap.entries()) {
      if (conf.websiteId === newConfig.websiteId && conf.userId === newConfig.userId && d !== normalized) {
        devMap.delete(d);
      }
    }

    devMap.set(normalized, newConfig);
    this.writeDevDomains(devMap);
    this.cache.set(normalized, { config: newConfig, cachedAt: Date.now() });

    return { success: true, data: newConfig };
  }

  /**
   * Updates an existing domain record (e.g. after DNS verification or primary toggle).
   */
  public static async updateDomain(
    config: CustomDomainConfig
  ): Promise<DomainStoreResult<CustomDomainConfig>> {
    const key = config.normalizedDomain.toLowerCase().trim();

    if (this.firestoreAvailable && this.firestore) {
      try {
        const docRef = this.firestore.collection(COLLECTION_NAME).doc(key);
        await docRef.set(config, { merge: true });
        this.cache.set(key, { config, cachedAt: Date.now() });
        return { success: true, data: config };
      } catch (err: any) {
        console.error('[CustomDomainStore] Error updating domain in Firestore:', err);
        return { success: false, error: err.message, statusCode: 500 };
      }
    }

    if (this.isProduction()) {
      return {
        success: false,
        error: 'Durable datastore (Firestore) is not configured in production.',
        statusCode: 503,
      };
    }

    const devMap = this.readDevDomains();
    devMap.set(key, config);
    this.writeDevDomains(devMap);
    this.cache.set(key, { config, cachedAt: Date.now() });
    return { success: true, data: config };
  }

  /**
   * Disconnects a domain with strict ownership validation.
   */
  public static async disconnectDomain(
    normalizedDomain: string,
    websiteId: string,
    userId: string
  ): Promise<DomainStoreResult<boolean>> {
    const key = normalizedDomain.toLowerCase().trim();

    if (this.firestoreAvailable && this.firestore) {
      try {
        const docRef = this.firestore.collection(COLLECTION_NAME).doc(key);
        const snapshot = await docRef.get();
        if (!snapshot.exists) {
          return { success: false, error: 'Domain configuration not found.', statusCode: 404 };
        }

        const record = snapshot.data() as CustomDomainConfig;
        if (record.websiteId !== websiteId || record.userId !== userId) {
          return { success: false, error: 'Unauthorized: Domain does not belong to this user.', statusCode: 403 };
        }

        // Delete from Firestore
        await docRef.delete();
        this.cache.delete(key);
        return { success: true, data: true };
      } catch (err: any) {
        console.error('[CustomDomainStore] Error disconnecting domain in Firestore:', err);
        return { success: false, error: err.message, statusCode: 500 };
      }
    }

    if (this.isProduction()) {
      return {
        success: false,
        error: 'Durable datastore (Firestore) is not configured in production.',
        statusCode: 503,
      };
    }

    const devMap = this.readDevDomains();
    const record = devMap.get(key);
    if (!record || record.websiteId !== websiteId || record.userId !== userId) {
      return { success: false, error: 'Domain configuration not found.', statusCode: 404 };
    }

    devMap.delete(key);
    this.writeDevDomains(devMap);
    this.cache.delete(key);
    return { success: true, data: true };
  }

  /**
   * Look up a custom domain for inbound routing.
   * Checks Firestore authoritative datastore, supporting any newly started Cloud Run instance.
   */
  public static async lookupDomain(hostname: string): Promise<CustomDomainConfig | null> {
    const cleanHost = hostname.toLowerCase().trim().split(':')[0];

    // Try exact match
    let config = await this.getDomain(cleanHost);

    // Try www alias
    if (!config && cleanHost.startsWith('www.')) {
      config = await this.getDomain(cleanHost.replace(/^www\./, ''));
    } else if (!config) {
      config = await this.getDomain(`www.${cleanHost}`);
    }

    return config;
  }
}
