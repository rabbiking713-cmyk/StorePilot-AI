import fs from 'fs';
import path from 'path';
import { PublishedSiteRecord } from '../../types';
import { getAdminDb } from '../auth/serverAuth';
import { sanitizeForFirestore } from './websiteService';

const DATA_DIR = path.join(process.cwd(), 'data');
const PUBLISHED_SITES_FILE = path.join(DATA_DIR, 'published_sites.json');
const COLLECTION_NAME = 'publishedSites';

export class PublishedSiteStore {
  private static memoryMap = new Map<string, PublishedSiteRecord>();
  private static isInitialized = false;

  private static ensureDataDir(): void {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (err) {
        // Safe to ignore in read-only serverless filesystems
      }
    }
  }

  /**
   * Initializes local cache and migrates existing published sites from disk to Firestore if needed.
   */
  public static async initialize(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;
    this.ensureDataDir();

    // 1. Load any existing local files from disk (e.g. existing kontrol-accra, aura-coffee)
    try {
      if (fs.existsSync(PUBLISHED_SITES_FILE)) {
        const raw = fs.readFileSync(PUBLISHED_SITES_FILE, 'utf8');
        const list: PublishedSiteRecord[] = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (item && item.slug) {
              this.memoryMap.set(item.slug.toLowerCase(), item);
            }
          }
          console.log(`[PublishedSiteStore] Loaded ${this.memoryMap.size} published site(s) from local storage.`);
        }
      }
    } catch (err) {
      console.warn('[PublishedSiteStore] Local disk load warning:', err);
    }

    // 2. Automatically sync/migrate existing disk records to Firestore
    const adminDb = getAdminDb();
    if (adminDb && this.memoryMap.size > 0) {
      try {
        for (const [slug, record] of this.memoryMap.entries()) {
          const docRef = adminDb.collection(COLLECTION_NAME).doc(slug);
          const snap = await docRef.get();
          if (!snap.exists) {
            await docRef.set(sanitizeForFirestore(record));
            console.log(`[PublishedSiteStore] Migrated published site "${slug}" to Cloud Firestore.`);
          }
        }
      } catch (migrationErr) {
        console.warn('[PublishedSiteStore] Migration to Firestore warning:', migrationErr);
      }
    }
  }

  private static persistDisk(): void {
    try {
      this.ensureDataDir();
      const records = Array.from(this.memoryMap.values());
      fs.writeFileSync(PUBLISHED_SITES_FILE, JSON.stringify(records, null, 2), 'utf-8');
    } catch {
      // Safe to ignore on Vercel read-only serverless disk
    }
  }

  /**
   * Looks up a published site record by slug (checks memory cache then Cloud Firestore).
   */
  public static async getBySlug(slug: string): Promise<PublishedSiteRecord | null> {
    const cleanSlug = slug.toLowerCase().trim();

    // Authoritative lookup from Cloud Firestore
    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        const docRef = adminDb.collection(COLLECTION_NAME).doc(cleanSlug);
        const snap = await docRef.get();
        if (snap.exists) {
          const data = snap.data() as PublishedSiteRecord;
          this.memoryMap.set(cleanSlug, data);
          return data;
        }
      } catch (err) {
        console.warn(`[PublishedSiteStore] Firestore lookup failed for "${cleanSlug}":`, err);
      }
    }

    if (this.memoryMap.has(cleanSlug)) {
      return this.memoryMap.get(cleanSlug)!;
    }

    return null;
  }

  /**
   * Finds a published site record by internal website project ID.
   */
  public static async getBySiteId(siteId: string): Promise<PublishedSiteRecord | null> {
    for (const rec of this.memoryMap.values()) {
      if (rec.siteId === siteId && rec.status === 'published') {
        return rec;
      }
    }

    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        const snap = await adminDb
          .collection(COLLECTION_NAME)
          .where('siteId', '==', siteId)
          .where('status', '==', 'published')
          .limit(1)
          .get();

        if (!snap.empty) {
          const data = snap.docs[0].data() as PublishedSiteRecord;
          this.memoryMap.set(data.slug.toLowerCase(), data);
          return data;
        }
      } catch (err) {
        console.warn(`[PublishedSiteStore] Firestore getBySiteId error for "${siteId}":`, err);
      }
    }

    return null;
  }

  /**
   * Retrieves all published sites with status === 'published' (used for sitemaps and directories).
   */
  public static async getAllPublishedSites(): Promise<PublishedSiteRecord[]> {
    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        const snap = await adminDb
          .collection(COLLECTION_NAME)
          .where('status', '==', 'published')
          .get();

        const sites: PublishedSiteRecord[] = [];
        snap.forEach((doc) => {
          const data = doc.data() as PublishedSiteRecord;
          sites.push(data);
          this.memoryMap.set(data.slug.toLowerCase(), data);
        });

        if (sites.length > 0) {
          return sites;
        }
      } catch (err) {
        console.warn('[PublishedSiteStore] Firestore getAllPublishedSites error:', err);
      }
    }

    return Array.from(this.memoryMap.values()).filter((s) => s.status === 'published');
  }

  /**
   * Authoritatively saves or updates a published website record to Cloud Firestore and memory.
   */
  public static async save(record: PublishedSiteRecord): Promise<void> {
    const cleanSlug = record.slug.toLowerCase().trim();
    this.memoryMap.set(cleanSlug, record);
    this.persistDisk();

    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        await adminDb
          .collection(COLLECTION_NAME)
          .doc(cleanSlug)
          .set(sanitizeForFirestore(record));
        console.log(`[PublishedSiteStore] Persisted published site "${cleanSlug}" to Cloud Firestore.`);
      } catch (err) {
        console.error(`[PublishedSiteStore] Failed to write "${cleanSlug}" to Firestore:`, err);
      }
    }
  }

  /**
   * Deletes or unpublishes a site record from Cloud Firestore and memory.
   */
  public static async delete(slug: string): Promise<void> {
    const cleanSlug = slug.toLowerCase().trim();
    this.memoryMap.delete(cleanSlug);
    this.persistDisk();

    const adminDb = getAdminDb();
    if (adminDb) {
      try {
        await adminDb.collection(COLLECTION_NAME).doc(cleanSlug).delete();
        console.log(`[PublishedSiteStore] Removed published site "${cleanSlug}" from Cloud Firestore.`);
      } catch (err) {
        console.error(`[PublishedSiteStore] Failed to delete "${cleanSlug}" from Firestore:`, err);
      }
    }
  }

  /**
   * Access to raw in-memory Map for legacy synchronous route loops.
   */
  public static getRawMemoryMap(): Map<string, PublishedSiteRecord> {
    return this.memoryMap;
  }
}
