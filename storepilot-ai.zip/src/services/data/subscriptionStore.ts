import fs from 'fs';
import path from 'path';
import { getAdminDb } from '../auth/serverAuth';
import { UserSubscriptionRecord, SubscriptionPlan, SubscriptionStatus } from '../../types/subscription';
import { WebsiteStore } from './websiteStore';

const DATA_DIR = path.join(process.cwd(), 'data');
const SUBSCRIPTIONS_FILE = path.join(DATA_DIR, 'subscriptions.json');

// Exact 3 developer/testing emails specified in Phase 9 requirements
export const DEVELOPER_EMAILS = new Set([
  'powerkobbi9@gmail.com',
  'rabbiking713@gmail.com',
  'jakebenoit08@gmail.com',
]);

// Set of verified developer UIDs cached after authentication
const developerUids = new Set<string>();

export class SubscriptionStore {
  private static localMemoryMap: Map<string, UserSubscriptionRecord> = new Map();
  private static isInitialized = false;
  private static firestoreAvailable = false;
  private static firestoreChecked = false;

  private static ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (err) {
        console.warn('[SubscriptionStore] Could not create data directory:', err);
      }
    }
  }

  /**
   * Checks whether Cloud Firestore is accessible with the current server credentials.
   * If server credentials lack Firestore IAM permissions, it quietly falls back
   * to the durable local filesystem store without emitting fatal warning noise.
   */
  public static async isFirestoreAccessible(): Promise<boolean> {
    if (this.firestoreChecked) {
      return this.firestoreAvailable;
    }
    this.firestoreChecked = true;
    const adminDb = getAdminDb();
    if (!adminDb) {
      this.firestoreAvailable = false;
      return false;
    }
    try {
      await adminDb.collection('users').limit(1).get();
      this.firestoreAvailable = true;
    } catch {
      // In environments where server-side ADC lacks Firestore Admin roles,
      // fallback smoothly to the durable storage without spamming permission errors.
      this.firestoreAvailable = false;
    }
    return this.firestoreAvailable;
  }

  public static isProduction(): boolean {
    return process.env.NODE_ENV === 'production';
  }

  public static isFirestoreActive(): boolean {
    return this.firestoreAvailable;
  }

  public static getStorageBackend(): string {
    if (this.isProduction()) {
      return this.firestoreAvailable ? 'Cloud Firestore (Authoritative)' : 'Cloud Firestore (Unavailable - Credentials Missing)';
    }
    return this.firestoreAvailable ? 'Cloud Firestore (Dev Mode)' : 'Local JSON Sandbox (Dev/Test Only)';
  }

  public static initialize(): void {
    if (this.isInitialized) return;

    // In production, ephemeral filesystem persistence is disabled to guarantee
    // that local disk is never silently relied upon as production durability.
    if (!this.isProduction()) {
      this.ensureDataDir();

      try {
        if (fs.existsSync(SUBSCRIPTIONS_FILE)) {
          const raw = fs.readFileSync(SUBSCRIPTIONS_FILE, 'utf8');
          const items = JSON.parse(raw);
          if (Array.isArray(items)) {
            items.forEach((item: UserSubscriptionRecord) => {
              if (item.userId) {
                this.localMemoryMap.set(item.userId, item);
              }
            });
          }
        }
      } catch (err) {
        console.warn('[SubscriptionStore] Error reading subscriptions file:', err);
      }
    }

    this.isInitialized = true;
  }

  private static persistToDisk(): void {
    if (this.isProduction()) {
      // In PRODUCTION: Local filesystem fallback is strictly disabled to prevent
      // silently relying on ephemeral container disk as production durability.
      return;
    }
    try {
      this.ensureDataDir();
      const records = Array.from(this.localMemoryMap.values());
      fs.writeFileSync(SUBSCRIPTIONS_FILE, JSON.stringify(records, null, 2), 'utf8');
    } catch (err) {
      console.error('[SubscriptionStore] Failed to write subscriptions to disk:', err);
    }
  }

  /**
   * Authoritative server-side developer check.
   * Compares authenticated email or known UID against the strict allowlist.
   */
  public static isDeveloperAccount(email?: string, uid?: string): boolean {
    if (email && DEVELOPER_EMAILS.has(email.toLowerCase().trim())) {
      if (uid) {
        developerUids.add(uid);
      }
      return true;
    }
    if (uid && developerUids.has(uid)) {
      return true;
    }
    return false;
  }

  /**
   * Registers a verified Firebase UID as a developer account if the email matches.
   */
  public static registerDeveloperUid(uid: string, email: string): void {
    if (DEVELOPER_EMAILS.has(email.toLowerCase().trim())) {
      developerUids.add(uid);
    }
  }

  /**
   * Retrieve authoritative subscription record for a user.
   * If developer: returns internal Agency-tier developer exemption.
   * Otherwise: fetches from Firestore users/{uid} or local durable storage. Defaults to starter ($0/mo).
   */
  public static async getSubscription(
    userId: string,
    email?: string
  ): Promise<UserSubscriptionRecord> {
    this.initialize();

    // 1. Check developer exemption
    if (this.isDeveloperAccount(email, userId)) {
      if (userId) developerUids.add(userId);
      return {
        userId,
        email: email || '',
        displayName: 'StorePilot Developer',
        plan: 'agency',
        subscriptionStatus: 'active',
        isDeveloper: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }

    // 2. Query Firestore users/{userId} if accessible
    const firestoreReady = await this.isFirestoreAccessible();
    if (firestoreReady) {
      const adminDb = getAdminDb();
      if (adminDb) {
        try {
          const userDocRef = adminDb.collection('users').doc(userId);
          const docSnap = await userDocRef.get();
          if (docSnap.exists) {
            const data = docSnap.data();
            if (data?.plan) {
              const record: UserSubscriptionRecord = {
                userId,
                email: data.email || email || '',
                displayName: data.displayName,
                plan: data.plan as SubscriptionPlan,
                subscriptionStatus: (data.subscriptionStatus as SubscriptionStatus) || 'inactive',
                paystackCustomerCode: data.paystackCustomerCode,
                paystackSubscriptionCode: data.paystackSubscriptionCode,
                currentPeriodStart: data.currentPeriodStart,
                currentPeriodEnd: data.currentPeriodEnd,
                isDeveloper: false,
                createdAt: data.createdAt || new Date().toISOString(),
                updatedAt: data.updatedAt || new Date().toISOString(),
              };
              this.localMemoryMap.set(userId, record);
              return record;
            }
          }
        } catch {
          this.firestoreAvailable = false;
        }
      }
    }

    // 3. Fallback to durable local memory / disk
    const existing = this.localMemoryMap.get(userId);
    if (existing) {
      return existing;
    }

    // 4. Default: Free Starter Plan
    const defaultStarter: UserSubscriptionRecord = {
      userId,
      email: email || '',
      plan: 'starter',
      subscriptionStatus: 'active', // Free starter plan is active by default
      isDeveloper: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.localMemoryMap.set(userId, defaultStarter);
    this.persistToDisk();
    return defaultStarter;
  }

  /**
   * Persist subscription state updates to Firestore users/{userId} and durable storage
   */
  public static async updateSubscription(
    userId: string,
    updates: Partial<UserSubscriptionRecord>
  ): Promise<UserSubscriptionRecord> {
    this.initialize();

    const current = await this.getSubscription(userId, updates.email);
    const updated: UserSubscriptionRecord = {
      ...current,
      ...updates,
      userId,
      updatedAt: new Date().toISOString(),
    };

    this.localMemoryMap.set(userId, updated);
    this.persistToDisk();

    // Sync to Firestore if accessible
    const firestoreReady = await this.isFirestoreAccessible();
    if (firestoreReady) {
      const adminDb = getAdminDb();
      if (adminDb) {
        try {
          const userDocRef = adminDb.collection('users').doc(userId);
          await userDocRef.set(
            {
              plan: updated.plan,
              subscriptionStatus: updated.subscriptionStatus,
              paystackCustomerCode: updated.paystackCustomerCode || null,
              paystackSubscriptionCode: updated.paystackSubscriptionCode || null,
              currentPeriodStart: updated.currentPeriodStart || null,
              currentPeriodEnd: updated.currentPeriodEnd || null,
              updatedAt: updated.updatedAt,
            },
            { merge: true }
          );
          console.log(`[SubscriptionStore] Updated subscription in Firestore for user ${userId} to ${updated.plan} (${updated.subscriptionStatus})`);
        } catch {
          this.firestoreAvailable = false;
        }
      }
    }

    return updated;
  }

  /**
   * Cancel subscription: Updates status to 'cancelled' while preserving user's websites, orders, and products.
   */
  public static async cancelSubscription(userId: string): Promise<UserSubscriptionRecord> {
    return this.updateSubscription(userId, {
      subscriptionStatus: 'cancelled',
    });
  }

  /**
   * Validates website creation limits based on the user's authoritative plan:
   * - Starter ($0/mo): 1 active website
   * - Professional ($29/mo): 5 active websites
   * - Agency ($79/mo) / Developer: Unlimited active websites
   */
  public static async canCreateWebsite(
    userId: string,
    email?: string
  ): Promise<{
    allowed: boolean;
    limit: number | 'unlimited';
    current: number;
    plan: SubscriptionPlan;
    reason?: string;
  }> {
    const sub = await this.getSubscription(userId, email);
    const websites = await WebsiteStore.getWebsitesByOwner(userId);
    const current = websites.length;

    // Agency or Developer has unlimited websites
    if (sub.isDeveloper || sub.plan === 'agency') {
      return { allowed: true, limit: 'unlimited', current, plan: sub.plan };
    }

    if (sub.plan === 'professional') {
      const limit = 5;
      if (current >= limit) {
        return {
          allowed: false,
          limit,
          current,
          plan: sub.plan,
          reason: `You have reached the Professional plan limit of ${limit} websites. Please upgrade to Agency / Studio for unlimited websites.`,
        };
      }
      return { allowed: true, limit, current, plan: sub.plan };
    }

    // Starter plan: limit of 1 website
    const limit = 1;
    if (current >= limit) {
      return {
        allowed: false,
        limit,
        current,
        plan: sub.plan,
        reason: `You have reached the Starter plan limit of ${limit} website project. Please upgrade to Professional or Agency to create more websites.`,
      };
    }

    return { allowed: true, limit, current, plan: sub.plan };
  }
}
