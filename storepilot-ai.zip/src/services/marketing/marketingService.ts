import {
  GenerateMarketingPayload,
  GenerateMarketingResponse,
  MarketingOutputResult,
  SavedMarketingItem,
  MarketingToolType,
} from '../../types/marketing';
import { AuthService } from '../auth/authService';

const STORAGE_PREFIX = 'storepilot_marketing_history_';

export class MarketingService {
  private static memoryCache: Map<string, SavedMarketingItem[]> = new Map();

  /**
   * Calls the server-side Gemini marketing endpoint with authenticated user headers
   */
  public static async generateMarketing(
    payload: GenerateMarketingPayload
  ): Promise<{ result: MarketingOutputResult; modelUsed: string }> {
    const token = await AuthService.getIdToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch('/api/generate-marketing', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        ...payload,
        websiteId: payload.context.siteId,
      }),
    });

    const data: GenerateMarketingResponse = await response.json();

    if (!response.ok || !data.success || !data.result) {
      const errorMsg =
        data.error ||
        (response.status === 503
          ? 'GEMINI_API_KEY is not configured on the server. Please configure your key to use AI Marketing Studio.'
          : 'Failed to generate marketing content. Please try again.');
      throw new Error(errorMsg);
    }

    return {
      result: data.result,
      modelUsed: data.modelUsed || 'gemini-3.8-flash',
    };
  }

  /**
   * Load history of saved marketing generations for the user from server/cache
   */
  public static getSavedItems(userId: string): SavedMarketingItem[] {
    if (this.memoryCache.has(userId)) {
      return this.memoryCache.get(userId)!;
    }

    try {
      const raw = localStorage.getItem(`${STORAGE_PREFIX}${userId}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        this.memoryCache.set(userId, parsed);
        // Kick off async background fetch from server to synchronize
        this.fetchSavedItems(userId).catch(() => {});
        return parsed;
      }
    } catch {
      // Fallback
    }

    // Trigger async server fetch
    this.fetchSavedItems(userId).catch(() => {});
    return [];
  }

  /**
   * Fetches saved marketing items from the server API
   */
  public static async fetchSavedItems(userId: string): Promise<SavedMarketingItem[]> {
    try {
      const token = await AuthService.getIdToken();
      if (!token) return [];

      const response = await fetch('/api/marketing', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) return this.memoryCache.get(userId) || [];
      const data = await response.json();
      if (data.success && Array.isArray(data.items)) {
        this.memoryCache.set(userId, data.items);
        try {
          localStorage.setItem(`${STORAGE_PREFIX}${userId}`, JSON.stringify(data.items));
        } catch {}
        return data.items;
      }
    } catch (err) {
      console.warn('[MarketingService] Failed to fetch marketing items from server:', err);
    }
    return this.memoryCache.get(userId) || [];
  }

  /**
   * Save a generated marketing item to durable server storage and update local cache
   */
  public static saveItem(
    userId: string,
    params: {
      websiteId: string;
      websiteName: string;
      toolType: MarketingToolType;
      title: string;
      result: MarketingOutputResult;
    }
  ): SavedMarketingItem {
    const items = this.getSavedItems(userId);
    const newItem: SavedMarketingItem = {
      id: `mkt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      userId,
      websiteId: params.websiteId,
      websiteName: params.websiteName,
      toolType: params.toolType,
      title: params.title,
      createdAt: new Date().toISOString(),
      result: params.result,
    };

    const updated = [newItem, ...items].slice(0, 50);
    this.memoryCache.set(userId, updated);

    try {
      localStorage.setItem(`${STORAGE_PREFIX}${userId}`, JSON.stringify(updated));
    } catch {}

    // Async sync to server
    (async () => {
      try {
        const token = await AuthService.getIdToken();
        if (token) {
          await fetch('/api/marketing', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(params),
          });
        }
      } catch (err) {
        console.warn('[MarketingService] Failed to sync saved item to server:', err);
      }
    })();

    return newItem;
  }

  /**
   * Delete an item from history
   */
  public static deleteItem(userId: string, itemId: string): SavedMarketingItem[] {
    const items = this.getSavedItems(userId);
    const filtered = items.filter((i) => i.id !== itemId);
    this.memoryCache.set(userId, filtered);

    try {
      localStorage.setItem(`${STORAGE_PREFIX}${userId}`, JSON.stringify(filtered));
    } catch {}

    // Async sync deletion to server
    (async () => {
      try {
        const token = await AuthService.getIdToken();
        if (token) {
          await fetch(`/api/marketing/${encodeURIComponent(itemId)}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
        }
      } catch (err) {
        console.warn('[MarketingService] Failed to delete item on server:', err);
      }
    })();

    return filtered;
  }

  /**
   * Clear all marketing history for a user
   */
  public static clearHistory(userId: string): void {
    this.memoryCache.delete(userId);
    try {
      localStorage.removeItem(`${STORAGE_PREFIX}${userId}`);
    } catch {}
  }
}
