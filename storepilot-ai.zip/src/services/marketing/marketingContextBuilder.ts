import { Website } from '../../types';
import {
  BusinessMarketingContext,
  BusinessProductContext,
} from '../../types/marketing';
import {
  HeroSection,
  FeaturesSection,
  ProductsSection,
  AboutSection,
  CtaSection,
  ContactSection,
} from '../../types/websiteSpec';

/**
 * Builds a strictly-grounded BusinessMarketingContext from real stored Website and WebsiteSpec data.
 * Adheres to strict truth constraints: no invented products, prices, testimonials, or claims.
 */
export function buildMarketingContext(website: Website): BusinessMarketingContext {
  const spec = website.spec;

  // Extract products strictly from products section if present
  const products: BusinessProductContext[] = [];
  const callsToAction: string[] = [];
  const features: Array<{ id?: string; title: string; description: string }> = [];
  let heroHeadline = '';
  let heroSubheadline = '';
  let heroBadge = '';
  let aboutHeadline = '';
  let aboutContent = '';
  let aboutHighlights: string[] = [];
  let contactInfo: { email?: string; phone?: string; address?: string; hours?: string } | undefined;

  if (spec?.sections) {
    for (const sec of spec.sections) {
      if (sec.type === 'hero') {
        const hero = sec as HeroSection;
        heroHeadline = hero.headline || '';
        heroSubheadline = hero.subheadline || '';
        heroBadge = hero.badge || '';
        if (hero.primaryCta?.label) callsToAction.push(hero.primaryCta.label);
        if (hero.secondaryCta?.label) callsToAction.push(hero.secondaryCta.label);
      } else if (sec.type === 'products') {
        const prodSec = sec as ProductsSection;
        if (Array.isArray(prodSec.items)) {
          for (const item of prodSec.items) {
            products.push({
              id: item.id || String(Math.random()),
              name: item.name,
              price: item.price,
              category: item.category,
              description: item.description,
              badge: item.badge,
              imageUrl: item.imageUrl,
            });
          }
        }
        if (prodSec.ctaLabel) callsToAction.push(prodSec.ctaLabel);
      } else if (sec.type === 'features') {
        const featSec = sec as FeaturesSection;
        if (Array.isArray(featSec.items)) {
          for (const item of featSec.items) {
            features.push({
              id: item.id,
              title: item.title,
              description: item.description,
            });
          }
        }
      } else if (sec.type === 'about') {
        const aboutSec = sec as AboutSection;
        aboutHeadline = aboutSec.headline || '';
        aboutContent = aboutSec.content || '';
        if (Array.isArray(aboutSec.highlights)) {
          aboutHighlights = [...aboutSec.highlights];
        }
      } else if (sec.type === 'cta') {
        const ctaSec = sec as CtaSection;
        if (ctaSec.buttonLabel) callsToAction.push(ctaSec.buttonLabel);
      } else if (sec.type === 'contact') {
        const contSec = sec as ContactSection;
        contactInfo = {
          email: contSec.email,
          phone: contSec.phone,
          address: contSec.address,
          hours: contSec.hours,
        };
      }
    }
  }

  // Deduplicate CTAs
  const uniqueCtas = Array.from(new Set(callsToAction.filter(Boolean)));

  return {
    siteId: website.id,
    siteName: website.name || spec?.siteName || 'StorePilot Shop',
    businessName: spec?.businessName || website.name || 'StorePilot Shop',
    tagline: spec?.tagline || '',
    businessDescription: spec?.businessDescription || website.description || '',
    industry: spec?.industry || website.businessType || 'General Retail & Services',
    targetAudience: spec?.targetAudience || 'Target customers and shoppers',
    heroHeadline,
    heroSubheadline,
    heroBadge,
    products,
    features,
    aboutHeadline,
    aboutContent,
    aboutHighlights,
    callsToAction: uniqueCtas,
    contactInfo,
    themeMood: spec?.theme?.styleMood || 'Modern Minimalist',
    primaryColor: spec?.theme?.primaryColor || '#0f172a',
    accentColor: spec?.theme?.accentColor || '#6366f1',
    publishStatus: website.publishStatus || 'draft',
    publishedSlug: website.publishedSlug || website.slug,
  };
}
