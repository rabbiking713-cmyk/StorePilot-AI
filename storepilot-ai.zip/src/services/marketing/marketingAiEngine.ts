import { GoogleGenAI } from '@google/genai';
import {
  GenerateMarketingPayload,
  MarketingOutputResult,
  BusinessMarketingContext,
  SocialPostRequest,
  TikTokReelsRequest,
  VideoScriptRequest,
  AdCopyRequest,
  ProductPromoRequest,
  MarketingCampaignRequest,
} from '../../types/marketing';

// Helper to strip Markdown code fences and extract valid JSON
function cleanAndParseJson<T = any>(rawText: string): T {
  let cleaned = rawText.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  }
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  }
  return JSON.parse(cleaned);
}

// Helper to programmatically enforce strict character limits at word boundaries
function truncateToLimit(text: string, maxLen: number): string {
  if (!text || text.length <= maxLen) return text;
  const sliced = text.slice(0, maxLen).trim();
  const lastSpace = sliced.lastIndexOf(' ');
  if (lastSpace > maxLen * 0.7) {
    return sliced.slice(0, lastSpace).replace(/[,.:;!?-]+$/, '').trim();
  }
  return sliced.replace(/[,.:;!?-]+$/, '').trim();
}

// Fallback caller using modern Gemini models
async function callGemini(
  ai: GoogleGenAI,
  promptText: string,
  systemInstruction: string
): Promise<{ text: string; modelUsed: string }> {
  const models = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: promptText,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const text = response.text;
      if (text && text.trim().length > 0) {
        return { text, modelUsed: model };
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || String(err);
      console.warn(`[Marketing Engine] Model ${model} failed (${errMsg.slice(0, 100)}). Checking fallback...`);
      if (
        errMsg.includes('503') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('demand') ||
        errMsg.includes('429') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('quota') ||
        errMsg.includes('rate limit')
      ) {
        continue;
      }
      throw err;
    }
  }

  throw lastError || new Error('All Gemini generation attempts failed.');
}

/**
 * Summarize real business context into clean text for prompt injection
 */
function formatBusinessContext(ctx: BusinessMarketingContext): string {
  const productsList =
    ctx.products.length > 0
      ? ctx.products
          .map(
            (p, idx) =>
              `  ${idx + 1}. ${p.name} - Price: ${p.price || 'N/A'}${p.category ? ` (Category: ${p.category})` : ''}${
                p.badge ? ` [Badge: ${p.badge}]` : ''
              }\n     Description: ${p.description || 'N/A'}`
          )
          .join('\n')
      : '  (No individual products listed yet. Market the business and its general offerings.)';

  const featuresList =
    ctx.features.length > 0
      ? ctx.features.map((f) => `  - ${f.title}: ${f.description}`).join('\n')
      : '  - High quality and customer focus';

  const ctasList = ctx.callsToAction.length > 0 ? ctx.callsToAction.join(', ') : 'Visit Store, Explore Collection';

  return `BUSINESS PROFILE:
- Business / Brand Name: "${ctx.businessName}"
- Site Name: "${ctx.siteName}"
- Tagline: "${ctx.tagline || 'N/A'}"
- Industry / Category: "${ctx.industry}"
- Target Audience: "${ctx.targetAudience}"
- Brand Description: "${ctx.businessDescription}"
- Hero Headline: "${ctx.heroHeadline}"
- Hero Subheadline: "${ctx.heroSubheadline}"
${ctx.heroBadge ? `- Hero Highlight Badge: "${ctx.heroBadge}"` : ''}
${ctx.aboutHeadline ? `- About Headline: "${ctx.aboutHeadline}"` : ''}
${ctx.aboutContent ? `- About Story: "${ctx.aboutContent}"` : ''}
${ctx.aboutHighlights && ctx.aboutHighlights.length > 0 ? `- Key Highlights: ${ctx.aboutHighlights.join(', ')}` : ''}
- Key Brand Features:
${featuresList}
- Real Catalog Items / Products:
${productsList}
- Active Calls to Action (CTAs): ${ctasList}
- Style & Mood: ${ctx.themeMood || 'Modern Minimalist'}
- Live Status: ${ctx.publishStatus === 'published' ? `Published at /site/${ctx.publishedSlug || ''}` : 'Draft'}`;
}

const COMMON_TRUTH_RULES = `CRITICAL TRUTH & FACTUAL CONSTRAINTS:
1. ONLY reference products, prices, and features that appear in the business profile above.
2. DO NOT invent products that do not exist in the catalog.
3. DO NOT invent prices or modify provided prices. If a price is given (e.g. "$45.00"), use it accurately or omit specific prices if not needed.
4. DO NOT invent fake customer testimonials, fake reviews, fake statistics (e.g. "Over 10,000 customers"), fake awards, certifications, or guarantees.
5. If information is missing, create compelling marketing angles focused on the brand's verified mission, aesthetics, and domain rather than hallucinating facts.`;

export async function generateMarketingContent(
  ai: GoogleGenAI,
  payload: GenerateMarketingPayload
): Promise<{ result: MarketingOutputResult; modelUsed: string }> {
  const { toolType, context, options } = payload;
  const businessContextText = formatBusinessContext(context);

  switch (toolType) {
    case 'social_post': {
      const opt = options as SocialPostRequest;
      const systemInstruction = `You are StorePilot AI Marketing Studio, an expert social media strategist and copywriter.
Generate an engaging, high-converting social media post tailored for ${opt.platform.toUpperCase()}.
Tone: ${opt.tone}
Goal: ${opt.goal}
${COMMON_TRUTH_RULES}

PLATFORM CONSTRAINTS:
- Instagram: Visually descriptive, captivating hook in first 2 lines, clean line breaks, clear CTA, 7-12 niche-relevant hashtags.
- Facebook: Storytelling, conversational, question hook to invite comments, 2-3 hashtags.
- LinkedIn: Thought leadership, professional perspective, business/craftsmanship insights, clear line breaks, 3-5 professional hashtags.
- X: Punchy, high-impact hook, under 280 characters for the post body, sharp CTA, 2-3 hashtags.

OUTPUT SCHEMA (Must be valid JSON object):
{
  "platform": "${opt.platform}",
  "goal": "${opt.goal}",
  "tone": "${opt.tone}",
  "headline": "string (The hook or opening attention-grabber)",
  "body": "string (Full post body with appropriate formatting and line breaks)",
  "cta": "string (Clear Call-To-Action)",
  "hashtags": ["string", "string"]
}`;

      const promptText = `${businessContextText}

POST REQUIREMENTS:
- Platform: ${opt.platform}
- Content Goal: ${opt.goal}
- Brand Tone: ${opt.tone}
${opt.selectedProductName ? `- Selected Focus Product: "${opt.selectedProductName}"` : ''}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate the complete social post as JSON matching the schema.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);
      return { result: parsed, modelUsed };
    }

    case 'tiktok_reels': {
      const opt = options as TikTokReelsRequest;
      const systemInstruction = `You are StorePilot AI Marketing Studio, an expert short-form video creative director (TikTok & Instagram Reels).
Generate 3 to 4 viral, high-converting video concepts based on the business profile.
Tone: ${opt.tone || 'Energetic and Relatable'}
${COMMON_TRUTH_RULES}

Every video idea MUST strictly include:
- Hook (What stops the scroll in the first 2 seconds)
- Video concept (The creative premise)
- What to show (Visual framing, camera angle, action)
- On-screen text (Text overlays to retain attention)
- Suggested voiceover (Natural spoken script or talking points)
- CTA (What viewer should do next)
- Caption (Instagram/TikTok caption)
- Hashtags (4-8 trending & niche hashtags)

OUTPUT SCHEMA (Must be valid JSON object):
{
  "ideas": [
    {
      "id": "idea-1",
      "title": "string (Short catchy title for the video concept)",
      "hook": "string (Visual or verbal hook in first 2 seconds)",
      "concept": "string (Creative premise and flow)",
      "whatToShow": "string (Visual direction and action)",
      "onScreenText": "string (Exact text overlay on screen)",
      "suggestedVoiceover": "string (Spoken audio script)",
      "cta": "string (Actionable CTA)",
      "caption": "string (Caption text)",
      "hashtags": ["string", "string"]
    }
  ]
}`;

      const promptText = `${businessContextText}

VIDEO REQUIREMENTS:
- Focus Angle: ${opt.focusAngle || 'problem_solution'}
- Tone: ${opt.tone || 'Engaging & Authentic'}
${opt.focusProduct ? `- Focus Product / Service: "${opt.focusProduct}"` : ''}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate 3-4 distinct video concepts that fit the business authentically. Output valid JSON.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);
      return { result: parsed, modelUsed };
    }

    case 'video_script': {
      const opt = options as VideoScriptRequest;
      const formatLabels: Record<string, string> = {
        '15s_hook': '15-second Quick Hook & Teaser',
        '30s_promo': '30-second High-Converting Commercial / Promo',
        '60s_brand_story': '60-second Brand Story & Explainer',
        product_deep_dive: 'Product Showcase & Deep Dive',
      };

      const systemInstruction = `You are StorePilot AI Marketing Studio, an award-winning commercial video director and copywriter.
Generate a structured, professional video script with a scene-by-scene visual and audio breakdown.
Tone: ${opt.tone}
Format: ${formatLabels[opt.format] || opt.format}
${COMMON_TRUTH_RULES}

OUTPUT SCHEMA (Must be valid JSON object):
{
  "title": "string (Title of the video production)",
  "format": "${opt.format}",
  "estimatedDuration": "string (e.g. '30 seconds')",
  "hook": "string (Opening line and visual hook)",
  "problem": "string (Customer pain point or desire addressed)",
  "solution": "string (How the business/product solves it)",
  "keyBenefits": ["string", "string", "string"],
  "cta": "string (Closing call to action)",
  "scenes": [
    {
      "sceneNumber": 1,
      "timestamp": "string (e.g. '0:00 - 0:05')",
      "visualCue": "string (Camera direction, shot type, actor/product placement)",
      "audioVoiceover": "string (Exact spoken words or sound effect)",
      "onScreenText": "string (Text overlay, optional)"
    }
  ]
}`;

      const promptText = `${businessContextText}

SCRIPT REQUIREMENTS:
- Format: ${formatLabels[opt.format] || opt.format}
- Tone: ${opt.tone}
${opt.focusTopicOrProduct ? `- Specific Focus: "${opt.focusTopicOrProduct}"` : ''}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate the complete commercial script with timestamps and scenes. Output valid JSON.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);
      return { result: parsed, modelUsed };
    }

    case 'ad_copy': {
      const opt = options as AdCopyRequest;
      const platformLabels: Record<string, string> = {
        meta: 'Meta (Facebook & Instagram Ads)',
        google: 'Google Search Ads',
        tiktok: 'TikTok In-Feed Ads',
        linkedin: 'LinkedIn Sponsored Content',
      };

      const systemInstruction = `You are StorePilot AI Marketing Studio, a senior performance marketing specialist.
Generate high-converting paid ad copy tailored for ${platformLabels[opt.platform] || opt.platform}.
Objective: ${opt.objective}
Tone: ${opt.tone}
${COMMON_TRUTH_RULES}

CONSTRAINTS BY PLATFORM:
- Meta: 2-3 Primary Text variations (short, medium storytelling, punchy bullet points), 3-4 compelling Headlines (under 40 chars), 2 Descriptions, Recommended CTA button.
- Google Search: 3-4 Headlines (STRICTLY <= 30 characters each), 2 Descriptions (STRICTLY <= 90 characters each), Display path slug, and 2 audience hooks.
- TikTok: 2 punchy caption variations, sound/visual angle, clear CTA button.
- LinkedIn: 2 professional intro variations, value proposition headline, professional CTA.

OUTPUT SCHEMA (Must be valid JSON object):
{
  "platform": "${opt.platform}",
  "objective": "${opt.objective}",
  "primaryTexts": ["string (Variation 1)", "string (Variation 2)"],
  "headlines": ["string (Headline 1)", "string (Headline 2)", "string (Headline 3)"],
  "descriptions": ["string (Description 1)", "string (Description 2)"],
  "recommendedCtaButton": "string (e.g. 'Shop Now', 'Learn More', 'Get Started')",
  "displayUrlPath": "string (e.g. 'storepilot.com/site/${context.publishedSlug || 'shop'}')",
  "audienceTargetingAngles": ["string (Targeting angle 1)", "string (Targeting angle 2)"]
}`;

      const promptText = `${businessContextText}

AD CAMPAIGN REQUIREMENTS:
- Platform: ${platformLabels[opt.platform] || opt.platform}
- Advertising Objective: ${opt.objective}
- Brand Tone: ${opt.tone}
${opt.focusProductOrOffer ? `- Focus Product / Offer: "${opt.focusProductOrOffer}"` : ''}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate high-converting ad variations adhering strictly to character limits and truth constraints. Output valid JSON.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);

      // Programmatic enforcement of Google Search Ads character constraints
      if (opt.platform === 'google' && parsed) {
        if (Array.isArray(parsed.headlines)) {
          parsed.headlines = parsed.headlines.map((h: string) => truncateToLimit(String(h), 30));
        }
        if (Array.isArray(parsed.descriptions)) {
          parsed.descriptions = parsed.descriptions.map((d: string) => truncateToLimit(String(d), 90));
        }
      }

      return { result: parsed, modelUsed };
    }

    case 'product_promo': {
      const opt = options as ProductPromoRequest;
      const systemInstruction = `You are StorePilot AI Marketing Studio, a product marketing specialist.
Create a complete promotional package for a specific product or service from the store.
Angle: ${opt.promoAngle}
Tone: ${opt.tone}
${COMMON_TRUTH_RULES}

STRICT PRODUCT GROUNDING:
- Focus solely on the selected product: "${opt.productName}"
- Listed Price: "${opt.productPrice || 'N/A'}"
- NEVER invent a different price or nonexistent ingredients/materials/features.
- Create an irresistible spotlight hook, compelling feed copy, and a 3-slide story sequence (Slide 1: Hook, Slide 2: Feature/Craft, Slide 3: Urgent CTA).

OUTPUT SCHEMA (Must be valid JSON object):
{
  "productName": "${opt.productName}",
  "productPrice": "${opt.productPrice || ''}",
  "hook": "string (Attention-stopping hook)",
  "valueProposition": "string (Why customers love this exact item)",
  "feedPostCopy": "string (Ready-to-post feed caption with spacing)",
  "storySequence": [
    {
      "slideNumber": 1,
      "slideType": "hook",
      "visualCue": "string (Visual framing for slide 1)",
      "stickerOrText": "string (Interactive sticker or text overlay)",
      "captionCue": "string (Voiceover / caption)"
    },
    {
      "slideNumber": 2,
      "slideType": "feature",
      "visualCue": "string (Close up product feature)",
      "stickerOrText": "string (Text highlight)",
      "captionCue": "string (Voiceover / caption)"
    },
    {
      "slideNumber": 3,
      "slideType": "urgency_cta",
      "visualCue": "string (Packaging or final shot with link sticker)",
      "stickerOrText": "string (Link sticker / Tap to order)",
      "captionCue": "string (Final call to action)"
    }
  ],
  "cta": "string (Clear CTA)",
  "hashtags": ["string", "string"]
}`;

      const promptText = `${businessContextText}

PROMOTIONAL FOCUS:
- Target Product: "${opt.productName}"
- Stored Price: "${opt.productPrice || 'N/A'}"
- Product Description: "${opt.productDescription || 'N/A'}"
- Promotional Angle: ${opt.promoAngle}
- Tone: ${opt.tone}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate the product spotlight package as JSON.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);
      return { result: parsed, modelUsed };
    }

    case 'campaign_generator': {
      const opt = options as MarketingCampaignRequest;
      const systemInstruction = `You are StorePilot AI Marketing Studio, a Chief Marketing Officer (CMO) orchestrating an integrated multi-channel marketing campaign.
Campaign Type: ${opt.campaignType}
Duration: ${opt.durationDays} Days
Tone: ${opt.tone}
${COMMON_TRUTH_RULES}

Design a cohesive day-by-day marketing schedule across digital channels (Instagram, TikTok, Email/Newsletter, LinkedIn/X).
Every day must have a clear objective that builds momentum toward the final conversion.

OUTPUT SCHEMA (Must be valid JSON object):
{
  "campaignName": "string (Memorable, professional campaign title)",
  "concept": "string (The core narrative and campaign theme)",
  "campaignType": "${opt.campaignType}",
  "durationDays": ${opt.durationDays},
  "targetAudience": "string (Audience segment for this campaign)",
  "coreMessage": "string (Single most important message)",
  "days": [
    {
      "dayNumber": 1,
      "dayTitle": "string (e.g. 'Day 1: The Teaser & Curiosity Hook')",
      "recommendedChannel": "string (e.g. 'Instagram Stories & Reels')",
      "contentFormat": "string (e.g. 'Short video + Poll sticker')",
      "hook": "string (Opening line/hook)",
      "postSummary": "string (Brief summary of content theme)",
      "fullDraft": "string (Ready-to-use draft copy for the post)",
      "cta": "string (Specific call to action)"
    }
  ]
}`;

      const promptText = `${businessContextText}

CAMPAIGN SPECIFICATIONS:
- Campaign Theme/Type: ${opt.campaignType}
- Duration: ${opt.durationDays} Days (Generate exactly ${opt.durationDays} day plans)
- Tone: ${opt.tone}
${opt.mainFocus ? `- Main Campaign Focus: "${opt.mainFocus}"` : ''}
${opt.customInstruction ? `- Founder's Custom Instruction: "${opt.customInstruction}"` : ''}

Generate the complete ${opt.durationDays}-day campaign plan matching the schema. Output valid JSON.`;

      const { text, modelUsed } = await callGemini(ai, promptText, systemInstruction);
      const parsed = cleanAndParseJson(text);
      return { result: parsed, modelUsed };
    }

    default:
      throw new Error(`Unsupported marketing tool type: ${toolType}`);
  }
}
