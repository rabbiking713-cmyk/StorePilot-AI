import { useState, useCallback, useRef } from 'react';
import { WebsiteSpec } from '../types/websiteSpec';

const MAX_HISTORY_STEPS = 35;

export function useEditorHistory(initialSpec: WebsiteSpec) {
  const [history, setHistory] = useState<WebsiteSpec[]>([initialSpec]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentSpec = history[currentIndex] || initialSpec;

  const canUndo = currentIndex > 0;
  const canRedo = currentIndex < history.length - 1;

  const undo = useCallback(() => {
    if (canUndo) {
      setCurrentIndex((prev) => prev - 1);
    }
  }, [canUndo]);

  const redo = useCallback(() => {
    if (canRedo) {
      setCurrentIndex((prev) => prev + 1);
    }
  }, [canRedo]);

  const updateSpec = useCallback((newSpec: WebsiteSpec, recordHistory: boolean = true) => {
    setHistory((prevHistory) => {
      if (!recordHistory) {
        // Replace current state without branching history
        const updated = [...prevHistory];
        updated[currentIndex] = newSpec;
        return updated;
      }

      // Branch history: drop any states after currentIndex and append newSpec
      const sliced = prevHistory.slice(0, currentIndex + 1);
      const updated = [...sliced, newSpec];

      if (updated.length > MAX_HISTORY_STEPS) {
        updated.shift();
      }

      return updated;
    });

    if (recordHistory) {
      setCurrentIndex((prevIndex) => {
        const nextIndex = prevIndex + 1;
        return nextIndex >= MAX_HISTORY_STEPS ? MAX_HISTORY_STEPS - 1 : nextIndex;
      });
    }
  }, [currentIndex]);

  const resetHistory = useCallback((spec: WebsiteSpec) => {
    setHistory([spec]);
    setCurrentIndex(0);
  }, []);

  return {
    spec: currentSpec,
    canUndo,
    canRedo,
    undo,
    redo,
    updateSpec,
    resetHistory,
    historyLength: history.length,
    currentIndex,
  };
}
