import express from 'express';
import path from 'path';
import fs from 'fs';
import dns from 'dns';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { WebsiteSpec } from './src/types/websiteSpec';
import { CustomDomainConfig } from './src/types/customDomain';
import { CustomDomainStore } from './src/services/data/customDomainStore';
import { PublishedSiteRecord } from './src/types';
import {
  generateSitemapXml,
  generateRobotsTxt,
  getStorePilotPrimaryOrigin,
  injectSeoIntoHtml,
} from './src/services/seo/seoService';
import { generateMarketingContent } from './src/services/marketing/marketingAiEngine';
import { OrderStore } from './src/services/data/orderStore';
import { CheckoutService } from './src/services/checkout/checkoutService';
import { PrintifyService } from './src/services/commerce/printifyService';
import { PrintifyFulfillmentService } from './src/services/commerce/printifyFulfillmentService';
import { CommerceIntentService } from './src/services/commerce/commerceIntentService';
import { ProductStore } from './src/services/data/productStore';
import { StorePilotProduct, SiteType } from './src/types/commerce';
import { requireAuth, AuthenticatedRequest } from './src/services/auth/serverAuth';
import { WebsiteStore } from './src/services/data/websiteStore';
import { MarketingStore } from './src/services/data/marketingStore';
import { SavedMarketingItem } from './src/types/marketing';
import { SubscriptionStore, DEVELOPER_EMAILS } from './src/services/data/subscriptionStore';
import { PaystackSubscriptionService } from './src/services/subscription/paystackSubscriptionService';
import { requirePlan, checkWebsiteCreationLimit } from './src/services/subscription/planGating';
import { SubscriptionPlan, STOREPILOT_PLANS } from './src/types/subscription';
import { PublishedSiteStore } from './src/services/data/publishedSiteStore';

dotenv.config();

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

app.use(
  express.json({
    limit: '10mb',
    verify: (req: any, _res, buf) => {
      req.rawBody = buf?.toString();
    },
  })
);

// Helper to get Gemini client
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// AI Status check endpoint
app.get('/api/ai-status', (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  const isConfigured = Boolean(apiKey && apiKey.trim() !== '' && apiKey !== 'MY_GEMINI_API_KEY');
  res.json({
    configured: isConfigured,
    model: 'gemini-3.8-flash',
    provider: 'Google AI Studio / Gemini API',
  });
});

// Helper to call Gemini with automatic 503 overload fallback
async function callGeminiJson(
  ai: GoogleGenAI,
  promptText: string,
  systemInstruction: string
): Promise<{ text: string; modelUsed: string }> {
  const models = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: promptText,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
        },
      });

      const text = response.text;
      if (text && text.trim().length > 0) {
        return { text, modelUsed: model };
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || String(err);
      console.warn(`Model ${model} call failed (${errMsg.slice(0, 100)}). Checking fallback...`);
      // If error is 503 / UNAVAILABLE / high demand or 429 / RESOURCE_EXHAUSTED / quota, try next model in loop
      if (
        errMsg.includes('503') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('demand') ||
        errMsg.includes('429') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('quota') ||
        errMsg.includes('rate limit')
      ) {
        continue;
      }
      throw err;
    }
  }

  throw lastError || new Error('All Gemini generation attempts failed.');
}

// Helper to strip Markdown code fences and extract valid JSON
function cleanAndParseJson<T = any>(rawText: string): T {
  let cleaned = rawText.trim();
  // Strip ```json ... ``` or ``` ... ```
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  }
  // If there's still surrounding text, find outermost { and }
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  }
  return JSON.parse(cleaned);
}

// Generate Website Endpoint (Starter users can build + preview; publishing is gated)
app.post('/api/generate-website', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { prompt, businessType } = req.body;

    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Please provide a prompt describing the website or business you want to build.',
      });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error:
          'GEMINI_API_KEY is not configured in the server environment. Please configure your GEMINI_API_KEY in the AI Studio Secrets panel.',
      });
    }

    const systemInstruction = `You are StorePilot AI, the premier website generation engine.
Your mission is to take a founder's natural language business prompt and generate a complete, professional, highly converting, structured website specification (WebsiteSpec).

STRICT RULES:
1. Output MUST be a valid JSON object matching the following structure exactly.
2. Tailor every piece of text, product, service, pricing, and visual style to the exact business domain described in the prompt.
3. Include realistic, high-quality content:
   - Specific headline & subheadline that sound like a real top-tier brand.
   - 3-4 feature or value proposition cards.
   - 3-6 realistic products or services with pricing (e.g. "$45.00" or local currency), badges ("Best Seller", "New", "Signature"), and descriptions.
   - An inspiring "About" section with founder storytelling and 3 key highlights.
   - 2-3 genuine customer testimonials with realistic names, titles, and ratings (5).
   - A compelling Call-To-Action (CTA) section.
   - A complete Contact section with email, phone, location address, and open hours.
   - Header with brand name, tagline, navigation links, and primary CTA.
   - Footer with copyright, short brand summary, and quick links.
4. Themes: Choose aesthetic primaryColor, accentColor, backgroundColor, textColor, and fontFamily ('sans', 'serif', or 'mono') that fit the brand mood.
5. Image URLs: Use high-quality, relevant Unsplash photos with valid HTTPS URLs (e.g. photos of fashion, cafe, tech, ceramics, architecture) with suitable descriptive keywords.

SCHEMA STRUCTURE:
{
  "siteName": "string",
  "businessName": "string",
  "tagline": "string",
  "businessDescription": "string",
  "industry": "string",
  "targetAudience": "string",
  "theme": {
    "primaryColor": "string (hex code, e.g. #0f172a or #2563eb)",
    "accentColor": "string (hex code, e.g. #f59e0b or #10b981)",
    "backgroundColor": "string (hex code, e.g. #ffffff or #f8fafc)",
    "textColor": "string (hex code, e.g. #0f172a)",
    "fontFamily": "sans" | "serif" | "mono",
    "styleMood": "string"
  },
  "header": {
    "brandName": "string",
    "tagline": "string",
    "navLinks": [
      { "id": "nav-1", "label": "string", "targetSectionId": "section-id" }
    ],
    "ctaButton": {
      "label": "string",
      "targetSectionId": "section-id"
    }
  },
  "sections": [
    {
      "type": "hero",
      "id": "hero",
      "badge": "string",
      "headline": "string",
      "subheadline": "string",
      "primaryCta": { "label": "string", "targetSectionId": "products" },
      "secondaryCta": { "label": "string", "targetSectionId": "about" },
      "imageUrl": "https://images.unsplash.com/..."
    },
    {
      "type": "features",
      "id": "features",
      "title": "string",
      "subtitle": "string",
      "items": [
        {
          "id": "f-1",
          "title": "string",
          "description": "string",
          "iconName": "Sparkles" | "Shield" | "Zap" | "Truck" | "Star" | "Clock" | "Check" | "Heart"
        }
      ]
    },
    {
      "type": "products",
      "id": "products",
      "title": "string",
      "subtitle": "string",
      "currencySymbol": "string (e.g. $, â‚µ, Â£, â‚¬)",
      "items": [
        {
          "id": "p-1",
          "name": "string",
          "price": "string",
          "category": "string",
          "description": "string",
          "badge": "string",
          "imageUrl": "https://images.unsplash.com/..."
        }
      ]
    },
    {
      "type": "about",
      "id": "about",
      "title": "string",
      "headline": "string",
      "content": "string",
      "highlights": ["string", "string", "string"],
      "imageUrl": "https://images.unsplash.com/..."
    },
    {
      "type": "testimonials",
      "id": "testimonials",
      "title": "string",
      "subtitle": "string",
      "items": [
        {
          "id": "t-1",
          "quote": "string",
          "author": "string",
          "role": "string",
          "rating": 5
        }
      ]
    },
    {
      "type": "cta",
      "id": "cta",
      "headline": "string",
      "subheadline": "string",
      "buttonLabel": "string",
      "targetSectionId": "contact"
    },
    {
      "type": "contact",
      "id": "contact",
      "title": "string",
      "subtitle": "string",
      "email": "string",
      "phone": "string",
      "address": "string",
      "hours": "string",
      "formEnabled": true
    }
  ],
  "footer": {
    "brandName": "string",
    "copyright": "string",
    "description": "string",
    "quickLinks": [{ "label": "string", "href": "#section" }],
    "socialLinks": [{ "platform": "Twitter", "url": "https://twitter.com" }]
  }
}`;

    const promptText = `Generate a full, production-ready website specification for the following business prompt:
"""
${prompt.trim()}
"""
${businessType ? `Suggested Business Category: ${businessType}` : ''}`;

    const { text: responseText, modelUsed } = await callGeminiJson(
      ai,
      promptText,
      systemInstruction
    );

    const parsedSpec: WebsiteSpec = cleanAndParseJson<WebsiteSpec>(responseText);

    // Sanity checks on parsed schema
    if (!parsedSpec.siteName || !Array.isArray(parsedSpec.sections)) {
      throw new Error('AI output did not contain valid website sections or site name.');
    }

    return res.json({
      success: true,
      spec: parsedSpec,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in /api/generate-website:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to generate website specification from Gemini.',
    });
  }
});

// Refine / Regenerate Website Endpoint (Starter users can build + preview; publishing is gated)
app.post('/api/refine-website', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { currentSpec, refinementPrompt } = req.body;

    if (!currentSpec || !refinementPrompt || typeof refinementPrompt !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Missing currentSpec or refinementPrompt for website refinement.',
      });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error:
          'GEMINI_API_KEY is not configured in the server environment. Please configure your GEMINI_API_KEY in the AI Studio Secrets panel.',
      });
    }

    const systemInstruction = `You are StorePilot AI, the premier website generation engine.
You are given an existing structured website specification (WebsiteSpec in JSON) and a user's refinement instruction (e.g. "make it more modern", "use a luxury style", "make colors more energetic", "add a services section", "change the headline", etc.).
Your job is to apply the requested refinement to the specification while preserving the existing content that was not requested to change.
Return ONLY the updated WebsiteSpec JSON object.`;

    const promptText = `EXISTING WEBSITE SPECIFICATION:
${JSON.stringify(currentSpec, null, 2)}

USER REFINEMENT INSTRUCTION:
"""
${refinementPrompt.trim()}
"""

Apply this instruction and return the updated WebsiteSpec JSON.`;

    const { text: responseText, modelUsed } = await callGeminiJson(
      ai,
      promptText,
      systemInstruction
    );

    const updatedSpec: WebsiteSpec = cleanAndParseJson<WebsiteSpec>(responseText);

    return res.json({
      success: true,
      spec: updatedSpec,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error('Error in /api/refine-website:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to refine website specification with Gemini.',
    });
  }
});

// ============================================================================
// PHASE 4A: PUBLISHED WEBSITES REGISTRY & ENDPOINTS
// ============================================================================

const DATA_DIR = path.resolve('data');
const PUBLISHED_SITES_FILE = path.join(DATA_DIR, 'published_sites.json');

// In-memory registry for rapid lookups backed by PublishedSiteStore
const publishedSitesMap = PublishedSiteStore.getRawMemoryMap();
// Global registry of site ownership across sessions (siteId -> userId)
const siteOwnershipMap: Map<string, string> = new Map();

async function loadPublishedSites() {
  await PublishedSiteStore.initialize();
  for (const r of publishedSitesMap.values()) {
    if (r.siteId && r.userId) {
      siteOwnershipMap.set(r.siteId, r.userId);
    }
  }
}

// Initial load
loadPublishedSites().catch((err) => {
  console.warn('Failed to load published sites:', err);
});
WebsiteStore.initialize();
MarketingStore.initialize();

// ============================================================================
// STOREPILOT WEBSITES API (DURABLE & STRICT MERCHANT OWNERSHIP ISOLATION)
// ============================================================================

// 1. Get All Websites Owned by Authenticated User
app.get('/api/websites', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const websites = await WebsiteStore.getWebsitesByOwner(userId);
    return res.json({ success: true, websites });
  } catch (err: any) {
    console.error('Error in GET /api/websites:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve websites.' });
  }
});

// 2. Create Website (ownerId Derived Exclusively from Authenticated Identity)
app.post('/api/websites', requireAuth, checkWebsiteCreationLimit, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id, name, businessType, description, originalPrompt, spec, isDemo } = req.body;

    if (!name || typeof name !== 'string') {
      return res.status(400).json({ success: false, error: 'Website name is required.' });
    }

    const website = await WebsiteStore.createWebsite(userId, {
      id: typeof id === 'string' && id ? id : undefined,
      name,
      businessType: businessType || 'General Business',
      description: description || '',
      originalPrompt,
      spec,
      isDemo,
    });

    return res.json({ success: true, website });
  } catch (err: any) {
    console.error('Error in POST /api/websites:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to create website.' });
  }
});

// 3. Get Single Website by ID (Strict Owner Isolation)
app.get('/api/websites/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id } = req.params;
    const website = await WebsiteStore.getWebsiteById(id, userId);

    if (!website) {
      return res.status(404).json({ success: false, error: 'Website not found or access denied.' });
    }

    return res.json({ success: true, website });
  } catch (err: any) {
    console.error('Error in GET /api/websites/:id:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve website.' });
  }
});

// 4. Update Website (Strict Owner Isolation)
app.patch('/api/websites/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id } = req.params;
    const updates = req.body;

    const updated = await WebsiteStore.updateWebsite(id, userId, updates);
    return res.json({ success: true, website: updated });
  } catch (err: any) {
    console.error('Error in PATCH /api/websites/:id:', err);
    const status = err?.message?.includes('Forbidden') ? 403 : err?.message?.includes('not found') ? 404 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to update website.' });
  }
});

// 5. Delete Website (Strict Owner Isolation)
app.delete('/api/websites/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id } = req.params;

    const deleted = await WebsiteStore.deleteWebsite(id, userId);
    return res.json({ success: true, deleted });
  } catch (err: any) {
    console.error('Error in DELETE /api/websites/:id:', err);
    const status = err?.message?.includes('Forbidden') ? 403 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to delete website.' });
  }
});

// 6. Duplicate Website (Strict Owner Isolation)
app.post('/api/websites/:id/duplicate', requireAuth, checkWebsiteCreationLimit, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id } = req.params;

    const duplicated = await WebsiteStore.duplicateWebsite(id, userId);
    return res.json({ success: true, website: duplicated });
  } catch (err: any) {
    console.error('Error in POST /api/websites/:id/duplicate:', err);
    const status = err?.message?.includes('Forbidden') ? 403 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to duplicate website.' });
  }
});

// ============================================================================
// PHASE 5: AI MARKETING STUDIO ENDPOINTS (DURABLE & OWNER ISOLATED)
// ============================================================================

// 1. Get Saved Marketing Library for Authenticated User
app.get('/api/marketing', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const items = await MarketingStore.getItemsByUser(userId);
    return res.json({ success: true, items });
  } catch (err: any) {
    console.error('Error in GET /api/marketing:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve marketing library.' });
  }
});

// 2. Save Item to Marketing Library
app.post('/api/marketing', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, websiteName, toolType, title, result } = req.body;

    if (!websiteId || !toolType || !title || !result) {
      return res.status(400).json({ success: false, error: 'Missing required marketing item fields.' });
    }

    const newItem: SavedMarketingItem = {
      id: `mkt_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
      userId, // Authoritative authenticated UID
      websiteId,
      websiteName: websiteName || 'Website',
      toolType,
      title,
      result,
      createdAt: new Date().toISOString(),
    };

    const saved = await MarketingStore.saveItem(newItem);
    return res.json({ success: true, item: saved });
  } catch (err: any) {
    console.error('Error in POST /api/marketing:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to save marketing item.' });
  }
});

// 3. Delete Saved Marketing Item
app.delete('/api/marketing/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { id } = req.params;

    const deleted = await MarketingStore.deleteItem(id, userId);
    return res.json({ success: true, deleted });
  } catch (err: any) {
    console.error('Error in DELETE /api/marketing/:id:', err);
    const status = err?.message?.includes('Forbidden') ? 403 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to delete marketing item.' });
  }
});

// 4. Generate Marketing with Gemini (Gated to Professional and Agency subscribers)
app.post('/api/generate-marketing', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { toolType, context, options, websiteId: rawWebsiteId } = req.body;
    const websiteId = rawWebsiteId || context?.siteId;

    if (!websiteId || typeof websiteId !== 'string' || websiteId.trim() === '') {
      return res.status(400).json({
        success: false,
        error: 'Bad Request: A valid websiteId is required to generate marketing content.',
      });
    }

    if (!toolType || !context || !options) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: toolType, context, and options are required.',
      });
    }

    // Grounding: Retrieve real stored WebsiteSpec if available
    const userSite = await WebsiteStore.getWebsiteById(websiteId, userId);
    if (userSite?.spec) {
      const realSpec = userSite.spec;
      if (realSpec.siteName && (!context.siteName || context.siteName === 'StorePilot Shop')) {
        context.siteName = realSpec.siteName;
      }
      if (realSpec.businessName && (!context.businessName || context.businessName === 'StorePilot Shop')) {
        context.businessName = realSpec.businessName;
      }
      if (realSpec.industry && (!context.industry || context.industry === 'General Retail & Services')) {
        context.industry = realSpec.industry;
      }
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error:
          'GEMINI_API_KEY is not configured in the server environment. Please configure your GEMINI_API_KEY in the AI Studio Secrets panel.',
      });
    }

    const { result, modelUsed } = await generateMarketingContent(ai, {
      toolType,
      context,
      options,
    });

    return res.json({
      success: true,
      toolType,
      result,
      modelUsed,
    });
  } catch (error: any) {
    console.error('Error in /api/generate-marketing:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to generate marketing content with Gemini.',
    });
  }
});

// Initialize durable CustomDomainStore (Firestore in production / sandbox in dev)
CustomDomainStore.initialize().catch((err) => {
  console.error('[StorePilot] Failed to initialize CustomDomainStore:', err);
});

// Initialize durable OrderStore (Firestore in production / sandbox in dev)
OrderStore.initialize().catch((err) => {
  console.error('[StorePilot] Failed to initialize OrderStore:', err);
});

// Initialize durable ProductStore (Firestore in production / sandbox in dev)
ProductStore.initialize().catch((err) => {
  console.error('[StorePilot] Failed to initialize ProductStore:', err);
});

// ============================================================================
// PHASE 9: PAYSTACK SAAS SUBSCRIPTIONS & SECURE PLAN GATING
// ============================================================================

// Initialize durable SubscriptionStore
SubscriptionStore.initialize();

// 1. Get current user's authoritative subscription status
app.get('/api/subscription/status', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const email = req.user!.email;
    const isDeveloper = SubscriptionStore.isDeveloperAccount(email, userId);

    if (isDeveloper && email) {
      SubscriptionStore.registerDeveloperUid(userId, email);
    }

    const sub = await SubscriptionStore.getSubscription(userId, email);
    const planDef = STOREPILOT_PLANS[sub.plan] || STOREPILOT_PLANS.starter;

    return res.json({
      success: true,
      plan: sub.plan,
      subscriptionStatus: sub.subscriptionStatus,
      isDeveloper: Boolean(sub.isDeveloper || isDeveloper),
      developerTier: isDeveloper ? 'Agency / Studio Exemption' : undefined,
      currentPeriodStart: sub.currentPeriodStart,
      currentPeriodEnd: sub.currentPeriodEnd,
      paystackCustomerCode: sub.paystackCustomerCode,
      paystackConfigured: PaystackSubscriptionService.isPaystackConfigured(),
      websiteLimit: planDef.websiteLimit,
    });
  } catch (err: any) {
    console.error('Error in GET /api/subscription/status:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve subscription status.' });
  }
});

// 2. Initialize Paystack Subscription Checkout (Server-authoritative pricing)
app.post('/api/subscription/initialize', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const email = req.user!.email;

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Your account must have an associated email address to subscribe.',
      });
    }

    const { plan, callbackUrl } = req.body;
    if (plan !== 'professional' && plan !== 'agency') {
      return res.status(400).json({
        success: false,
        error: 'Invalid plan selected. Only Professional ($29/mo) and Agency ($79/mo) plans require checkout.',
      });
    }

    const defaultCallback = callbackUrl || `${req.protocol}://${req.get('host')}/?subscription_callback=1`;
    const result = await PaystackSubscriptionService.initializeCheckout(
      userId,
      email,
      plan as SubscriptionPlan,
      defaultCallback
    );

    const status = result.success ? 200 : !result.paystackConfigured ? 503 : 400;
    return res.status(status).json(result);
  } catch (err: any) {
    console.error('Error in POST /api/subscription/initialize:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to initialize subscription checkout.' });
  }
});

// 3. Verify Initial Subscription Payment Server-Side with Paystack
app.get('/api/subscription/verify/:reference', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { reference } = req.params;
    if (!reference || typeof reference !== 'string') {
      return res.status(400).json({ success: false, error: 'Transaction reference is required.' });
    }

    const userId = req.user!.uid;
    const result = await PaystackSubscriptionService.verifyPayment(reference.trim(), userId);
    const status = result.success ? 200 : 400;
    return res.status(status).json(result);
  } catch (err: any) {
    console.error('Error in GET /api/subscription/verify/:reference:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Payment verification failed.' });
  }
});

// 4. Paystack Subscription Webhook Handler
app.post('/api/subscription/webhook', async (req, res) => {
  try {
    const signature = req.headers['x-paystack-signature'] as string;
    const rawBody = (req as any).rawBody || JSON.stringify(req.body);

    const isValid = PaystackSubscriptionService.verifyWebhookSignature(rawBody, signature);
    if (!isValid) {
      console.warn('[SubscriptionWebhook] Invalid Paystack webhook signature rejected.');
      return res.status(401).send('Invalid webhook signature');
    }

    const event = req.body;
    const result = await PaystackSubscriptionService.handleWebhookEvent(event);
    return res.status(200).json({ success: true, ...result });
  } catch (err: any) {
    console.error('Error in /api/subscription/webhook:', err);
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 5. Cancel Subscription (Preserves all websites, orders, and products)
app.post('/api/subscription/cancel', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const result = await PaystackSubscriptionService.cancelSubscription(userId);
    return res.json(result);
  } catch (err: any) {
    console.error('Error in POST /api/subscription/cancel:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to cancel subscription.' });
  }
});

// ============================================================================
// PHASE 6: REAL CUSTOMER CHECKOUT & ORDER MANAGEMENT ENDPOINTS
// ============================================================================

// 1. Initialize Customer Checkout & Paystack Transaction
app.post('/api/checkout/initialize', async (req, res) => {
  try {
    const { slug, siteId, customer, items } = req.body;

    if (!slug && !siteId) {
      return res.status(400).json({ success: false, error: 'A valid store slug or siteId is required.' });
    }

    if (!customer || typeof customer !== 'object') {
      return res.status(400).json({ success: false, error: 'Customer fulfillment information is required.' });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Cart must contain at least one item.' });
    }

    // Lookup published site record
    let siteRecord: PublishedSiteRecord | null | undefined;
    if (slug) {
      siteRecord = await PublishedSiteStore.getBySlug(String(slug).toLowerCase().trim());
    }
    if (!siteRecord && siteId) {
      siteRecord = await PublishedSiteStore.getBySiteId(siteId);
    }

    if (!siteRecord || !siteRecord.publishedSpec) {
      return res.status(404).json({
        success: false,
        error: 'The requested store is not published or active.',
      });
    }

    const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    const host = req.get('host') || `localhost:${port}`;
    const originUrl = `${protocol}://${host}`;

    const result = await CheckoutService.initializeCheckout({
      siteId: siteRecord.siteId,
      siteSlug: siteRecord.slug,
      siteName: siteRecord.name || siteRecord.publishedSpec.siteName || 'StorePilot Store',
      ownerId: siteRecord.userId,
      spec: siteRecord.publishedSpec,
      customer,
      rawItems: items,
      originUrl,
    });

    const isStorageUnavailable = Boolean(
      result.error?.toLowerCase().includes('storage unavailable') ||
      result.error?.toLowerCase().includes('database unavailable') ||
      result.error?.toLowerCase().includes('firestore')
    );
    const statusCode = result.success ? 200 : isStorageUnavailable || !result.paystackConfigured ? 503 : 400;
    return res.status(statusCode).json(result);
  } catch (err: any) {
    console.error('Error in /api/checkout/initialize:', err);
    return res.status(400).json({ success: false, error: err?.message || 'Failed to initialize checkout.' });
  }
});

// 2. Verify Payment Callback Server-Side with Paystack
app.get('/api/checkout/verify/:reference', async (req, res) => {
  try {
    const { reference } = req.params;
    if (!reference || typeof reference !== 'string') {
      return res.status(400).json({ success: false, error: 'Order reference is required.' });
    }

    const result = await CheckoutService.verifyPayment(reference.trim());
    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/checkout/verify:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Payment verification failed.' });
  }
});

// 3. Customer Order Receipt Lookup
app.get('/api/checkout/order/:reference', async (req, res) => {
  try {
    const { reference } = req.params;
    if (!reference || typeof reference !== 'string') {
      return res.status(400).json({ success: false, error: 'Order reference is required.' });
    }

    const order = await OrderStore.getOrderByReference(reference.trim());
    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found.' });
    }

    return res.json({ success: true, order });
  } catch (err: any) {
    console.error('Error in /api/checkout/order:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve order receipt.' });
  }
});

// 4. Secure Paystack Webhook Handler
app.post('/api/checkout/webhook', async (req, res) => {
  try {
    const signature = req.headers['x-paystack-signature'] as string;
    const rawBody = (req as any).rawBody || JSON.stringify(req.body);

    const isValid = CheckoutService.verifyWebhookSignature(rawBody, signature);
    if (!isValid) {
      console.warn('[Webhook] Invalid Paystack webhook signature rejected.');
      return res.status(401).send('Invalid webhook signature');
    }

    const event = req.body;
    if (event?.event === 'charge.success') {
      const data = event.data;
      const reference = data?.reference;
      if (reference) {
        const order = await OrderStore.getOrderByReference(reference);
        if (order) {
          // Idempotency: if already paid, skip duplicate processing
          if (order.paymentStatus === 'PAID') {
            console.log(`[Webhook] Order ${reference} is already marked as PAID (idempotent).`);
            return res.status(200).send('Webhook processed (already paid)');
          }

          // Strict amount and currency checks
          const isCurrencyMatch =
            !order.currency ||
            !data.currency ||
            data.currency.toUpperCase() === order.currency.toUpperCase();
          const isAmountMatch =
            typeof data.amount === 'number' && data.amount >= order.totalInSubunits;

          if (isCurrencyMatch && isAmountMatch) {
            const updated = await OrderStore.updatePaymentStatus(reference, 'PAID', {
              paystackReference: data.reference,
              channel: data.channel,
              paidAt: data.paid_at || new Date().toISOString(),
            });
            console.log(`[Webhook] Order ${reference} verified as PAID via Paystack webhook.`);

            // Trigger Printify fulfillment for verified paid order
            if (updated) {
              try {
                await PrintifyFulfillmentService.submitOrderToPrintify(updated);
              } catch (fulfillErr) {
                console.error('[Webhook] Printify fulfillment submission error:', fulfillErr);
              }
            }
          } else {
            console.warn(
              `[Webhook] Amount or currency mismatch for order ${reference}. Paid: ${data.amount} ${data.currency}, Required: ${order.totalInSubunits} ${order.currency}`
            );
            await OrderStore.updatePaymentStatus(reference, 'FAILED');
          }
        } else {
          console.warn(`[Webhook] Received charge.success for unrecognized order reference: ${reference}`);
        }
      }
    }

    return res.status(200).send('Webhook processed successfully');
  } catch (err: any) {
    console.error('Error in /api/checkout/webhook:', err);
    return res.status(500).send('Webhook processing error');
  }
});

// 5. Store Owner Orders List (Strict Owner Isolation)
app.get('/api/orders', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId } = req.query;
    let orders = await OrderStore.getOrdersByOwner(userId);

    if (websiteId && typeof websiteId === 'string' && websiteId.trim() !== '') {
      orders = orders.filter((o) => o.websiteId === websiteId || o.websiteSlug === websiteId);
    }

    return res.json({ success: true, orders });
  } catch (err: any) {
    console.error('Error in /api/orders:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve orders.' });
  }
});

// 6. Store Owner Order Detail Lookup (Strict Owner Isolation)
app.get('/api/orders/:orderId', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { orderId } = req.params;
    const order = await OrderStore.getOrderById(orderId);

    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found.' });
    }

    // Owner Isolation Enforcement
    if (order.ownerId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: You do not have permission to view this customer order.',
      });
    }

    return res.json({ success: true, order });
  } catch (err: any) {
    console.error('Error in /api/orders/:orderId:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve order.' });
  }
});

// 7. Store Owner Order Fulfillment Status Update (Strict Owner Isolation)
app.patch('/api/orders/:orderId/status', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { orderId } = req.params;
    const { orderStatus } = req.body;

    const validStatuses = ['NEW', 'PROCESSING', 'SHIPPED', 'COMPLETED', 'CANCELLED'];
    if (!orderStatus || !validStatuses.includes(orderStatus)) {
      return res.status(400).json({
        success: false,
        error: `Invalid orderStatus. Allowed values: ${validStatuses.join(', ')}`,
      });
    }

    const updated = await OrderStore.updateOrderStatus(orderId, userId, orderStatus);
    return res.json({ success: true, order: updated });
  } catch (err: any) {
    console.error('Error in /api/orders/:orderId/status:', err);
    const status = err?.message?.includes('Forbidden') ? 403 : err?.message?.includes('not found') ? 404 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to update order status.' });
  }
});

// 8. Store Owner Trigger Printify Fulfillment (Strict Owner Isolation & Payment Verification)
app.post('/api/orders/:orderId/fulfill-printify', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { orderId } = req.params;
    const order = await OrderStore.getOrderById(orderId);
    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found.' });
    }

    if (order.ownerId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: You do not own the website associated with this order.',
      });
    }

    // NON-NEGOTIABLE SECURITY: Order must be verified as PAID
    if (order.paymentStatus !== 'PAID') {
      return res.status(400).json({
        success: false,
        error: `Cannot submit unverified order to Printify. Order payment status is ${order.paymentStatus}.`,
      });
    }

    const result = await PrintifyFulfillmentService.submitOrderToPrintify(order);
    const refreshed = (await OrderStore.getOrderById(orderId)) || order;
    return res.json({ ...result, order: refreshed });
  } catch (err: any) {
    console.error('Error in /api/orders/:orderId/fulfill-printify:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to submit order to Printify.' });
  }
});

// 9. Store Owner Sync Printify Order Tracking & Status (Strict Owner Isolation)
app.post('/api/orders/:orderId/sync-printify', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { orderId } = req.params;
    const result = await PrintifyFulfillmentService.syncOrderFulfillment(orderId, userId);

    if (!result.success) {
      const status = result.error?.includes('Forbidden') ? 403 : result.error?.includes('not found') ? 404 : 400;
      return res.status(status).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/orders/:orderId/sync-printify:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to sync with Printify.' });
  }
});

// 10. Store Owner Push Order to Production (Strict Owner Isolation)
app.post('/api/orders/:orderId/send-to-production', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { orderId } = req.params;
    const result = await PrintifyFulfillmentService.sendToProduction(orderId, userId);

    if (!result.success) {
      const status = result.error?.includes('Forbidden') ? 403 : result.error?.includes('not found') ? 404 : 400;
      return res.status(status).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/orders/:orderId/send-to-production:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to send to production.' });
  }
});

// ============================================================================
// PHASE 7A: AI COMMERCE DETECTION & PRINTIFY PRODUCT ENGINE ENDPOINTS
// ============================================================================

// 1. Detect Commerce Intent from Prompt
app.post('/api/commerce/detect-intent', async (req, res) => {
  try {
    const { prompt, businessType } = req.body;
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'A prompt string is required.' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      const fallback = CommerceIntentService.classifyWithRules(prompt, businessType);
      return res.json({ success: true, ...fallback });
    }

    try {
      const systemInstruction = `You are the StorePilot AI Commerce Intent Analyzer.
Your task is to analyze a founder's website request and determine whether they intend to build an E-COMMERCE STORE that sells physical merchandise or products, or a NON-COMMERCE website (Blog, Portfolio, Personal, Business, Education, Service, Creative).

IMPORTANT RULES:
StorePilot is a GENERAL AI website builder first. Do NOT turn every website into an e-commerce store!
- A photography portfolio, lawyer website, blog, educational academy, medical clinic, or resume is NON-COMMERCE (isCommerce: false).
- A store selling sneakers, clothing, hoodies, jewelry, mugs, or print-on-demand merchandise is COMMERCE (isCommerce: true).

Output MUST be a JSON object with this exact schema:
{
  "isCommerce": boolean,
  "siteType": "BLOG" | "PORTFOLIO" | "PERSONAL" | "BUSINESS" | "EDUCATION" | "SERVICE" | "CREATIVE" | "ECOMMERCE",
  "confidence": number,
  "detectedProductQuery": "concise catalog search term like 'sneakers' or 'hoodie' or null",
  "suggestedStyle": "clean modern or streetwear or luxury or artisanal",
  "targetAudience": "target demographic",
  "reasoning": "short explanation"
}`;

      const aiResponse = await callGeminiJson(
        ai,
        `User Prompt: "${prompt}"\nBusiness Type Hint: "${businessType || 'General'}"`,
        systemInstruction
      );

      const parsed = cleanAndParseJson<any>(aiResponse.text);
      const isComm = Boolean(parsed.isCommerce);
      const siteType: SiteType = parsed.siteType || (isComm ? 'ECOMMERCE' : 'BUSINESS');

      return res.json({
        success: true,
        isCommerce: isComm,
        siteType,
        confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 0.9,
        detectedProductQuery: parsed.detectedProductQuery || (isComm ? 'apparel' : undefined),
        suggestedStyle: parsed.suggestedStyle || 'Modern Minimalist',
        targetAudience: parsed.targetAudience || 'General Audience',
        reasoning: parsed.reasoning || 'Evaluated by StorePilot AI',
      });
    } catch (aiErr) {
      console.warn('[CommerceIntent] Gemini analysis fallback to rule engine:', aiErr);
      const fallback = CommerceIntentService.classifyWithRules(prompt, businessType);
      return res.json({ success: true, ...fallback });
    }
  } catch (err: any) {
    console.error('Error in /api/commerce/detect-intent:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Intent detection failed.' });
  }
});

// 2. Search Real Printify Catalog (Authenticated)
app.post('/api/commerce/printify/search', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { query, limit } = req.body;
    const searchLimit = typeof limit === 'number' ? Math.min(50, Math.max(1, limit)) : 20;

    const result = await PrintifyService.searchCatalog(query || '', searchLimit);
    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/commerce/printify/search:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Search failed.' });
  }
});

// 3. Get Real Printify Product Blueprint Details (Authenticated)
app.get('/api/commerce/printify/product/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const blueprintId = parseInt(req.params.id, 10);
    if (isNaN(blueprintId) || blueprintId <= 0) {
      return res.status(400).json({ success: false, error: 'Valid Printify product ID is required.' });
    }

    const result = await PrintifyService.getBlueprintDetails(blueprintId);
    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/commerce/printify/product/:id:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve product details.' });
  }
});

// 4. Retrieve Merchant Approved Products (Authenticated & Tenant Isolated)
app.get('/api/commerce/products', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId } = req.query;
    let products: StorePilotProduct[] = [];
    if (websiteId && typeof websiteId === 'string' && websiteId.trim() !== '') {
      products = await ProductStore.getProductsByWebsite(websiteId.trim(), userId);
    } else {
      products = await ProductStore.getProductsByOwner(userId);
    }

    return res.json({ success: true, products });
  } catch (err: any) {
    console.error('Error in /api/commerce/products:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to retrieve products.' });
  }
});

// 5. Merchant Explicit Product Approval (Authenticated)
app.post('/api/commerce/products/approve', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, products } = req.body;
    if (!websiteId || typeof websiteId !== 'string') {
      return res.status(400).json({ success: false, error: 'websiteId is required.' });
    }

    if (!Array.isArray(products) || products.length === 0) {
      return res.status(400).json({ success: false, error: 'At least one product must be selected for approval.' });
    }

    const savedProducts: StorePilotProduct[] = [];
    for (const raw of products) {
      if (!raw.printifyBlueprintId || typeof raw.printifyBlueprintId !== 'number') {
        return res.status(400).json({
          success: false,
          error: 'Valid printifyBlueprintId is required for all approved products.',
        });
      }

      const prodId = raw.id || `sp_prod_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
      const now = new Date().toISOString();

      const newProduct: StorePilotProduct = {
        id: prodId,
        websiteId: websiteId.trim(),
        ownerId: userId,
        printifyBlueprintId: raw.printifyBlueprintId,
        printifyPrintProviderId: raw.printifyPrintProviderId || undefined,
        printifyVariantId: raw.printifyVariantId || undefined,
        printifyShopProductId: raw.printifyShopProductId || undefined,
        printifyTitle: raw.printifyTitle || raw.storefrontTitle || 'Printify Product',
        printifyBrand: raw.printifyBrand || undefined,
        printifyModel: raw.printifyModel || undefined,
        storefrontTitle: raw.storefrontTitle || raw.printifyTitle || 'Product',
        storefrontDescription: raw.storefrontDescription || 'Premium custom crafted product.',
        storefrontPrice:
          typeof raw.storefrontPrice === 'number' && raw.storefrontPrice > 0 ? raw.storefrontPrice : 45,
        currency: raw.currency || 'USD',
        currencySymbol: raw.currencySymbol || '$',
        images:
          Array.isArray(raw.images) && raw.images.length > 0
            ? raw.images
            : ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80'],
        isApproved: true,
        isFeatured: Boolean(raw.isFeatured),
        badge: raw.badge || undefined,
        category: raw.category || undefined,
        createdAt: now,
        updatedAt: now,
      };

      const saved = await ProductStore.saveProduct(newProduct);
      savedProducts.push(saved);
    }

    return res.json({ success: true, count: savedProducts.length, products: savedProducts });
  } catch (err: any) {
    console.error('Error in /api/commerce/products/approve:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to approve products.' });
  }
});

// 6. Update Product Storefront Presentation (Authenticated & Owner Isolated)
app.patch('/api/commerce/products/:productId', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { productId } = req.params;
    const updates = req.body;

    const updated = await ProductStore.updateProduct(productId, userId, updates);
    return res.json({ success: true, product: updated });
  } catch (err: any) {
    console.error('Error in /api/commerce/products/:productId:', err);
    const status = err?.message?.includes('access denied') ? 403 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to update product.' });
  }
});

// 7. Delete Product (Authenticated & Owner Isolated)
app.delete('/api/commerce/products/:productId', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { productId } = req.params;
    await ProductStore.deleteProduct(productId, userId);
    return res.json({ success: true, deleted: true });
  } catch (err: any) {
    console.error('Error in DELETE /api/commerce/products/:productId:', err);
    const status = err?.message?.includes('access denied') ? 403 : 500;
    return res.status(status).json({ success: false, error: err?.message || 'Failed to delete product.' });
  }
});

// 8. Generate E-Commerce WebsiteSpec Grounded in Approved Products
app.post('/api/commerce/generate-store', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { prompt, businessType, approvedProducts, currency = 'USD', currencySymbol = '$' } = req.body;

    if (!Array.isArray(approvedProducts) || approvedProducts.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Cannot generate an e-commerce store without approved products.',
      });
    }

    const rawPrompt = prompt || 'Minimalist lifestyle and footwear store';
    const siteTitle = businessType || 'StorePilot Shop';

    // Map approved products into WebsiteSpec product line items
    const productItems = approvedProducts.map((p: StorePilotProduct, idx: number) => ({
      id: p.id || `prod-${idx + 1}`,
      name: p.storefrontTitle || p.printifyTitle || 'Curated Product',
      price: `${currencySymbol}${p.storefrontPrice?.toFixed(2) || '45.00'}`,
      category: p.category || 'Collection',
      description: p.storefrontDescription || 'Crafted with premium materials and precision.',
      imageUrl:
        p.images && p.images.length > 0
          ? p.images[0]
          : 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80',
      badge: p.badge || (idx === 0 ? 'Best Seller' : idx === 1 ? 'New Release' : 'Featured'),
      printifyBlueprintId: p.printifyBlueprintId,
      printifyPrintProviderId: p.printifyPrintProviderId,
      printifyVariantId: p.printifyVariantId,
      printifyShopProductId: p.printifyShopProductId,
    }));

    // Generate brand copy using Gemini if available
    let spec: WebsiteSpec;
    const ai = getGeminiClient();

    if (ai) {
      try {
        const systemInstruction = `You are StorePilot AI, the premier e-commerce generation engine.
A merchant has selected and approved ${approvedProducts.length} REAL print-on-demand products from the catalog.
Your mission is to generate a complete, high-converting, professional e-commerce WebsiteSpec that centers around these exact approved products.

CRITICAL CONSTRAINTS:
1. You MUST use the exact approved product titles, prices, and images provided in the user message. Do NOT invent new products.
2. Set "siteType": "ECOMMERCE".
3. Include sections: hero, features, products (with the provided products), about, testimonials, cta, contact.
4. Provide inspiring brand storytelling, benefits, and aesthetic typography/color scheme.`;

        const userPayload = `Prompt: "${rawPrompt}"
Approved Products:
${JSON.stringify(
  productItems.map((p: any) => ({
    name: p.name,
    price: p.price,
    description: p.description,
    badge: p.badge,
    imageUrl: p.imageUrl,
    printifyBlueprintId: p.printifyBlueprintId,
  })),
  null,
  2
)}`;

        const aiResponse = await callGeminiJson(ai, userPayload, systemInstruction);
        const parsed = cleanAndParseJson<WebsiteSpec>(aiResponse.text);

        // Ensure products section contains the authoritative approved items
        const prodSecIdx = parsed.sections.findIndex((s) => s.type === 'products');
        if (prodSecIdx !== -1) {
          (parsed.sections[prodSecIdx] as any).items = productItems;
          (parsed.sections[prodSecIdx] as any).currencySymbol = currencySymbol;
        } else {
          parsed.sections.push({
            type: 'products',
            id: 'products',
            title: 'Featured Collection',
            subtitle: 'Crafted with quality and attention to detail.',
            currencySymbol,
            items: productItems,
            ctaLabel: 'Add to Cart',
          });
        }

        parsed.siteType = 'ECOMMERCE';
        parsed.commerceConfig = {
          enabled: true,
          provider: 'printify',
          currency,
          currencySymbol,
          approvedProductCount: approvedProducts.length,
          approvedProducts,
        };

        spec = parsed;
      } catch (geminiErr) {
        console.warn('[GenerateStore] Gemini generation failed, using deterministic template:', geminiErr);
        spec = createDeterministicStoreSpec(rawPrompt, siteTitle, productItems, currency, currencySymbol, approvedProducts);
      }
    } else {
      spec = createDeterministicStoreSpec(rawPrompt, siteTitle, productItems, currency, currencySymbol, approvedProducts);
    }

    return res.json({ success: true, spec });
  } catch (err: any) {
    console.error('Error in /api/commerce/generate-store:', err);
    return res.status(500).json({ success: false, error: err?.message || 'Store generation failed.' });
  }
});

// Deterministic e-commerce store fallback builder
function createDeterministicStoreSpec(
  prompt: string,
  siteTitle: string,
  productItems: any[],
  currency: string,
  currencySymbol: string,
  approvedProducts: StorePilotProduct[]
): WebsiteSpec {
  const brandName = siteTitle.includes('StorePilot') ? 'Solace Goods' : siteTitle;
  return {
    siteName: brandName,
    businessName: `${brandName} Co.`,
    tagline: 'Modern Goods Built for Enduring Quality',
    businessDescription: `A premium online storefront offering curated essentials. Generated for: ${prompt}`,
    industry: 'Retail & E-commerce',
    targetAudience: 'Discerning customers seeking refined everyday essentials',
    siteType: 'ECOMMERCE',
    commerceConfig: {
      enabled: true,
      provider: 'printify',
      currency,
      currencySymbol,
      approvedProductCount: approvedProducts.length,
      approvedProducts,
    },
    theme: {
      primaryColor: '#0f172a',
      accentColor: '#3b82f6',
      backgroundColor: '#ffffff',
      textColor: '#0f172a',
      fontFamily: 'sans',
      styleMood: 'Modern Minimalist',
    },
    header: {
      brandName,
      tagline: 'Refined Everyday Essentials',
      navLinks: [
        { id: 'nav-1', label: 'Products', targetSectionId: 'products' },
        { id: 'nav-2', label: 'Why Us', targetSectionId: 'features' },
        { id: 'nav-3', label: 'Our Story', targetSectionId: 'about' },
        { id: 'nav-4', label: 'Contact', targetSectionId: 'contact' },
      ],
      ctaButton: {
        label: 'Shop Now',
        targetSectionId: 'products',
      },
    },
    sections: [
      {
        type: 'hero',
        id: 'hero',
        badge: 'New Season Collection',
        headline: 'Timeless Design Meets Daily Performance',
        subheadline: 'Explore our latest collection of premium footwear and apparel crafted for comfort and longevity.',
        primaryCta: { label: 'Explore Products', targetSectionId: 'products' },
        secondaryCta: { label: 'Our Story', targetSectionId: 'about' },
        imageUrl: productItems[0]?.imageUrl || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80',
      },
      {
        type: 'features',
        id: 'features',
        title: 'Built with Integrity',
        subtitle: 'Every piece is crafted to the highest quality standards.',
        items: [
          {
            id: 'f-1',
            title: 'Print-on-Demand Precision',
            description: 'Custom manufactured on demand using high-grade eco-friendly materials.',
            iconName: 'Sparkles',
          },
          {
            id: 'f-2',
            title: 'Fast Worldwide Dispatch',
            description: 'Reliable fulfillment partners delivering straight to your door.',
            iconName: 'Truck',
          },
          {
            id: 'f-3',
            title: '100% Satisfaction Guarantee',
            description: 'Effortless customer support and guaranteed replacement policy.',
            iconName: 'Shield',
          },
        ],
      },
      {
        type: 'products',
        id: 'products',
        title: 'Curated Essentials',
        subtitle: 'Select from our verified catalog collection.',
        currencySymbol,
        items: productItems,
        ctaLabel: 'Add to Cart',
      },
      {
        type: 'about',
        id: 'about',
        title: 'Our Purpose',
        headline: 'Designed to Outlast Trends',
        content:
          'We founded our brand on the belief that everyday essentials should be both beautiful and durable. By partnering with leading print-on-demand craftspeople, we eliminate wasteful overproduction while delivering top-tier quality directly to you.',
        highlights: [
          'Zero excess inventory or mass factory waste',
          'Premium ethically sourced materials',
          'Rigorous multi-point quality inspection',
        ],
        imageUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
      },
      {
        type: 'testimonials',
        id: 'testimonials',
        title: 'Customer Stories',
        subtitle: 'Real reviews from verified buyers across the globe.',
        items: [
          {
            id: 't-1',
            quote: 'The quality exceeded my expectations. Crisp print, rich colors, and fits like a dream.',
            author: 'Marcus Chen',
            role: 'Creative Director',
            rating: 5,
          },
          {
            id: 't-2',
            quote: 'Fast shipping and truly premium materials. This has quickly become my daily favorite.',
            author: 'Elena Rostova',
            role: 'Product Designer',
            rating: 5,
          },
        ],
      },
      {
        type: 'cta',
        id: 'cta',
        headline: 'Ready to Upgrade Your Essentials?',
        subheadline: 'Shop our curated catalog now and enjoy complimentary shipping on your first order.',
        buttonLabel: 'Browse All Products',
        targetSectionId: 'products',
      },
      {
        type: 'contact',
        id: 'contact',
        title: 'Get in Touch',
        subtitle: 'Our concierge support team is here to assist you with any questions.',
        email: 'support@storepilot.shop',
        phone: '+1 (555) 019-2834',
        address: '742 Evergreen Way, Suite 400',
        hours: 'Monday – Friday: 9am – 6pm EST',
        formEnabled: true,
      },
    ],
    footer: {
      brandName,
      copyright: `© ${new Date().getFullYear()} ${brandName}. Powered by StorePilot AI.`,
      description: 'Exceptional print-on-demand lifestyle and apparel products designed for modern life.',
    },
  };
}

// Domain Normalization & Validation Helper
function normalizeDomainInput(raw: string): { valid: boolean; normalized: string; error?: string } {
  if (!raw || typeof raw !== 'string') {
    return { valid: false, normalized: '', error: 'Domain name is required.' };
  }

  let cleaned = raw.trim().toLowerCase();

  // Strip protocol
  cleaned = cleaned.replace(/^https?:\/\//i, '');

  // Strip path, query params, hash
  cleaned = cleaned.split('/')[0].split('?')[0].split('#')[0];

  // Strip port if accidentally supplied
  cleaned = cleaned.split(':')[0];

  // Strip leading and trailing dots
  cleaned = cleaned.replace(/^\.+|\.+$/g, '');

  if (!cleaned) {
    return { valid: false, normalized: '', error: 'Domain name is required.' };
  }

  if (cleaned.length > 253) {
    return { valid: false, normalized: '', error: 'Domain name is too long (maximum 253 characters).' };
  }

  // Reject localhost and IP addresses
  if (cleaned === 'localhost' || /^(\d{1,3}\.){3}\d{1,3}$/.test(cleaned)) {
    return { valid: false, normalized: '', error: 'IP addresses and localhost cannot be used as custom domains.' };
  }

  // Reject storepilot internal domains
  if (cleaned.endsWith('.storepilot.ai') || cleaned === 'storepilot.ai' || cleaned.endsWith('.run.app')) {
    return { valid: false, normalized: '', error: 'Please enter your own external custom domain (e.g. mybrand.com).' };
  }

  // Domain syntax validation: RFC 1035 / RFC 1123 compliant hostname
  const domainRegex = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
  if (!domainRegex.test(cleaned)) {
    return {
      valid: false,
      normalized: '',
      error: 'Invalid domain syntax. Example valid domains: myfashionstore.com, www.myfashionstore.com, shop.brand.org',
    };
  }

  return { valid: true, normalized: cleaned };
}

function generateVerificationToken(): string {
  return `sp_verify_${crypto.randomBytes(16).toString('hex')}`;
}

const verifyRateLimits = new Map<string, number>();
const VERIFY_COOLDOWN_MS = 4000;

function getTargetDnsHost(req: express.Request): string {
  const host = req.get('host') || process.env.APP_HOST || 'ais-pre-x2vtss3jj66uxuw72dddrw-549021129273.europe-west1.run.app';
  return host.split(':')[0];
}

async function checkDnsTxtRecord(domain: string, expectedToken: string): Promise<{
  verified: boolean;
  recordsFound?: string[];
  error?: string;
}> {
  const host = `_storepilot.${domain}`;
  try {
    const rawRecords = await dns.promises.resolveTxt(host);
    const flattened = rawRecords.map((chunk) => chunk.join(''));
    const expectedValue = `storepilot-verification=${expectedToken}`;
    const found = flattened.some((val) => val.trim() === expectedValue);

    if (found) {
      return { verified: true, recordsFound: flattened };
    }

    return {
      verified: false,
      recordsFound: flattened,
      error: `DNS TXT record found at "${host}", but verification token did not match. Expected "${expectedValue}", found: [${flattened.join(', ')}].`,
    };
  } catch (err: any) {
    if (err.code === 'ENOTFOUND' || err.code === 'ENODATA' || err.code === 'NXDOMAIN') {
      return {
        verified: false,
        error: `DNS TXT record at "${host}" was not found yet. DNS changes may take some time to propagate across servers. Please ensure the TXT record is added at your DNS provider and check again.`,
      };
    }
    return {
      verified: false,
      error: `DNS lookup failed (${err.code || err.message}). Please try again shortly.`,
    };
  }
}

// Helper to sanitize slug
function sanitizeSlug(raw: string): string {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

const RESERVED_SLUGS = [
  'api',
  'site',
  'assets',
  'admin',
  'dashboard',
  'auth',
  'login',
  'templates',
  'settings',
  'overview',
  'favicon',
  'robots',
  'sitemap',
];

// Check Slug Availability
app.get('/api/check-slug', async (req, res) => {
  const rawSlug = String(req.query.slug || '');
  const siteId = String(req.query.siteId || '');
  const userId = String(req.query.userId || '');

  if (!rawSlug.trim()) {
    return res.status(400).json({ available: false, error: 'Slug is required.' });
  }

  const slug = sanitizeSlug(rawSlug);

  if (slug.length < 2 || slug.length > 60) {
    return res.json({
      available: false,
      error: 'Slug must be between 2 and 60 characters long.',
    });
  }

  if (RESERVED_SLUGS.includes(slug)) {
    return res.json({
      available: false,
      error: `"${slug}" is a reserved system keyword. Please choose a different slug.`,
      suggestedSlug: `${slug}-site`,
    });
  }

  const existing = await PublishedSiteStore.getBySlug(slug);
  if (!existing || existing.status === 'unpublished') {
    return res.json({ available: true, slug });
  }

  // If already owned by this user for this site
  if (existing.siteId === siteId && (!userId || existing.userId === userId)) {
    return res.json({ available: true, slug, isCurrent: true });
  }

  // Conflict: owned by another user or another website project
  let suffix = 2;
  let candidate = `${slug}-${suffix}`;
  let candidateRecord = await PublishedSiteStore.getBySlug(candidate);
  while (candidateRecord && candidateRecord.status === 'published') {
    suffix++;
    candidate = `${slug}-${suffix}`;
    candidateRecord = await PublishedSiteStore.getBySlug(candidate);
  }

  return res.json({
    available: false,
    error: `The URL slug "${slug}" is already in use by another published website.`,
    suggestedSlug: candidate,
  });
});

// Helper function for publishing a website project
async function handlePublishProject(
  userId: string,
  userEmail: string | undefined,
  siteId: string,
  rawSlug: string | undefined,
  spec: any,
  name?: string,
  description?: string,
  reqHost?: string,
  reqProtocol?: string
) {
  if (!siteId || !spec) {
    throw new Error('Missing required publication parameters (siteId, spec).');
  }

  // Verify site belongs to authenticated user
  let userSite = await WebsiteStore.getWebsiteById(siteId, userId);
  if (!userSite && spec) {
    userSite = await WebsiteStore.upsertWebsite({
      id: siteId,
      ownerId: userId,
      name: name || spec.siteName || 'My Website',
      slug: sanitizeSlug(rawSlug || name || spec.siteName || 'my-store'),
      businessType: 'General Business',
      description: description || spec.businessDescription || '',
      status: 'draft',
      pagesCount: 1,
      spec,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }
  if (!userSite) {
    const error: any = new Error('Forbidden: You do not have permission to publish this website project.');
    error.status = 403;
    throw error;
  }

  const slug = sanitizeSlug(rawSlug || name || spec.siteName || userSite.name || 'my-store');

  if (slug.length < 2 || slug.length > 60) {
    const error: any = new Error('URL slug must be between 2 and 60 alphanumeric characters and hyphens.');
    error.status = 400;
    throw error;
  }

  if (RESERVED_SLUGS.includes(slug)) {
    const error: any = new Error(`"${slug}" is a reserved system keyword. Please choose another slug.`);
    error.status = 400;
    throw error;
  }

  // Verify ownership and check conflicts
  const existing = await PublishedSiteStore.getBySlug(slug);
  if (existing && existing.status === 'published') {
    if (existing.userId !== userId) {
      const error: any = new Error(`URL slug "${slug}" is already claimed by another user's website. Please choose another slug.`);
      error.status = 409;
      throw error;
    }
    if (existing.siteId !== siteId) {
      const error: any = new Error(`URL slug "${slug}" is already used by another one of your websites. Please choose a unique slug.`);
      error.status = 409;
      throw error;
    }
  }

  // If this website was previously published with a different slug, clean up old slug
  const allExistingSites = await PublishedSiteStore.getAllPublishedSites();
  for (const rec of allExistingSites) {
    if (rec.siteId === siteId && rec.userId === userId && rec.slug !== slug) {
      await PublishedSiteStore.delete(rec.slug);
    }
  }

  const version = (existing?.publishedVersion || 0) + 1;
  const record: PublishedSiteRecord = {
    slug,
    siteId,
    userId,
    userEmail: userEmail || undefined,
    name: name || spec.siteName || spec.businessName || userSite.name || 'Published Site',
    description: description || spec.businessDescription || spec.tagline || userSite.description || '',
    publishedSpec: JSON.parse(JSON.stringify(spec)), // Deep clone pristine snapshot!
    publishedAt: new Date().toISOString(),
    publishedVersion: version,
    status: 'published',
  };

  await PublishedSiteStore.save(record);

  // Update website store status
  await WebsiteStore.updateWebsite(siteId, userId, {
    status: 'published',
    publishStatus: 'published',
    publishedSlug: slug,
    publishedAt: record.publishedAt,
    publishedSpec: record.publishedSpec,
    publishedVersion: record.publishedVersion,
  });

  const protocol = reqProtocol || 'http';
  const host = reqHost || `localhost:${port}`;
  const publicUrl = `${protocol}://${host}/site/${slug}`;

  return {
    success: true,
    slug,
    publicUrl,
    publishedAt: record.publishedAt,
    publishedVersion: record.publishedVersion,
  };
}

// Publish Website Endpoint (Authenticated, Plan Gated to Professional/Agency/Dev)
app.post('/api/publish', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const userEmail = req.user!.email;
    const { siteId, slug: rawSlug, spec, name, description } = req.body;
    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
    const host = req.get('host') || `localhost:${port}`;

    const result = await handlePublishProject(
      userId,
      userEmail,
      siteId,
      rawSlug,
      spec,
      name,
      description,
      host,
      protocol
    );

    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/publish:', err);
    const status = err.status || 500;
    return res.status(status).json({
      success: false,
      error: err?.message || 'Failed to publish website.',
    });
  }
});

// RESTful Website Publish Endpoint by ID (Gated to Professional, Agency & Developer)
app.post('/api/websites/:id/publish', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const userEmail = req.user!.email;
    const { id } = req.params;
    const { slug: rawSlug, spec: bodySpec, name, description } = req.body;

    const userSite = await WebsiteStore.getWebsiteById(id, userId);
    if (!userSite) {
      return res.status(404).json({ success: false, error: 'Website not found or access denied.' });
    }

    const specToUse = bodySpec || userSite.spec;
    if (!specToUse) {
      return res.status(400).json({ success: false, error: 'Cannot publish website without a spec.' });
    }

    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
    const host = req.get('host') || `localhost:${port}`;

    const result = await handlePublishProject(
      userId,
      userEmail,
      id,
      rawSlug || userSite.publishedSlug || userSite.slug,
      specToUse,
      name || userSite.name,
      description || userSite.description,
      host,
      protocol
    );

    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/websites/:id/publish:', err);
    const status = err.status || 500;
    return res.status(status).json({
      success: false,
      error: err?.message || 'Failed to publish website.',
    });
  }
});

// RESTful Website Republish Endpoint by ID (Gated to Professional, Agency & Developer)
app.post('/api/websites/:id/republish', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const userEmail = req.user!.email;
    const { id } = req.params;
    const { slug: rawSlug, spec: bodySpec, name, description } = req.body;

    const userSite = await WebsiteStore.getWebsiteById(id, userId);
    if (!userSite) {
      return res.status(404).json({ success: false, error: 'Website not found or access denied.' });
    }

    const specToUse = bodySpec || userSite.spec;
    if (!specToUse) {
      return res.status(400).json({ success: false, error: 'Cannot republish website without a spec.' });
    }

    const protocol = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
    const host = req.get('host') || `localhost:${port}`;

    const result = await handlePublishProject(
      userId,
      userEmail,
      id,
      rawSlug || userSite.publishedSlug || userSite.slug,
      specToUse,
      name || userSite.name,
      description || userSite.description,
      host,
      protocol
    );

    return res.json(result);
  } catch (err: any) {
    console.error('Error in /api/websites/:id/republish:', err);
    const status = err.status || 500;
    return res.status(status).json({
      success: false,
      error: err?.message || 'Failed to republish website.',
    });
  }
});

// Unpublish Website Endpoint (Authenticated & Owner Verified)
app.post('/api/unpublish', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { siteId, slug } = req.body;

    if (!siteId) {
      return res.status(400).json({
        success: false,
        error: 'Missing siteId for unpublish request.',
      });
    }

    let targetRecord: PublishedSiteRecord | null | undefined;
    if (slug) {
      targetRecord = await PublishedSiteStore.getBySlug(sanitizeSlug(slug));
    }
    if (!targetRecord) {
      targetRecord = await PublishedSiteStore.getBySiteId(siteId);
    }

    if (!targetRecord) {
      return res.status(404).json({
        success: false,
        error: 'No active published website found for this project.',
      });
    }

    // Verify ownership! User A cannot unpublish User B's website
    if (targetRecord.userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized: You do not have permission to unpublish this website.',
      });
    }

    // Remove from active public map and persist in Firestore
    await PublishedSiteStore.delete(targetRecord.slug);

    // Update website store status
    await WebsiteStore.updateWebsite(siteId, userId, {
      status: 'draft',
      publishStatus: 'draft',
      publishedSlug: undefined,
      publishedAt: undefined,
      publishedSpec: undefined,
      publishedVersion: undefined,
    });

    return res.json({
      success: true,
      message: `Website "${targetRecord.name}" successfully unpublished.`,
    });
  } catch (err: any) {
    console.error('Error in /api/unpublish:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to unpublish website.',
    });
  }
});

// Public Website Lookup Endpoint (No Auth Required)
app.get('/api/published/:slug', async (req, res) => {
  const slug = sanitizeSlug(req.params.slug);
  const record = await PublishedSiteStore.getBySlug(slug);

  if (!record || record.status !== 'published') {
    return res.status(404).json({
      success: false,
      error: `Website with slug "${slug}" not found or has been unpublished.`,
    });
  }

  // Return public website snapshot only - no secrets or user accounts exposed!
  return res.json({
    success: true,
    site: {
      name: record.name,
      slug: record.slug,
      description: record.description,
      publishedAt: record.publishedAt,
      publishedVersion: record.publishedVersion,
      spec: record.publishedSpec,
    },
  });
});

// ==========================================
// Phase 4C: Public Sitemaps & Search Engine Discovery
// ==========================================

// Public XML Sitemap for Published Shops
app.get('/sitemap.xml', async (req, res) => {
  try {
    const origin = getStorePilotPrimaryOrigin(
      `${req.headers['x-forwarded-proto'] || req.protocol}://${req.get('host')}`
    );
    const activeSites = await PublishedSiteStore.getAllPublishedSites();
    const xml = generateSitemapXml(activeSites, origin);
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=3600, s-maxage=3600');
    return res.status(200).send(xml);
  } catch (err: any) {
    console.error('Error generating sitemap.xml:', err);
    return res.status(500).send('Error generating sitemap');
  }
});

// Public Robots.txt
app.get('/robots.txt', (req, res) => {
  try {
    const origin = getStorePilotPrimaryOrigin(
      `${req.headers['x-forwarded-proto'] || req.protocol}://${req.get('host')}`
    );
    const robots = generateRobotsTxt(origin);
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    return res.status(200).send(robots);
  } catch (err: any) {
    console.error('Error generating robots.txt:', err);
    return res.status(500).send('Error generating robots.txt');
  }
});

// ==========================================
// Phase 4B: Custom Domain API Endpoints
// ==========================================

// 1. Get Domain Config for Website
app.get(['/api/domains/website/:websiteId', '/api/domains/config/:websiteId'], async (req, res) => {
  const websiteId = String(req.params.websiteId || '');
  if (!websiteId) {
    return res.status(400).json({ success: false, error: 'websiteId is required.' });
  }

  try {
    const config = await CustomDomainStore.getDomainByWebsiteId(websiteId);
    return res.json({ success: true, config });
  } catch (err: any) {
    console.error('Error fetching domain config:', err);
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 2. Connect Custom Domain (Gated to Professional & Agency subscribers)
app.post('/api/domains/connect', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, domain: rawDomain } = req.body;

    if (!websiteId || !userId || !rawDomain) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters: websiteId, userId, and domain are required.',
      });
    }

    const { valid, normalized, error } = normalizeDomainInput(rawDomain);
    if (!valid || !normalized) {
      return res.status(400).json({
        success: false,
        error: error || 'Invalid domain format.',
      });
    }

    // Generate cryptographically secure verification token
    const verificationToken = generateVerificationToken();
    const targetHost = getTargetDnsHost(req);

    // Prepare DNS instructions
    const isWwwOrSubdomain = normalized.split('.').length > 2;
    const subdomainPrefix = isWwwOrSubdomain ? normalized.split('.')[0] : 'www';

    const domainConfig: CustomDomainConfig = {
      id: `cd_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
      userId,
      websiteId,
      domain: rawDomain.trim().toLowerCase(),
      normalizedDomain: normalized,
      verificationToken,
      verificationStatus: 'PENDING_VERIFICATION',
      connectionStatus: 'PENDING_VERIFICATION',
      createdAt: new Date().toISOString(),
      sslStatus: 'pending',
      primaryDomain: true,
      dnsRecords: {
        txt: {
          type: 'TXT',
          host: '_storepilot',
          value: `storepilot-verification=${verificationToken}`,
          description: `Add TXT record at host "_storepilot" to verify domain ownership.`,
        },
        cname: {
          type: 'CNAME',
          host: subdomainPrefix,
          value: targetHost,
          description: `Point CNAME for ${subdomainPrefix}.${normalized.replace(/^[^.]+\./, '')} to StorePilot server target "${targetHost}".`,
        },
        apex: {
          type: 'ALIAS',
          host: '@',
          value: targetHost,
          description: `Point root domain via ALIAS/ANAME record or CNAME flattening to "${targetHost}".`,
        },
      },
      requiresHostMapping: true,
    };

    const storeResult = await CustomDomainStore.connectDomain(domainConfig);

    if (!storeResult.success) {
      return res.status(storeResult.statusCode || 400).json({
        success: false,
        error: storeResult.error,
      });
    }

    return res.json({
      success: true,
      config: storeResult.data,
      message: 'Custom domain registered. Please configure your DNS records to verify ownership.',
    });
  } catch (err: any) {
    console.error('Error connecting custom domain:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected server error occurred while connecting the custom domain.',
    });
  }
});

// 3. Verify Custom Domain Ownership via Real DNS Query (Gated to Professional & Agency)
app.post('/api/domains/verify', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, domain: rawDomain } = req.body;

    if (!websiteId || !userId || !rawDomain) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters: websiteId, userId, and domain.',
      });
    }

    const { valid, normalized } = normalizeDomainInput(rawDomain);
    if (!valid || !normalized) {
      return res.status(400).json({ success: false, error: 'Invalid domain name.' });
    }

    const record = await CustomDomainStore.getDomain(normalized);
    if (!record || record.websiteId !== websiteId || record.userId !== userId) {
      return res.status(404).json({
        success: false,
        error: 'Custom domain configuration not found for this website.',
      });
    }

    // Rate Limiting Protection (4 seconds cooldown per domain)
    const now = Date.now();
    const lastAttempt = verifyRateLimits.get(normalized) || 0;
    if (now - lastAttempt < VERIFY_COOLDOWN_MS) {
      const waitSeconds = Math.ceil((VERIFY_COOLDOWN_MS - (now - lastAttempt)) / 1000);
      return res.status(429).json({
        success: false,
        error: `Please wait ${waitSeconds} second${waitSeconds > 1 ? 's' : ''} before checking DNS verification again.`,
      });
    }
    verifyRateLimits.set(normalized, now);

    // Perform actual DNS lookup
    const dnsResult = await checkDnsTxtRecord(normalized, record.verificationToken);

    record.lastCheckedAt = new Date().toISOString();

    if (dnsResult.verified) {
      record.verificationStatus = 'VERIFIED';
      record.verifiedAt = new Date().toISOString();
      record.connectionStatus = 'VERIFIED';
      record.sslStatus = 'pending'; // Realistic infrastructure state
      record.errorMessage = undefined;
      await CustomDomainStore.updateDomain(record);

      return res.json({
        success: true,
        verified: true,
        config: record,
        message: 'Domain ownership verified successfully! DNS TXT record confirmed.',
      });
    } else {
      record.verificationStatus = 'FAILED';
      record.errorMessage = dnsResult.error;
      await CustomDomainStore.updateDomain(record);

      return res.json({
        success: false,
        verified: false,
        config: record,
        error: dnsResult.error,
      });
    }
  } catch (err: any) {
    console.error('Error verifying custom domain:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected error occurred during DNS verification.',
    });
  }
});

// 4. Test Simulator Verification (Disabled in production environments)
app.post('/api/domains/test-simulate-verify', async (req, res) => {
  if (isProduction) {
    return res.status(403).json({
      success: false,
      error: 'Simulation verification is strictly disabled in production. Domain ownership must be verified via real DNS TXT records.',
    });
  }

  try {
    const { websiteId, domain: rawDomain, userId, activate } = req.body;
    const { valid, normalized } = normalizeDomainInput(rawDomain);
    if (!valid || !normalized) {
      return res.status(400).json({ success: false, error: 'Invalid domain name.' });
    }

    const record = await CustomDomainStore.getDomain(normalized);
    if (!record || record.websiteId !== websiteId || record.userId !== userId) {
      return res.status(404).json({ success: false, error: 'Domain configuration not found.' });
    }

    record.verificationStatus = 'VERIFIED';
    record.verifiedAt = new Date().toISOString();
    record.lastCheckedAt = new Date().toISOString();
    record.connectionStatus = activate ? 'ACTIVE' : 'VERIFIED';
    record.sslStatus = activate ? 'active' : 'pending';
    record.errorMessage = undefined;

    await CustomDomainStore.updateDomain(record);

    return res.json({
      success: true,
      verified: true,
      config: record,
      message: `Domain ${normalized} simulated verification successful (${record.connectionStatus}).`,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 5. Set Primary Domain (Gated to Professional & Agency)
app.post('/api/domains/set-primary', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, domain: rawDomain, isPrimary } = req.body;
    const { valid, normalized } = normalizeDomainInput(rawDomain);
    if (!valid || !normalized) {
      return res.status(400).json({ success: false, error: 'Invalid domain.' });
    }

    const record = await CustomDomainStore.getDomain(normalized);
    if (!record || record.websiteId !== websiteId || record.userId !== userId) {
      return res.status(404).json({ success: false, error: 'Domain not found or unauthorized.' });
    }

    record.primaryDomain = Boolean(isPrimary);
    await CustomDomainStore.updateDomain(record);

    return res.json({ success: true, config: record });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 6. Disconnect Domain (Gated to Professional & Agency)
app.post('/api/domains/disconnect', requireAuth, requirePlan('professional'), async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { websiteId, domain: rawDomain } = req.body;
    const { valid, normalized } = normalizeDomainInput(rawDomain);
    if (!valid || !normalized) {
      return res.status(400).json({ success: false, error: 'Invalid domain.' });
    }

    const result = await CustomDomainStore.disconnectDomain(normalized, websiteId, userId);
    if (!result.success) {
      return res.status(result.statusCode || 400).json({
        success: false,
        error: result.error,
      });
    }

    return res.json({
      success: true,
      message: `Domain "${normalized}" has been disconnected. Your StorePilot URL remains fully active.`,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// 7. Domain Lookup Endpoint (Used by client routing to resolve custom domain)
app.get('/api/domains/lookup/:hostname', async (req, res) => {
  const rawHostname = String(req.params.hostname || '').toLowerCase().trim();
  const hostname = rawHostname.split(':')[0]; // strip port

  try {
    const config = await CustomDomainStore.lookupDomain(hostname);

    if (!config || (config.verificationStatus !== 'VERIFIED' && config.connectionStatus !== 'ACTIVE')) {
      return res.status(404).json({
        success: false,
        error: `Domain "${hostname}" is not connected or has not been verified yet.`,
      });
    }

    // Find published site record for this website
    const publishedSite = await PublishedSiteStore.getBySiteId(config.websiteId);

    if (!publishedSite) {
      return res.json({
        success: true,
        verified: true,
        config,
        site: null,
        error: 'This domain is verified, but the associated StorePilot website has not been published yet.',
      });
    }

    return res.json({
      success: true,
      verified: true,
      config,
      site: {
        name: publishedSite.name,
        slug: publishedSite.slug,
        description: publishedSite.description,
        publishedAt: publishedSite.publishedAt,
        publishedVersion: publishedSite.publishedVersion,
        spec: publishedSite.publishedSpec,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message });
  }
});

// Production / Vercel public shop SEO handler and SPA fallback
function setupProductionRoutes(expressApp: express.Express) {
  expressApp.get('/site/:slug', async (req, res) => {
    const slug = sanitizeSlug(req.params.slug);
    const record = await PublishedSiteStore.getBySlug(slug);
    const distIndexPath = path.resolve('dist/index.html');
    const rootIndexPath = path.resolve('index.html');
    const indexPath = fs.existsSync(distIndexPath)
      ? distIndexPath
      : fs.existsSync(rootIndexPath)
      ? rootIndexPath
      : null;

    const rawHtml = indexPath
      ? fs.readFileSync(indexPath, 'utf-8')
      : '<!DOCTYPE html><html><head><meta charset="utf-8"><title>StorePilot</title></head><body><div id="root"></div></body></html>';
    const origin = getStorePilotPrimaryOrigin(
      `${req.headers['x-forwarded-proto'] || req.protocol}://${req.get('host')}`
    );

    if (!record || record.status !== 'published') {
      const notFoundHtml = injectSeoIntoHtml(rawHtml, null, origin, true);
      return res.status(404).send(notFoundHtml);
    }

    const seoHtml = injectSeoIntoHtml(rawHtml, record, origin, false);
    return res.status(200).send(seoHtml);
  });

  expressApp.get('*', async (req, res) => {
    const distIndexPath = path.resolve('dist/index.html');
    const rootIndexPath = path.resolve('index.html');
    const indexPath = fs.existsSync(distIndexPath)
      ? distIndexPath
      : fs.existsSync(rootIndexPath)
      ? rootIndexPath
      : null;

    if (!indexPath || !fs.existsSync(indexPath)) {
      return res.status(404).send('Not Found');
    }

    // Check if request is coming from a custom domain
    const rawHost = req.get('host') || '';
    const reqHost = rawHost.split(':')[0].toLowerCase();
    const isInternalHost =
      reqHost === 'localhost' ||
      reqHost === '127.0.0.1' ||
      reqHost.endsWith('.run.app') ||
      reqHost.endsWith('.storepilot.ai') ||
      reqHost.endsWith('.vercel.app');

    let customDomainRecord: CustomDomainConfig | null = null;
    if (!isInternalHost) {
      try {
        customDomainRecord = await CustomDomainStore.lookupDomain(reqHost);
      } catch {
        customDomainRecord = null;
      }
    }

    if (
      customDomainRecord &&
      (customDomainRecord.verificationStatus === 'VERIFIED' ||
        customDomainRecord.connectionStatus === 'ACTIVE')
    ) {
      const publishedSite = await PublishedSiteStore.getBySiteId(customDomainRecord.websiteId);

      if (publishedSite && fs.existsSync(indexPath)) {
        const rawHtml = fs.readFileSync(indexPath, 'utf-8');
        const customOrigin = `https://${customDomainRecord.domain}`;
        const seoHtml = injectSeoIntoHtml(rawHtml, publishedSite, customOrigin, false);
        return res.status(200).send(seoHtml);
      }
    }

    res.sendFile(indexPath);
  });
}

// Setup dev middleware or production static files
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });

    // Public Shop SEO Handler in Development Mode
    app.get('/site/:slug', async (req, res, next) => {
      try {
        const slug = sanitizeSlug(req.params.slug);
        const record = await PublishedSiteStore.getBySlug(slug);
        const indexPath = path.resolve('index.html');
        if (!fs.existsSync(indexPath)) return next();

        const rawHtml = fs.readFileSync(indexPath, 'utf-8');
        const origin = getStorePilotPrimaryOrigin(
          `${req.headers['x-forwarded-proto'] || req.protocol}://${req.get('host')}`
        );

        if (!record || record.status !== 'published') {
          const notFoundHtml = injectSeoIntoHtml(rawHtml, null, origin, true);
          const transformed = await vite.transformIndexHtml(req.originalUrl, notFoundHtml);
          return res.status(404).send(transformed);
        }

        const seoHtml = injectSeoIntoHtml(rawHtml, record, origin, false);
        const transformed = await vite.transformIndexHtml(req.originalUrl, seoHtml);
        return res.status(200).send(transformed);
      } catch (err) {
        next(err);
      }
    });

    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    setupProductionRoutes(app);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`StorePilot AI server running on http://0.0.0.0:${port}`);
  });
}

// In local / standard server environments, launch the HTTP listener.
// In Vercel serverless environments (process.env.VERCEL is set), test runners, or module imports, export the Express app directly.
const isDirectRun = Boolean(
  process.argv[1] && (process.argv[1].endsWith('server.ts') || process.argv[1].endsWith('server.js'))
);

if (!process.env.VERCEL && process.env.NODE_ENV !== 'test' && isDirectRun) {
  startServer().catch((err) => {
    console.error('Failed to start StorePilot server:', err);
    process.exit(1);
  });
} else {
  setupProductionRoutes(app);
}

export default app;
export { app, startServer };
